package com.mahendi.muhasabah;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Daily score (0–100), XP, levels, streaks and badges. */
public final class Score {
    public static final int[] LEVEL_XP = {0, 300, 800, 1600, 3000, 5000, 8000, 12000, 17000, 24000, 33000};
    public static final String[] LEVEL_NAMES = {"Beginner", "Seeker", "Learner", "Striver", "Steadfast",
            "Disciplined", "Mujahid-e-Nafs", "Muhsin", "Champion", "Legend", "Sabiqun"};
    public static final int BETTER_DAY_BONUS = 20;

    public static class Day {
        public int base, penalty, score, done, total;
    }

    /** Task value including a running timer (today only). */
    public static double liveValue(Store s, Task t, String date) {
        double v = s.value(date, t);
        if (t.type == Task.MINUTES && date.equals(Store.today())) {
            long st = s.timerStart(t.id);
            if (st > 0) v += (System.currentTimeMillis() - st) / 60000.0;
        }
        return v;
    }

    public static Day compute(Store s, String date) {
        Day d = new Day();
        List<Task> tasks = s.tasksOn(date);
        double sumW = 0, got = 0;
        for (Task t : tasks) {
            double f = t.frac(liveValue(s, t, date));
            sumW += t.weight();
            got += t.weight() * f;
            d.total++;
            if (f >= 0.999) d.done++;
        }
        d.base = sumW == 0 ? 0 : (int) Math.round(got / sumW * 100);
        d.penalty = penalty(s, s.overMinutes(date)) + extraPenalty(s, date);
        d.penalty = Math.min(Cfg.get(s, "pen_total_cap"), d.penalty);
        d.score = Math.max(0, d.base - d.penalty);
        return d;
    }

    /** 1 point per 3 minutes over your limits, max 25. */
    public static int penalty(Store s, int overMinutes) {
        return Math.min(Cfg.get(s, "pen_tp_cap"), overMinutes / Math.max(1, Cfg.get(s, "pen_tp_per")));
    }

    public static int goodDay(Store s) {
        return Cfg.get(s, "better_thr");
    }

    /** Reels over the daily limit (1 pt each, max 10) and na-mahram glances (2 pts each, max 12). */
    public static int extraPenalty(Store s, String date) {
        int reelsOver = Math.max(0, s.reels(date) - s.reelsLimit());
        int nm = s.namahram(date);
        return Math.min(Cfg.get(s, "pen_reel_cap"), reelsOver * Cfg.get(s, "pen_reel_each"))
                + Math.min(Cfg.get(s, "pen_nm_cap"), nm * Cfg.get(s, "pen_nm_each"));
    }

    public static int dayScore(Store s, String date) {
        String today = Store.today();
        if (!date.equals(today) && s.p.contains("final_" + date)) return s.i("score_" + date, 0);
        if (!date.equals(today) && !s.p.contains("day_" + date) && !s.p.contains("use_" + date)) {
            return s.i("score_" + date, 0);
        }
        int sc = compute(s, date).score;
        s.put("score_" + date, sc);
        if (!date.equals(today)) s.put("final_" + date, true);
        return sc;
    }

    public static boolean hasData(Store s, String date) {
        return s.p.contains("day_" + date);
    }

    public static boolean betterDay(Store s, int offset) {
        String d = Store.date(offset);
        if (!hasData(s, d)) return false;
        int today = dayScore(s, d);
        if (today <= 0) return false;
        return today > dayScore(s, Store.date(offset - 1)) || today >= goodDay(s);
    }

    public static int streak(Store s) {
        int n = 0;
        String br = s.s(Lock.K_STREAK_BREAK, ""); // an emergency unlock breaks the streak on that day
        for (int k = -1; k > -400; k--) {
            if (br.length() > 0 && Store.date(k).compareTo(br) <= 0) break;
            if (betterDay(s, k)) n++;
            else break;
        }
        if (!Store.today().equals(br) && betterDay(s, 0)) n++;
        if (n > s.i("best_streak", 0)) s.put("best_streak", n);
        return n;
    }

    public static int betterDays(Store s) {
        int n = 0;
        for (int k = 0; k > -400; k--) {
            String d = Store.date(k);
            if (!hasData(s, d) && k < -60) break;
            if (betterDay(s, k)) n++;
        }
        return n;
    }

    public static int xp(Store s) {
        int sum = 0;
        String today = Store.today();
        for (Map.Entry<String, ?> e : s.p.getAll().entrySet()) {
            String k = e.getKey();
            if (k.startsWith("score_") && !k.equals("score_" + today) && e.getValue() instanceof Integer) {
                sum += (Integer) e.getValue();
            }
        }
        sum += compute(s, today).score;
        sum += betterDays(s) * Cfg.get(s, "better_bonus");
        sum -= s.i(Lock.K_XP_PEN, 0);
        return Math.max(0, sum);
    }

    public static int level(int xp) {
        int l = 0;
        for (int k = 0; k < LEVEL_XP.length; k++) if (xp >= LEVEL_XP[k]) l = k;
        return l;
    }

    public static float levelProgress(int xp) {
        int l = level(xp);
        if (l >= LEVEL_XP.length - 1) return 1f;
        return (xp - LEVEL_XP[l]) / (float) (LEVEL_XP[l + 1] - LEVEL_XP[l]);
    }

    public static class Badge {
        public String emoji, name, desc;
        public boolean earned;

        Badge(String e, String n, String d, boolean got) {
            emoji = e;
            name = n;
            desc = d;
            earned = got;
        }
    }

    private static int countDays(Store s, String taskId, int lookback) {
        int n = 0;
        for (Task t : s.tasks()) {
            if (!t.id.equals(taskId)) continue;
            for (int k = 0; k > -lookback; k--) if (t.frac(s.value(Store.date(k), t)) >= 0.999) n++;
        }
        return n;
    }

    private static int maxRun(Store s, String taskId) {
        int best = 0, run = 0;
        Task task = null;
        for (Task t : s.tasks()) if (t.id.equals(taskId)) task = t;
        if (task == null) return 0;
        for (int k = -120; k <= 0; k++) {
            if (task.frac(s.value(Store.date(k), task)) >= 0.999) {
                run++;
                best = Math.max(best, run);
            } else run = 0;
        }
        return best;
    }

    public static List<Badge> badges(Store s) {
        List<Badge> l = new ArrayList<Badge>();
        int best = Math.max(s.i("best_streak", 0), streak(s));
        int better = betterDays(s);
        boolean perfect = false, detox = false;
        int detoxDays = 0, anyDone = 0;
        for (int k = 0; k > -120; k--) {
            String d = Store.date(k);
            if (!hasData(s, d)) continue;
            Day day = k == 0 ? compute(s, d) : null;
            int sc = dayScore(s, d);
            if (sc >= 100 || (day != null && day.base >= 100)) perfect = true;
            if (s.p.contains("use_" + d) && s.overMinutes(d) == 0) detoxDays++;
            anyDone++;
        }
        detox = detoxDays >= 7;
        l.add(new Badge("🌱", "First Step", "Track your first day", anyDone > 0));
        l.add(new Badge("✨", "Better Day", "Beat yesterday once", better >= 1));
        l.add(new Badge("🔥", "On Fire", "3-day streak", best >= 3));
        l.add(new Badge("⚡", "Unstoppable", "7-day streak", best >= 7));
        l.add(new Badge("👑", "Istiqamah", "30-day streak", best >= 30));
        l.add(new Badge("🌅", "Fajr Warrior", "Fajr on time 7 days in a row", maxRun(s, "fajr") >= 7));
        l.add(new Badge("📖", "Quran Companion", "Hit Quran goal 7 days in a row", maxRun(s, "quran") >= 7));
        l.add(new Badge("📚", "Bookworm", "Hit reading goal 10 days", countDays(s, "read", 120) >= 10));
        l.add(new Badge("📵", "Digital Detox", "Stay within app limits 7 days", detox));
        l.add(new Badge("💯", "Perfect Day", "Score 100", perfect));
        l.add(new Badge("🏆", "10 Better Days", "Beat yesterday 10 times", better >= 10));
        l.add(new Badge("🕌", "Namazi", "All 5 namaz for 7 days in a row", maxRun(s, "namaz") >= 7));
        return l;
    }
}
