package com.mahendi.muhasabah;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.List;

/** Reminder editor dialog and the "Reminders" box on the Today screen. */
public final class ReminderUi {

    public static void edit(final Activity a, Reminders.R existing, final Runnable done) {
        final boolean isNew = existing == null;
        final Reminders.R r = isNew ? Reminders.newDefault(a) : existing;
        LinearLayout body = Ui.col(a);

        body.addView(label(a, Lang.pick("WHAT SHOULD I REMIND YOU?", "શું યાદ કરાવું?")));
        final EditText title = Ui.input(a, Lang.pick("e.g. Recite Ziyarat Ashura", "દા.ત. ઝિયારતે આશૂરા પઢો"), r.title, false);
        body.addView(title);

        body.addView(label(a, Lang.pick("TIME", "સમય")));
        final int[] time = {r.time};
        final TextView tv = Ui.ghost(a, Ui.clock(r.time), Ui.GOLD);
        body.addView(tv, Ui.lp(Ui.MATCH, Ui.WRAP));
        tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new TimePickerDialog(a, android.R.style.Theme_DeviceDefault_Dialog_Alert, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int h, int m) {
                        time[0] = h * 60 + m;
                        tv.setText(Ui.clock(time[0]));
                    }
                }, time[0] / 60, time[0] % 60, false).show();
            }
        });

        body.addView(label(a, Lang.pick("DAYS", "દિવસ")));
        final int[] days = {r.days};
        final LinearLayout dr = Ui.row(a);
        final String[] dn = Lang.dayInitials();
        final Runnable[] paint = new Runnable[1];
        paint[0] = new Runnable() {
            @Override
            public void run() {
                for (int k = 0; k < 7; k++) {
                    TextView d = (TextView) dr.getChildAt(k);
                    boolean on = (days[0] & (1 << k)) != 0;
                    d.setBackground(on ? Ui.circle(Ui.GOLD) : Ui.roundStroke(Ui.CARD2, 50, Ui.STROKE, 1));
                    d.setTextColor(on ? 0xFF1A1205 : Ui.SUB);
                }
            }
        };
        for (int k = 0; k < 7; k++) {
            final int bit = k;
            TextView d = Ui.text(a, dn[k], 13, Ui.SUB, true);
            d.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(Ui.dp(36), Ui.dp(36));
            p.setMargins(0, 0, Ui.dp(5), 0);
            dr.addView(d, p);
            d.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    days[0] ^= (1 << bit);
                    paint[0].run();
                }
            });
        }
        paint[0].run();
        body.addView(dr);

        body.addView(label(a, Lang.pick("REMIND HOW MANY TIMES (until I tap Done)", "કેટલી વાર યાદ કરાવું ('થઈ ગયું' સુધી)")));
        final int[] rep = {Math.max(1, Math.min(6, r.repeat)) - 1};
        body.addView(Dialogs.selector(a, new String[]{"1×", "2×", "3×", "4×", "5×", "6×"}, rep, null));
        body.addView(label(a, Lang.pick("GAP BETWEEN REMINDERS", "બે રિમાઇન્ડર વચ્ચેનો સમય")));
        final int[] gaps = {5, 10, 15, 20, 30, 60};
        int gi = 1;
        for (int k = 0; k < gaps.length; k++) if (gaps[k] == r.interval) gi = k;
        final int[] gap = {gi};
        String[] gl = new String[gaps.length];
        for (int k = 0; k < gaps.length; k++) gl[k] = gaps[k] + Lang.pick(" min", " મિ");
        body.addView(Dialogs.selector(a, gl, gap, null));

        body.addView(label(a, Lang.pick("LINK TO A TASK (Done also completes it)", "કામ સાથે જોડો ('થઈ ગયું' કામ પણ પૂરું કરશે)")));
        final List<Task> tasks = Store.get(a).tasks();
        String[] tn = new String[tasks.size() + 1];
        tn[0] = Lang.pick("None", "કોઈ નહીં");
        int ti = 0;
        for (int k = 0; k < tasks.size(); k++) {
            tn[k + 1] = tasks.get(k).emoji + " " + tasks.get(k).display();
            if (tasks.get(k).id.equals(r.taskId)) ti = k + 1;
        }
        final int[] task = {ti};
        body.addView(Dialogs.selector(a, tn, task, null));

        body.addView(Ui.space(a, 18));
        TextView save = Ui.button(a, isNew ? Lang.pick("Add reminder", "રિમાઇન્ડર ઉમેરો") : Lang.pick("Save", "સેવ"), Ui.GOLD, Ui.GOLD_D, 0xFF1A1205);
        body.addView(save, Ui.lp(Ui.MATCH, Ui.WRAP));
        final AlertDialog d = Dialogs.sheet(a, isNew ? Lang.pick("New reminder", "નવું રિમાઇન્ડર") : Lang.pick("Edit reminder", "રિમાઇન્ડર બદલો"), body);
        if (!isNew) {
            body.addView(Ui.space(a, 10));
            TextView del = Ui.ghost(a, Lang.pick("Delete reminder", "રિમાઇન્ડર કાઢી નાખો"), Ui.RED);
            body.addView(del, Ui.lp(Ui.MATCH, Ui.WRAP));
            del.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Reminders.delete(a, r.id);
                    d.dismiss();
                    if (done != null) done.run();
                }
            });
        }
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String tt = title.getText().toString().trim();
                if (task[0] > 0 && tt.length() == 0) tt = tasks.get(task[0] - 1).emoji + " " + tasks.get(task[0] - 1).display();
                if (tt.length() == 0) {
                    Toast.makeText(a, Lang.pick("Write what to remind", "શું યાદ કરાવવું તે લખો"), Toast.LENGTH_SHORT).show();
                    return;
                }
                r.title = tt;
                r.time = time[0];
                r.days = days[0];
                r.repeat = rep[0] + 1;
                r.interval = gaps[gap[0]];
                r.taskId = task[0] > 0 ? tasks.get(task[0] - 1).id : "";
                r.active = true;
                Reminders.upsert(a, r);
                d.dismiss();
                if (done != null) done.run();
            }
        });
        d.show();
    }

    private static TextView label(Activity a, String s) {
        TextView t = Ui.text(a, s, 12, Ui.SUB, true);
        t.setPadding(0, Ui.dp(14), 0, Ui.dp(6));
        return t;
    }

    /** The Reminders box on Today. */
    public static View box(final Activity a, final Runnable refresh) {
        LinearLayout c = Ui.card(a);
        LinearLayout h = Ui.row(a);
        h.addView(Ui.text(a, Lang.pick("⏰  Reminders", "⏰  રિમાઇન્ડર"), 15, Ui.TEXT, true), Ui.weight(1));
        TextView add = Ui.pill(a, Lang.t("add"), Ui.alpha(Ui.GOLD, 0.16f), Ui.GOLD);
        add.setPadding(Ui.dp(12), Ui.dp(6), Ui.dp(12), Ui.dp(6));
        Ui.press(add);
        h.addView(add);
        c.addView(h);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edit(a, null, refresh);
            }
        });
        List<Reminders.R> all = Reminders.all(a);
        java.util.Calendar cal = java.util.Calendar.getInstance();
        int shown = 0;
        for (final Reminders.R r : all) {
            if (!r.active || !r.onDay(cal)) continue;
            shown++;
            boolean done = Reminders.doneToday(a, r);
            int fired = Reminders.firedToday(a, r);
            LinearLayout row = Ui.row(a);
            row.setPadding(0, Ui.dp(10), 0, Ui.dp(4));
            TextView tick = Ui.text(a, done ? "✓" : "", 15, 0xFFFFFFFF, true);
            tick.setGravity(Gravity.CENTER);
            tick.setBackground(done ? Ui.circle(Ui.EMERALD) : Ui.roundStroke(0, 50, Ui.MUTED, 2));
            row.addView(tick, Ui.lpm(Ui.dp(28), Ui.dp(28), 0, 0, 12, 0));
            LinearLayout col = Ui.col(a);
            col.addView(Ui.text(a, r.title, 14.5f, done ? Ui.MUTED : Ui.TEXT, true));
            String st = Ui.clock(r.time) + (done ? Lang.pick(" · done", " · થઈ ગયું")
                    : fired > 0 ? Lang.pick(" · reminded " + fired + "/" + r.repeat, " · " + fired + "/" + r.repeat + " વાર યાદ કરાવ્યું") : "");
            col.addView(Ui.text(a, st, 12, Ui.SUB, false));
            row.addView(col, Ui.weight(1));
            c.addView(row);
            Ui.press(row);
            final boolean fdone = done;
            tick.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!fdone) {
                        Reminders.markDone(a, r.id);
                        refresh.run();
                    }
                }
            });
            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (r.taskId.length() > 0) a.startActivity(new Intent(a, TaskActivity.class).putExtra("task", r.taskId));
                    else edit(a, r, refresh);
                }
            });
            row.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    edit(a, r, refresh);
                    return true;
                }
            });
        }
        if (shown == 0) {
            TextView e = Ui.text(a, Lang.pick("No reminders today. Tap + Add — I'll keep reminding you until you tap Done.",
                    "આજે કોઈ રિમાઇન્ડર નથી. + ઉમેરો દબાવો — 'થઈ ગયું' દબાવો ત્યાં સુધી યાદ કરાવતો રહીશ."), 12.5f, Ui.MUTED, false);
            e.setPadding(0, Ui.dp(8), 0, 0);
            c.addView(e);
        }
        return c;
    }

    static GradientDrawable unused() {
        return null;
    }
}
