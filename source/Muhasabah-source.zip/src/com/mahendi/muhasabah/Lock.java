package com.mahendi.muhasabah;

import android.content.Context;
import android.os.SystemClock;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

/**
 * Commitment lock.
 *  • Lockdown: for 24h / 48h / 7d / 30d nothing can be loosened (only made stricter).
 *  • Cooling-off: outside a lock, every loosening change waits (default 24h) before it applies.
 *  • Trusted time: ignores phone-clock changes (clock-jump detection + internet time).
 *  • Emergency: a partner's secret PIN can end a lock early — at a cost (XP + streak), and it's logged.
 */
public final class Lock {
    public static final String K_UNTIL = "lock_until", K_STARTED = "lock_started", K_COOL = "lock_cool_h", K_REQ = "lock_req",
            K_LOG = "lock_log", K_OFF = "lock_time_off", K_GRACE = "lock_grace_until", K_PIN = "lock_pin", K_SALT = "lock_salt",
            K_PNAME = "lock_partner_name", K_PPHONE = "lock_partner_phone", K_XP_PEN = "xp_penalty", K_STREAK_BREAK = "streak_break",
            K_NET_AT = "lock_net_at";
    public static final int[] HOURS = {24, 48, 168, 720};
    public static final int EMERGENCY_XP = 100;
    private static final long HOUR = 3600_000L;

    private Lock() {
    }

    // ---------------- trusted time ----------------
    public static long now(Store s) {
        return System.currentTimeMillis() + s.l(K_OFF, 0);
    }

    /**
     * Called often (service tick, app open): if the wall clock jumped compared with the phone's
     * monotonic clock, fold the jump into the offset so the lock's countdown is unaffected.
     */
    public static synchronized void tick(Context c) {
        Store s = Store.get(c);
        long wall = System.currentTimeMillis(), el = SystemClock.elapsedRealtime();
        long lw = s.l("lock_tw", 0), le = s.l("lock_te", 0);
        if (lw > 0 && le > 0 && el >= le) {
            long drift = (wall - lw) - (el - le);
            if (Math.abs(drift) > 2 * 60_000L) s.put(K_OFF, s.l(K_OFF, 0) - drift);
        }
        s.put("lock_tw", wall);
        s.put("lock_te", el);
        applyDue(c);
    }

    /** Re-anchors trusted time to internet time (HTTP Date header). Runs off the main thread. */
    public static void syncNetwork(final Context c) {
        final Store s = Store.get(c);
        if (!isLocked(s) && pending(s).isEmpty()) return;
        if (System.currentTimeMillis() - s.l(K_NET_AT, 0) < 20 * 60_000L) return;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    HttpURLConnection h = (HttpURLConnection) new URL("https://raw.githubusercontent.com/kananimahdi3097-a11y/muhasabah/main/update.json").openConnection();
                    h.setRequestMethod("HEAD");
                    h.setConnectTimeout(8000);
                    h.setReadTimeout(8000);
                    h.setUseCaches(false);
                    long t0 = System.currentTimeMillis();
                    h.connect();
                    long date = h.getHeaderFieldDate("Date", 0);
                    h.disconnect();
                    if (date > 0) {
                        long off = date - (t0 + System.currentTimeMillis()) / 2;
                        if (Math.abs(off - s.l(K_OFF, 0)) > 3 * 60_000L) s.put(K_OFF, off);
                        s.put(K_NET_AT, System.currentTimeMillis());
                        s.put("lock_tw", System.currentTimeMillis());
                        s.put("lock_te", SystemClock.elapsedRealtime());
                    }
                } catch (Throwable ignored) {
                }
            }
        }).start();
    }

    // ---------------- lockdown ----------------
    public static boolean isLocked(Store s) {
        return now(s) < s.l(K_UNTIL, 0);
    }

    public static long remainingMs(Store s) {
        return Math.max(0, s.l(K_UNTIL, 0) - now(s));
    }

    public static long until(Store s) {
        return s.l(K_UNTIL, 0);
    }

    /** Starts (or extends — never shortens) a lock. */
    public static void start(Store s, int hours) {
        long end = Math.max(s.l(K_UNTIL, 0), now(s) + hours * HOUR);
        if (!isLocked(s)) s.put(K_STARTED, now(s));
        s.put(K_UNTIL, end);
        s.put(K_GRACE, 0L);
        log(s, "start", hours + "h");
    }

    public static boolean graceActive(Store s) {
        return now(s) < s.l(K_GRACE, 0);
    }

    public static int coolHours(Store s) {
        return s.i(K_COOL, 24);
    }

    // ---------------- changes ----------------
    /** A loosening change. type + fields; desc is what the user sees. */
    public static JSONObject change(String type, String key, Object val, String desc) {
        JSONObject o = new JSONObject();
        try {
            o.put("type", type);
            o.put("key", key);
            o.put("val", val);
            o.put("desc", desc);
        } catch (Exception ignored) {
        }
        return o;
    }

    public static final int NOW = 0, QUEUED = 1, REFUSED = 2;

    /** Applies now (grace), queues it for the cooling-off period, or refuses (locked). */
    public static int request(Context c, JSONObject ch) {
        Store s = Store.get(c);
        if (graceActive(s)) {
            apply(s, ch);
            return NOW;
        }
        if (isLocked(s)) {
            log(s, "refused", ch.optString("desc"));
            return REFUSED;
        }
        try {
            ch.put("at", now(s));
            ch.put("due", now(s) + coolHours(s) * HOUR);
            ch.put("id", "r" + System.nanoTime());
            JSONArray a = new JSONArray(s.s(K_REQ, "[]"));
            a.put(ch);
            s.put(K_REQ, a.toString());
        } catch (Exception ignored) {
        }
        return QUEUED;
    }

    public static List<JSONObject> pending(Store s) {
        List<JSONObject> l = new ArrayList<JSONObject>();
        try {
            JSONArray a = new JSONArray(s.s(K_REQ, "[]"));
            for (int i = 0; i < a.length(); i++) if (a.optJSONObject(i) != null) l.add(a.optJSONObject(i));
        } catch (Exception ignored) {
        }
        return l;
    }

    private static void savePending(Store s, List<JSONObject> l) {
        JSONArray a = new JSONArray();
        for (JSONObject o : l) a.put(o);
        s.put(K_REQ, a.toString());
    }

    public static void cancel(Store s, String id) {
        List<JSONObject> l = pending(s), keep = new ArrayList<JSONObject>();
        for (JSONObject o : l) if (!id.equals(o.optString("id"))) keep.add(o);
        savePending(s, keep);
        log(s, "cancel", "");
    }

    /** When a request's time is reached (and no lock is running) it is applied. */
    public static synchronized int applyDue(Context c) {
        Store s = Store.get(c);
        if (isLocked(s)) return 0;
        List<JSONObject> l = pending(s), keep = new ArrayList<JSONObject>();
        int n = 0;
        long t = now(s);
        for (JSONObject o : l) {
            if (o.optLong("due") <= t) {
                apply(s, o);
                log(s, "applied", o.optString("desc"));
                n++;
            } else keep.add(o);
        }
        if (n > 0) savePending(s, keep);
        return n;
    }

    /** Performs a change. */
    static void apply(Store s, JSONObject ch) {
        String type = ch.optString("type"), key = ch.optString("key");
        try {
            if (type.equals("words_remove") || type.equals("sites_remove")) {
                boolean words = type.equals("words_remove");
                List<String> cur = words ? s.blockedWords() : s.blockedSites();
                List<String> rm = new ArrayList<String>();
                for (String x : ch.optString("val").split(",")) if (x.trim().length() > 0) rm.add(x.trim().toLowerCase());
                StringBuilder b = new StringBuilder();
                for (String w : cur) if (!rm.contains(w)) b.append(b.length() > 0 ? "," : "").append(w);
                if (words) s.setBlockedWords(b.toString());
                else s.setBlockedSites(b.toString());
            } else if (type.equals("app_limit") || type.equals("app_remove")) {
                JSONArray apps = s.apps(), out = new JSONArray();
                for (int i = 0; i < apps.length(); i++) {
                    JSONObject o = apps.optJSONObject(i);
                    if (o == null) continue;
                    if (key.equals(o.optString("pkg"))) {
                        if (type.equals("app_remove")) continue;
                        o.put("limit", ch.optInt("val"));
                    }
                    out.put(o);
                }
                s.saveApps(out);
            } else if (type.equals("int")) {
                s.put(key, ch.optInt("val"));
            } else if (type.equals("reset")) {
                s.p.edit().remove(key).apply();
            } else if (type.equals("bool")) {
                s.put(key, ch.optBoolean("val"));
            } else if (type.equals("pin_clear")) {
                s.p.edit().remove(K_PIN).remove(K_SALT).apply();
            }
        } catch (Exception ignored) {
        }
    }

    // ---------------- partner emergency PIN ----------------
    public static boolean hasPin(Store s) {
        return s.s(K_PIN, "").length() > 0;
    }

    public static void setPin(Store s, String pin) {
        byte[] salt = new byte[12];
        new SecureRandom().nextBytes(salt);
        String sh = hex(salt);
        s.put(K_SALT, sh);
        s.put(K_PIN, hash(sh, pin));
    }

    public static boolean checkPin(Store s, String pin) {
        return hasPin(s) && hash(s.s(K_SALT, ""), pin).equals(s.s(K_PIN, ""));
    }

    /** Ends the lock now; costs XP and the streak; the PIN is used up (partner sets a new one). */
    public static void emergencyUnlock(Store s) {
        s.put(K_UNTIL, now(s));
        s.put(K_GRACE, now(s) + 30 * 60_000L);
        s.put(K_XP_PEN, s.i(K_XP_PEN, 0) + EMERGENCY_XP);
        s.put(K_STREAK_BREAK, Store.today());
        s.p.edit().remove(K_PIN).remove(K_SALT).apply();
        log(s, "emergency", "");
    }

    private static String hash(String salt, String pin) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            return hex(md.digest((salt + ":" + pin).getBytes("UTF-8")));
        } catch (Exception e) {
            return "";
        }
    }

    private static String hex(byte[] b) {
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format("%02x", x));
        return sb.toString();
    }

    // ---------------- log ----------------
    /** Events: start, refused, applied, cancel, emergency, tamper. */
    public static synchronized void log(Store s, String type, String info) {
        try {
            JSONArray a = new JSONArray(s.s(K_LOG, "[]"));
            JSONObject o = new JSONObject();
            o.put("t", type);
            o.put("d", Store.today());
            o.put("i", info);
            a.put(o);
            while (a.length() > 300) a.remove(0);
            s.put(K_LOG, a.toString());
        } catch (Exception ignored) {
        }
    }

    /** Count of events of a type between two dates (inclusive, yyyy-MM-dd). */
    public static int count(Store s, String type, String from, String to) {
        int n = 0;
        try {
            JSONArray a = new JSONArray(s.s(K_LOG, "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o == null || !type.equals(o.optString("t"))) continue;
                String d = o.optString("d");
                if (d.compareTo(from) >= 0 && d.compareTo(to) <= 0) n++;
            }
        } catch (Exception ignored) {
        }
        return n;
    }

    // ---------------- helpers ----------------
    public static String left(long ms) {
        long m = ms / 60_000L;
        long d = m / 1440, h = (m % 1440) / 60, mm = m % 60;
        if (d > 0) return d + (Lang.gu() ? "દિ " : Lang.ur() ? " دن " : Lang.hi() ? "दि " : "d ") + h + (Lang.gu() ? "ક" : Lang.ur() ? " گھ" : Lang.hi() ? "घं" : "h");
        if (h > 0) return h + (Lang.gu() ? "ક " : Lang.ur() ? " گھ " : Lang.hi() ? "घं " : "h ") + mm + (Lang.gu() ? "મિ" : Lang.ur() ? " م" : Lang.hi() ? "मि" : "m");
        return Math.max(1, mm) + (Lang.gu() ? " મિ" : Lang.ur() ? " منٹ" : Lang.hi() ? " मि" : " min");
    }

    /** Which direction of a Fine-tune number is "looser". +1: raising loosens, -1: lowering loosens, 0: free. */
    public static int looseDir(String key) {
        if (key.equals("a_step") || key.equals("a_pause") || key.equals("a_pause_gap") || key.equals("n_night_start")
                || key.equals("n_night_gap") || key.equals("n_oversleep") || key.equals("pen_tp_per")) return 1;
        if (key.equals("a_warn") || key.startsWith("pen_") || key.equals("better_thr")) return -1;
        return 0;
    }

    /** Keys a backup restore must never loosen. */
    public static final String[] PROTECTED_KEYS = {"blocked_words", "blocked_sites", "apps", Store.K_REELS_LIMIT, Store.K_MONITOR,
            Store.K_BLOCK_ON, K_UNTIL, K_STARTED, K_COOL, K_REQ, K_LOG, K_OFF, K_GRACE, K_PIN, K_SALT, K_XP_PEN, K_STREAK_BREAK,
            "a_warn", "a_step", "a_pause", "a_pause_gap", ScreenGuard.K_ON};
}
