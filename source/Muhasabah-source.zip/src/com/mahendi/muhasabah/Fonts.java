package com.mahendi.muhasabah;

import android.content.Context;
import android.graphics.Typeface;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.TypefaceSpan;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

/**
 * Loads the bundled Al Qalam (Arabic) and Shruti (Gujarati) fonts, plus any font the user
 * imported, and applies the right typeface per script — including mixed Arabic/Gujarati/Latin text.
 */
public final class Fonts {
    private static Typeface arabic, gujarati, gujaratiBold, urdu;
    private static boolean tried;
    private static Context app;

    public static void init(Context c) {
        app = c.getApplicationContext();
        if (tried) return;
        tried = true;
        arabic = loadUser("arabic_font.ttf", "fonts/alqalam.ttf");
        gujarati = loadUser("gujarati_font.ttf", "fonts/shruti.ttf");
        gujaratiBold = loadAsset("fonts/shruti_bold.ttf");
        if (gujaratiBold == null) gujaratiBold = gujarati;
        urdu = loadAsset("fonts/nastaliq.ttf");
        if (urdu == null) urdu = arabic;
    }

    public static Typeface urdu() {
        return urdu;
    }

    /** Letters used in Urdu but not in Quranic Arabic: ٹ ڈ ڑ ں ے ۓ ھ ہ ی ک گ پ چ ژ. */
    public static boolean isUrdu(CharSequence s) {
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == 0x0679 || c == 0x0688 || c == 0x0691 || c == 0x06BA || c == 0x06D2 || c == 0x06D3 || c == 0x06BE
                    || c == 0x06C1 || c == 0x06CC || c == 0x06A9 || c == 0x06AF || c == 0x067E || c == 0x0686 || c == 0x0698)
                return true;
        }
        return false;
    }

    /** Urdu text in Nastaliq with room for its tall letters. */
    public static void applyUrdu(TextView t) {
        t.setText(t.getText().toString());
        if (urdu != null) t.setTypeface(urdu);
        t.setLineSpacing(t.getTextSize() * 0.45f, 1f);
        t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, t.getTextSize() * 1.06f);
    }

    private static Typeface loadUser(String userFile, String assetPath) {
        try {
            File f = new File(app.getFilesDir(), userFile);
            if (f.exists()) return Typeface.createFromFile(f);
        } catch (Exception ignored) {
        }
        return loadAsset(assetPath);
    }

    private static Typeface loadAsset(String path) {
        try {
            return Typeface.createFromAsset(app.getAssets(), path);
        } catch (Exception e) {
            return null;
        }
    }

    public static void reload() {
        tried = false;
        init(app);
    }

    public static Typeface arabic() {
        return arabic;
    }

    public static Typeface gujarati() {
        return gujarati;
    }

    /** Save an imported font file; which = "arabic_font.ttf" or "gujarati_font.ttf". */
    public static boolean importFont(Context c, InputStream in, String which) {
        try {
            File tmp = new File(c.getFilesDir(), which + ".tmp");
            FileOutputStream out = new FileOutputStream(tmp);
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            out.close();
            Typeface.createFromFile(tmp); // validate
            File dst = new File(c.getFilesDir(), which);
            dst.delete();
            if (!tmp.renameTo(dst)) return false;
            reload();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private static int script(char ch) {
        if (ch >= 0x0600 && ch <= 0x06FF || ch >= 0x0750 && ch <= 0x077F || ch >= 0xFB50 && ch <= 0xFDFF
                || ch >= 0xFE70 && ch <= 0xFEFF) return 1; // Arabic
        if (ch >= 0x0A80 && ch <= 0x0AFF) return 2; // Gujarati
        if (Character.isLetter(ch)) return 0;
        return -1; // neutral
    }

    /** Apply Arabic font to a TextView of pure Arabic. */
    public static void applyArabic(TextView t) {
        t.setText(t.getText().toString()); // drop per-script spans so the whole ayah is Al Qalam
        if (arabic != null) t.setTypeface(arabic);
    }

    public static void applyGujarati(TextView t, boolean bold) {
        Typeface tf = bold ? gujaratiBold : gujarati;
        if (tf != null) t.setTypeface(tf);
    }

    /**
     * For text that mixes scripts (e.g. Gujarati with an Arabic word, or English menu with Gujarati),
     * span each run with the right font so nothing falls back to a missing glyph.
     */
    public static CharSequence mixed(CharSequence s) {
        if (s == null || s.length() == 0) return s;
        SpannableStringBuilder b = new SpannableStringBuilder(s);
        int n = s.length(), start = 0, cur = -1;
        for (int i = 0; i <= n; i++) {
            int sc = i < n ? script(s.charAt(i)) : -2;
            if (sc == -1) continue; // spaces, digits, punctuation stay with the current run
            if (cur == -1) {
                cur = sc;
                continue;
            }
            if (sc != cur) {
                int end = i;
                if (sc != -2) { // give trailing neutrals to the next run only if it is Latin
                    while (end > start && script(s.charAt(end - 1)) == -1 && sc == 0) end--;
                } else end = n;
                Typeface tf = cur == 1 ? (isUrdu(s.subSequence(start, end)) ? urdu : arabic) : cur == 2 ? gujarati : null;
                if (tf != null && end > start) b.setSpan(new TypefaceSpanCompat(tf), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                start = end;
                cur = sc;
            }
        }
        return b;
    }

    public static void applyMixed(TextView t) {
        t.setText(mixed(t.getText()));
    }

    /** TypefaceSpan that takes an actual Typeface (API 28+). */
    static final class TypefaceSpanCompat extends TypefaceSpan {
        private final Typeface tf;

        TypefaceSpanCompat(Typeface tf) {
            super((String) null);
            this.tf = tf;
        }

        @Override
        public void updateDrawState(android.text.TextPaint p) {
            apply(p);
        }

        @Override
        public void updateMeasureState(android.text.TextPaint p) {
            apply(p);
        }

        private void apply(android.text.TextPaint p) {
            Typeface old = p.getTypeface();
            int style = old == null ? 0 : old.getStyle();
            Typeface want = tf;
            if ((style & Typeface.BOLD) != 0 && tf == gujarati && gujaratiBold != null) want = gujaratiBold;
            p.setTypeface(want);
            if (tf == urdu && urdu != arabic) p.setTextSize(p.getTextSize() * 1.05f);
        }
    }
}
