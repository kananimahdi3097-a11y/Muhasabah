package com.mahendi.muhasabah;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Fix the previous day's entries for a while after the day ends (24 or 48 hours, set in Settings):
 * forgot to tick a namaz, entered a wrong count … The day's score and XP are recomputed after a change.
 */
public final class PastDays {
    public static final String K_WINDOW = "edit_window_h"; // 24 or 48
    private PastDays() {
    }

    public static int windowHours(Store s) {
        int h = s.i(K_WINDOW, 48);
        return h == 24 ? 24 : 48;
    }

    /** Past dates that can still be edited right now, newest first. */
    public static List<String> editable(Store s) {
        List<String> out = new ArrayList<String>();
        long now = System.currentTimeMillis(), win = windowHours(s) * 3600000L;
        for (int k = 1; k <= 2; k++) {
            long end = Store.startOfToday() - (k - 1) * 86400000L; // midnight that closed that day
            if (now < end + win) out.add(Store.date(-k));
        }
        return out;
    }

    /** When editing of that date closes. */
    public static long closesAt(Store s, String date) {
        int k = -Store.daysBetween(Store.today(), date); // 1 = yesterday
        return Store.startOfToday() - (k - 1) * 86400000L + windowHours(s) * 3600000L;
    }

    public static String dayName(String date) {
        if (date.equals(Store.date(-1))) return HadithCard.label("Yesterday", "ગઈકાલ", "کل (گزشتہ)", "कल (बीता)");
        java.util.Calendar c = Store.cal(date);
        return Lang.dayShort(c.get(java.util.Calendar.DAY_OF_WEEK) - 1) + " " + c.get(java.util.Calendar.DAY_OF_MONTH);
    }

    private static void rescore(Store s, String date) {
        s.p.edit().remove("final_" + date).apply();
        Score.dayScore(s, date);
    }

    public static void sheet(final Activity a, final String date, final Runnable onClose) {
        final Store s = Store.get(a);
        final LinearLayout body = Ui.col(a);
        final TextView score = Ui.text(a, "", 14, Ui.GOLD, true);
        final Runnable paintScore = new Runnable() {
            @Override
            public void run() {
                rescore(s, date);
                score.setText(HadithCard.label("Score that day: ", "એ દિવસનો સ્કોર: ", "اس دن کا اسکور: ", "उस दिन का स्कोर: ") + Score.dayScore(s, date));
            }
        };
        long close = closesAt(s, date);
        java.util.Calendar cc = java.util.Calendar.getInstance();
        cc.setTimeInMillis(close);
        String until = Lang.dayShort(cc.get(java.util.Calendar.DAY_OF_WEEK) - 1) + " " + Ui.clock(cc.get(java.util.Calendar.HOUR_OF_DAY) * 60 + cc.get(java.util.Calendar.MINUTE));
        body.addView(Ui.text(a, HadithCard.label("You can fix this day until " + until + ". Be honest — this is your own muhasabah.",
                "તમે આ દિવસ " + until + " સુધી સુધારી શકો છો. પ્રામાણિક રહો — આ તમારું પોતાનું મુહાસબા છે.",
                "آپ اس دن کو " + until + " تک درست کر سکتے ہیں۔ ایمانداری رکھیں — یہ آپ کا اپنا محاسبہ ہے۔",
                "आप इस दिन को " + until + " तक ठीक कर सकते हैं। ईमानदार रहें — यह आपका अपना मुहासबा है।"), 13, Ui.SUB, false));
        body.addView(score, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 8, 0, 10));
        List<Task> tasks = s.tasksOn(date);
        if (tasks.isEmpty())
            body.addView(Ui.text(a, HadithCard.label("No tasks on this day.", "આ દિવસે કોઈ કામ નથી.", "اس دن کوئی کام نہیں۔", "इस दिन कोई काम नहीं।"), 14, Ui.MUTED, false));
        for (final Task t : tasks) body.addView(row(a, s, date, t, paintScore), Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 8));
        paintScore.run();
        AlertDialog d = Dialogs.sheet(a, "✏️  " + dayName(date), body);
        d.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface di) {
                if (onClose != null) onClose.run();
            }
        });
        d.show();
    }

    private static View row(final Activity a, final Store s, final String date, final Task t, final Runnable paintScore) {
        final LinearLayout r = Ui.row(a);
        r.setBackground(Ui.roundStroke(Ui.CARD2, 16, Ui.STROKE, 1));
        r.setPadding(Ui.dp(12), Ui.dp(10), Ui.dp(10), Ui.dp(10));
        r.addView(Ui.text(a, t.emoji, 20, Ui.TEXT, false), Ui.lpm(Ui.dp(32), Ui.WRAP, 0, 0, 6, 0));
        LinearLayout mid = Ui.col(a);
        mid.addView(Ui.text(a, t.display(), 14.5f, Ui.TEXT, true));
        final TextView val = Ui.text(a, "", 12.5f, Ui.SUB, false);
        mid.addView(val);
        r.addView(mid, Ui.weight(1));
        final Runnable paint = new Runnable() {
            @Override
            public void run() {
                double v = s.value(date, t);
                val.setText(valueText(t, v));
                val.setTextColor(t.frac(v) >= 0.999 ? Ui.EMERALD : Ui.SUB);
            }
        };
        final Dialogs.IntCallback set = new Dialogs.IntCallback() {
            @Override
            public void done(int v) {
                s.setValue(date, t, v);
                Haptics.play(t.frac(v) >= 0.999 ? Haptics.SUCCESS : Haptics.TOGGLE);
                paint.run();
                paintScore.run();
            }
        };
        if (t.type == Task.CHECK) {
            TextView b = Ui.pill(a, "✓ / ✕", Ui.alpha(Ui.EMERALD, 0.16f), Ui.EMERALD);
            b.setPadding(Ui.dp(14), Ui.dp(9), Ui.dp(14), Ui.dp(9));
            Ui.press(b);
            r.addView(b);
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    set.done(s.value(date, t) >= 1 ? 0 : 1);
                }
            });
        } else if (t.type == Task.CHOICE) {
            TextView b = Ui.pill(a, Lang.t("change"), Ui.alpha(Ui.PURPLE, 0.16f), Ui.PURPLE);
            b.setPadding(Ui.dp(12), Ui.dp(9), Ui.dp(12), Ui.dp(9));
            Ui.press(b);
            r.addView(b);
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Dialogs.chooseOption(a, t, (int) s.value(date, t), set);
                }
            });
        } else {
            final int step = t.type == Task.MINUTES ? 5 : 1;
            TextView minus = btn(a, "−"), plus = btn(a, "+");
            r.addView(minus, Ui.lp(Ui.dp(36), Ui.dp(36)));
            r.addView(Ui.space(a, 1), Ui.lp(Ui.dp(8), 1));
            r.addView(plus, Ui.lp(Ui.dp(36), Ui.dp(36)));
            minus.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int cur = (int) Math.max(0, Math.round(s.value(date, t)));
                    if (cur <= 0) {
                        Haptics.play(Haptics.WARN);
                        return;
                    }
                    set.done(Math.max(0, cur - step));
                }
            });
            plus.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    set.done((int) Math.max(0, Math.round(s.value(date, t))) + step);
                }
            });
            // tap the value to type an exact number
            val.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final List<String> out = new ArrayList<String>();
                    Dialogs.prompt(a, t.display(), String.valueOf((int) Math.max(0, Math.round(s.value(date, t)))), true, out, new Runnable() {
                        @Override
                        public void run() {
                            if (out.isEmpty()) return;
                            try {
                                set.done(Math.max(0, Integer.parseInt(out.get(0).trim())));
                            } catch (Exception ignored) {
                            }
                        }
                    });
                }
            });
        }
        paint.run();
        return r;
    }

    private static TextView btn(Activity a, String label) {
        TextView b = Ui.text(a, label, 20, Ui.TEXT, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(Ui.roundStroke(Ui.CARD, 50, Ui.STROKE, 1));
        Ui.press(b);
        return b;
    }

    private static String valueText(Task t, double v) {
        switch (t.type) {
            case Task.CHECK:
                return v >= 1 ? Lang.t("done_tick") : Lang.t("not_yet");
            case Task.COUNT:
                return (int) Math.max(0, v) + " / " + t.target + (t.unit.length() > 0 ? " " + t.unit : "") + "  ✎";
            case Task.MINUTES:
                return Ui.hm((int) Math.max(0, Math.round(v))) + " / " + Ui.hm(t.target) + "  ✎";
            default: {
                int i = (int) v;
                String[] o = t.displayOptions();
                return i >= 0 && i < o.length ? o[i] : Lang.pick("Not answered", "જવાબ નથી");
            }
        }
    }
}
