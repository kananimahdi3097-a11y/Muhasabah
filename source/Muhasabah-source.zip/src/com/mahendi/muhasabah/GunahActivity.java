package com.mahendi.muhasabah;

import android.app.Activity;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Insets;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.TimePicker;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Tawbah & Islah: pick a sin you fell into today and receive 7 days of referenced reminders.
 * Private by design — no score, no summaries, no history; details hidden on the lock screen.
 */
public class GunahActivity extends Activity {
    @Override
    protected void attachBaseContext(android.content.Context b) {
        super.attachBaseContext(Ui.wrap(b));
    }

    @Override
    public boolean dispatchTouchEvent(android.view.MotionEvent ev) {
        Haptics.touch(getWindow().getDecorView(), ev);
        return super.dispatchTouchEvent(ev);
    }

    private LinearLayout page;
    private ScrollView sv;
    private String showKey;
    private int showDay;

    private static String L(String en, String gu, String ur, String hi) {
        return HadithCard.label(en, gu, ur, hi);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.init(this);
        Lang.init(this);
        Gunah.channel(this);
        sv = new ScrollView(this);
        sv.setBackgroundColor(Ui.BG);
        page = Ui.col(this);
        sv.addView(page);
        setContentView(sv);
        sv.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View v, WindowInsets in) {
                Insets i = in.getInsets(WindowInsets.Type.systemBars());
                page.setPadding(Ui.dp(18) + i.left, Ui.dp(12) + i.top, Ui.dp(18) + i.right, Ui.dp(30) + i.bottom);
                return WindowInsets.CONSUMED;
            }
        });
        read(getIntent());
        build();
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        read(i);
        build();
        sv.scrollTo(0, 0);
    }

    private void read(Intent i) {
        showKey = i == null ? null : i.getStringExtra("key");
        showDay = i == null ? 0 : i.getIntExtra("day", 0);
    }

    private void build() {
        page.removeAllViews();
        Gunah.check(this);
        LinearLayout head = Ui.row(this);
        TextView back = Ui.text(this, "←", 22, Ui.TEXT, true);
        back.setGravity(Gravity.CENTER);
        back.setBackground(Ui.circle(Ui.CARD2));
        head.addView(back, Ui.lpm(Ui.dp(44), Ui.dp(44), 0, 0, 12, 0));
        Ui.press(back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        head.addView(Ui.title(this, L("Tawbah & Islah", "તૌબા અને ઇસ્લાહ", "توبہ و اصلاح", "तौबा और इस्लाह"), 26), Ui.weight(1));
        page.addView(head, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));

        TextView privacy = Ui.text(this, L("🔒 Private. Nothing here affects your score, streak or summaries. Only the running 7-day reminders are kept, on this phone, and the lock screen hides their details.",
                "🔒 ખાનગી. અહીંની કોઈ વાત તમારા સ્કોર, સ્ટ્રીક કે સારાંશમાં નથી જતી. ફક્ત ચાલુ 7 દિવસના રિમાઇન્ડર આ ફોનમાં જ રહે છે, અને લૉક-સ્ક્રીન પર તેની વિગત છુપાયેલી રહે છે.",
                "🔒 نجی۔ یہاں کی کوئی بات آپ کے اسکور، اسٹریک یا خلاصے میں شامل نہیں ہوتی۔ صرف جاری 7 دن کی یاد دہانیاں اسی فون میں رہتی ہیں، اور لاک اسکرین پر ان کی تفصیل چھپی رہتی ہے۔",
                "🔒 निजी। यहाँ की कोई बात आपके स्कोर, स्ट्रीक या सारांश में नहीं जाती। सिर्फ़ चालू 7 दिन के रिमाइंडर इसी फ़ोन में रहते हैं, और लॉक-स्क्रीन पर उनकी जानकारी छुपी रहती है।"),
                12.5f, Ui.SUB, false);
        privacy.setBackground(Ui.roundStroke(Ui.CARD, 16, Ui.STROKE, 1));
        privacy.setPadding(Ui.dp(14), Ui.dp(12), Ui.dp(14), Ui.dp(12));
        page.addView(privacy, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 16));

        // the reminder that was opened (from a notification, or right after starting)
        if (showKey != null && Gunah.sin(this, showKey) != null && showDay >= 1) {
            JSONObject sin = Gunah.sin(this, showKey);
            page.addView(sectionTitle(sin.optString("emoji") + "  " + Gunah.name(sin)));
            dayCards(showKey, showDay, true);
            page.addView(Ui.space(this, 10));
        }

        // running series
        JSONObject all = Gunah.series(this);
        if (all.length() > 0) {
            page.addView(sectionTitle(L("Running now", "હાલ ચાલુ", "ابھی جاری", "अभी चालू")));
            JSONArray keys = all.names();
            for (int i = 0; keys != null && i < keys.length(); i++) {
                final String key = keys.optString(i);
                JSONObject sin = Gunah.sin(this, key);
                int day = Gunah.dayOf(this, key);
                if (sin == null || day == 0) continue;
                page.addView(runningRow(key, sin, day), Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 8));
            }
            page.addView(Ui.space(this, 8));
        }

        // reminder time
        LinearLayout tr = Ui.row(this);
        tr.setBackground(Ui.roundStroke(Ui.CARD, 16, Ui.STROKE, 1));
        tr.setPadding(Ui.dp(14), Ui.dp(12), Ui.dp(14), Ui.dp(12));
        tr.addView(Ui.text(this, L("⏰ Daily reminder time", "⏰ રોજનો રિમાઇન્ડર સમય", "⏰ روزانہ یاد دہانی کا وقت", "⏰ रोज़ का रिमाइंडर समय"), 14, Ui.TEXT, true), Ui.weight(1));
        TextView tv = Ui.pill(this, Ui.clock(Gunah.time(this)), Ui.alpha(Ui.EMERALD, 0.16f), Ui.EMERALD);
        tr.addView(tv);
        Ui.press(tr);
        tr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int t = Gunah.time(GunahActivity.this);
                new TimePickerDialog(GunahActivity.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int h, int m) {
                        Haptics.play(Haptics.SELECT);
                        Gunah.setTime(GunahActivity.this, h * 60 + m);
                        build();
                    }
                }, t / 60, t % 60, false).show();
            }
        });
        page.addView(tr, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 18));

        // the list
        page.addView(sectionTitle(L("I did this today", "આજે મારાથી આ થઈ ગયું", "آج مجھ سے یہ ہو گیا", "आज मुझसे यह हो गया")));
        page.addView(Ui.text(this, L("Tap one to start 7 days of reminders: Quran, hadith, Ghurar al-Hikam, Bihar al-Anwar, a growth hadith, tawbah and a practical step. Tapping again restarts the 7 days.",
                "7 દિવસના રિમાઇન્ડર શરૂ કરવા એક પર ટૅપ કરો: કુરાન, હદીસ, ગુરરુલ હિકમ, બિહારુલ અન્વાર, પ્રગતિની હદીસ, તૌબા અને વ્યવહારુ પગલું. ફરી ટૅપ કરવાથી 7 દિવસ ફરી શરૂ થાય છે.",
                "7 دن کی یاد دہانیاں شروع کرنے کے لیے ایک پر ٹیپ کریں: قرآن، حدیث، غرر الحکم، بحار الانوار، ترقی کی حدیث، توبہ اور عملی قدم۔ دوبارہ ٹیپ کرنے سے 7 دن پھر سے شروع ہوں گے۔",
                "7 दिन के रिमाइंडर शुरू करने के लिए एक पर टैप करें: क़ुरान, हदीस, ग़ुररुल हिकम, बिहारुल अनवार, तरक़्क़ी की हदीस, तौबा और अमली क़दम। दोबारा टैप करने से 7 दिन फिर से शुरू होंगे।"),
                12.5f, Ui.MUTED, false), Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 10));
        JSONArray sins = Gunah.sins(this);
        LinearLayout row = null;
        int n = sins.length() + 1; // + the "add your own" tile
        boolean anyMine = false;
        for (int i = 0; i < n; i++) {
            if (i % 2 == 0) {
                row = Ui.row(this);
                page.addView(row, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 8));
            }
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, Ui.WRAP, 1f);
            if (i % 2 == 0) p.setMargins(0, 0, Ui.dp(8), 0);
            if (i == sins.length()) {
                TextView add = Ui.text(this, "➕  " + L("Add your own", "તમારી પોતાની ઉમેરો", "اپنی شامل کریں", "अपनी जोड़ें"), 13.5f, Ui.GOLD, true);
                add.setBackground(Ui.roundStroke(Ui.alpha(Ui.GOLD, 0.08f), 14, Ui.alpha(Ui.GOLD, 0.55f), 1));
                add.setPadding(Ui.dp(12), Ui.dp(12), Ui.dp(10), Ui.dp(12));
                add.setMinHeight(Ui.dp(52));
                add.setGravity(Gravity.CENTER_VERTICAL);
                Ui.press(add);
                add.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Haptics.play(Haptics.TAP);
                        editMine(null);
                    }
                });
                row.addView(add, p);
                continue;
            }
            final JSONObject sin = sins.optJSONObject(i);
            final String key = sin.optString("key");
            final boolean mine = sin.optBoolean("custom");
            if (mine) anyMine = true;
            boolean running = Gunah.dayOf(this, key) > 0;
            TextView t = Ui.text(this, sin.optString("emoji") + "  " + Gunah.name(sin), 13.5f, running ? Ui.EMERALD : Ui.TEXT, true);
            t.setBackground(Ui.roundStroke(running ? Ui.alpha(Ui.EMERALD, 0.10f) : Ui.CARD, 14, running ? Ui.alpha(Ui.EMERALD, 0.5f) : Ui.STROKE, 1));
            t.setPadding(Ui.dp(12), Ui.dp(12), Ui.dp(10), Ui.dp(12));
            t.setMinHeight(Ui.dp(52));
            t.setGravity(Gravity.CENTER_VERTICAL);
            Ui.press(t);
            t.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ask(key, sin);
                }
            });
            if (mine) {
                t.setText(t.getText() + "  ✎");
                t.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        Haptics.play(Haptics.LONG);
                        editMine(key);
                        return true;
                    }
                });
            }
            row.addView(t, p);
        }
        if (n % 2 == 1 && row != null) row.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
        if (anyMine)
            page.addView(Ui.text(this, L("✎ = your own. Long-press it to edit or delete.", "✎ = તમારી પોતાની. બદલવા કે કાઢવા માટે લાંબું દબાવો.",
                    "✎ = آپ کی اپنی۔ بدلنے یا ہٹانے کے لیے دیر تک دبائیں۔", "✎ = आपकी अपनी। बदलने या हटाने के लिए देर तक दबाएँ।"), 11.5f, Ui.MUTED, false),
                    Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 2, 0, 0));

        TextView src = Ui.text(this, L("Sources: Quran (Tanzil text, Pickthall English); Al-Kafi and Nahj al-Balagha via Thaqalayn (CC BY 4.0) with gradings; Ghurar al-Hikam and Bihar al-Anwar Arabic from the OpenITI corpus (CC BY-NC-SA 4.0). Translations not credited to a translator are by Muhasabah — please check with a scholar.",
                "સ્રોત: કુરાન (તન્ઝીલ ટેક્સ્ટ, પિકથૉલ અંગ્રેજી); અલ-કાફી અને નહજુલ બલાગા — થકલૈન (CC BY 4.0) ગ્રેડિંગ સાથે; ગુરરુલ હિકમ અને બિહારુલ અન્વારનો અરબી — OpenITI (CC BY-NC-SA 4.0). જે અનુવાદ પર અનુવાદકનું નામ નથી તે Muhasabahના છે — કૃપા કરી આલિમથી ચકાસો.",
                "ماخذ: قرآن (تنزیل متن، پکتھال انگریزی)؛ الکافی اور نہج البلاغہ — ثقلین (CC BY 4.0) درجہ بندی کے ساتھ؛ غرر الحکم اور بحار الانوار کا عربی متن — OpenITI (CC BY-NC-SA 4.0)۔ جن تراجم پر مترجم کا نام نہیں وہ Muhasabah کے ہیں — براہِ کرم کسی عالم سے تصدیق کریں۔",
                "स्रोत: क़ुरान (तंज़ील टेक्स्ट, पिकथॉल अंग्रेज़ी); अल-काफ़ी और नहजुल बलाग़ा — सक़लैन (CC BY 4.0) ग्रेडिंग के साथ; ग़ुररुल हिकम और बिहारुल अनवार का अरबी — OpenITI (CC BY-NC-SA 4.0)। जिन अनुवादों पर अनुवादक का नाम नहीं, वे Muhasabah के हैं — कृपया किसी आलिम से जाँच लें।"),
                11, Ui.MUTED, false);
        src.setPadding(0, Ui.dp(16), 0, 0);
        page.addView(src);
    }

    private TextView sectionTitle(String s) {
        TextView t = Ui.title(this, s, 18);
        t.setPadding(0, Ui.dp(4), 0, Ui.dp(10));
        return t;
    }

    private View runningRow(final String key, final JSONObject sin, final int day) {
        LinearLayout c = Ui.col(this);
        c.setBackground(Ui.roundStroke(Ui.alpha(Ui.EMERALD, 0.08f), 16, Ui.alpha(Ui.EMERALD, 0.45f), 1));
        c.setPadding(Ui.dp(14), Ui.dp(12), Ui.dp(14), Ui.dp(12));
        LinearLayout r = Ui.row(this);
        r.addView(Ui.text(this, sin.optString("emoji") + "  " + Gunah.name(sin), 15, Ui.TEXT, true), Ui.weight(1));
        r.addView(Ui.pill(this, L("Day " + day + " / 7", "દિવસ " + day + " / 7", "دن " + day + " / 7", "दिन " + day + " / 7"), Ui.alpha(Ui.EMERALD, 0.18f), Ui.EMERALD));
        c.addView(r);
        c.addView(Ui.space(this, 8));
        c.addView(Ui.bar(this, day / 7f, Ui.EMERALD, 6));
        LinearLayout btns = Ui.row(this);
        btns.setPadding(0, Ui.dp(10), 0, 0);
        TextView view = Ui.ghost(this, L("Open reminders", "રિમાઇન્ડર જુઓ", "یاد دہانیاں دیکھیں", "रिमाइंडर देखें"), Ui.EMERALD);
        TextView stop = Ui.ghost(this, L("Stop", "બંધ કરો", "روکیں", "बंद करें"), Ui.SUB);
        btns.addView(view, Ui.weight(1));
        btns.addView(Ui.space(this, 1), Ui.lp(Ui.dp(8), 1));
        btns.addView(stop, Ui.weight(1));
        c.addView(btns);
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Haptics.play(Haptics.TAP);
                showAll(key, day);
            }
        });
        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Dialogs.confirm(GunahActivity.this, L("Stop these reminders?", "આ રિમાઇન્ડર બંધ કરશો?", "یہ یاد دہانیاں روک دیں؟", "ये रिमाइंडर बंद करें?"),
                        Gunah.name(sin), new Runnable() {
                            @Override
                            public void run() {
                                Gunah.stop(GunahActivity.this, key);
                                if (key.equals(showKey)) showKey = null;
                                build();
                            }
                        });
            }
        });
        return c;
    }

    /** All the days received so far for one series, in a sheet. */
    private void showAll(String key, int upTo) {
        LinearLayout body = Ui.col(this);
        LinearLayout saved = page;
        page = body;
        for (int d = upTo; d >= 1; d--) dayCards(key, d, d == upTo);
        page = saved;
        JSONObject sin = Gunah.sin(this, key);
        Dialogs.sheet(this, sin.optString("emoji") + "  " + Gunah.name(sin), body).show();
    }

    private void dayCards(String key, int day, boolean highlight) {
        JSONObject[] its = Gunah.items(this, key, day);
        LinearLayout c = Ui.col(this);
        c.setBackground(Ui.roundStroke(0xFF10171F, 22, Ui.alpha(Ui.EMERALD, highlight ? 0.55f : 0.30f), 1));
        c.setPadding(Ui.dp(16), Ui.dp(16), Ui.dp(16), Ui.dp(14));
        c.addView(Ui.text(this, L("DAY " + day + " / 7", "દિવસ " + day + " / 7", "دن " + day + " / 7", "दिन " + day + " / 7") + "  ·  " + Gunah.dayLabel(day).toUpperCase(Lang.locale()),
                11, Ui.EMERALD, true));
        for (int i = 0; i < its.length; i++) {
            if (its[i] == null) continue;
            if (i > 0) {
                View sep = new View(this);
                sep.setBackgroundColor(Ui.STROKE);
                c.addView(sep, Ui.lpm(Ui.MATCH, Ui.dp(1), 0, 14, 0, 2));
            }
            HadithCard.fill(this, c, its[i]);
        }
        if (its.length > 0 && its[0] != null) HadithCard.link(this, c, its[0]);
        page.addView(c, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));
    }

    /** Add (key == null) or edit one of your own bad habits. */
    private void editMine(final String key) {
        final JSONObject cur = key == null ? null : Gunah.customOne(this, key);
        final LinearLayout body = Ui.col(this);
        body.addView(Ui.text(this, L("Name the habit you want to leave. It stays private on this phone.",
                "જે આદત છોડવી છે તેનું નામ લખો. તે આ ફોનમાં જ ખાનગી રહેશે.",
                "جو عادت چھوڑنی ہے اس کا نام لکھیں۔ یہ اسی فون میں نجی رہے گی۔",
                "जो आदत छोड़नी है उसका नाम लिखें। यह इसी फ़ोन में निजी रहेगी।"), 13, Ui.SUB, false));
        LinearLayout r = Ui.row(this);
        final android.widget.EditText emoji = Ui.input(this, "🙂", cur == null ? "" : cur.optString("emoji"), false);
        emoji.setGravity(Gravity.CENTER);
        final android.widget.EditText name = Ui.input(this, L("e.g. Swearing, Wasting time, Smoking", "દા.ત. ગાળ બોલવી, સમય બગાડવો, સિગારેટ પીવી",
                "مثلاً گالی دینا، وقت ضائع کرنا، سگریٹ نوشی", "जैसे गाली देना, समय बर्बाद करना, सिगरेट पीना"), cur == null ? "" : cur.optString("name"), false);
        r.addView(emoji, Ui.lp(Ui.dp(58), Ui.WRAP));
        r.addView(Ui.space(this, 1), Ui.lp(Ui.dp(8), 1));
        r.addView(name, Ui.weight(1));
        body.addView(r, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));

        // which reminders to receive
        body.addView(small(L("Reminders to receive", "કયા રિમાઇન્ડર મળે", "کون سی یاد دہانیاں ملیں", "कौन-से रिमाइंडर मिलें")));
        final JSONArray built = Gunah.builtIn(this);
        final String[] base = {cur == null ? "" : cur.optString("base")};
        final TextView pick = Ui.pill(this, "", Ui.alpha(Ui.EMERALD, 0.14f), Ui.EMERALD);
        pick.setPadding(Ui.dp(14), Ui.dp(10), Ui.dp(14), Ui.dp(10));
        final Runnable paint = new Runnable() {
            @Override
            public void run() {
                JSONObject b = null;
                for (int i = 0; i < built.length(); i++) if (built.optJSONObject(i).optString("key").equals(base[0])) b = built.optJSONObject(i);
                pick.setText(b == null ? "🤲  " + L("General tawbah (fits any habit)", "સામાન્ય તૌબા (દરેક આદત માટે)", "عام توبہ (ہر عادت کے لیے)", "आम तौबा (हर आदत के लिए)") + "  ▾"
                        : b.optString("emoji") + "  " + L("Same as: ", "આના જેવા: ", "اس جیسی: ", "इसके जैसे: ") + Gunah.name(b) + "  ▾");
            }
        };
        paint.run();
        Ui.press(pick);
        pick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LinearLayout list = Ui.col(GunahActivity.this);
                final android.app.AlertDialog[] dd = new android.app.AlertDialog[1];
                for (int i = -1; i < built.length(); i++) {
                    final String k = i < 0 ? "" : built.optJSONObject(i).optString("key");
                    String label = i < 0 ? "🤲  " + L("General tawbah — Quran & hadith on repentance + a practical step",
                            "સામાન્ય તૌબા — તૌબા વિશે કુરાન અને હદીસ + વ્યવહારુ પગલું",
                            "عام توبہ — توبہ پر قرآن و حدیث + عملی قدم", "आम तौबा — तौबा पर क़ुरान व हदीस + अमली क़दम")
                            : built.optJSONObject(i).optString("emoji") + "  " + Gunah.name(built.optJSONObject(i));
                    TextView o = Ui.text(GunahActivity.this, label, 14, k.equals(base[0]) ? Ui.EMERALD : Ui.TEXT, true);
                    o.setBackground(Ui.roundStroke(k.equals(base[0]) ? Ui.alpha(Ui.EMERALD, 0.10f) : Ui.CARD2, 12, Ui.STROKE, 1));
                    o.setPadding(Ui.dp(12), Ui.dp(11), Ui.dp(12), Ui.dp(11));
                    Ui.press(o);
                    o.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Haptics.play(Haptics.SELECT);
                            base[0] = k;
                            paint.run();
                            dd[0].dismiss();
                        }
                    });
                    list.addView(o, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 6));
                }
                dd[0] = Dialogs.sheet(GunahActivity.this, L("Reminders to receive", "કયા રિમાઇન્ડર મળે", "کون سی یاد دہانیاں ملیں", "कौन-से रिमाइंडर मिलें"), list);
                dd[0].show();
            }
        });
        body.addView(pick, Ui.lp(Ui.MATCH, Ui.WRAP));
        body.addView(Ui.text(this, L("Pick a close one from the list (e.g. Swearing → Foul language) for its own ayat and hadith, or keep General tawbah.",
                "નજીકની કોઈ એક પસંદ કરો (દા.ત. ગાળ → ખરાબ ભાષા) તો તેની આયતો અને હદીસ મળશે, નહીં તો સામાન્ય તૌબા રાખો.",
                "قریب ترین کوئی ایک چنیں (مثلاً گالی → بری زبان) تو اسی کی آیات اور احادیث ملیں گی، ورنہ عام توبہ رکھیں۔",
                "क़रीब की कोई एक चुनें (जैसे गाली → बुरी ज़बान) तो उसी की आयतें और हदीसें मिलेंगी, वरना आम तौबा रखें।"), 11.5f, Ui.MUTED, false),
                Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));

        // own words
        body.addView(small(L("Your own reminder (optional)", "તમારું પોતાનું રિમાઇન્ડર (મરજિયાત)", "آپ کی اپنی یاد دہانی (اختیاری)", "आपका अपना रिमाइंडर (वैकल्पिक)")));
        final android.widget.EditText note = Ui.input(this, L("Why you want to leave it, or your plan — shown on day 7",
                "તમે તેને કેમ છોડવા માંગો છો, કે તમારો પ્લાન — 7મા દિવસે દેખાશે",
                "آپ اسے کیوں چھوڑنا چاہتے ہیں، یا آپ کا منصوبہ — ساتویں دن دکھے گا",
                "आप इसे क्यों छोड़ना चाहते हैं, या आपका प्लान — सातवें दिन दिखेगा"), cur == null ? "" : cur.optString("note"), false);
        note.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE | android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        note.setMinLines(2);
        note.setGravity(Gravity.TOP | Gravity.START);
        body.addView(note, Ui.lp(Ui.MATCH, Ui.WRAP));

        body.addView(Ui.space(this, 16));
        LinearLayout btns = Ui.row(this);
        TextView del = Ui.ghost(this, L("Delete", "કાઢી નાખો", "حذف کریں", "हटाएँ"), Ui.RED);
        TextView save = Ui.button(this, L("Save", "સેવ કરો", "محفوظ کریں", "सेव करें"), Ui.EMERALD, Ui.TEAL, 0xFFFFFFFF);
        if (cur != null) {
            btns.addView(del, Ui.weight(1));
            btns.addView(Ui.space(this, 1), Ui.lp(Ui.dp(10), 1));
        }
        btns.addView(save, Ui.weight(1));
        body.addView(btns);
        final android.app.AlertDialog d = Dialogs.sheet(this, key == null ? "➕  " + L("Add a bad habit", "ખરાબ આદત ઉમેરો", "بری عادت شامل کریں", "बुरी आदत जोड़ें")
                : "✎  " + L("Edit habit", "આદત બદલો", "عادت بدلیں", "आदत बदलें"), body);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nm = name.getText().toString().trim();
                if (nm.length() == 0) {
                    Haptics.play(Haptics.WARN);
                    name.setError(L("Write a name", "નામ લખો", "نام لکھیں", "नाम लिखें"));
                    return;
                }
                Gunah.saveCustom(GunahActivity.this, key, emoji.getText().toString(), nm, base[0], note.getText().toString());
                Haptics.play(Haptics.SUCCESS);
                d.dismiss();
                build();
            }
        });
        del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Dialogs.confirm(GunahActivity.this, L("Delete this habit?", "આ આદત કાઢી નાખશો?", "یہ عادت حذف کریں؟", "यह आदत हटाएँ?"),
                        cur.optString("emoji") + "  " + cur.optString("name"), new Runnable() {
                            @Override
                            public void run() {
                                Gunah.deleteCustom(GunahActivity.this, key);
                                if (key.equals(showKey)) showKey = null;
                                d.dismiss();
                                build();
                            }
                        });
            }
        });
        d.show();
    }

    private TextView small(String s) {
        TextView t = Ui.text(this, s, 12, Ui.SUB, true);
        t.setPadding(0, Ui.dp(14), 0, Ui.dp(6));
        return t;
    }

    private void ask(final String key, final JSONObject sin) {
        boolean running = Gunah.dayOf(this, key) > 0;
        String when = Ui.clock(Gunah.time(this));
        String msg = L("Day 1 opens now. Days 2–7 arrive every day at " + when + ".\n\nSay sincerely: Astaghfirullaha rabbi wa atubu ilayh.",
                "દિવસ 1 હમણાં ખુલશે. દિવસ 2–7 રોજ " + when + " વાગ્યે આવશે.\n\nદિલથી કહો: અસ્તગફિરુલ્લાહ રબ્બી વ અતૂબુ ઇલૈહ.",
                "دن 1 ابھی کھلے گا۔ دن 2–7 ہر روز " + when + " بجے آئیں گے۔\n\nدل سے کہیں: أستغفر الله ربي وأتوب إليه",
                "दिन 1 अभी खुलेगा। दिन 2–7 हर रोज़ " + when + " बजे आएँगे।\n\nदिल से कहें: अस्तग़फ़िरुल्लाहा रब्बी व अतूबु इलैह।");
        if (running) msg = L("This is already running. Start the 7 days again from today?\n\n", "આ પહેલેથી ચાલુ છે. આજથી ફરી 7 દિવસ શરૂ કરશો?\n\n",
                "یہ پہلے سے جاری ہے۔ آج سے پھر 7 دن شروع کریں؟\n\n", "यह पहले से चालू है। आज से फिर 7 दिन शुरू करें?\n\n") + msg;
        Dialogs.confirm(this, sin.optString("emoji") + "  " + Gunah.name(sin), msg, new Runnable() {
            @Override
            public void run() {
                Gunah.start(GunahActivity.this, key);
                Haptics.play(Haptics.SUCCESS);
                showKey = key;
                showDay = 1;
                build();
                sv.post(new Runnable() {
                    @Override
                    public void run() {
                        sv.smoothScrollTo(0, 0);
                    }
                });
            }
        });
    }
}
