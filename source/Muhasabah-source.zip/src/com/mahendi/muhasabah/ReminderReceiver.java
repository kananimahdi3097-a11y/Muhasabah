package com.mahendi.muhasabah;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

/** Alarm wake-ups and the Done / Snooze buttons on reminder notifications. */
public class ReminderReceiver extends BroadcastReceiver {
    public static final String TICK = "com.mahendi.muhasabah.REM_TICK", DONE = "com.mahendi.muhasabah.REM_DONE",
            SNOOZE = "com.mahendi.muhasabah.REM_SNOOZE";

    @Override
    public void onReceive(Context c, Intent i) {
        String a = i.getAction();
        String id = i.getStringExtra("id");
        if (DONE.equals(a) && id != null) {
            Reminders.markDone(c, id);
            Toast.makeText(c, Lang.pick("Done ✓ MashaAllah", "થઈ ગયું ✓ માશાઅલ્લાહ"), Toast.LENGTH_SHORT).show();
        } else if (SNOOZE.equals(a) && id != null) {
            Reminders.snooze(c, id);
        } else if (Gunah.ACTION_TICK.equals(a)) {
            Gunah.check(c);
            Gunah.schedule(c);
        } else {
            Reminders.check(c);
            Reminders.schedule(c);
        }
    }
}
