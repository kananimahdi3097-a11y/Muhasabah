package com.mahendi.muhasabah;

import android.app.Activity;
import android.app.TimePickerDialog;
import android.graphics.Insets;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.WindowInsets;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

/** Full detail screen for one task: live timer with Start/Pause/Reset, counters, history, reminder. */
public class TaskActivity extends Activity {
    @Override
    protected void attachBaseContext(android.content.Context b) {
        super.attachBaseContext(Ui.wrap(b));
    }

    @Override
    public boolean dispatchTouchEvent(android.view.MotionEvent ev) {
        Haptics.touch(getWindow().getDecorView(), ev);
        return super.dispatchTouchEvent(ev);
    }

    private Store s;
    private Task t;
    private LinearLayout page;
    private ScrollView sv;
    private TextView bigClock, startBtn, statusLine;
    private Views.ScoreRing ring;
    private final Handler h = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.init(this);
        s = Store.get(this);
        sv = new ScrollView(this);
        sv.setBackgroundColor(Ui.BG);
        page = Ui.col(this);
        sv.addView(page);
        setContentView(sv);
        sv.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View v, WindowInsets in) {
                Insets i = in.getInsets(WindowInsets.Type.systemBars());
                page.setPadding(Ui.dp(18) + i.left, Ui.dp(12) + i.top, Ui.dp(18) + i.right, Ui.dp(30) + i.bottom);
                return WindowInsets.CONSUMED;
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        String id = getIntent().getStringExtra("task");
        t = null;
        if (id != null) for (Task x : s.tasks()) if (x.id.equals(id)) t = x;
        if (t == null) {
            finish();
            return;
        }
        build();
        h.post(tick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        h.removeCallbacks(tick);
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (t != null && t.type == Task.MINUTES && bigClock != null) {
                long secs = Timers.secondsToday(s, t);
                bigClock.setText(Timers.clock(secs));
                float f = Math.min(1f, secs / 60f / Math.max(1, t.target));
                ring.set(Math.round(f * 100), Lang.pick("of " + Ui.hm(t.target), "/ " + Ui.hm(t.target)), false);
            }
            h.postDelayed(this, 1000);
        }
    };

    private void rebuild() {
        final int y = sv.getScrollY();
        build();
        Ui.holdScroll(sv, y);
    }

    private void build() {
        page.removeAllViews();
        String today = Store.today();
        double v = Score.liveValue(s, t, today);
        double f = t.frac(v);

        // top bar
        LinearLayout head = Ui.row(this);
        TextView back = Ui.text(this, "←", 22, Ui.TEXT, true);
        back.setGravity(Gravity.CENTER);
        back.setBackground(Ui.circle(Ui.CARD2));
        head.addView(back, Ui.lpm(Ui.dp(44), Ui.dp(44), 0, 0, 12, 0));
        Ui.press(back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View vv) {
                finish();
            }
        });
        head.addView(Ui.title(this, t.emoji + "  " + t.display(), 22), Ui.weight(1));
        TextView edit = Ui.text(this, "✎", 20, Ui.GOLD, true);
        edit.setGravity(Gravity.CENTER);
        edit.setBackground(Ui.circle(Ui.CARD2));
        head.addView(edit, Ui.lp(Ui.dp(44), Ui.dp(44)));
        head.addView(Ui.gear(this), Ui.lpm(Ui.dp(44), Ui.dp(44), 8, 0, 0, 0));
        Ui.press(edit);
        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View vv) {
                Dialogs.editTask(TaskActivity.this, t, new Runnable() {
                    @Override
                    public void run() {
                        onResume();
                    }
                });
            }
        });
        page.addView(head, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 18));

        // hero with ring
        LinearLayout hero = Ui.col(this);
        hero.setGravity(Gravity.CENTER_HORIZONTAL);
        hero.setBackground(Ui.grad3(0xFF0F766E, 0xFF064E3B, 0xFF1E1B4B, 28));
        hero.setPadding(Ui.dp(18), Ui.dp(22), Ui.dp(18), Ui.dp(22));
        ring = new Views.ScoreRing(this);
        String sub = t.type == Task.MINUTES ? Lang.pick("of " + Ui.hm(t.target), "/ " + Ui.hm(t.target)) : "%";
        ring.set((int) Math.round(f * 100), sub, true);
        hero.addView(ring, Ui.lp(Ui.dp(170), Ui.dp(170)));
        statusLine = Ui.text(this, progressLine(v), 15, Ui.GOLD_L, true);
        statusLine.setGravity(Gravity.CENTER);
        statusLine.setPadding(0, Ui.dp(12), 0, 0);
        hero.addView(statusLine);
        page.addView(hero, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 16));

        // controls
        LinearLayout ctl = Ui.card(this);
        if (t.type == Task.MINUTES) minuteControls(ctl);
        else if (t.type == Task.COUNT) countControls(ctl, v);
        else if (t.type == Task.CHECK) checkControls(ctl, v);
        else choiceControls(ctl, (int) v);
        page.addView(ctl, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 14));

        // history
        page.addView(historyCard(), Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 14));
        // reminder
        page.addView(reminderCard(), Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 14));

        // info
        int sumW = 0;
        for (Task x : s.tasksOn(Store.today())) sumW += x.weight();
        if (!t.onDate(Store.today())) sumW += t.weight();
        int maxPts = sumW == 0 ? 0 : Math.round(t.weight() * 100f / sumW);
        TextView info = Ui.text(this, Lang.pick("Worth up to " + maxPts + " of today's 100 points · importance: " + Task.IMPORTANCE_NAMES[Math.max(0, Math.min(2, t.importance - 1))],
                "આજના 100માંથી " + maxPts + " પોઇન્ટ સુધી · મહત્વ: " + new String[]{"ઓછું", "મધ્યમ", "વધારે"}[Math.max(0, Math.min(2, t.importance - 1))]),
                12.5f, Ui.MUTED, false);
        info.setGravity(Gravity.CENTER);
        page.addView(info);
    }

    private String progressLine(double v) {
        switch (t.type) {
            case Task.CHECK:
                return v >= 1 ? Lang.pick("Done for today ✓", "આજે થઈ ગયું ✓") : Lang.pick("Not done yet", "હજી બાકી");
            case Task.COUNT:
                return (int) Math.max(0, v) + " / " + t.target + (t.unit.length() > 0 ? " " + t.unit : "");
            case Task.MINUTES:
                return Ui.hm((int) v) + " / " + Ui.hm(t.target);
            default: {
                String[] o = t.displayOptions();
                int i = (int) v;
                return i >= 0 && i < o.length ? o[i] : Lang.pick("Not answered yet", "હજી જવાબ નથી");
            }
        }
    }

    private void changed() {
        Haptics.play(Haptics.TOGGLE);
        rebuild();
    }

    // ---------- MINUTES ----------
    private void minuteControls(LinearLayout c) {
        bigClock = Ui.title(this, Timers.clock(Timers.secondsToday(s, t)), 54);
        bigClock.setGravity(Gravity.CENTER);
        bigClock.setTypeface(android.graphics.Typeface.create("sans-serif-condensed", android.graphics.Typeface.BOLD));
        c.addView(bigClock, Ui.lp(Ui.MATCH, Ui.WRAP));
        boolean run = Timers.running(s, t);
        TextView live = Ui.text(this, run ? Lang.pick("● Running", "● ચાલુ છે") : Lang.pick("Paused", "થોભાવેલ"), 13, run ? Ui.EMERALD : Ui.MUTED, true);
        live.setGravity(Gravity.CENTER);
        c.addView(live, Ui.lp(Ui.MATCH, Ui.WRAP));
        if (run) live.animate().alpha(0.4f).setDuration(700).withEndAction(new Runnable() {
            @Override
            public void run() {
            }
        }).start();

        LinearLayout r = Ui.row(this);
        r.setPadding(0, Ui.dp(16), 0, 0);
        startBtn = run ? Ui.button(this, Lang.pick("❚❚  Pause", "❚❚  થોભો"), Ui.GOLD, Ui.GOLD_D, 0xFF1A1205)
                : Ui.button(this, Timers.secondsToday(s, t) > 0 ? Lang.pick("▶\uFE0E  Resume", "▶\uFE0E  ફરી શરૂ") : Lang.pick("▶\uFE0E  Start", "▶\uFE0E  શરૂ"), Ui.EMERALD, Ui.TEAL, 0xFFFFFFFF);
        TextView reset = Ui.ghost(this, Lang.pick("↺  Reset", "↺  રીસેટ"), Ui.RED);
        r.addView(startBtn, Ui.weight(1.4f));
        r.addView(Ui.space(this, 1), Ui.lp(Ui.dp(10), 1));
        r.addView(reset, Ui.weight(1));
        c.addView(r);
        startBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean was = Timers.running(s, t);
                Timers.toggle(s, t);
                Haptics.play(was ? Haptics.STOP : Haptics.START);
                rebuild();
            }
        });
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Dialogs.confirm(TaskActivity.this, Lang.pick("Reset today's time?", "આજનો સમય રીસેટ કરવો?"),
                        Lang.pick("This sets today's minutes for this task back to 0.", "આ કામની આજની મિનિટ 0 થઈ જશે."), new Runnable() {
                            @Override
                            public void run() {
                                Timers.reset(s, t);
                                rebuild();
                            }
                        });
            }
        });
        quickRow(c, new int[]{-5, 5, 10, 15, 30}, Lang.pick(" min", " મિ"));
        setExactRow(c, Lang.pick("Set today's total minutes", "આજની કુલ મિનિટ સેટ કરો"));
    }

    // ---------- COUNT ----------
    private void countControls(LinearLayout c, double v) {
        bigClock = null;
        TextView big = Ui.title(this, String.valueOf((int) Math.max(0, v)), 60);
        big.setGravity(Gravity.CENTER);
        c.addView(big, Ui.lp(Ui.MATCH, Ui.WRAP));
        LinearLayout r = Ui.row(this);
        r.setPadding(0, Ui.dp(14), 0, 0);
        TextView minus = Ui.ghost(this, "−  1", Ui.TEXT), plus = Ui.button(this, "+  1", Ui.EMERALD, Ui.TEAL, 0xFFFFFFFF);
        minus.setTextSize(20);
        plus.setTextSize(20);
        r.addView(minus, Ui.weight(1));
        r.addView(Ui.space(this, 1), Ui.lp(Ui.dp(10), 1));
        r.addView(plus, Ui.weight(1.4f));
        c.addView(r);
        minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View vv) {
                s.setValue(Store.today(), t, Math.max(0, s.value(Store.today(), t) - 1));
                changed();
            }
        });
        plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View vv) {
                s.setValue(Store.today(), t, Math.max(0, s.value(Store.today(), t)) + 1);
                changed();
            }
        });
        quickRow(c, new int[]{2, 5, 10, 20}, "");
        setExactRow(c, Lang.pick("Set today's count", "આજનો કુલ આંકડો સેટ કરો"));
    }

    // ---------- CHECK ----------
    private void checkControls(LinearLayout c, double v) {
        bigClock = null;
        final boolean done = v >= 1;
        TextView b = done ? Ui.ghost(this, Lang.pick("↺  Mark as not done", "↺  બાકી તરીકે માર્ક કરો"), Ui.SUB)
                : Ui.button(this, Lang.pick("✓  Mark done", "✓  થઈ ગયું"), Ui.EMERALD, Ui.TEAL, 0xFFFFFFFF);
        b.setTextSize(18);
        c.addView(b, Ui.lp(Ui.MATCH, Ui.WRAP));
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View vv) {
                s.setValue(Store.today(), t, done ? 0 : 1);
                changed();
            }
        });
    }

    // ---------- CHOICE ----------
    private void choiceControls(LinearLayout c, int cur) {
        bigClock = null;
        String[] o = t.displayOptions();
        for (int k = 0; k < t.options.length; k++) {
            final int idx = k;
            LinearLayout r = Ui.row(this);
            r.setPadding(Ui.dp(16), Ui.dp(14), Ui.dp(16), Ui.dp(14));
            boolean sel = k == cur;
            r.setBackground(sel ? Ui.roundStroke(Ui.alpha(Ui.GOLD, 0.15f), 16, Ui.GOLD, 1.2f) : Ui.roundStroke(Ui.CARD2, 16, Ui.STROKE, 1));
            r.addView(Ui.text(this, (sel ? "●  " : "○  ") + (k < o.length ? o[k] : t.options[k]), 16, Ui.TEXT, true), Ui.weight(1));
            int sc = k < t.optionScores.length ? t.optionScores[k] : 0;
            r.addView(Ui.pill(this, sc + "%", Ui.alpha(sc >= 70 ? Ui.EMERALD : sc >= 40 ? Ui.GOLD : Ui.RED, 0.2f),
                    sc >= 70 ? Ui.EMERALD : sc >= 40 ? Ui.GOLD : Ui.RED));
            c.addView(r, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 8));
            Ui.press(r);
            r.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View vv) {
                    s.setValue(Store.today(), t, idx);
                    changed();
                }
            });
        }
    }

    private void quickRow(LinearLayout c, int[] vals, final String unit) {
        LinearLayout r = Ui.row(this);
        r.setPadding(0, Ui.dp(12), 0, 0);
        for (int k = 0; k < vals.length; k++) {
            final int q = vals[k];
            TextView b = Ui.text(this, (q > 0 ? "+" : "−") + Math.abs(q) + unit, 13.5f, q > 0 ? Ui.GOLD_L : Ui.SUB, true);
            b.setGravity(Gravity.CENTER);
            b.setPadding(0, Ui.dp(10), 0, Ui.dp(10));
            b.setBackground(Ui.roundStroke(Ui.CARD2, 12, Ui.STROKE, 1));
            Ui.press(b);
            LinearLayout.LayoutParams p = Ui.weight(1);
            p.setMargins(k == 0 ? 0 : Ui.dp(3), 0, k == vals.length - 1 ? 0 : Ui.dp(3), 0);
            r.addView(b, p);
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String d = Store.today();
                    s.setValue(d, t, Math.max(0, Math.max(0, s.value(d, t)) + q));
                    changed();
                }
            });
        }
        c.addView(r);
    }

    private void setExactRow(LinearLayout c, String label) {
        LinearLayout r = Ui.row(this);
        r.setPadding(0, Ui.dp(12), 0, 0);
        final EditText e = Ui.input(this, label, "", true);
        r.addView(e, Ui.weight(1));
        TextView ok = Ui.ghost(this, Lang.pick("Set", "સેટ"), Ui.GOLD);
        r.addView(ok, Ui.lpm(Ui.WRAP, Ui.WRAP, 8, 0, 0, 0));
        c.addView(r);
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    int n = Integer.parseInt(e.getText().toString().trim());
                    s.setTimer(t.id, 0);
                    s.setValue(Store.today(), t, Math.max(0, n));
                    changed();
                } catch (Exception ex) {
                    Toast.makeText(TaskActivity.this, Lang.pick("Type a number", "આંકડો લખો"), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // ---------- history ----------
    private View historyCard() {
        LinearLayout c = Ui.card(this);
        int streak = 0;
        for (int k = 0; k > -365; k--) {
            if (t.frac(s.value(Store.date(k), t)) >= 0.999) streak++;
            else if (k < 0) break;
        }
        LinearLayout r = Ui.row(this);
        r.addView(Ui.text(this, Lang.pick("Last 14 days", "છેલ્લા 14 દિવસ"), 15, Ui.TEXT, true), Ui.weight(1));
        r.addView(Ui.pill(this, "🔥 " + streak, Ui.alpha(Ui.ORANGE, 0.15f), Ui.ORANGE));
        c.addView(r);
        Views.Bars bars = new Views.Bars(this);
        int[] vals = new int[14];
        String[] labs = new String[14];
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, -13);
        for (int k = 0; k < 14; k++) {
            vals[k] = (int) Math.round(t.frac(k == 13 ? Score.liveValue(s, t, Store.today()) : s.value(Store.date(k - 13), t)) * 100);
            labs[k] = String.valueOf(cal.get(Calendar.DAY_OF_MONTH));
            cal.add(Calendar.DAY_OF_YEAR, 1);
        }
        bars.set(vals, labs);
        c.addView(bars, Ui.lpm(Ui.MATCH, Ui.dp(160), 0, 10, 0, 0));
        return c;
    }

    // ---------- reminder ----------
    private View reminderCard() {
        LinearLayout c = Ui.card(this);
        final Reminders.R existing = Reminders.forTask(this, t.id);
        LinearLayout r = Ui.row(this);
        LinearLayout col = Ui.col(this);
        col.addView(Ui.text(this, Lang.pick("⏰  Reminder for this task", "⏰  આ કામ માટે રિમાઇન્ડર"), 15, Ui.TEXT, true));
        String desc = existing == null || !existing.active ? Lang.pick("Off", "બંધ")
                : Ui.clock(existing.time) + " · " + Reminders.days(existing.days) + " · " + Lang.pick("repeats ", "") + existing.repeat
                + Lang.pick("× every " + existing.interval + " min until Done", "× દર " + existing.interval + " મિ, 'થઈ ગયું' સુધી");
        col.addView(Ui.text(this, desc, 12.5f, Ui.SUB, false));
        r.addView(col, Ui.weight(1));
        final Switch sw = new Switch(this);
        sw.setChecked(existing != null && existing.active);
        r.addView(sw);
        c.addView(r);
        sw.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton b, boolean on) {
                Haptics.play(Haptics.TOGGLE);
                if (on) {
                    final Reminders.R rr = existing != null ? existing : Reminders.newDefault(TaskActivity.this);
                    rr.taskId = t.id;
                    rr.title = t.emoji + " " + t.display();
                    new TimePickerDialog(TaskActivity.this, android.R.style.Theme_DeviceDefault_Dialog_Alert, new TimePickerDialog.OnTimeSetListener() {
                        @Override
                        public void onTimeSet(TimePicker view, int hh, int mm) {
                            rr.time = hh * 60 + mm;
                            rr.active = true;
                            Reminders.upsert(TaskActivity.this, rr);
                            rebuild();
                        }
                    }, rr.time / 60, rr.time % 60, false).show();
                } else if (existing != null) {
                    existing.active = false;
                    Reminders.upsert(TaskActivity.this, existing);
                    rebuild();
                }
            }
        });
        if (existing != null && existing.active) {
            TextView ed = Ui.ghost(this, Lang.pick("Edit reminder", "રિમાઇન્ડર બદલો"), Ui.GOLD);
            c.addView(ed, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
            ed.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ReminderUi.edit(TaskActivity.this, existing, new Runnable() {
                        @Override
                        public void run() {
                            rebuild();
                        }
                    });
                }
            });
        }
        return c;
    }
}
