package com.mahendi.muhasabah;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import org.json.JSONObject;

import java.util.Random;

/** Notification channels, posting, and the motivational line bank. */
public final class Notify {
    public static final String CH_NUDGE = "nudges", CH_DAILY = "daily", CH_SERVICE = "guard";
    private static final Random RND = new Random();

    public static final String[] EN_SCROLL = {
            "Your future self is watching. Close the app.",
            "You set this limit for a reason. Respect it.",
            "Nothing in that feed will build your business.",
            "Every minute here is a minute taken from your goals.",
            "Scroll less. Build more.",
            "One reel more never ends. Stop at this one."};
    public static final String[] GU_SCROLL = {
            "Bas kar bhai, phone muki de! Kaam baaki che.",
            "Reels thi kai nai male bhai. Kaam thi j male.",
            "Ek ek minute no hisaab aapvano che, bhai.",
            "Bhai, aa time pacho nai aave. Uth ane kaam kar."};
    public static final String[] GU_BAD_DAY = {
            "Bhai, aaje kai j nathi karyu! Have to kari le bhai — Allah ne javab aapvano che.",
            "Have to padhi le bhai. Samay pacho nai aave.",
            "Kaal karta aaje vadhu saru karvanu che — yaad che ne?",
            "Hajji pan time che bhai. Ek kaam to puru kar!"};
    public static final String[] GU_SLEEP = {
            "Sui ja bhai, kaale Fajr che.",
            "Phone muki de ane sui ja bhai. Kaale nava jor thi."};
    public static final String[] GU_WAKE = {
            "Uth ja bhai! Divas sharu thai gayo che.",
            "Bahu suyo bhai — have kaam par lagi ja."};

    public static String any(String[] a) {
        return a[RND.nextInt(a.length)];
    }

    public static void channels(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        NotificationChannel n = new NotificationChannel(CH_NUDGE, "Habit nudges", NotificationManager.IMPORTANCE_HIGH);
        n.setDescription("Alerts when you cross your screen-time limits or stay up late");
        n.enableVibration(true);
        nm.createNotificationChannel(n);
        NotificationChannel d = new NotificationChannel(CH_DAILY, "Daily check-ins", NotificationManager.IMPORTANCE_DEFAULT);
        d.setDescription("Morning start, evening 'better than yesterday' check");
        nm.createNotificationChannel(d);
        NotificationChannel s = new NotificationChannel(CH_SERVICE, "Guardian (always on)", NotificationManager.IMPORTANCE_MIN);
        s.setDescription("Keeps Muhasabah watching your timepass apps");
        s.setShowBadge(false);
        nm.createNotificationChannel(s);
    }

    public static PendingIntent openApp(Context c, int req) {
        Intent i = new Intent(c, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(c, req, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    /** Wisdom text formatted for a notification body. */
    public static String wisdomText(JSONObject w) {
        if (w == null || w.optString("en").length() == 0) return "";
        String ar = w.optString("ar");
        String s = (ar.length() > 0 ? ar + "\n" : "") + "“" + Lang.both(w) + "”";
        String src = w.optString("src");
        if (src.length() > 0) s += "\n— " + src;
        return s;
    }

    public static void post(Context c, int id, String channel, String title, String line, JSONObject wisdom) {
        Lang.init(c);
        title = Lang.tr(title);
        line = Lang.tr(line);
        String body = line;
        String wt = wisdomText(wisdom);
        String big = wt.length() == 0 ? line : line + "\n\n" + wt;
        Notification.Builder b = new Notification.Builder(c, channel)
                .setSmallIcon(R.drawable.ic_stat)
                .setColor(Ui.GOLD)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(big))
                .setContentIntent(openApp(c, id))
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_REMINDER);
        try {
            c.getSystemService(NotificationManager.class).notify(id, b.build());
        } catch (SecurityException ignored) {
            // notification permission not granted yet
        }
    }

    /** Like post(), but tapping opens the given screen. */
    public static void postIntent(Context c, int id, String channel, String title, String line, Intent open) {
        Lang.init(c);
        title = Lang.tr(title);
        line = Lang.tr(line);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent pi = PendingIntent.getActivity(c, id, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = new Notification.Builder(c, channel)
                .setSmallIcon(R.drawable.ic_stat)
                .setColor(Ui.GOLD)
                .setContentTitle(title)
                .setContentText(line)
                .setStyle(new Notification.BigTextStyle().bigText(line))
                .setContentIntent(pi)
                .setAutoCancel(true);
        try {
            c.getSystemService(NotificationManager.class).notify(id, b.build());
        } catch (SecurityException ignored) {
        }
    }

    public static Notification guardian(Context c, String text) {
        return new Notification.Builder(c, CH_SERVICE)
                .setSmallIcon(R.drawable.ic_stat)
                .setColor(Ui.EMERALD)
                .setContentTitle("Muhasabah is guarding your time")
                .setContentText(text)
                .setContentIntent(openApp(c, 1))
                .setOngoing(true)
                .setShowWhen(false)
                .build();
    }
}
