package com.mahendi.muhasabah;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Insets;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;

/** 🏆 Compete with friends: a small group leaderboard of daily scores (today / this week). */
public class CompeteActivity extends Activity {
    @Override
    protected void attachBaseContext(Context b) {
        super.attachBaseContext(Ui.wrap(b));
    }

    @Override
    public boolean dispatchTouchEvent(android.view.MotionEvent ev) {
        Haptics.touch(getWindow().getDecorView(), ev);
        return super.dispatchTouchEvent(ev);
    }

    private LinearLayout page;
    private Store s;
    private boolean week;
    private TextView status;

    private static String L(String en, String gu, String ur, String hi) {
        return HadithCard.label(en, gu, ur, hi);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.init(this);
        Lang.init(this);
        s = Store.get(this);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Ui.BG);
        page = Ui.col(this);
        sv.addView(page);
        setContentView(sv);
        sv.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View v, WindowInsets in) {
                Insets i = in.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.ime());
                page.setPadding(Ui.dp(18) + i.left, Ui.dp(12) + i.top, Ui.dp(18) + i.right, Ui.dp(30) + i.bottom);
                return WindowInsets.CONSUMED;
            }
        });
        build();
        refresh(true);
    }

    private void refresh(boolean force) {
        if (!Compete.inRoom(s)) return;
        if (status != null) status.setText(L("Updating…", "અપડેટ થાય છે…", "اپ ڈیٹ ہو رہا ہے…", "अपडेट हो रहा है…"));
        Compete.sync(this, force, new Compete.Done() {
            @Override
            public void done(final boolean ok) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing()) return;
                        build();
                        if (!ok && status != null)
                            status.setText(L("⚠️ Couldn't reach the internet — showing the last update.", "⚠️ ઇન્ટરનેટ ન મળ્યું — છેલ્લું અપડેટ બતાવે છે.",
                                    "⚠️ انٹرنیٹ نہیں ملا — آخری اپ ڈیٹ دکھا رہے ہیں۔", "⚠️ इंटरनेट नहीं मिला — आख़िरी अपडेट दिखा रहे हैं।"));
                    }
                });
            }
        });
    }

    private void build() {
        page.removeAllViews();
        LinearLayout head = Ui.row(this);
        TextView back = Ui.text(this, "←", 22, Ui.TEXT, true);
        back.setGravity(Gravity.CENTER);
        back.setIncludeFontPadding(false);
        back.setBackground(Ui.circle(Ui.CARD2));
        head.addView(back, Ui.lpm(Ui.dp(44), Ui.dp(44), 0, 0, 12, 0));
        Ui.press(back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        TextView title = Ui.title(this, L("Compete with friends", "મિત્રો સાથે સ્પર્ધા", "دوستوں سے مقابلہ", "दोस्तों से मुक़ाबला"), 24);
        Ui.fit(title, 1, 16);
        head.addView(title, Ui.weight(1));
        page.addView(head, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 14));

        if (!Compete.inRoom(s)) start();
        else board();
    }

    // ---------------- no group yet ----------------
    private void start() {
        LinearLayout hero = Ui.col(this);
        hero.setBackground(Ui.grad(0xFF1E3A8A, 0xFF4C1D95, 24, android.graphics.drawable.GradientDrawable.Orientation.TL_BR));
        hero.setPadding(Ui.dp(18), Ui.dp(18), Ui.dp(18), Ui.dp(18));
        hero.addView(Ui.text(this, "🏆", 34, Ui.TEXT, false));
        hero.addView(Ui.title(this, L("Race your friends to a better day", "મિત્રો સાથે બહેતર દિવસની દોડ", "دوستوں کے ساتھ بہتر دن کی دوڑ", "दोस्तों के साथ बेहतर दिन की दौड़"), 20));
        TextView sub = Ui.text(this, L("Make a group, share its code with friends who use Muhasabah, and see each other's daily score.",
                "ગ્રુપ બનાવો, Muhasabah વાપરતા મિત્રોને તેનો કોડ મોકલો, અને એકબીજાનો રોજનો સ્કોર જુઓ.",
                "گروپ بنائیں، Muhasabah استعمال کرنے والے دوستوں کو اس کا کوڈ بھیجیں، اور ایک دوسرے کا روزانہ اسکور دیکھیں۔",
                "ग्रुप बनाएँ, Muhasabah इस्तेमाल करने वाले दोस्तों को उसका कोड भेजें, और एक-दूसरे का रोज़ का स्कोर देखें।"), 13.5f, Ui.alpha(0xFFFFFFFF, 0.85f), false);
        sub.setPadding(0, Ui.dp(6), 0, 0);
        hero.addView(sub);
        page.addView(hero, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 14));

        page.addView(profileCard(), Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 14));

        TextView create = Ui.button(this, "➕  " + L("Create a group", "ગ્રુપ બનાવો", "گروپ بنائیں", "ग्रुप बनाएँ"), Ui.EMERALD, Ui.TEAL, 0xFFFFFFFF);
        page.addView(create, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 10));
        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Haptics.play(Haptics.SUCCESS);
                Compete.join(CompeteActivity.this, Compete.newCode());
                build();
                refresh(true);
                share();
            }
        });

        LinearLayout jc = Ui.card(this);
        jc.addView(Ui.text(this, L("Have a code from a friend?", "મિત્રનો કોડ છે?", "دوست کا کوڈ ہے؟", "दोस्त का कोड है?"), 15, Ui.TEXT, true));
        final EditText code = Ui.input(this, "XXXX-XXXX-XXXX", "", false);
        code.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS | android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        code.setGravity(Gravity.CENTER);
        code.setLetterSpacing(0.1f);
        String clip = clipCode();
        if (clip != null) code.setText(clip);
        jc.addView(code, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 10, 0, 10));
        TextView join = Ui.button(this, L("Join group", "ગ્રુપમાં જોડાઓ", "گروپ میں شامل ہوں", "ग्रुप में जुड़ें"), Ui.BLUE, 0xFF4338CA, 0xFFFFFFFF);
        jc.addView(join, Ui.lp(Ui.MATCH, Ui.WRAP));
        join.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String c = Compete.clean(code.getText().toString());
                if (c == null) {
                    Haptics.play(Haptics.WARN);
                    code.setError(L("That code doesn't look right (12 letters/numbers)", "આ કોડ બરાબર નથી લાગતો (12 અક્ષર/અંક)",
                            "یہ کوڈ درست نہیں لگتا (12 حروف/اعداد)", "यह कोड सही नहीं लगता (12 अक्षर/अंक)"));
                    return;
                }
                Haptics.play(Haptics.SUCCESS);
                Compete.join(CompeteActivity.this, c);
                build();
                refresh(true);
            }
        });
        page.addView(jc, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 14));
        page.addView(privacyNote());
    }

    /** Your name and emoji as friends see them. */
    private View profileCard() {
        LinearLayout c = Ui.card(this);
        c.addView(Ui.text(this, L("How friends see you", "મિત્રોને તમે કેવા દેખાશો", "دوست آپ کو کیسے دیکھیں گے", "दोस्त आपको कैसे देखेंगे"), 12, Ui.SUB, true));
        LinearLayout r = Ui.row(this);
        final EditText em = Ui.input(this, "🙂", Compete.emoji(s), false);
        em.setGravity(Gravity.CENTER);
        final EditText nm = Ui.input(this, L("Your name", "તમારું નામ", "آپ کا نام", "आपका नाम"), s.s(Store.K_NAME, "Mahdi"), false);
        r.addView(em, Ui.lp(Ui.dp(58), Ui.WRAP));
        r.addView(Ui.space(this, 1), Ui.lp(Ui.dp(8), 1));
        r.addView(nm, Ui.weight(1));
        c.addView(r, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        android.text.TextWatcher w = new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence a, int b, int c2, int d) {
            }

            public void onTextChanged(CharSequence a, int b, int c2, int d) {
            }

            public void afterTextChanged(android.text.Editable e) {
                String n = nm.getText().toString().trim();
                if (n.length() > 0) s.put(Store.K_NAME, n.length() > 24 ? n.substring(0, 24) : n);
                String e2 = em.getText().toString().trim();
                s.put(Compete.K_EMOJI, e2.length() == 0 ? "🙂" : e2.length() > 8 ? e2.substring(0, 8) : e2);
            }
        };
        nm.addTextChangedListener(w);
        em.addTextChangedListener(w);
        return c;
    }

    private TextView privacyNote() {
        TextView t = Ui.text(this, L("🔒 Shared with your group only: your name, emoji, daily score (0–100), tasks done today and streak. Never your tasks, apps, reels or anything else. Updates are encrypted with the group code and passed through a free relay (ntfy.sh), which can't read them. Needs internet.",
                "🔒 ફક્ત તમારા ગ્રુપ સાથે: તમારું નામ, ઇમોજી, રોજનો સ્કોર (0–100), આજના પૂરા કામની સંખ્યા અને સ્ટ્રીક. તમારા કામ, ઍપ, રીલ્સ કે બીજું કંઈ ક્યારેય નહીં. અપડેટ ગ્રુપ કોડથી એન્ક્રિપ્ટ થાય છે અને ફ્રી રિલે (ntfy.sh) મારફતે જાય છે, જે તેને વાંચી શકતું નથી. ઇન્ટરનેટ જોઈએ.",
                "🔒 صرف آپ کے گروپ کے ساتھ: آپ کا نام، ایموجی، روزانہ اسکور (0–100)، آج کے مکمل کام کی تعداد اور اسٹریک۔ آپ کے کام، ایپس، ریلز یا کچھ اور کبھی نہیں۔ اپ ڈیٹ گروپ کوڈ سے انکرپٹ ہوتے ہیں اور ایک مفت ریلے (ntfy.sh) سے گزرتے ہیں، جو انہیں پڑھ نہیں سکتا۔ انٹرنیٹ ضروری ہے۔",
                "🔒 सिर्फ़ आपके ग्रुप के साथ: आपका नाम, इमोजी, रोज़ का स्कोर (0–100), आज पूरे हुए कामों की गिनती और स्ट्रीक। आपके काम, ऐप, रील्स या कुछ और कभी नहीं। अपडेट ग्रुप कोड से एन्क्रिप्ट होते हैं और एक मुफ़्त रिले (ntfy.sh) से गुज़रते हैं, जो उन्हें पढ़ नहीं सकता। इंटरनेट ज़रूरी है।"),
                11.5f, Ui.MUTED, false);
        t.setPadding(Ui.dp(2), Ui.dp(4), Ui.dp(2), 0);
        return t;
    }

    // ---------------- the leaderboard ----------------
    private void board() {
        // tabs
        LinearLayout tabs = Ui.row(this);
        final String[] names = {L("Today", "આજે", "آج", "आज"), L("This week", "આ અઠવાડિયું", "یہ ہفتہ", "यह हफ़्ता")};
        for (int k = 0; k < 2; k++) {
            final boolean wk = k == 1;
            boolean on = wk == week;
            TextView t = Ui.text(this, names[k], 14, on ? 0xFFFFFFFF : Ui.SUB, true);
            t.setGravity(Gravity.CENTER);
            t.setBackground(on ? Ui.grad(Ui.BLUE, 0xFF4338CA, 50, android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT)
                    : Ui.roundStroke(Ui.CARD, 50, Ui.STROKE, 1));
            t.setPadding(Ui.dp(12), Ui.dp(10), Ui.dp(12), Ui.dp(10));
            Ui.press(t);
            t.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Haptics.play(Haptics.SELECT);
                    week = wk;
                    build();
                }
            });
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, Ui.WRAP, 1f);
            if (k == 0) p.setMargins(0, 0, Ui.dp(8), 0);
            tabs.addView(t, p);
        }
        page.addView(tabs, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));

        List<Compete.Row> rows = Compete.board(this, week);
        // podium-style summary of my place
        int myRank = 1;
        for (int i = 0; i < rows.size(); i++) if (rows.get(i).mine) myRank = i + 1;
        LinearLayout hero = Ui.col(this);
        hero.setBackground(Ui.grad(0xFF065F46, 0xFF1E3A8A, 24, android.graphics.drawable.GradientDrawable.Orientation.TL_BR));
        hero.setPadding(Ui.dp(18), Ui.dp(16), Ui.dp(18), Ui.dp(16));
        String medal = myRank == 1 ? "🥇" : myRank == 2 ? "🥈" : myRank == 3 ? "🥉" : "🏅";
        TextView big = Ui.title(this, medal + "  #" + myRank + L(" of " + rows.size(), " / " + rows.size(), " / " + rows.size(), " / " + rows.size()), 26);
        big.setTextColor(0xFFFFFFFF);
        Ui.fit(big, 1, 16);
        hero.addView(big);
        String line = rows.size() <= 1
                ? L("Share the code below — your friends will appear here.", "નીચેનો કોડ મોકલો — તમારા મિત્રો અહીં દેખાશે.",
                "نیچے والا کوڈ بھیجیں — آپ کے دوست یہاں نظر آئیں گے۔", "नीचे वाला कोड भेजें — आपके दोस्त यहाँ दिखेंगे।")
                : myRank == 1 ? L("You're leading. Keep it up, in shaa Allah!", "તમે આગળ છો. ઇન્શાઅલ્લાહ આમ જ ચાલુ રાખો!", "آپ آگے ہیں۔ ان شاء اللہ اسی طرح جاری رکھیں!", "आप आगे हैं। इंशाअल्लाह ऐसे ही जारी रखें!")
                : L((week ? rows.get(myRank - 2).week - rows.get(myRank - 1).week : rows.get(myRank - 2).today - rows.get(myRank - 1).today) + " points to pass " + rows.get(myRank - 2).name,
                (week ? rows.get(myRank - 2).week - rows.get(myRank - 1).week : rows.get(myRank - 2).today - rows.get(myRank - 1).today) + " પોઈન્ટ અને તમે " + rows.get(myRank - 2).name + " થી આગળ",
                (week ? rows.get(myRank - 2).week - rows.get(myRank - 1).week : rows.get(myRank - 2).today - rows.get(myRank - 1).today) + " پوائنٹ اور آپ " + rows.get(myRank - 2).name + " سے آگے",
                (week ? rows.get(myRank - 2).week - rows.get(myRank - 1).week : rows.get(myRank - 2).today - rows.get(myRank - 1).today) + " पॉइंट और आप " + rows.get(myRank - 2).name + " से आगे");
        TextView ln = Ui.text(this, line, 13.5f, Ui.alpha(0xFFFFFFFF, 0.88f), false);
        ln.setPadding(0, Ui.dp(4), 0, 0);
        hero.addView(ln);
        page.addView(hero, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));

        LinearLayout list = Ui.card(this);
        for (int i = 0; i < rows.size(); i++) {
            if (i > 0) {
                View sep = new View(this);
                sep.setBackgroundColor(Ui.STROKE);
                list.addView(sep, Ui.lpm(Ui.MATCH, 1, 0, 6, 0, 6));
            }
            list.addView(row(i + 1, rows.get(i)));
        }
        page.addView(list, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 8));
        status = Ui.text(this, L("Updates every ~30 min while the app runs. Pull the latest:", "એપ ચાલુ હોય ત્યારે લગભગ દર 30 મિનિટે અપડેટ. હમણાં જ મેળવો:",
                "ایپ چلتے وقت تقریباً ہر 30 منٹ میں اپ ڈیٹ۔ ابھی تازہ کریں:", "ऐप चलते समय लगभग हर 30 मिनट में अपडेट। अभी ताज़ा करें:"), 11.5f, Ui.MUTED, false);
        page.addView(status, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 8));
        TextView upd = Ui.ghost(this, "🔄  " + L("Refresh", "રિફ્રેશ", "تازہ کریں", "रिफ़्रेश"), Ui.BLUE);
        page.addView(upd, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 16));
        upd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Haptics.play(Haptics.REFRESH);
                refresh(true);
            }
        });

        // invite
        LinearLayout ic = Ui.card(this);
        ic.addView(Ui.text(this, L("Group code", "ગ્રુપ કોડ", "گروپ کوڈ", "ग्रुप कोड"), 12, Ui.SUB, true));
        TextView code = Ui.title(this, Compete.room(s), 24);
        code.setTextColor(Ui.GOLD);
        code.setLetterSpacing(0.08f);
        code.setGravity(Gravity.CENTER);
        code.setPadding(0, Ui.dp(8), 0, Ui.dp(10));
        Ui.fit(code, 1, 14);
        ic.addView(code, Ui.lp(Ui.MATCH, Ui.WRAP));
        LinearLayout br = Ui.row(this);
        TextView shareB = Ui.button(this, "📤  " + L("Invite", "આમંત્રણ", "دعوت", "न्योता"), Ui.EMERALD, Ui.TEAL, 0xFFFFFFFF);
        TextView copy = Ui.ghost(this, "📋  " + L("Copy", "કૉપી", "کاپی", "कॉपी"), Ui.GOLD);
        br.addView(shareB, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        br.addView(Ui.space(this, 1), Ui.lp(Ui.dp(10), 1));
        br.addView(copy, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        ic.addView(br);
        shareB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                share();
            }
        });
        copy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ClipboardManager cm = getSystemService(ClipboardManager.class);
                cm.setPrimaryClip(ClipData.newPlainText("Muhasabah group", Compete.room(s)));
                Haptics.play(Haptics.SUCCESS);
            }
        });
        page.addView(ic, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 14));

        page.addView(profileCard(), Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 14));
        page.addView(privacyNote(), Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 16));

        TextView leave = Ui.ghost(this, L("Leave this group", "આ ગ્રુપ છોડો", "یہ گروپ چھوڑیں", "यह ग्रुप छोड़ें"), Ui.RED);
        page.addView(leave, Ui.lp(Ui.MATCH, Ui.WRAP));
        leave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Dialogs.confirm(CompeteActivity.this, L("Leave the group?", "ગ્રુપ છોડશો?", "گروپ چھوڑیں؟", "ग्रुप छोड़ें?"),
                        L("Your friends will no longer see your score. You can join again with the same code.",
                                "તમારા મિત્રો હવે તમારો સ્કોર નહીં જુએ. એ જ કોડથી ફરી જોડાઈ શકો છો.",
                                "آپ کے دوست اب آپ کا اسکور نہیں دیکھیں گے۔ اسی کوڈ سے دوبارہ شامل ہو سکتے ہیں۔",
                                "आपके दोस्त अब आपका स्कोर नहीं देखेंगे। उसी कोड से फिर जुड़ सकते हैं।"), new Runnable() {
                            @Override
                            public void run() {
                                Compete.leave(CompeteActivity.this);
                                build();
                            }
                        });
            }
        });
    }

    private View row(int rank, Compete.Row r) {
        LinearLayout row = Ui.row(this);
        row.setPadding(Ui.dp(8), Ui.dp(8), Ui.dp(8), Ui.dp(8));
        if (r.mine) row.setBackground(Ui.round(Ui.alpha(Ui.GOLD, 0.10f), 14));
        TextView rk = Ui.text(this, rank <= 3 ? (rank == 1 ? "🥇" : rank == 2 ? "🥈" : "🥉") : String.valueOf(rank), rank <= 3 ? 20 : 15, Ui.SUB, true);
        rk.setGravity(Gravity.CENTER);
        row.addView(rk, Ui.lp(Ui.dp(34), Ui.WRAP));
        TextView em = Ui.text(this, r.emoji, 22, Ui.TEXT, false);
        em.setGravity(Gravity.CENTER);
        row.addView(em, Ui.lpm(Ui.dp(36), Ui.WRAP, 2, 0, 8, 0));
        LinearLayout mid = Ui.col(this);
        TextView nm = Ui.text(this, r.name + (r.mine ? L("  (you)", "  (તમે)", "  (آپ)", "  (आप)") : ""), 15, r.mine ? Ui.GOLD : Ui.TEXT, true);
        Ui.fit(nm, 1, 11);
        mid.addView(nm);
        String sub = "🔥 " + r.streak + (r.total > 0 ? "   ✅ " + r.done + "/" + r.total : "") + (r.mine ? "" : "   · " + Compete.ago(r.at));
        TextView sb = Ui.text(this, sub, 11.5f, Ui.SUB, false);
        Ui.fit(sb, 1, 9);
        mid.addView(sb);
        row.addView(mid, Ui.weight(1));
        TextView sc = Ui.title(this, String.valueOf(week ? r.week : r.today), 22);
        sc.setTextColor(rank == 1 ? Ui.GOLD : Ui.TEXT);
        sc.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        row.addView(sc, Ui.lpm(Ui.WRAP, Ui.WRAP, 8, 0, 0, 0));
        return row;
    }

    private void share() {
        String code = Compete.room(s);
        String msg = L("Let's compete on Muhasabah 🏆\nOpen Muhasabah → 🏆 Compete with friends → Join, and enter this code:\n\n" + code,
                "ચાલો Muhasabah પર સ્પર્ધા કરીએ 🏆\nMuhasabah ખોલો → 🏆 મિત્રો સાથે સ્પર્ધા → જોડાઓ, અને આ કોડ લખો:\n\n" + code,
                "آئیں Muhasabah پر مقابلہ کریں 🏆\nMuhasabah کھولیں → 🏆 دوستوں سے مقابلہ → شامل ہوں، اور یہ کوڈ لکھیں:\n\n" + code,
                "चलो Muhasabah पर मुक़ाबला करें 🏆\nMuhasabah खोलें → 🏆 दोस्तों से मुक़ाबला → जुड़ें, और यह कोड लिखें:\n\n" + code);
        Intent i = new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, msg);
        try {
            startActivity(Intent.createChooser(i, L("Invite friends", "મિત્રોને આમંત્રણ", "دوستوں کو دعوت", "दोस्तों को न्योता")));
        } catch (Exception ignored) {
        }
    }

    /** A group code sitting in the clipboard (e.g. copied from WhatsApp). */
    private String clipCode() {
        try {
            ClipboardManager cm = getSystemService(ClipboardManager.class);
            if (cm == null || !cm.hasPrimaryClip()) return null;
            CharSequence t = cm.getPrimaryClip().getItemAt(0).coerceToText(this);
            if (t == null) return null;
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("[A-Za-z2-9]{4}-[A-Za-z2-9]{4}-[A-Za-z2-9]{4}").matcher(t);
            return m.find() ? Compete.clean(m.group()) : null;
        } catch (Exception e) {
            return null;
        }
    }
}
