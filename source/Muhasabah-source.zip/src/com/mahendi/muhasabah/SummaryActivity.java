package com.mahendi.muhasabah;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.graphics.Insets;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.widget.DatePicker;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** Day / Week / Month summary of your improvement — pick any day, week or month. */
public class SummaryActivity extends Activity {
    @Override
    protected void attachBaseContext(android.content.Context b) {
        super.attachBaseContext(Ui.wrap(b));
    }

    @Override
    public boolean dispatchTouchEvent(android.view.MotionEvent ev) {
        Haptics.touch(getWindow().getDecorView(), ev);
        return super.dispatchTouchEvent(ev);
    }

    public static final int DAY = 0, WEEK = 1, MONTH = 2;
    private Store s;
    private LinearLayout page;
    private ScrollView sv;
    private int mode = WEEK;
    private String anchor; // a date inside the shown period

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.init(this);
        s = Store.get(this);
        mode = getIntent().getIntExtra("mode", WEEK);
        anchor = getIntent().getStringExtra("date");
        if (anchor == null) anchor = Store.today();
        sv = new ScrollView(this);
        sv.setBackgroundColor(Ui.BG);
        page = Ui.col(this);
        sv.addView(page);
        setContentView(sv);
        sv.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View v, WindowInsets in) {
                Insets i = in.getInsets(WindowInsets.Type.systemBars());
                page.setPadding(Ui.dp(18) + i.left, Ui.dp(12) + i.top, Ui.dp(18) + i.right, Ui.dp(30) + i.bottom);
                return WindowInsets.CONSUMED;
            }
        });
        build();
    }

    private void go(int newMode, String date) {
        mode = newMode;
        anchor = date;
        build();
        sv.scrollTo(0, 0);
        page.setAlpha(0f);
        page.animate().alpha(1f).setDuration(200).start();
    }

    private void build() {
        page.removeAllViews();
        LinearLayout head = Ui.row(this);
        TextView back = Ui.text(this, "←", 22, Ui.TEXT, true);
        back.setGravity(Gravity.CENTER);
        back.setBackground(Ui.circle(Ui.CARD2));
        head.addView(back, Ui.lpm(Ui.dp(44), Ui.dp(44), 0, 0, 12, 0));
        Ui.press(back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        head.addView(Ui.title(this, Lang.pick("Summary", "સારાંશ"), 26), Ui.weight(1));
        head.addView(Ui.gear(this), Ui.lp(Ui.dp(44), Ui.dp(44)));
        page.addView(head, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 14));

        final int[] m = {mode};
        page.addView(Dialogs.selector(this, new String[]{Lang.pick("📅 Day", "📅 દિવસ"), Lang.pick("🗓 Week", "🗓 અઠવાડિયું"), Lang.pick("📆 Month", "📆 મહિનો")}, m,
                new Runnable() {
                    @Override
                    public void run() {
                        go(m[0], anchor);
                    }
                }));

        // period navigator
        String[] range = mode == DAY ? new String[]{anchor, anchor} : mode == WEEK ? Summary.weekOf(anchor) : Summary.monthOf(anchor);
        LinearLayout nav = Ui.row(this);
        nav.setPadding(0, Ui.dp(14), 0, Ui.dp(14));
        TextView prev = navBtn("‹"), next = navBtn("›");
        TextView label = Ui.text(this, periodLabel(range), 16, Ui.TEXT, true);
        label.setGravity(Gravity.CENTER);
        Ui.fit(label, 1, 11);
        nav.addView(prev, Ui.lp(Ui.dp(44), Ui.dp(44)));
        nav.addView(label, Ui.weight(1));
        nav.addView(next, Ui.lp(Ui.dp(44), Ui.dp(44)));
        page.addView(nav);
        final boolean canNext = Store.daysBetween(range[1], Store.today()) > 0;
        next.setAlpha(canNext ? 1f : 0.3f);
        prev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                go(mode, mode == DAY ? Summary.shift(anchor, -1) : mode == WEEK ? Summary.shift(anchor, -7) : Summary.shiftMonth(anchor, -1));
            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!canNext) return;
                String n = mode == DAY ? Summary.shift(anchor, 1) : mode == WEEK ? Summary.shift(anchor, 7) : Summary.shiftMonth(anchor, 1);
                if (Store.daysBetween(n, Store.today()) < 0) n = Store.today();
                go(mode, n);
            }
        });
        label.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar c = Store.cal(anchor);
                DatePickerDialog dp = new DatePickerDialog(SummaryActivity.this, android.R.style.Theme_DeviceDefault_Dialog_Alert,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int y, int mo, int d) {
                                Calendar k = Calendar.getInstance();
                                k.set(y, mo, d, 12, 0, 0);
                                go(mode, Store.fmt(k));
                            }
                        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
                dp.getDatePicker().setMaxDate(System.currentTimeMillis());
                dp.show();
            }
        });
        TextView hint = Ui.text(this, Lang.pick("Tap the date to pick any day · ‹ › to move", "કોઈ પણ દિવસ માટે તારીખ દબાવો · ‹ › આગળ-પાછળ"), 11.5f, Ui.MUTED, false);
        hint.setGravity(Gravity.CENTER);
        page.addView(hint, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, -8, 0, 12));

        if (mode == DAY) dayView(anchor);
        else periodView(range, mode == MONTH);
    }

    private TextView navBtn(String t) {
        TextView b = Ui.text(this, t, 24, Ui.GOLD, true);
        b.setGravity(Gravity.CENTER);
        b.setIncludeFontPadding(false);
        b.setPadding(0, 0, 0, Ui.dp(3));
        b.setBackground(Ui.circle(Ui.CARD2));
        Ui.press(b);
        return b;
    }

    private Locale loc() {
        return Lang.locale();
    }

    private String periodLabel(String[] r) {
        if (mode == DAY) {
            String t = new SimpleDateFormat("EEEE, d MMM yyyy", loc()).format(Store.cal(r[0]).getTime());
            return r[0].equals(Store.today()) ? Lang.pick("Today · ", "આજ · ") + t : t;
        }
        if (mode == MONTH) return new SimpleDateFormat("MMMM yyyy", loc()).format(Store.cal(r[0]).getTime());
        SimpleDateFormat f = new SimpleDateFormat("d MMM", loc());
        return f.format(Store.cal(r[0]).getTime()) + " – " + f.format(Store.cal(r[1]).getTime());
    }

    private static int scoreColor(int sc) {
        if (sc >= 80) return Ui.EMERALD;
        if (sc >= 55) return Ui.GOLD;
        if (sc >= 30) return Ui.ORANGE;
        return Ui.RED;
    }

    // ===================================================== DAY
    private void dayView(final String date) {
        Score.Day d = Score.compute(s, date);
        int sc = Summary.score(s, date), prev = Summary.score(s, Summary.shift(date, -1));
        boolean any = Summary.hasData(s, date);

        LinearLayout hero = Ui.col(this);
        hero.setGravity(Gravity.CENTER_HORIZONTAL);
        hero.setBackground(Ui.grad3(0xFF0F766E, 0xFF064E3B, 0xFF1E1B4B, 26));
        hero.setPadding(Ui.dp(18), Ui.dp(20), Ui.dp(18), Ui.dp(20));
        Views.ScoreRing ring = new Views.ScoreRing(this);
        ring.set(sc, Lang.pick("of 100", "/ 100"), true);
        hero.addView(ring, Ui.lp(Ui.dp(140), Ui.dp(140)));
        int diff = sc - prev;
        String line = !any ? Lang.pick("No activity recorded this day", "આ દિવસે કંઈ નોંધાયું નથી")
                : diff > 0 ? Lang.pick("▲ " + diff + " better than the day before", "▲ આગલા દિવસથી " + diff + " વધુ")
                : diff < 0 ? Lang.pick("▼ " + (-diff) + " lower than the day before", "▼ આગલા દિવસથી " + (-diff) + " ઓછું")
                : Lang.pick("Same as the day before", "આગલા દિવસ જેટલું જ");
        TextView l = Ui.text(this, line, 15, diff > 0 ? 0xFFA7F3D0 : diff < 0 ? 0xFFFDA4AF : Ui.GOLD_L, true);
        l.setPadding(0, Ui.dp(12), 0, 0);
        hero.addView(l);
        if (d.penalty > 0) {
            TextView pn = Ui.text(this, Lang.pick("Tasks " + d.base + " − penalties " + d.penalty, "કામ " + d.base + " − સજા " + d.penalty), 12.5f, Ui.alpha(0xFFFFFFFF, 0.75f), false);
            pn.setPadding(0, Ui.dp(4), 0, 0);
            hero.addView(pn);
        }
        page.addView(hero, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 14));

        // stats tiles
        LinearLayout tiles = Ui.equalRow(this);
        tiles.addView(tile("✅", d.done + "/" + d.total, Lang.pick("tasks done", "કામ પૂરા"), Ui.EMERALD), Ui.cell());
        tiles.addView(Ui.space(this, 1), Ui.lp(Ui.dp(8), 1));
        tiles.addView(tile("📱", s.timepassMinutes(date) + "", Lang.pick("min timepass", "મિ ટાઇમપાસ"), Ui.GOLD), Ui.cell());
        tiles.addView(Ui.space(this, 1), Ui.lp(Ui.dp(8), 1));
        tiles.addView(tile("🎬", s.reels(date) + "", Lang.pick("reels", "રીલ્સ"), Ui.ORANGE), Ui.cell());
        tiles.addView(Ui.space(this, 1), Ui.lp(Ui.dp(8), 1));
        tiles.addView(tile("👁️", s.namahram(date) + "", Lang.pick("na-mahram", "નામહરમ"), Ui.PINK), Ui.cell());
        page.addView(tiles, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 14));

        // tasks of that day
        LinearLayout tc = Ui.card(this);
        tc.addView(Ui.text(this, Lang.pick("Tasks that day", "તે દિવસના કામ"), 15, Ui.TEXT, true), Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 6));
        List<Task> tasks = s.tasksOn(date);
        if (tasks.isEmpty()) tc.addView(Ui.text(this, Lang.pick("No tasks were scheduled.", "કોઈ કામ નક્કી નહોતું."), 13, Ui.SUB, false));
        for (Task t : tasks) {
            double v = date.equals(Store.today()) ? Score.liveValue(s, t, date) : s.value(date, t);
            double f = t.frac(v);
            LinearLayout r = Ui.row(this);
            r.setPadding(0, Ui.dp(9), 0, Ui.dp(3));
            r.addView(Ui.text(this, t.emoji, 18, Ui.TEXT, false), Ui.lpm(Ui.dp(30), Ui.WRAP, 0, 0, 6, 0));
            r.addView(Ui.text(this, t.display(), 14, Ui.TEXT, true), Ui.weight(1));
            r.addView(Ui.text(this, valueText(t, v), 13, f >= 0.999 ? Ui.EMERALD : f > 0 ? Ui.GOLD : Ui.MUTED, true));
            tc.addView(r);
            tc.addView(Ui.bar(this, (float) f, f >= 0.999 ? Ui.EMERALD : Ui.GOLD, 4));
        }
        page.addView(tc, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 14));

        // apps that day
        JSONObject u = s.usage(date);
        JSONArray apps = s.apps();
        if (u.length() > 0) {
            LinearLayout ac = Ui.card(this);
            ac.addView(Ui.text(this, Lang.pick("Screen time that day", "તે દિવસનો સ્ક્રીન ટાઇમ"), 15, Ui.TEXT, true), Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 6));
            for (int k = 0; k < apps.length(); k++) {
                JSONObject o = apps.optJSONObject(k);
                if (o == null) continue;
                int mins = u.optInt(o.optString("pkg"), 0), lim = o.optInt("limit", 30);
                LinearLayout r = Ui.row(this);
                r.setPadding(0, Ui.dp(6), 0, Ui.dp(2));
                r.addView(Ui.text(this, o.optString("name"), 13.5f, Ui.TEXT, false), Ui.weight(1));
                r.addView(Ui.text(this, mins + " / " + lim + Lang.pick(" min", " મિ"), 13, mins > lim ? Ui.RED : Ui.SUB, true));
                ac.addView(r);
            }
            page.addView(ac, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 14));
        }

        // the reminder you had that day
        JSONObject w = s.byId(s.s("wod_" + date, ""));
        if (w != null) {
            LinearLayout wc = Ui.col(this);
            wc.setBackground(Ui.roundStroke(0xFF1A1710, 22, Ui.alpha(Ui.GOLD, 0.35f), 1));
            wc.setPadding(Ui.dp(16), Ui.dp(16), Ui.dp(16), Ui.dp(14));
            wc.addView(Ui.text(this, Lang.pick("✦  YOUR WISDOM THAT DAY", "✦  તે દિવસની હિકમત"), 11, Ui.GOLD, true));
            if (w.optString("ar").length() > 0) {
                TextView a = Ui.text(this, w.optString("ar"), 21, Ui.GOLD_L, false);
                a.setTextDirection(View.TEXT_DIRECTION_RTL);
                Ui.arabic(a);
                a.setPadding(0, Ui.dp(10), 0, Ui.dp(2));
                wc.addView(a);
            }
            Ui.translations(this, wc, w, 14.5f, true);
            if (w.optString("src").length() > 0) {
                TextView src = Ui.text(this, "— " + w.optString("src"), 11.5f, Ui.SUB, false);
                src.setPadding(0, Ui.dp(6), 0, 0);
                wc.addView(src);
            }
            page.addView(wc);
        }
    }

    private String valueText(Task t, double v) {
        switch (t.type) {
            case Task.CHECK:
                return v >= 1 ? "✓" : "—";
            case Task.COUNT:
                return (int) Math.max(0, v) + "/" + t.target;
            case Task.MINUTES:
                return Ui.hm((int) Math.max(0, v)) + " / " + Ui.hm(t.target);
            default: {
                String[] o = t.displayOptions();
                int i = (int) v;
                return i >= 0 && i < o.length ? o[i] : "—";
            }
        }
    }

    // ===================================================== WEEK / MONTH
    private void periodView(String[] range, final boolean month) {
        Summary.Period p = Summary.compute(s, range[0], range[1]);
        Summary.Period prev = Summary.previous(s, p, month);
        String unit = month ? Lang.pick("month", "મહિના") : Lang.pick("week", "અઠવાડિયા");

        // headline
        LinearLayout hero = Ui.col(this);
        hero.setBackground(Ui.grad3(0xFF4C1D95, 0xFF6D28D9, 0xFF0F766E, 26));
        hero.setPadding(Ui.dp(20), Ui.dp(20), Ui.dp(20), Ui.dp(20));
        hero.addView(Ui.text(this, Lang.pick("AVERAGE SCORE", "સરેરાશ સ્કોર"), 12, Ui.GOLD_L, true));
        LinearLayout hr = Ui.row(this);
        TextView big = Ui.title(this, String.valueOf(p.avg), 54);
        big.setTextColor(0xFFFFFFFF);
        hr.addView(big);
        int diff = p.avg - prev.avg;
        boolean hasPrev = prev.daysWithData > 0;
        TextView dt = Ui.text(this, !hasPrev ? Lang.pick("  first " + unit + " tracked", "  પહેલું " + unit + " ટ્રૅક થયું")
                : diff >= 0 ? "  ▲ " + diff + Lang.pick(" vs last " + unit, " ગયા " + unit + " કરતાં") : "  ▼ " + (-diff) + Lang.pick(" vs last " + unit, " ગયા " + unit + " કરતાં"),
                15, !hasPrev ? Ui.GOLD_L : diff >= 0 ? 0xFFA7F3D0 : 0xFFFDA4AF, true);
        hr.addView(dt);
        hero.addView(hr);
        hero.addView(Ui.text(this, headline(p, prev, hasPrev, unit), 14.5f, Ui.alpha(0xFFFFFFFF, 0.9f), false));
        page.addView(hero, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 14));

        // tiles
        LinearLayout t1 = Ui.equalRow(this);
        t1.addView(tile("✨", p.betterDays + "", Lang.pick("better days", "બહેતર દિવસ"), Ui.GOLD), Ui.cell());
        t1.addView(Ui.space(this, 1), Ui.lp(Ui.dp(8), 1));
        t1.addView(tile("✅", p.completion + "%", Lang.pick("tasks done", "કામ પૂરા"), Ui.EMERALD), Ui.cell());
        t1.addView(Ui.space(this, 1), Ui.lp(Ui.dp(8), 1));
        t1.addView(tile("🏆", p.best + "", Lang.pick("best day", "શ્રેષ્ઠ દિવસ"), Ui.BLUE), Ui.cell());
        page.addView(t1, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 8));
        LinearLayout t2 = Ui.equalRow(this);
        int days = Math.max(1, p.dates.size());
        t2.addView(tile("📱", (p.timepass / days) + "", Lang.pick("min/day timepass", "મિ/દિ ટાઇમપાસ") + arrow(p.timepass / days, prev.timepass / Math.max(1, prev.dates.size()), true), Ui.ORANGE), Ui.cell());
        t2.addView(Ui.space(this, 1), Ui.lp(Ui.dp(8), 1));
        t2.addView(tile("🎬", p.reels + "", Lang.pick("reels", "રીલ્સ") + arrow(p.reels, prev.reels, true), Ui.RED), Ui.cell());
        t2.addView(Ui.space(this, 1), Ui.lp(Ui.dp(8), 1));
        t2.addView(tile("👁️", p.namahram + "", Lang.pick("na-mahram", "નામહરમ") + arrow(p.namahram, prev.namahram, true), Ui.PINK), Ui.cell());
        page.addView(t2, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 14));

        // chart / calendar
        if (month) page.addView(calendar(range, p), Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 14));
        else {
            LinearLayout cc = Ui.card(this);
            cc.addView(Ui.text(this, Lang.pick("Day by day", "દિવસ પ્રમાણે"), 15, Ui.TEXT, true));
            Views.Bars bars = new Views.Bars(this);
            String[] labs = new String[7];
            int[] vals = new int[7];
            String[] dn = Lang.dayInitialsMon();
            for (int k = 0; k < 7; k++) {
                labs[k] = dn[k];
                vals[k] = k < p.scores.length ? p.scores[k] : 0;
            }
            bars.set(vals, labs);
            cc.addView(bars, Ui.lpm(Ui.MATCH, Ui.dp(170), 0, 10, 0, 0));
            TextView tip = Ui.text(this, Lang.pick("Tap a day below to see its full summary", "આખો સારાંશ જોવા નીચે દિવસ દબાવો"), 11.5f, Ui.MUTED, false);
            cc.addView(tip);
            LinearLayout dayRow = Ui.row(this);
            dayRow.setPadding(0, Ui.dp(8), 0, 0);
            for (int k = 0; k < 7; k++) {
                final String d = Summary.shift(range[0], k);
                boolean future = Store.daysBetween(d, Store.today()) < 0;
                TextView b = Ui.text(this, String.valueOf(Store.cal(d).get(Calendar.DAY_OF_MONTH)), 13, future ? Ui.MUTED : Ui.TEXT, true);
                b.setGravity(Gravity.CENTER);
                b.setPadding(0, Ui.dp(8), 0, Ui.dp(8));
                b.setBackground(Ui.roundStroke(Ui.CARD2, 12, Ui.STROKE, 1));
                LinearLayout.LayoutParams lp = Ui.weight(1);
                lp.setMargins(Ui.dp(2), 0, Ui.dp(2), 0);
                dayRow.addView(b, lp);
                if (!future) b.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        go(DAY, d);
                    }
                });
            }
            cc.addView(dayRow);
            page.addView(cc, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 14));
        }

        // tasks
        LinearLayout tc = Ui.card(this);
        tc.addView(Ui.text(this, Lang.pick("Tasks this " + unit, "આ " + unit + "ના કામ"), 15, Ui.TEXT, true), Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 4));
        List<Summary.TaskStat> list = p.tasks;
        Collections.sort(list, new Comparator<Summary.TaskStat>() {
            @Override
            public int compare(Summary.TaskStat a, Summary.TaskStat b) {
                return b.pct() - a.pct();
            }
        });
        Summary.TaskStat improved = null, attention = null;
        int bestGain = 0;
        for (Summary.TaskStat ts : list) {
            Summary.TaskStat old = Summary.find(prev, ts.task.id);
            int gain = old == null ? 0 : ts.pct() - old.pct();
            if (gain > bestGain) {
                bestGain = gain;
                improved = ts;
            }
            if (ts.scheduled >= 2 && (attention == null || ts.pct() < attention.pct())) attention = ts;
            LinearLayout r = Ui.row(this);
            r.setPadding(0, Ui.dp(10), 0, Ui.dp(3));
            r.addView(Ui.text(this, ts.task.emoji, 18, Ui.TEXT, false), Ui.lpm(Ui.dp(30), Ui.WRAP, 0, 0, 6, 0));
            LinearLayout col = Ui.col(this);
            col.addView(Ui.text(this, ts.task.display(), 14, Ui.TEXT, true));
            String extra = ts.task.type == Task.MINUTES ? " · " + Ui.hm((int) ts.total) + Lang.pick(" total", " કુલ")
                    : ts.task.type == Task.COUNT ? " · " + (int) ts.total + Lang.pick(" total", " કુલ") : "";
            col.addView(Ui.text(this, ts.done + "/" + ts.scheduled + Lang.pick(" days", " દિવસ") + extra
                    + (old == null ? "" : "  " + (gain >= 0 ? "▲" : "▼") + Math.abs(gain) + "%"), 12, Ui.SUB, false));
            r.addView(col, Ui.weight(1));
            r.addView(Ui.text(this, ts.pct() + "%", 15, scoreColor(ts.pct()), true));
            tc.addView(r);
            tc.addView(Ui.bar(this, ts.pct() / 100f, scoreColor(ts.pct()), 4));
        }
        if (list.isEmpty()) tc.addView(Ui.text(this, Lang.pick("No tasks recorded yet.", "હજી કોઈ કામ નોંધાયું નથી."), 13, Ui.SUB, false));
        page.addView(tc, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 14));

        // insights
        LinearLayout ic = Ui.card(this);
        ic.addView(Ui.text(this, Lang.pick("💡  Insights", "💡  તારણ"), 15, Ui.TEXT, true), Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 6));
        if (p.bestDate.length() > 0)
            insight(ic, "🏆", Lang.pick("Best day: ", "શ્રેષ્ઠ દિવસ: ") + dayName(p.bestDate) + " (" + p.best + ")", p.bestDate);
        if (p.worstDate.length() > 0 && !p.worstDate.equals(p.bestDate))
            insight(ic, "🔻", Lang.pick("Weakest day: ", "નબળો દિવસ: ") + dayName(p.worstDate) + " (" + p.worst + ")", p.worstDate);
        if (improved != null)
            insight(ic, "📈", Lang.pick("Most improved: ", "સૌથી વધુ સુધારો: ") + improved.task.display() + " (+" + bestGain + "%)", null);
        if (attention != null && attention.pct() < 70)
            insight(ic, "🎯", Lang.pick("Needs attention: ", "ધ્યાન આપો: ") + attention.task.display() + " (" + attention.pct() + "%)", null);
        if (hasPrev) {
            int tpNow = p.timepass / days, tpOld = prev.timepass / Math.max(1, prev.dates.size());
            if (tpNow < tpOld) insight(ic, "📵", Lang.pick("Timepass down " + (tpOld - tpNow) + " min/day — MashaAllah", "ટાઇમપાસ રોજ " + (tpOld - tpNow) + " મિ ઓછો — માશાઅલ્લાહ"), null);
            else if (tpNow > tpOld) insight(ic, "⚠️", Lang.pick("Timepass up " + (tpNow - tpOld) + " min/day", "ટાઇમપાસ રોજ " + (tpNow - tpOld) + " મિ વધ્યો"), null);
        }
        if (!p.dates.isEmpty()) {
            String from = p.dates.get(0), to = p.dates.get(p.dates.size() - 1);
            int blocked = Lock.count(s, "tamper", from, to) + Lock.count(s, "refused", from, to);
            int cancelled = Lock.count(s, "cancel", from, to), broke = Lock.count(s, "emergency", from, to);
            if (broke > 0) insight(ic, "💔", Lang.pick("Lock broken " + broke + "× (emergency) — start a new one tonight", "લૉક " + broke + " વાર તોડ્યું (ઇમરજન્સી) — આજે રાતે નવું શરૂ કરો"), null);
            if (blocked > 0) insight(ic, "🔒", Lang.pick(blocked + " attempts to loosen your rules were stopped", "નિયમ ઢીલા કરવાના " + blocked + " પ્રયાસ રોકાયા"), null);
            if (cancelled > 0) insight(ic, "🌟", Lang.pick("You cancelled " + cancelled + " loosening request(s) — that's real strength", "તમે " + cancelled + " ઢીલા ફેરફાર રદ કર્યા — આ જ સાચી તાકાત"), null);
        }
        page.addView(ic, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 14));

        // closing hadith
        JSONObject w = s.byId(diff >= 0 || !hasPrev ? "h3" : "h1");
        if (w != null) {
            LinearLayout wc = Ui.col(this);
            wc.setBackground(Ui.roundStroke(0xFF1A1710, 22, Ui.alpha(Ui.GOLD, 0.35f), 1));
            wc.setPadding(Ui.dp(16), Ui.dp(16), Ui.dp(16), Ui.dp(14));
            if (w.optString("ar").length() > 0) {
                TextView a = Ui.text(this, w.optString("ar"), 21, Ui.GOLD_L, false);
                a.setTextDirection(View.TEXT_DIRECTION_RTL);
                Ui.arabic(a);
                wc.addView(a);
            }
            Ui.translations(this, wc, w, 14.5f, true);
            TextView src = Ui.text(this, "— " + w.optString("src"), 11.5f, Ui.SUB, false);
            src.setPadding(0, Ui.dp(6), 0, 0);
            wc.addView(src);
            page.addView(wc);
        }
    }

    private String arrow(int now, int old, boolean lowerIsBetter) {
        if (old == now) return "";
        boolean good = lowerIsBetter ? now < old : now > old;
        return (now < old ? "  ▼" : "  ▲") + (good ? "" : "!");
    }

    private String dayName(String d) {
        return new SimpleDateFormat("EEE d MMM", loc()).format(Store.cal(d).getTime());
    }

    private void insight(LinearLayout parent, String emoji, String text, final String date) {
        LinearLayout r = Ui.row(this);
        r.setPadding(0, Ui.dp(7), 0, Ui.dp(7));
        r.addView(Ui.text(this, emoji, 16, Ui.TEXT, false), Ui.lpm(Ui.dp(28), Ui.WRAP, 0, 0, 6, 0));
        r.addView(Ui.text(this, text + (date != null ? "  ›" : ""), 13.5f, Ui.TEXT, false), Ui.weight(1));
        parent.addView(r);
        if (date != null) {
            Ui.press(r);
            r.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    go(DAY, date);
                }
            });
        }
    }

    private String headline(Summary.Period p, Summary.Period prev, boolean hasPrev, String unit) {
        if (p.daysWithData == 0) return Lang.pick("Nothing recorded yet.", "હજી કંઈ નોંધાયું નથી.");
        int diff = p.avg - prev.avg;
        if (!hasPrev) return Lang.pick("A strong start — keep building.", "સરસ શરૂઆત — આગળ વધતા રહો.");
        if (diff >= 10) return Lang.pick("Big improvement this " + unit + ". Alhamdulillah! 🌟", "આ " + unit + " મોટો સુધારો. અલ્હમ્દુલિલ્લાહ! 🌟");
        if (diff > 0) return Lang.pick("Better than last " + unit + " — keep the momentum.", "ગયા " + unit + " કરતાં બહેતર — આ જ ગતિ રાખો.");
        if (diff == 0) return Lang.pick("Same as last " + unit + ". Push one task higher.", "ગયા " + unit + " જેટલું જ. એક કામ વધુ સારું કરો.");
        return Lang.pick("A little lower than last " + unit + ". New " + unit + ", new chance.", "ગયા " + unit + " કરતાં થોડું ઓછું. નવું " + unit + ", નવો મોકો.");
    }

    private View calendar(String[] range, Summary.Period p) {
        LinearLayout c = Ui.card(this);
        c.addView(Ui.text(this, Lang.pick("Your month — tap any day", "તમારો મહિનો — કોઈ પણ દિવસ દબાવો"), 15, Ui.TEXT, true), Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 10));
        String[] dn = Lang.dayInitialsMon();
        LinearLayout hdr = Ui.row(this);
        for (String d : dn) {
            TextView t = Ui.text(this, d, 11.5f, Ui.MUTED, true);
            t.setGravity(Gravity.CENTER);
            hdr.addView(t, Ui.weight(1));
        }
        c.addView(hdr);
        Calendar first = Store.cal(range[0]);
        int lead = (first.get(Calendar.DAY_OF_WEEK) + 5) % 7;
        int total = Store.daysBetween(range[0], range[1]) + 1;
        int cells = ((lead + total + 6) / 7) * 7;
        LinearLayout row = null;
        for (int i = 0; i < cells; i++) {
            if (i % 7 == 0) {
                row = Ui.row(this);
                c.addView(row, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 4, 0, 0));
            }
            int dayIdx = i - lead;
            TextView cell = Ui.text(this, "", 12.5f, Ui.TEXT, true);
            cell.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, Ui.dp(40), 1f);
            lp.setMargins(Ui.dp(2), 0, Ui.dp(2), 0);
            if (dayIdx >= 0 && dayIdx < total) {
                final String d = Summary.shift(range[0], dayIdx);
                boolean future = Store.daysBetween(d, Store.today()) < 0;
                cell.setText(String.valueOf(dayIdx + 1));
                if (future || dayIdx >= p.scores.length || !Summary.hasData(s, d)) {
                    cell.setBackground(Ui.roundStroke(0, 10, Ui.STROKE, 1));
                    cell.setTextColor(Ui.MUTED);
                } else {
                    int sc = p.scores[dayIdx];
                    cell.setBackground(Ui.round(Ui.alpha(scoreColor(sc), 0.25f + 0.6f * sc / 100f), 10));
                    cell.setTextColor(0xFFFFFFFF);
                    if (d.equals(Store.today())) cell.setBackground(Ui.roundStroke(Ui.alpha(scoreColor(sc), 0.5f), 10, Ui.GOLD, 2));
                    Ui.press(cell);
                    cell.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            go(DAY, d);
                        }
                    });
                }
            }
            row.addView(cell, lp);
        }
        LinearLayout legend = Ui.row(this);
        legend.setPadding(0, Ui.dp(10), 0, 0);
        int[][] lg = {{Ui.RED, 0}, {Ui.ORANGE, 30}, {Ui.GOLD, 55}, {Ui.EMERALD, 80}};
        for (int[] g : lg) {
            View dot = new View(this);
            dot.setBackground(Ui.round(g[0], 4));
            legend.addView(dot, Ui.lpm(Ui.dp(12), Ui.dp(12), 0, 0, 4, 0));
            legend.addView(Ui.text(this, g[1] + "+   ", 11, Ui.MUTED, false));
        }
        c.addView(legend);
        return c;
    }

    private View tile(String emoji, String value, String label, int color) {
        LinearLayout t = Ui.col(this);
        t.setBackground(Ui.roundStroke(Ui.CARD, 18, Ui.STROKE, 1));
        t.setPadding(Ui.dp(10), Ui.dp(12), Ui.dp(10), Ui.dp(12));
        t.addView(Ui.text(this, emoji, 17, Ui.TEXT, false));
        TextView v = Ui.title(this, value, 22);
        v.setTextColor(color);
        Ui.fit(v, 1, 11.0f);
        t.addView(v);
        TextView lb = Ui.text(this, label, 10.5f, Ui.SUB, false);
        Ui.fit(lb, 2, 8f);
        t.addView(lb);
        return t;
    }

    static GradientDrawable unused() {
        return null;
    }
}
