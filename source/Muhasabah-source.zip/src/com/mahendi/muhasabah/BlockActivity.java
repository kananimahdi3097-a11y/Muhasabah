package com.mahendi.muhasabah;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONObject;

/** Full-screen block shown when the guardian stops a reel/site/word, with a reminder + activity. */
public class BlockActivity extends Activity {
    @Override
    protected void attachBaseContext(android.content.Context b) {
        super.attachBaseContext(Ui.wrap(b));
    }

    @Override
    public boolean dispatchTouchEvent(android.view.MotionEvent ev) {
        Haptics.touch(getWindow().getDecorView(), ev);
        return super.dispatchTouchEvent(ev);
    }


    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.init(this);
        Store s = Store.get(this);
        String kind = getIntent().getStringExtra("kind");
        if (kind == null) kind = "word";
        int count = getIntent().getIntExtra("count", 0);
        final String app = getIntent().getStringExtra("app");
        final String why = app == null ? "" : AppLock.why(s, app);
        if ("applock".equals(kind)) kind = "cap".equals(why) || "reels".equals(why) || "incognito".equals(why) ? why : "vulgar".equals(why) ? "vulgar" : "word";

        boolean reels = "reels".equals(kind) || "cap".equals(kind), lock = "lock".equals(kind);
        String topicA = reels ? "reels" : "purity";
        String topicB = reels ? "time" : "gaze";
        JSONObject w = s.pick(topicA, topicB, "akl");
        JSONObject act = s.activity(reels ? "reels" : "purity");

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                reels ? new int[]{0xFF3B2A0B, 0xFF0A0E1A, 0xFF050811}
                        : new int[]{0xFF3B0B14, 0xFF0A0E1A, 0xFF050811}));
        LinearLayout root = Ui.col(this);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(Ui.dp(24), Ui.dp(60), Ui.dp(24), Ui.dp(40));
        sv.addView(root);

        String title, sub;
        if (lock) {
            title = Lang.pick("🔒 You locked this", "🔒 તમે આ લૉક કર્યું છે");
            sub = Lang.pick("Your rules are locked for " + Lock.left(Lock.remainingMs(s)) + " more. Settings that could switch Muhasabah off stay closed until then.",
                    "તમારા નિયમ હજી " + Lock.left(Lock.remainingMs(s)) + " લૉક છે. ત્યાં સુધી Muhasabah બંધ કરી શકે એવા સેટિંગ્સ નહીં ખૂલે.");
        } else if ("cap".equals(kind)) {
            String n = AppLock.appName(this, app);
            title = HadithCard.label("⏳ " + n + " time is over for today", "⏳ આજનો " + n + " નો સમય પૂરો", "⏳ آج " + n + " کا وقت ختم", "⏳ आज " + n + " का समय ख़त्म");
            sub = HadithCard.label("You've used your " + AppLock.cap(s, app) + " minutes. It opens again tomorrow — no extension.",
                    "તમે તમારી " + AppLock.cap(s, app) + " મિનિટ વાપરી લીધી. કાલે ફરી ખૂલશે — કોઈ વધારો નહીં.",
                    "آپ نے اپنے " + AppLock.cap(s, app) + " منٹ استعمال کر لیے۔ کل دوبارہ کھلے گا — کوئی اضافہ نہیں۔",
                    "आपने अपने " + AppLock.cap(s, app) + " मिनट इस्तेमाल कर लिए। कल फिर खुलेगा — कोई बढ़ोतरी नहीं।");
        } else if (reels) {
            title = Lang.pick("Enough reels for today", "આજ માટે બસ રીલ્સ");
            sub = Lang.pick("You've watched " + Math.max(count, s.reelsLimit()) + " today. That time won't come back.",
                    "આજે તમે " + Math.max(count, s.reelsLimit()) + " જોઈ. એ સમય પાછો નહીં આવે.");
        } else if ("incognito".equals(kind)) {
            title = HadithCard.label("Private tabs aren't allowed", "પ્રાઇવેટ ટૅબની છૂટ નથી", "پرائیویٹ ٹیب کی اجازت نہیں", "प्राइवेट टैब की इजाज़त नहीं");
            sub = HadithCard.label("Incognito / private tabs hide the screen from the guard, so they can't be used.",
                    "ઇન્કૉગ્નિટો / પ્રાઇવેટ ટૅબ ગાર્ડથી સ્ક્રીન છુપાવે છે, એટલે તે વાપરી શકાતી નથી.",
                    "انکوگنیٹو / پرائیویٹ ٹیب اسکرین کو گارڈ سے چھپاتے ہیں، اس لیے انہیں استعمال نہیں کیا جا سکتا۔",
                    "इनकॉग्निटो / प्राइवेट टैब स्क्रीन को गार्ड से छिपाते हैं, इसलिए इन्हें इस्तेमाल नहीं किया जा सकता।");
        } else if ("vulgar".equals(kind)) {
            title = Lang.pick("Stop — guard your gaze", "રોકાઈ જાઓ — નજર સાચવો");
            String rs = ScreenGuard.reasonText(s.s(ScreenGuard.K_REASON, ""));
            if (rs.length() > 0) title += "\n" + HadithCard.label("(" + rs + ")", "(" + rs + ")", "(" + rs + ")", "(" + rs + ")");
            sub = HadithCard.label("Something haram appeared on the screen, so Muhasabah closed it. Say Astaghfirullah and move on — Allah is the Most Merciful.",
                    "સ્ક્રીન પર કંઈક હરામ દેખાયું, એટલે Muhasabah એ તેને બંધ કર્યું. અસ્તગફિરુલ્લાહ કહો અને આગળ વધો — અલ્લાહ ખૂબ રહેમ કરનાર છે.",
                    "اسکرین پر کچھ حرام نظر آیا، اس لیے Muhasabah نے اسے بند کر دیا۔ استغفراللہ کہیں اور آگے بڑھیں — اللہ بہت رحم کرنے والا ہے۔",
                    "स्क्रीन पर कुछ हराम दिखा, इसलिए Muhasabah ने उसे बंद कर दिया। अस्तग़फ़िरुल्लाह कहें और आगे बढ़ें — अल्लाह बहुत रहम करने वाला है।");
        } else {
            title = Lang.pick("Stop — guard your gaze", "રોકાઈ જાઓ — નજર સાચવો");
            sub = Lang.pick("This page is blocked. Allah is watching, and He is the Most Merciful.",
                    "આ પેજ બ્લૉક છે. અલ્લાહ જોઈ રહ્યો છે, અને તે ખૂબ રહેમ કરનાર છે.");
        }
        root.addView(Ui.pill(this, reels ? "🎬  " + Lang.pick("BLOCKED", "બ્લૉક") : "🛡️  " + Lang.pick("BLOCKED", "બ્લૉક"),
                Ui.alpha(reels ? Ui.GOLD : Ui.RED, 0.18f), reels ? Ui.GOLD : 0xFFFF8FA3));
        root.addView(Ui.space(this, 16));
        TextView t = Ui.title(this, title, 30);
        t.setGravity(Gravity.CENTER);
        root.addView(t);
        TextView st = Ui.text(this, sub, 15, Ui.SUB, false);
        st.setGravity(Gravity.CENTER);
        st.setPadding(0, Ui.dp(6), 0, 0);
        root.addView(st);
        if (app != null && AppLock.locked(s, app)) {
            long left = AppLock.until(s, app) - System.currentTimeMillis();
            String n = AppLock.appName(this, app);
            boolean day = AppLock.until(s, app) >= AppLock.endOfToday() - 60_000L;
            String mins = String.valueOf(Math.max(1, (left + 59_999) / 60_000));
            TextView lk = Ui.text(this, "🔒 " + (day ? HadithCard.label(n + " is locked until tomorrow", n + " કાલ સુધી લૉક છે", n + " کل تک لاک ہے", n + " कल तक लॉक है")
                    : HadithCard.label(n + " is locked for " + mins + " more min", n + " હજી " + mins + " મિનિટ લૉક છે", n + " مزید " + mins + " منٹ لاک ہے", n + " और " + mins + " मिनट लॉक है")), 14.5f, 0xFFFF8FA3, true);
            lk.setGravity(Gravity.CENTER);
            lk.setPadding(0, Ui.dp(12), 0, 0);
            root.addView(lk);
        }

        if (s.b(Store.K_STRICT, true)) {
            root.addView(Ui.space(this, 14));
            TextView g = Ui.text(this, Lines.make(Store.get(this), Lines.SCROLL, true), 17, Ui.GOLD_L, true);
            g.setGravity(Gravity.CENTER);
            root.addView(g);
        }
        root.addView(Ui.space(this, 24));

        // reminder card
        LinearLayout card = Ui.col(this);
        card.setBackground(Ui.roundStroke(Ui.alpha(0xFF141A2B, 0.9f), 24, Ui.alpha(Ui.GOLD, 0.3f), 1.2f));
        card.setPadding(Ui.dp(20), Ui.dp(20), Ui.dp(20), Ui.dp(20));
        String ar = w.optString("ar");
        if (ar.length() > 0) {
            TextView a = Ui.text(this, ar, 23, Ui.GOLD_L, false);
            a.setGravity(Gravity.CENTER);
            a.setTextDirection(View.TEXT_DIRECTION_RTL);
            Ui.arabic(a);
            a.setLineSpacing(Ui.dp(6), 1f);
            card.addView(a);
            card.addView(Ui.space(this, 12));
        }
        Ui.translations(this, card, w, 16.5f, true);
        if (w.optString("src").length() > 0) {
            TextView src = Ui.text(this, "— " + w.optString("src"), 12, Ui.SUB, false);
            src.setGravity(Gravity.CENTER);
            src.setPadding(0, Ui.dp(10), 0, 0);
            card.addView(src);
        }
        root.addView(card, Ui.lp(Ui.MATCH, Ui.WRAP));

        // activity suggestion
        if (act != null && act.optString("en").length() > 0) {
            root.addView(Ui.space(this, 16));
            LinearLayout ac = Ui.row(this);
            ac.setBackground(Ui.roundStroke(Ui.alpha(Ui.EMERALD, 0.12f), 20, Ui.alpha(Ui.EMERALD, 0.4f), 1));
            ac.setPadding(Ui.dp(16), Ui.dp(14), Ui.dp(16), Ui.dp(14));
            ac.addView(Ui.text(this, act.optString("e"), 26, Ui.TEXT, false), Ui.lpm(Ui.dp(40), Ui.WRAP, 0, 0, 12, 0));
            ac.addView(Ui.text(this, Lang.both(act), 14.5f, Ui.TEXT, true), Ui.weight(1));
            root.addView(ac, Ui.lp(Ui.MATCH, Ui.WRAP));
        }

        root.addView(Ui.space(this, 26));
        TextView ok = Ui.button(this, Lang.pick("🚀  Take me back to good", "🚀  મને ભલાઈ તરફ લઈ જાઓ"), Ui.EMERALD, Ui.TEAL, 0xFFFFFFFF);
        root.addView(ok, Ui.lp(Ui.MATCH, Ui.WRAP));
        setContentView(sv);

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goHome();
            }
        });
        if ("vulgar".equals(kind) && app != null) {
            final TextView wrong = Ui.ghost(this, HadithCard.label("❌  That was a mistake (normal video)", "❌  આ ભૂલ હતી (સામાન્ય વીડિયો)",
                    "❌  یہ غلطی تھی (عام ویڈیو)", "❌  यह ग़लती थी (सामान्य वीडियो)"), Ui.SUB);
            root.addView(Ui.space(this, 10));
            root.addView(wrong, Ui.lp(Ui.MATCH, Ui.WRAP));
            wrong.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ScreenGuard.reportWrong(s, app);
                    Haptics.play(Haptics.SUCCESS);
                    wrong.setEnabled(false);
                    wrong.setText(HadithCard.label("✓  Thanks — the guard is now a little less sensitive", "✓  આભાર — ગાર્ડ હવે થોડું ઓછું સંવેદનશીલ છે",
                            "✓  شکریہ — گارڈ اب تھوڑا کم حساس ہے", "✓  शुक्रिया — गार्ड अब थोड़ा कम संवेदनशील है"));
                }
            });
        }
        try {
            Vibrator vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            vib.vibrate(VibrationEffect.createWaveform(new long[]{0, 140, 70, 140}, -1));
        } catch (Exception ignored) {
        }
    }

    private void goHome() {
        Intent h = new Intent(Intent.ACTION_MAIN);
        h.addCategory(Intent.CATEGORY_HOME);
        h.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(h);
        finish();
    }

    @Override
    public void onBackPressed() {
        goHome();
    }
}
