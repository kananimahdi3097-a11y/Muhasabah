package com.mahendi.muhasabah;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Restarts the guardian after the phone reboots or the app is updated. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if (Store.get(c).b(Store.K_MONITOR, true)) WatchService.start(c);
        Reminders.schedule(c);
        Gunah.schedule(c);
        if (Intent.ACTION_MY_PACKAGE_REPLACED.equals(i.getAction())) {
            Notify.channels(c);
            Notify.post(c, 470, Notify.CH_DAILY, Lang.pick("✅ Muhasabah updated to v", "✅ Muhasabah અપડેટ થયું · v") + Updater.installedName(c),
                    Lang.pick("All your progress is safe. Bismillah!", "તમારી બધી પ્રગતિ સુરક્ષિત છે. બિસ્મિલ્લાહ!"), null);
        }
    }
}
