package com.mahendi.muhasabah;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** App language (English / Gujarati / Urdu / Hindi) and all UI strings. Set once in Settings. */
public final class Lang {
    public static final int EN = 0, GU = 1, UR = 2, HI = 3;
    public static final String[] NAMES = {"English", "ગુજરાતી", "اردو", "हिन्दी"};
    /** Content languages are a bit mask: which translations to show under ayat, hadith and cards. */
    public static final int M_EN = 1, M_GU = 2, M_UR = 4, M_HI = 8;
    /** Legacy content setting: 0 = English + Gujarati, 1 = English, 2 = Gujarati. */
    public static final int C_BOTH = 0, C_EN = 1, C_GU = 2;
    private static int cur = EN, mask = M_EN | M_GU;

    // ---------- Urdu / Hindi dictionary (assets/i18n.json: English -> [ur, hi]) ----------
    private static final Map<String, String[]> D = new HashMap<String, String[]>();
    private static final List<Object[]> PAT = new ArrayList<Object[]>();
    private static final Map<String, String> CACHE = new HashMap<String, String>();
    private static boolean loaded;
    private static final Pattern NUM = Pattern.compile("-?\\d+(?:[.,:]\\d+)*");

    public static synchronized void init(Context c) {
        if (loaded) return;
        loaded = true;
        try {
            InputStream in = c.getApplicationContext().getAssets().open("i18n.json");
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            in.close();
            JSONObject o = new JSONObject(bo.toString("UTF-8"));
            Iterator<String> it = o.keys();
            while (it.hasNext()) {
                String k = it.next();
                JSONArray a = o.optJSONArray(k);
                if (a == null || a.length() < 2) continue;
                String[] v = {a.optString(0), a.optString(1)};
                D.put(k, v);
                if (k.indexOf('#') >= 0) {
                    StringBuilder re = new StringBuilder("^");
                    String[] parts = k.split("#", -1);
                    for (int i = 0; i < parts.length; i++) {
                        if (i > 0) re.append("(.+?)");
                        re.append(Pattern.quote(parts[i]));
                    }
                    re.append("$");
                    PAT.add(new Object[]{Pattern.compile(re.toString(), Pattern.DOTALL), v});
                }
            }
        } catch (Exception ignored) {
        }
    }

    /** Translate an English UI string to the current language (Urdu/Hindi) if the dictionary knows it. */
    public static String tr(String en) {
        return tr(en, true);
    }

    /** exactOnly: no wildcard matching (used for every TextView, so content text is never touched). */
    public static String tr(String en, boolean patterns) {
        if (en == null || cur < UR || en.length() == 0) return en;
        String ck = (patterns ? "1" : "0") + en;
        synchronized (CACHE) {
            String hit = CACHE.get(ck);
            if (hit != null) return hit;
        }
        int col = cur == UR ? 0 : 1;
        String out = null;
        String[] v = D.get(en);
        if (v != null) out = v[col];
        if (out == null) { // numbers → #
            Matcher m = NUM.matcher(en);
            List<String> nums = new ArrayList<String>();
            StringBuffer sb = new StringBuffer();
            while (m.find()) {
                nums.add(m.group());
                m.appendReplacement(sb, "#");
            }
            m.appendTail(sb);
            if (!nums.isEmpty()) {
                v = D.get(sb.toString());
                if (v != null) out = fillArgs(v[col], nums);
            }
        }
        if (out == null && patterns) {
            for (Object[] p : PAT) {
                Matcher m = ((Pattern) p[0]).matcher(en);
                if (m.matches()) {
                    List<String> args = new ArrayList<String>();
                    for (int i = 1; i <= m.groupCount(); i++) args.add(tr(m.group(i), false));
                    out = fillArgs(((String[]) p[1])[col], args);
                    break;
                }
            }
        }
        if (out == null || out.length() == 0) out = en;
        synchronized (CACHE) {
            if (CACHE.size() > 3000) CACHE.clear();
            CACHE.put(ck, out);
        }
        return out;
    }

    private static String fillArgs(String t, List<String> args) {
        for (int i = args.size(); i >= 1; i--) t = t.replace("{" + i + "}", args.get(i - 1));
        return t;
    }

    // ---------- content languages ----------
    public static void setMask(int m) {
        mask = (m & 15) == 0 ? M_EN : (m & 15);
    }

    public static int mask() {
        return mask;
    }

    /** Old 3-way setting → mask (kept so old backups still work). */
    public static void setContent(int c) {
        setMask(c == C_EN ? M_EN : c == C_GU ? M_GU : M_EN | M_GU);
    }

    public static boolean showEn() {
        return (mask & M_EN) != 0;
    }

    public static boolean showGu() {
        return (mask & M_GU) != 0;
    }

    public static boolean showUr() {
        return (mask & M_UR) != 0;
    }

    public static boolean showHi() {
        return (mask & M_HI) != 0;
    }

    /** Field names in content JSON per language, in display order. */
    public static final String[] CODES = {"en", "gu", "ur", "hi"};

    /** The translations of a content item that the user wants to see (never empty). Each entry: {lang, text}. */
    public static List<String[]> texts(JSONObject o, String[] fields) {
        List<String[]> out = new ArrayList<String[]>();
        String en = o == null ? "" : o.optString(fields[0]);
        for (int l = 0; l < 4; l++) {
            if ((mask & (1 << l)) == 0) continue;
            String v = o == null ? "" : o.optString(fields[l]);
            if (v.length() == 0 || l > 0 && v.equals(en)) continue;
            out.add(new String[]{CODES[l], v});
        }
        if (out.isEmpty()) {
            for (int l = 0; l < 4 && out.isEmpty(); l++) {
                String v = o == null ? "" : o.optString(fields[l]);
                if (v.length() > 0) out.add(new String[]{CODES[l], v});
            }
        }
        return out;
    }

    public static final String[] F_TEXT = {"en", "gu", "ur", "hi"};

    /** Content text in the chosen languages, one per line. */
    public static String both(JSONObject o) {
        StringBuilder b = new StringBuilder();
        for (String[] t : texts(o, F_TEXT)) {
            if (b.length() > 0) b.append('\n');
            b.append(t[1]);
        }
        return b.toString();
    }

    /** Content text in the chosen content language(s); used where only English + Gujarati exist. */
    public static String both(String en, String gu) {
        try {
            JSONObject o = new JSONObject();
            o.put("en", en == null ? "" : en);
            o.put("gu", gu == null ? "" : gu);
            if (!showEn() && !showGu()) return pick(en, gu);
            return both(o);
        } catch (Exception e) {
            return en;
        }
    }

    /** One string for the UI language from a content item (en/gu/ur/hi fields). */
    public static String one(JSONObject o, String[] fields) {
        String v = o.optString(fields[Math.min(cur, fields.length - 1)]);
        return v.length() > 0 ? v : o.optString(fields[0]);
    }

    public static void set(int l) {
        cur = l < EN || l > HI ? EN : l;
        synchronized (CACHE) {
            CACHE.clear();
        }
    }

    public static int get() {
        return cur;
    }

    public static boolean gu() {
        return cur == GU;
    }

    public static boolean ur() {
        return cur == UR;
    }

    public static boolean hi() {
        return cur == HI;
    }

    private static final String[][] DAY_SHORT = {
            {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"},
            {"રવિ", "સોમ", "મંગળ", "બુધ", "ગુરુ", "શુક્ર", "શનિ"},
            {"اتوار", "پیر", "منگل", "بدھ", "جمعرات", "جمعہ", "ہفتہ"},
            {"रवि", "सोम", "मंगल", "बुध", "गुरु", "शुक्र", "शनि"}};
    private static final String[][] DAY_INIT = {
            {"S", "M", "T", "W", "T", "F", "S"},
            {"ર", "સો", "મં", "બુ", "ગુ", "શુ", "શ"},
            {"اتوار", "پیر", "منگل", "بدھ", "جمعرات", "جمعہ", "ہفتہ"},
            {"र", "सो", "मं", "बु", "गु", "शु", "श"}};

    /** Day name, index 0 = Sunday. */
    public static String dayShort(int i) {
        return DAY_SHORT[cur][((i % 7) + 7) % 7];
    }

    /** Tiny day label for chips/charts, Sunday first (Urdu has no one-letter form, so the short name). */
    public static String[] dayInitials() {
        return DAY_INIT[cur].clone();
    }

    /** Same, Monday first. */
    public static String[] dayInitialsMon() {
        String[] a = DAY_INIT[cur], o = new String[7];
        for (int i = 0; i < 7; i++) o[i] = a[(i + 1) % 7];
        return o;
    }

    public static Locale locale() {
        return cur == GU ? new Locale("gu", "IN") : cur == UR ? new Locale("ur", "IN") : cur == HI ? new Locale("hi", "IN") : Locale.US;
    }

    /** Pick the right string for the current language from an English + Gujarati pair. */
    public static String pick(String en, String gu) {
        if (cur == GU) return gu != null && gu.length() > 0 ? gu : en;
        if (cur >= UR) return tr(en);
        return en;
    }

    private static final Map<String, String[]> M = new HashMap<String, String[]>();

    private static void p(String k, String en, String gu) {
        M.put(k, new String[]{en, gu});
    }

    public static String t(String key) {
        String[] v = M.get(key);
        if (v == null) return key;
        return cur == GU ? v[1] : cur >= UR ? tr(v[0]) : v[0];
    }

    public static String t(String key, Object a) {
        return t(key).replace("{0}", String.valueOf(a));
    }

    public static String t(String key, Object a, Object b) {
        return t(key).replace("{0}", String.valueOf(a)).replace("{1}", String.valueOf(b));
    }

    static {
        // nav
        p("nav_today", "Today", "આજ");
        p("nav_discover", "Discover", "જાણો");
        p("nav_wisdom", "Wisdom", "હિકમત");
        p("nav_progress", "Progress", "પ્રગતિ");
        p("nav_ask", "Ask", "પૂછો");
        // greetings
        p("greet_morning", "Subh bakhair ☀️", "સુબહ બખૈર ☀️");
        p("greet_day", "Assalamu Alaikum 👋", "અસ્સલામુ અલયકુમ 👋");
        p("greet_eve", "Shab bakhair 🌙", "શબ બખૈર 🌙");
        // today
        p("today_vs", "TODAY vs YESTERDAY", "આજ vs ગઈકાલ");
        p("ahead_by", "Ahead by {0} 🎉", "{0} થી આગળ 🎉");
        p("excellent", "Excellent day 💎", "શાનદાર દિવસ 💎");
        p("need_win", "Need +{0} to win", "જીતવા +{0} જોઈએ");
        p("yesterday", "Yesterday: {0}", "ગઈકાલ: {0}");
        p("timepass_minus", "   ·   timepass −{0}", "   ·   ટાઇમપાસ −{0}");
        p("level", "Lv {0} · {1}", "લેવલ {0} · {1}");
        p("tasks_title", "Today's tasks", "આજના કામ");
        p("tap_hint", "Tap to update · long-press to edit", "અપડેટ માટે ટૅપ · બદલવા લાંબું દબાવો");
        p("add", "＋ Add", "＋ ઉમેરો");
        p("rule_line", "📜 The rule: every day must be better than yesterday — or stay above 90.",
                "📜 નિયમ: દરેક દિવસ ગઈકાલ કરતાં બહેતર હોવો જોઈએ — અથવા 90થી ઉપર રહો.");
        p("done_tick", "Done ✓", "થઈ ગયું ✓");
        p("not_yet", "Not yet", "હજી નહીં");
        p("pts", "pts", "પોઇન્ટ");
        p("start", "▶\uFE0E  Start", "▶\uFE0E  શરૂ");
        p("answer", "Answer ›", "જવાબ ›");
        p("change", "Change ›", "બદલો ›");
        // timepass / counters card
        p("timepass_today", "📱 Timepass today", "📱 આજનો ટાઇમપાસ");
        p("usage_off", "Screen-time access is off — tap to allow, so I can track it.",
                "સ્ક્રીન-ટાઇમ ઍક્સેસ બંધ છે — ટૅપ કરીને ચાલુ કરો, જેથી હું ટ્રૅક કરી શકું.");
        p("over_limit", "Over your limit by {0} min — that costs you {1} points today.",
                "તમારી મર્યાદાથી {0} મિનિટ વધુ — આજે તમને {1} પોઇન્ટનું નુકસાન.");
        p("reels_today", "🎬 Reels / Shorts today", "🎬 આજની રીલ્સ / શોર્ટ્સ");
        p("namahram_counter", "👁️ Na-mahram glances", "👁️ નામહરમ નજરો");
        p("tap_log", "Tap to log", "નોંધવા ટૅપ કરો");
        p("logged", "Logged. May Allah keep your gaze pure.", "નોંધાયું. અલ્લાહ તમારી નજર પાક રાખે.");
        // discover
        p("discover_sub", "Your {0} cards for today — learn, then go act.",
                "આજના તમારા {0} કાર્ડ — શીખો, પછી અમલ કરો.");
        p("swipe_next", "Swipe for next  →", "આગળ માટે સ્વાઇપ  →");
        p("save", "♡  Save", "♡  સેવ");
        p("saved", "♥  Saved", "♥  સેવ થયું");
        p("share", "↗  Share", "↗  શેર");
        p("next", "Next  →", "આગળ  →");
        p("finish", "Finish ✓", "પૂરું ✓");
        p("done_today", "You're done for today", "આજ માટે પૂરું થયું");
        p("done_msg", "You learned {0} useful things. Knowledge only counts when you act — close this and finish one task now.",
                "તમે {0} ઉપયોગી વાતો શીખી. ઇલ્મ ત્યારે જ કામનું જ્યારે અમલ કરો — બંધ કરો અને એક કામ પૂરું કરો.");
        p("go_tasks", "Go to my tasks  →", "મારા કામ પર જાઓ  →");
        p("read_again", "Read today's cards again", "આજના કાર્ડ ફરી વાંચો");
        // wisdom
        p("wisdom_sub", "Quran & Ahl al-Bayt reminders that power your nudges",
                "કુરઆન અને અહલેબૈતની નસીહતો જે તમારા રિમાઇન્ડર ચલાવે છે");
        p("add_one", "＋ Add one", "＋ એક ઉમેરો");
        p("paste_many", "⇪ Paste many", "⇪ ઘણા પેસ્ટ કરો");
        p("wisdom_of_day", "✦  WISDOM OF THE DAY", "✦  આજની હિકમત");
        p("all", "All", "બધા");
        p("saved_tab", "♥ Saved", "♥ સેવ");
        p("n_reminders", "{0} reminders · long-press to remove", "{0} નસીહતો · હટાવવા લાંબું દબાવો");
        // progress
        p("progress_sub", "Today must beat yesterday. Here's the proof.",
                "આજ ગઈકાલને હરાવવું જોઈએ. આ રહ્યો પુરાવો.");
        p("streak", "Streak · best {0}", "સિલસિલો · શ્રેષ્ઠ {0}");
        p("better_days", "Better days", "બહેતર દિવસો");
        p("avg7", "7-day average", "7-દિવસની સરેરાશ");
        p("last14", "Last 14 days", "છેલ્લા 14 દિવસ");
        p("badges", "Badges", "બૅજ");
        // settings bits used in main
        p("settings", "Settings", "સેટિંગ્સ");
        p("finish_setup", "⚠️  Finish setup so I can guard your time — tap here ({0} left)",
                "⚠️  સેટઅપ પૂરું કરો જેથી હું સમય સાચવી શકું — અહીં ટૅપ કરો ({0} બાકી)");
        // celebrations
        p("better_day_title", "Better Day!", "બહેતર દિવસ!");
        p("better_day_msg", "You just beat yesterday's score. Alhamdulillah — keep going, every point now is a bonus.",
                "તમે હમણાં ગઈકાલનો સ્કોર હરાવ્યો. અલ્હમ્દુલિલ્લાહ — ચાલુ રાખો, હવે દરેક પોઇન્ટ બોનસ છે.");
        p("level_up", "Level {0}!", "લેવલ {0}!");
        p("level_up_msg", "You are now a {0}. Your effort is adding up — MashaAllah.",
                "હવે તમે {0} છો. તમારી મહેનત રંગ લાવી રહી છે — માશાઅલ્લાહ.");
        p("alhamdulillah", "Alhamdulillah 🤲", "અલ્હમ્દુલિલ્લાહ 🤲");
    }
}
