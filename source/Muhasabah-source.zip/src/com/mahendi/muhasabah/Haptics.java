package com.mahendi.muhasabah;

import android.content.Context;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.EditText;
import java.lang.ref.WeakReference;

/**
 * Distinct, slightly strong haptics for each kind of action. Uses the phone's haptic "primitives"
 * when supported (crisp on the OnePlus X-axis motor), with fallbacks. Strength is set in Settings.
 */
public final class Haptics {
    public static final int TAP = 0, NAV = 1, TOGGLE = 2, SUCCESS = 3, START = 4, STOP = 5, WARN = 6, LONG = 7, REFRESH = 8, SELECT = 9;
    public static final String K_LEVEL = "haptic_level"; // 0 off, 1 light, 2 normal, 3 strong
    private static Vibrator vib;
    private static Context app;
    private static long lastAt;

    public static void init(Context c) {
        app = c.getApplicationContext();
        if (vib == null) vib = (Vibrator) app.getSystemService(Context.VIBRATOR_SERVICE);
    }

    private static float level() {
        int l = app == null ? 3 : Store.get(app).i(K_LEVEL, 3);
        return l <= 0 ? 0 : l == 1 ? 0.45f : l == 2 ? 0.75f : 1f;
    }

    public static void play(int kind) {
        if (vib == null || !vib.hasVibrator()) return;
        float s = level();
        if (s <= 0) return;
        long now = System.currentTimeMillis();
        if (kind == TAP && now - lastAt < 60) return; // a specific effect just played
        lastAt = now;
        try {
            VibrationEffect e = composed(kind, s);
            if (e == null) e = fallback(kind, s);
            vib.vibrate(e);
        } catch (Throwable ignored) {
        }
    }

    private static boolean has(int... p) {
        try {
            return vib.areAllPrimitivesSupported(p);
        } catch (Throwable t) {
            return false;
        }
    }

    private static VibrationEffect composed(int kind, float s) {
        VibrationEffect.Composition c = VibrationEffect.startComposition();
        int CLICK = VibrationEffect.Composition.PRIMITIVE_CLICK, TICK = VibrationEffect.Composition.PRIMITIVE_TICK,
                RISE = VibrationEffect.Composition.PRIMITIVE_QUICK_RISE, FALL = VibrationEffect.Composition.PRIMITIVE_QUICK_FALL,
                SLOW = VibrationEffect.Composition.PRIMITIVE_SLOW_RISE;
        int THUD = Build.VERSION.SDK_INT >= 31 ? VibrationEffect.Composition.PRIMITIVE_THUD : CLICK;
        int SPIN = Build.VERSION.SDK_INT >= 31 ? VibrationEffect.Composition.PRIMITIVE_SPIN : SLOW;
        switch (kind) {
            case TAP:
                if (!has(CLICK)) return null;
                c.addPrimitive(CLICK, 0.8f * s);
                break;
            case NAV:
                if (!has(TICK, CLICK)) return null;
                c.addPrimitive(TICK, 1f * s).addPrimitive(CLICK, 0.55f * s, 30);
                break;
            case SELECT:
                if (!has(TICK)) return null;
                c.addPrimitive(TICK, 1f * s);
                break;
            case TOGGLE:
                if (!has(CLICK)) return null;
                c.addPrimitive(CLICK, 1f * s).addPrimitive(CLICK, 0.6f * s, 70);
                break;
            case SUCCESS:
                if (!has(RISE, CLICK)) return null;
                c.addPrimitive(RISE, 0.7f * s).addPrimitive(CLICK, 1f * s, 40).addPrimitive(CLICK, 0.7f * s, 90);
                break;
            case START:
                if (!has(RISE)) return null;
                c.addPrimitive(RISE, 1f * s);
                break;
            case STOP:
                if (!has(FALL, CLICK)) return null;
                c.addPrimitive(FALL, 1f * s).addPrimitive(CLICK, 0.6f * s, 20);
                break;
            case WARN:
                if (!has(THUD, CLICK)) return null;
                c.addPrimitive(THUD, 1f * s).addPrimitive(THUD, 0.8f * s, 110);
                break;
            case LONG:
                if (!has(THUD)) return null;
                c.addPrimitive(THUD, 1f * s);
                break;
            case REFRESH:
                if (!has(SPIN)) return null;
                c.addPrimitive(SPIN, 0.9f * s);
                break;
            default:
                return null;
        }
        return c.compose();
    }

    private static VibrationEffect fallback(int kind, float s) {
        int amp = Math.max(1, Math.min(255, Math.round(255 * s)));
        switch (kind) {
            case SUCCESS:
                return VibrationEffect.createWaveform(new long[]{0, 30, 50, 45}, new int[]{0, amp / 2, 0, amp}, -1);
            case WARN:
                return VibrationEffect.createWaveform(new long[]{0, 60, 80, 60}, new int[]{0, amp, 0, amp}, -1);
            case TOGGLE:
                return VibrationEffect.createWaveform(new long[]{0, 18, 60, 14}, new int[]{0, amp, 0, amp * 2 / 3}, -1);
            case LONG:
                return VibrationEffect.createOneShot(55, amp);
            case START:
            case STOP:
            case REFRESH:
                return VibrationEffect.createOneShot(35, amp);
            default:
                return VibrationEffect.createOneShot(20, amp);
        }
    }

    // ---------- automatic tap haptic for every clickable view ----------
    private static WeakReference<View> target;
    private static float dx, dy;
    private static long downAt;
    private static boolean moved;
    private static final int[] LOC = new int[2];

    /** Call from Activity.dispatchTouchEvent / a dialog's root: buzzes when any clickable view is tapped. */
    public static void touch(View root, MotionEvent e) {
        if (root == null) return;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                dx = e.getRawX();
                dy = e.getRawY();
                downAt = System.currentTimeMillis();
                moved = false;
                View v = hit(root, dx, dy);
                target = v == null ? null : new WeakReference<>(v);
                break;
            case MotionEvent.ACTION_MOVE:
                int slop = ViewConfiguration.get(root.getContext()).getScaledTouchSlop();
                if (Math.abs(e.getRawX() - dx) > slop || Math.abs(e.getRawY() - dy) > slop) moved = true;
                break;
            case MotionEvent.ACTION_UP:
                View t = target == null ? null : target.get();
                target = null;
                if (t != null && !moved && t.isEnabled() && t.isShown()
                        && System.currentTimeMillis() - downAt < ViewConfiguration.getLongPressTimeout()) play(TAP);
                break;
            case MotionEvent.ACTION_CANCEL:
                target = null;
                break;
        }
    }

    private static View hit(View v, float x, float y) {
        if (v.getVisibility() != View.VISIBLE) return null;
        v.getLocationOnScreen(LOC);
        if (x < LOC[0] || y < LOC[1] || x > LOC[0] + v.getWidth() || y > LOC[1] + v.getHeight()) return null;
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = g.getChildCount() - 1; i >= 0; i--) {
                View h = hit(g.getChildAt(i), x, y);
                if (h != null) return h;
            }
        }
        return v.isClickable() && !(v instanceof EditText) ? v : null;
    }
}
