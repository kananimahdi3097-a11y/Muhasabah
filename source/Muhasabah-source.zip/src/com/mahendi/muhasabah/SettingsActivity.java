package com.mahendi.muhasabah;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Insets;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

/** Everything editable: tasks, apps & limits, schedule, permissions, backup. */
public class SettingsActivity extends Activity {
    @Override
    protected void attachBaseContext(android.content.Context b) {
        super.attachBaseContext(Ui.wrap(b));
    }

    @Override
    public boolean dispatchTouchEvent(android.view.MotionEvent ev) {
        Haptics.touch(getWindow().getDecorView(), ev);
        return super.dispatchTouchEvent(ev);
    }

    private Store s;
    private LinearLayout page;
    private ScrollView sv;
    private String query = "";
    private boolean searchOpen;
    private EditText searchBox;
    private TextView noHits;
    private final java.util.WeakHashMap<View, Integer> origVis = new java.util.WeakHashMap<View, Integer>();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.init(this);
        s = Store.get(this);
        sv = new ScrollView(this);
        sv.setBackgroundColor(Ui.BG);
        page = Ui.col(this);
        sv.addView(page);
        setContentView(sv);
        sv.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View v, WindowInsets in) {
                Insets i = in.getInsets(WindowInsets.Type.systemBars());
                page.setPadding(Ui.dp(18) + i.left, Ui.dp(12) + i.top, Ui.dp(18) + i.right, Ui.dp(30) + i.bottom);
                return WindowInsets.CONSUMED;
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        build();
    }

    private final Runnable rebuildR = new Runnable() {
        @Override
        public void run() {
            rebuild();
        }
    };

    private void rebuild() {
        final int y = sv.getScrollY();
        build();
        Ui.holdScroll(sv, y);
    }

    private void build() {
        page.removeAllViews();
        LinearLayout head = Ui.row(this);
        TextView back = Ui.text(this, "←", 22, Ui.TEXT, true);
        back.setGravity(Gravity.CENTER);
        back.setBackground(Ui.circle(Ui.CARD2));
        head.addView(back, Ui.lpm(Ui.dp(44), Ui.dp(44), 0, 0, 12, 0));
        Ui.press(back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        head.addView(Ui.title(this, Lang.t("settings"), 26), Ui.weight(1));
        final TextView find = Ui.text(this, "🔍", 18, Ui.TEXT, false);
        find.setGravity(Gravity.CENTER);
        find.setBackground(Ui.circle(searchOpen ? Ui.alpha(Ui.GOLD, 0.25f) : Ui.CARD2));
        Ui.press(find);
        head.addView(find, Ui.lp(Ui.dp(44), Ui.dp(44)));
        page.addView(head, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 8));
        origVis.clear();

        // search bar (🔍 toggles it)
        searchBox = Ui.input(this, HadithCard.label("Search settings… (e.g. reels, lock, language)", "સેટિંગ્સ શોધો… (જેમ કે રીલ્સ, લૉક, ભાષા)",
                "ترتیبات تلاش کریں… (مثلاً ریلز، لاک، زبان)", "सेटिंग्स खोजें… (जैसे रील्स, लॉक, भाषा)"), query, false);
        searchBox.setSingleLine(true);
        searchBox.setVisibility(searchOpen ? View.VISIBLE : View.GONE);
        page.addView(searchBox, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 6));
        noHits = Ui.text(this, HadithCard.label("Nothing found", "કંઈ મળ્યું નહીં", "کچھ نہیں ملا", "कुछ नहीं मिला"), 14, Ui.MUTED, false);
        noHits.setGravity(Gravity.CENTER);
        noHits.setPadding(0, Ui.dp(30), 0, Ui.dp(30));
        noHits.setVisibility(View.GONE);
        noHits.setTag("nohits");
        find.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Haptics.play(Haptics.TAP);
                searchOpen = !searchOpen;
                find.setBackground(Ui.circle(searchOpen ? Ui.alpha(Ui.GOLD, 0.25f) : Ui.CARD2));
                android.view.inputmethod.InputMethodManager im = (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                if (searchOpen) {
                    searchBox.setVisibility(View.VISIBLE);
                    searchBox.requestFocus();
                    im.showSoftInput(searchBox, 0);
                    sv.smoothScrollTo(0, 0);
                } else {
                    searchBox.setText("");
                    searchBox.setVisibility(View.GONE);
                    im.hideSoftInputFromWindow(searchBox.getWindowToken(), 0);
                }
            }
        });
        searchBox.addTextChangedListener(new android.text.TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence c, int a, int b, int d) {
            }

            @Override
            public void onTextChanged(CharSequence c, int a, int b, int d) {
            }

            @Override
            public void afterTextChanged(android.text.Editable e) {
                query = e.toString().trim();
                applyFilter();
            }
        });

        // ---------- Commitment lock
        section(Lang.pick("COMMITMENT LOCK", "કમિટમેન્ટ લૉક"));
        LinearLayout lockCard = Ui.card(this);
        LockUi.settingsCard(this, lockCard, rebuildR);
        page.addView(lockCard);

        // ---------- Language
        section(Lang.pick("LANGUAGE", "ભાષા") + " · زبان · भाषा");
        LinearLayout lc2 = Ui.card(this);
        lc2.addView(Ui.text(this, Lang.pick("Menus & buttons", "મેનુ અને બટન"), 13, Ui.SUB, true), Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 8));
        final int[] lh = {Math.max(0, Math.min(3, s.i(Store.K_LANG, 0)))};
        lc2.addView(Dialogs.selector(this, Lang.NAMES, lh, new Runnable() {
            @Override
            public void run() {
                s.put(Store.K_LANG, lh[0]);
                Lang.set(lh[0]);
                rebuild();
            }
        }));
        lc2.addView(Ui.text(this, Lang.pick("Translations under ayat, hadith & cards — pick any (Arabic is always shown)",
                "આયત, હદીસ અને કાર્ડ નીચે અનુવાદ — ગમે તેટલા પસંદ કરો (અરબી હંમેશા દેખાશે)"), 13, Ui.SUB, true),
                Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 16, 0, 8));
        final android.widget.HorizontalScrollView mhs = new android.widget.HorizontalScrollView(this);
        mhs.setHorizontalScrollBarEnabled(false);
        final LinearLayout mrow = Ui.row(this);
        mhs.addView(mrow);
        final int[] cm = {s.contentMask()};
        final Runnable[] paintM = new Runnable[1];
        paintM[0] = new Runnable() {
            @Override
            public void run() {
                for (int k = 0; k < mrow.getChildCount(); k++) {
                    TextView t = (TextView) mrow.getChildAt(k);
                    boolean on = (cm[0] & (1 << k)) != 0;
                    t.setBackground(on ? Ui.grad(Ui.GOLD, Ui.GOLD_D, 50, android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT)
                            : Ui.roundStroke(Ui.CARD2, 50, Ui.STROKE, 1));
                    t.setTextColor(on ? 0xFF1A1205 : Ui.SUB);
                    t.setText(Fonts.mixed((on ? "✓ " : "") + Lang.NAMES[k]));
                }
            }
        };
        for (int k = 0; k < 4; k++) {
            final int bit = 1 << k;
            TextView t = Ui.text(this, Lang.NAMES[k], 13, Ui.SUB, true);
            t.setPadding(Ui.dp(14), Ui.dp(8), Ui.dp(14), Ui.dp(8));
            LinearLayout.LayoutParams p = Ui.lp(Ui.WRAP, Ui.WRAP);
            p.setMargins(0, 0, Ui.dp(8), 0);
            mrow.addView(t, p);
            t.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int nm = cm[0] ^ bit;
                    if (nm == 0) {
                        Haptics.play(Haptics.WARN);
                        return; // keep at least one
                    }
                    Haptics.play(Haptics.SELECT);
                    cm[0] = nm;
                    s.put(Store.K_CMASK, nm);
                    Lang.setMask(nm);
                    paintM[0].run();
                }
            });
        }
        paintM[0].run();
        lc2.addView(mhs);
        page.addView(lc2);

        // ---------- Look
        section(Lang.pick("LOOK", "દેખાવ"));
        LinearLayout lk = Ui.card(this);
        lk.addView(Ui.text(this, Lang.pick("Accent colour", "મુખ્ય રંગ"), 13, Ui.SUB, true), Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 10));
        LinearLayout sw = Ui.row(this);
        int curAcc = s.i("accent", 0);
        for (int k = 0; k < Ui.ACCENTS.length; k++) {
            final int idx = k;
            TextView dot = Ui.text(this, k == curAcc ? "✓" : "", 16, 0xFF111111, true);
            dot.setGravity(Gravity.CENTER);
            dot.setBackground(Ui.grad(Ui.ACCENTS[k][1], Ui.ACCENTS[k][2], 50, android.graphics.drawable.GradientDrawable.Orientation.TL_BR));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(Ui.dp(44), Ui.dp(44));
            p.setMargins(0, 0, Ui.dp(12), 0);
            sw.addView(dot, p);
            Ui.press(dot);
            dot.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    s.put("accent", idx);
                    Ui.init(SettingsActivity.this);
                    rebuild();
                }
            });
        }
        lk.addView(sw);
        lk.addView(Ui.text(this, Lang.pick("Button vibration (each action feels different)", "બટન વાઇબ્રેશન (દરેક કામનો અલગ અનુભવ)"), 13, Ui.SUB, true),
                Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 16, 0, 8));
        final int[] hv = {Math.max(0, Math.min(3, s.i(Haptics.K_LEVEL, 3)))};
        lk.addView(Dialogs.selector(this, new String[]{Lang.pick("Off", "બંધ"), Lang.pick("Light", "હળવું"), Lang.pick("Normal", "સામાન્ય"), Lang.pick("Strong", "મજબૂત")}, hv, new Runnable() {
            @Override
            public void run() {
                s.put(Haptics.K_LEVEL, hv[0]);
                Haptics.play(Haptics.SUCCESS);
            }
        }));
        lk.addView(Ui.space(this, 8));
        toggle(lk, Lang.pick("Opening animation", "શરૂઆતનું એનિમેશન"),
                Lang.pick("Glowing emblem, name and Arabic when the app opens", "એપ ખૂલે ત્યારે ચમકતો લોગો, નામ અને અરબી"), Intro.K_ON, true);
        page.addView(lk);

        // ---------- Setup / permissions
        section(Lang.pick("SETUP — needed for the habit guardian", "સેટઅપ — ગાર્ડિયન માટે જરૂરી"));
        boolean usage = WatchService.hasUsage(this), notif = WatchService.hasNotif(this),
                overlay = WatchService.hasOverlay(this), battery = WatchService.hasBattery(this);
        LinearLayout pc = Ui.card(this);
        permRow(pc, "📊", "Screen-time access", "So I can see time spent in timepass apps", usage, new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
        Intent ni = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
        permRow(pc, "🔔", "Notifications", "For Hadith reminders and nudges", notif, ni);
        permRow(pc, "🛑", "Display over other apps", "For the full-screen pause on heavy scrolling", overlay,
                new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
        permRow(pc, "🔋", "Battery: unrestricted", "So OnePlus doesn't stop the guardian", battery,
                new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName())));
        TextView tip = Ui.text(this, "OnePlus tip: also open Settings → Apps → Muhasabah → Battery → \"Allow background activity\", "
                + "and in Recents, lock the Muhasabah card (🔒) so it is never cleared.", 12, Ui.MUTED, false);
        tip.setPadding(0, Ui.dp(10), 0, 0);
        pc.addView(tip);
        page.addView(pc);

        // ---------- Behaviour
        section("BEHAVIOUR");
        LinearLayout bc = Ui.card(this);
        toggle(bc, "🛡️  Habit guardian", "Watch apps, nudge at night, daily check-ins", Store.K_MONITOR, true);
        toggle(bc, "🔥  Strict Gujarati mode", "\"Have to kari le bhai…\" when the day is going badly", Store.K_STRICT, true);
        toggle(bc, HadithCard.label("🏆  Compete with friends", "🏆  મિત્રો સાથે સ્પર્ધા", "🏆  دوستوں سے مقابلہ", "🏆  दोस्तों से मुक़ाबला"),
                HadithCard.label("Optional · a small group leaderboard of daily scores, on the home screen", "મરજિયાત · રોજના સ્કોરનું નાનું ગ્રુપ લીડરબોર્ડ, હોમ સ્ક્રીન પર",
                        "اختیاری · روزانہ اسکور کا چھوٹا گروپ لیڈر بورڈ، ہوم اسکرین پر", "वैकल्पिक · रोज़ के स्कोर का छोटा ग्रुप लीडरबोर्ड, होम स्क्रीन पर"), Compete.K_ON, false);
        valueRow(bc, "👤  Your name", s.s(Store.K_NAME, "Mahdi"), new Runnable() {
            @Override
            public void run() {
                final List<String> out = new ArrayList<String>();
                Dialogs.prompt(SettingsActivity.this, "Your name", s.s(Store.K_NAME, ""), false, out, new Runnable() {
                    @Override
                    public void run() {
                        if (out.size() > 0 && out.get(0).length() > 0) s.put(Store.K_NAME, out.get(0));
                        rebuild();
                    }
                });
            }
        });
        valueRow(bc, HadithCard.label("✏️  Edit previous days for", "✏️  પાછલા દિવસો સુધારવાની મુદત", "✏️  پچھلے دن درست کرنے کی مدت", "✏️  पिछले दिन ठीक करने की मोहलत"),
                PastDays.windowHours(s) + " h", new Runnable() {
            @Override
            public void run() {
                s.put(PastDays.K_WINDOW, PastDays.windowHours(s) == 48 ? 24 : 48);
                Haptics.play(Haptics.SELECT);
                rebuild();
            }
        });
        valueRow(bc, "✨  Discover cards per day", String.valueOf(s.i(Store.K_FEEDCAP, 12)), new Runnable() {
            @Override
            public void run() {
                final List<String> out = new ArrayList<String>();
                Dialogs.prompt(SettingsActivity.this, "Cards per day (keeps the feed healthy)", String.valueOf(s.i(Store.K_FEEDCAP, 12)), true, out, new Runnable() {
                    @Override
                    public void run() {
                        try {
                            s.put(Store.K_FEEDCAP, Math.max(3, Math.min(60, Integer.parseInt(out.get(0)))));
                        } catch (Exception ignored) {
                        }
                        rebuild();
                    }
                });
            }
        });
        final java.io.File af = new java.io.File(getFilesDir(), "arabic_font.ttf");
        fontRow(bc, "🕋  Arabic font", af.exists() ? "Your file ✓" : "Al Qalam (built-in)", 77, af);
        final java.io.File gf = new java.io.File(getFilesDir(), "gujarati_font.ttf");
        fontRow(bc, "અ  Gujarati font", gf.exists() ? "Your file ✓" : "Shruti (built-in)", 78, gf);
        TextView ft = Ui.text(this, "Al Qalam (Arabic) and Shruti (Gujarati) are built in. Tap to use a different .ttf; long-press a row to go back to the built-in font.", 12, Ui.MUTED, false);
        ft.setPadding(0, Ui.dp(4), 0, Ui.dp(4));
        bc.addView(ft);
        page.addView(bc);

        // ---------- Guardian (blocking)
        section(Lang.gu() ? "ગાર્ડિયન — રીલ્સ અને બ્લૉકિંગ" : "GUARDIAN — REELS & BLOCKING");
        LinearLayout gc = Ui.card(this);
        boolean guard = GuardService.isOn();
        if (GuardService.available(this)) {
            permRow(gc, "🛡️", Lang.pick("Accessibility guardian", "ઍક્સેસિબિલિટી ગાર્ડિયન"),
                    Lang.pick("Required to count Reels/Shorts and block sites & words", "રીલ્સ ગણવા અને સાઇટ/શબ્દ બ્લૉક કરવા જરૂરી"),
                    guard, new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            screenGuardRows(gc, guard);
            capRows(gc);
        } else {
            TextView lite = Ui.text(this, Lang.pick(
                    "Lite version: automatic reels counting and site/word blocking need the full version (install it later with Play Protect paused).",
                    "લાઇટ વર્ઝન: ઑટો રીલ્સ ગણતરી અને સાઇટ/શબ્દ બ્લૉકિંગ માટે ફુલ વર્ઝન જોઈએ (પછી Play Protect થોડી વાર બંધ કરીને ઇન્સ્ટોલ કરો)."),
                    13, Ui.ORANGE, false);
            lite.setPadding(0, 0, 0, Ui.dp(8));
            gc.addView(lite);
        }
        valueRow(gc, Lang.pick("🎬  Reels / Shorts per day", "🎬  રોજની રીલ્સ / શોર્ટ્સ"), String.valueOf(s.reelsLimit()), new Runnable() {
            @Override
            public void run() {
                final List<String> out = new ArrayList<String>();
                Dialogs.prompt(SettingsActivity.this, Lang.pick("Reels allowed per day", "રોજ કેટલી રીલ્સ"), String.valueOf(s.reelsLimit()), true, out, new Runnable() {
                    @Override
                    public void run() {
                        try {
                            int nv = Math.max(0, Math.min(500, Integer.parseInt(out.get(0)))), ov = s.reelsLimit();
                            if (nv > ov) {
                                LockUi.loosen(SettingsActivity.this, Lock.change("int", Store.K_REELS_LIMIT, nv,
                                        Lang.pick("Reels limit " + ov + " → " + nv, "રીલ્સ મર્યાદા " + ov + " → " + nv)), rebuildR);
                                return;
                            }
                            s.put(Store.K_REELS_LIMIT, nv);
                        } catch (Exception ignored) {
                        }
                        rebuild();
                    }
                });
            }
        });
        valueRow(gc, Lang.pick("🚫  Blocked words", "🚫  બ્લૉક શબ્દો"), s.blockedWords().size() + "", new Runnable() {
            @Override
            public void run() {
                editList(Lang.pick("Blocked words", "બ્લૉક શબ્દો"),
                        Lang.pick("One word or phrase per line. Any page or search with these is blocked.",
                                "એક લીટીમાં એક શબ્દ. આ શબ્દોવાળું પેજ કે સર્ચ બ્લૉક થશે."),
                        s.s("blocked_words", ""), true);
            }
        });
        valueRow(gc, Lang.pick("🌐  Blocked websites", "🌐  બ્લૉક વેબસાઇટ"), s.blockedSites().size() + "", new Runnable() {
            @Override
            public void run() {
                editList(Lang.pick("Blocked websites", "બ્લૉક વેબસાઇટ"),
                        Lang.pick("One domain per line, e.g. example.com", "એક લીટીમાં એક ડોમેન, દા.ત. example.com"),
                        s.s("blocked_sites", ""), false);
            }
        });
        TextView gt = Ui.text(this, Lang.pick(
                "Blocking has no off-switch inside the app. To fully stop it you must turn off this Accessibility service in your phone's Settings. Reels detection is best-effort and may miss or miscount sometimes.",
                "બ્લૉકિંગનો ઍપમાં કોઈ ઑફ-સ્વિચ નથી. પૂરેપૂરું બંધ કરવા ફોનના સેટિંગ્સમાંથી આ ઍક્સેસિબિલિટી સર્વિસ બંધ કરવી પડશે. રીલ્સ ડિટેક્શન શક્ય એટલું સારું છે, ક્યારેક ચૂકી શકે."),
                12, Ui.MUTED, false);
        gt.setPadding(0, Ui.dp(8), 0, 0);
        gc.addView(gt);
        page.addView(gc);

        // ---------- Schedule
        section("SCHEDULE");
        LinearLayout sc = Ui.card(this);
        timeRow(sc, "🌅  Wake-up time", Store.K_WAKE, 315);
        timeRow(sc, "🌙  Sleep time", Store.K_SLEEP, 1380);
        timeRow(sc, "⚖️  Evening check (today vs yesterday)", Store.K_CHECK, 1260);
        TextView st = Ui.text(this, "Late-night nudges start 30 min after sleep time. If you first use your phone over 1 hour after wake-up time, you get an oversleep reminder.", 12, Ui.MUTED, false);
        st.setPadding(0, Ui.dp(8), 0, 0);
        sc.addView(st);
        page.addView(sc);

        // ---------- Tasks
        section("DAILY TASKS");
        LinearLayout tc = Ui.card(this);
        List<Task> tasks = s.tasks();
        for (final Task t : tasks) {
            if (t.expired()) continue; // finished one-time tasks stay in history only
            LinearLayout r = Ui.row(this);
            r.setPadding(0, Ui.dp(8), 0, Ui.dp(8));
            r.addView(Ui.text(this, t.emoji, 20, Ui.TEXT, false), Ui.lpm(Ui.dp(34), Ui.WRAP, 0, 0, 6, 0));
            LinearLayout c = Ui.col(this);
            c.addView(Ui.text(this, t.name, 15, t.active ? Ui.TEXT : Ui.MUTED, true));
            String desc = Task.TYPE_NAMES[t.type] + (t.type == Task.COUNT || t.type == Task.MINUTES ? " · target " + t.target : "")
                    + (t.type == Task.CHOICE ? " · " + t.options.length + " answers" : "")
                    + " · " + Task.IMPORTANCE_NAMES[Math.max(0, Math.min(2, t.importance - 1))] + (t.active ? "" : " · hidden");
            c.addView(Ui.text(this, desc, 12, Ui.SUB, false));
            r.addView(c, Ui.weight(1));
            TextView up = Ui.text(this, "↑", 18, Ui.SUB, true), dn = Ui.text(this, "↓", 18, Ui.SUB, true);
            up.setPadding(Ui.dp(10), Ui.dp(4), Ui.dp(10), Ui.dp(4));
            dn.setPadding(Ui.dp(10), Ui.dp(4), Ui.dp(10), Ui.dp(4));
            r.addView(up);
            r.addView(dn);
            up.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    s.moveTask(t.id, -1);
                    rebuild();
                }
            });
            dn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    s.moveTask(t.id, 1);
                    rebuild();
                }
            });
            r.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Dialogs.editTask(SettingsActivity.this, t, reb);
                }
            });
            tc.addView(r);
        }
        TextView addT = Ui.button(this, "＋ Add a task", Ui.EMERALD, Ui.TEAL, 0xFFFFFFFF);
        tc.addView(addT, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        addT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Dialogs.editTask(SettingsActivity.this, null, reb);
            }
        });
        TextView resetT = Ui.ghost(this, "Restore default tasks", Ui.SUB);
        tc.addView(resetT, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        resetT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Dialogs.confirm(SettingsActivity.this, "Restore default tasks?", "Your custom tasks will be replaced by the starter set. History is kept.", new Runnable() {
                    @Override
                    public void run() {
                        s.saveTasks(Store.defaultTasks());
                        rebuild();
                    }
                });
            }
        });
        page.addView(tc);

        // ---------- Apps
        section("TIMEPASS APPS & DAILY LIMITS");
        LinearLayout ac = Ui.card(this);
        final JSONArray apps = s.apps();
        for (int k = 0; k < apps.length(); k++) {
            final int idx = k;
            final JSONObject o = apps.optJSONObject(k);
            if (o == null) continue;
            LinearLayout r = Ui.row(this);
            r.setPadding(0, Ui.dp(10), 0, Ui.dp(10));
            r.addView(Ui.text(this, o.optString("name"), 15, Ui.TEXT, true), Ui.weight(1));
            r.addView(Ui.pill(this, o.optInt("limit", 30) + " min/day", Ui.alpha(Ui.GOLD, 0.15f), Ui.GOLD));
            TextView x = Ui.text(this, "✕", 16, Ui.MUTED, true);
            x.setPadding(Ui.dp(14), Ui.dp(4), Ui.dp(4), Ui.dp(4));
            r.addView(x);
            r.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final List<String> out = new ArrayList<String>();
                    Dialogs.prompt(SettingsActivity.this, o.optString("name") + " — minutes per day", String.valueOf(o.optInt("limit", 30)), true, out, new Runnable() {
                        @Override
                        public void run() {
                            try {
                                int nv = Math.max(0, Integer.parseInt(out.get(0))), ov = o.optInt("limit", 30);
                                if (nv > ov) {
                                    LockUi.loosen(SettingsActivity.this, Lock.change("app_limit", o.optString("pkg"), nv,
                                            o.optString("name") + " " + ov + " → " + nv + Lang.pick(" min/day", " મિ/દિ")), rebuildR);
                                    return;
                                }
                                o.put("limit", nv);
                                s.saveApps(apps);
                            } catch (Exception ignored) {
                            }
                            rebuild();
                        }
                    });
                }
            });
            x.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    LockUi.loosen(SettingsActivity.this, Lock.change("app_remove", o.optString("pkg"), 0,
                            Lang.pick("Stop limiting " + o.optString("name"), o.optString("name") + " પરથી મર્યાદા હટાવો")), rebuildR);
                }
            });
            ac.addView(r);
        }
        TextView addA = Ui.button(this, "＋ Add an app from my phone", Ui.GOLD, Ui.GOLD_D, 0xFF1A1205);
        ac.addView(addA, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        addA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickApp();
            }
        });
        TextView at = Ui.text(this, "Tap an app to change its limit. Reminders: 5 min before limit → at limit → 15 min over → full-screen pause at 30 min over.", 12, Ui.MUTED, false);
        at.setPadding(0, Ui.dp(10), 0, 0);
        ac.addView(at);
        page.addView(ac);

        // ---------- Fine-tune (every number)
        section(Lang.pick("FINE-TUNE — every number", "બારીક સેટિંગ — દરેક આંકડો"));
        String[] groups = {Cfg.G_SCORE, Cfg.G_NUDGE, Cfg.G_APPS, Cfg.G_REM, Cfg.G_CAL};
        for (String g : groups) {
            LinearLayout fc = Ui.card(this);
            fc.addView(Ui.text(this, Cfg.groupTitle(g), 14, Ui.GOLD, true), Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 4));
            for (final Cfg.Item it : Cfg.ALL) {
                if (!it.group.equals(g)) continue;
                final int cur = s.i(it.key, it.def);
                String val = it.time ? Ui.clock(cur) : cur + (it.unit.length() > 0 ? " " + it.unit : "");
                LinearLayout r = Ui.row(this);
                r.setPadding(0, Ui.dp(10), 0, Ui.dp(10));
                r.addView(Ui.text(this, Lang.pick(it.en, it.gu), 13.5f, Ui.TEXT, false), Ui.weight(1));
                r.addView(Ui.text(this, val + "  ›", 14, cur == it.def ? Ui.SUB : Ui.GOLD, true), Ui.lpm(Ui.WRAP, Ui.WRAP, 10, 0, 0, 0));
                r.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (it.time) {
                            new TimePickerDialog(SettingsActivity.this, android.R.style.Theme_DeviceDefault_Dialog_Alert,
                                    new TimePickerDialog.OnTimeSetListener() {
                                        @Override
                                        public void onTimeSet(TimePicker view, int h, int m) {
                                            s.put(it.key, h * 60 + m);
                                            rebuild();
                                        }
                                    }, cur / 60, cur % 60, false).show();
                            return;
                        }
                        final List<String> out = new ArrayList<String>();
                        Dialogs.prompt(SettingsActivity.this, Lang.pick(it.en, it.gu) + "  (" + it.min + "–" + it.max + ")", String.valueOf(cur), true, out, new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    int nv = Math.max(it.min, Math.min(it.max, Integer.parseInt(out.get(0))));
                                    int dir = Lock.looseDir(it.key);
                                    if (dir != 0 && (nv - cur) * dir > 0) {
                                        LockUi.loosen(SettingsActivity.this, Lock.change("int", it.key, nv, Lang.pick(it.en, it.gu) + ": " + cur + " → " + nv), rebuildR);
                                        return;
                                    }
                                    s.put(it.key, nv);
                                } catch (Exception ignored) {
                                }
                                rebuild();
                            }
                        });
                    }
                });
                r.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        int dir = Lock.looseDir(it.key);
                        if (dir != 0 && (it.def - cur) * dir > 0) {
                            LockUi.loosen(SettingsActivity.this, Lock.change("reset", it.key, 0, Lang.pick(it.en, it.gu) + ": " + cur + " → " + it.def), rebuildR);
                            return true;
                        }
                        s.p.edit().remove(it.key).apply();
                        Toast.makeText(SettingsActivity.this, Lang.pick("Back to default", "ડિફૉલ્ટ પર પાછું"), Toast.LENGTH_SHORT).show();
                        rebuild();
                        return true;
                    }
                });
                fc.addView(r);
            }
            page.addView(fc, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 10));
        }
        TextView ftn = Ui.text(this, Lang.pick("Tap a number to change it · long-press to reset it to default.", "બદલવા ટૅપ કરો · ડિફૉલ્ટ માટે લાંબું દબાવો."), 12, Ui.MUTED, false);
        page.addView(ftn);

        // ---------- Discover categories
        section(Lang.pick("DISCOVER — CATEGORIES", "જાણો — વિભાગ"));
        LinearLayout dcat = Ui.card(this);
        for (final String cat : Store.FEED_CATS) {
            LinearLayout r = Ui.row(this);
            r.setPadding(0, Ui.dp(6), 0, Ui.dp(6));
            r.addView(Ui.text(this, cat, 15, Ui.TEXT, true), Ui.weight(1));
            android.widget.Switch swc = new android.widget.Switch(this);
            swc.setChecked(s.feedCatOn(cat));
            swc.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(android.widget.CompoundButton b, boolean on) {
                Haptics.play(Haptics.TOGGLE);
                    s.setFeedCat(cat, on);
                }
            });
            r.addView(swc);
            dcat.addView(r);
        }
        page.addView(dcat);

        // ---------- Wisdom refresh
        section(Lang.pick("WISDOM — WHAT ↻ REFRESH BRINGS", "હિકમત — ↻ રિફ્રેશમાં શું આવે"));
        LinearLayout wr = Ui.card(this);
        final String[] rkeys = {"imamzaman,society", "imamzaman", "society", "all"};
        String[] rlabels = {Lang.pick("Imam-e-Zamana + Society", "ઇમામે ઝમાના + સમાજ"), Lang.pick("Imam-e-Zamana", "ઇમામે ઝમાના"),
                Lang.pick("Society", "સમાજ"), Lang.pick("Everything", "બધું")};
        final int[] rsel = {0};
        String rcur = s.s(Store.K_REFRESH, rkeys[0]);
        for (int k = 0; k < rkeys.length; k++) if (rkeys[k].equals(rcur)) rsel[0] = k;
        wr.addView(Dialogs.selector(this, rlabels, rsel, new Runnable() {
            @Override
            public void run() {
                s.put(Store.K_REFRESH, rkeys[rsel[0]]);
            }
        }));
        page.addView(wr);

        // ---------- Library & content
        section(Lang.pick("LIBRARY & CONTENT", "લાઇબ્રેરી અને કન્ટેન્ટ"));
        LinearLayout libc = Ui.card(this);
        libc.addView(Ui.text(this, Lang.pick(s.wisdom().size() + " reminders · " + Library.get(this).count() + " entries from books",
                s.wisdom().size() + " નસીહતો · પુસ્તકોમાંથી " + Library.get(this).count()), 14, Ui.TEXT, true));
        for (final String[] bk : Library.get(this).books()) {
            LinearLayout r = Ui.row(this);
            r.setPadding(0, Ui.dp(8), 0, Ui.dp(8));
            r.addView(Ui.text(this, "📚  " + bk[0] + "  ·  " + bk[1], 13.5f, Ui.SUB, false), Ui.weight(1));
            TextView x = Ui.text(this, "✕", 15, Ui.MUTED, true);
            x.setPadding(Ui.dp(12), 0, Ui.dp(4), 0);
            r.addView(x);
            x.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Dialogs.confirm(SettingsActivity.this, Lang.pick("Remove this book?", "આ પુસ્તક હટાવવું?"), bk[0], new Runnable() {
                        @Override
                        public void run() {
                            Library.get(SettingsActivity.this).deleteBook(bk[0]);
                            rebuild();
                        }
                    });
                }
            });
            libc.addView(r);
        }
        // ---- authentic hadith books (Thaqalayn, CC BY 4.0) — downloaded only on request
        try {
            final org.json.JSONArray idxArr = new org.json.JSONArray(s.s("packs_index", "[]"));
            boolean any = false;
            long total = 0;
            for (int k = 0; k < idxArr.length(); k++) if (idxArr.optJSONObject(k).optBoolean("optional")) total += idxArr.optJSONObject(k).optLong("size");
            for (int k = 0; k < idxArr.length(); k++) {
                final org.json.JSONObject p = idxArr.optJSONObject(k);
                if (p == null || !p.optBoolean("optional")) continue;
                if (!any) {
                    libc.addView(Ui.text(this, Lang.pick("HADITH BOOKS — Arabic + English, graded (tap ⬇ to download)",
                            "હદીસના પુસ્તકો — અરબી + અંગ્રેજી, દરજ્જા સાથે (ડાઉનલોડ માટે ⬇)"), 12, Ui.SUB, true), Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 14, 0, 6));
                    any = true;
                }
                final String pid = p.optString("id");
                boolean have = s.i("pack_" + pid, 0) >= p.optInt("version", 1);
                boolean want = s.b("want_" + pid, false);
                LinearLayout r = Ui.row(this);
                r.setPadding(0, Ui.dp(6), 0, Ui.dp(6));
                LinearLayout rc = Ui.col(this);
                rc.addView(Ui.text(this, p.optString("title"), 13.5f, Ui.TEXT, true));
                rc.addView(Ui.text(this, p.optInt("count") + Lang.pick(" hadith · ", " હદીસ · ") + String.format(java.util.Locale.US, "%.1f MB", p.optLong("size") / 1e6)
                        + " · " + p.optString("translator"), 11, Ui.MUTED, false));
                r.addView(rc, Ui.weight(1));
                TextView b = Ui.pill(this, have ? "✓" : want ? "…" : "⬇", have ? Ui.alpha(Ui.EMERALD, 0.18f) : Ui.alpha(Ui.GOLD, 0.15f), have ? Ui.EMERALD : Ui.GOLD);
                b.setPadding(Ui.dp(14), Ui.dp(7), Ui.dp(14), Ui.dp(7));
                r.addView(b);
                if (!have) {
                    Ui.press(b);
                    b.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            s.put("want_" + pid, true);
                            ((TextView) v).setText("…");
                            downloadBooks();
                        }
                    });
                }
                libc.addView(r);
            }
            if (any) {
                TextView all = Ui.ghost(this, Lang.pick("⬇  Download all books (" + Math.round(total / 1e6) + " MB, use Wi-Fi)",
                        "⬇  બધાં પુસ્તકો ડાઉનલોડ (" + Math.round(total / 1e6) + " MB, Wi-Fi વાપરો)"), Ui.GOLD);
                libc.addView(all, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
                all.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        for (int k = 0; k < idxArr.length(); k++) {
                            org.json.JSONObject p = idxArr.optJSONObject(k);
                            if (p != null && p.optBoolean("optional")) s.put("want_" + p.optString("id"), true);
                        }
                        downloadBooks();
                    }
                });
                TextView cr = Ui.text(this, Lang.pick("Source: Thaqalayn (Stichting Thaqalayn), CC BY 4.0 · translators as listed · gradings by al-Majlisi, al-Behbudi, al-Muhsini and others as shown per hadith.",
                        "સ્રોત: Thaqalayn (CC BY 4.0) · અનુવાદકો ઉપર મુજબ · દરેક હદીસ સાથે અલ્લામા મજલિસી, બહબૂદી, મોહસિની વગેરેનો દરજ્જો."), 11, Ui.MUTED, false);
                cr.setPadding(0, Ui.dp(8), 0, 0);
                libc.addView(cr);
            }
        } catch (Exception ignored) {
        }
        TextView dl = Ui.ghost(this, Lang.pick("⬇  Get new content now", "⬇  નવું કન્ટેન્ટ હમણાં લાવો"), Ui.TEXT);
        TextView impc = Ui.ghost(this, Lang.pick("📂  Import a book / content file", "📂  પુસ્તક / કન્ટેન્ટ ફાઇલ ઉમેરો"), Ui.TEXT);
        libc.addView(dl, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
        libc.addView(impc, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        dl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(SettingsActivity.this, Lang.pick("Checking…", "તપાસી રહ્યા છીએ…"), Toast.LENGTH_SHORT).show();
                Content.sync(SettingsActivity.this, true, new Content.Done() {
                    @Override
                    public void done(int added, String error) {
                        Toast.makeText(SettingsActivity.this, error != null ? Lang.pick("Couldn't download: ", "ડાઉનલોડ ન થયું: ") + error
                                : added == 0 ? Lang.pick("Up to date ✓", "બધું અપડેટ છે ✓") : Lang.pick(added + " new items added ✨", added + " નવી વસ્તુઓ ઉમેરાઈ ✨"), Toast.LENGTH_LONG).show();
                        rebuild();
                    }
                });
            }
        });
        impc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                try {
                    startActivityForResult(i, 79);
                } catch (Exception e) {
                    Toast.makeText(SettingsActivity.this, "No file picker found", Toast.LENGTH_SHORT).show();
                }
            }
        });
        page.addView(libc);

        // ---------- Data
        section("DATA & BACKUP");
        LinearLayout dc = Ui.card(this);
        valueRow(dc, Lang.pick("⬆️  Check for updates", "⬆️  અપડેટ તપાસો"), "v" + versionName(), new Runnable() {
            @Override
            public void run() {
                if (Updater.BASE.contains("GITHUB_USER")) return;
                Toast.makeText(SettingsActivity.this, Lang.pick("Checking…", "તપાસી રહ્યા છીએ…"), Toast.LENGTH_SHORT).show();
                Updater.check(SettingsActivity.this, new Updater.Listener() {
                    @Override
                    public void onResult(Updater.Info newer, String error) {
                        if (error != null) Toast.makeText(SettingsActivity.this, Lang.pick("Couldn't check: ", "ચેક ન થયું: ") + error, Toast.LENGTH_LONG).show();
                        else if (newer == null) Toast.makeText(SettingsActivity.this, Lang.pick("You have the latest version ✓", "તમારી પાસે નવું વર્ઝન છે ✓"), Toast.LENGTH_SHORT).show();
                        else {
                            Toast.makeText(SettingsActivity.this, Lang.pick("Update v" + newer.versionName + " found — open the Today screen to install.",
                                    "અપડેટ v" + newer.versionName + " મળ્યું — ઇન્સ્ટૉલ કરવા આજ સ્ક્રીન ખોલો."), Toast.LENGTH_LONG).show();
                            finish();
                        }
                    }

                    @Override
                    public void onProgress(int percent) {
                    }
                });
            }
        });
        TextView exp = Ui.ghost(this, "⇪  Export backup (share JSON)", Ui.TEXT);
        TextView imp = Ui.ghost(this, "⇩  Restore from backup", Ui.TEXT);
        TextView lib = Ui.ghost(this, "📿  Restore built-in Hadith library", Ui.TEXT);
        dc.addView(exp, Ui.lp(Ui.MATCH, Ui.WRAP));
        dc.addView(imp, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        dc.addView(lib, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        exp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_SUBJECT, "Muhasabah backup " + Store.today());
                i.putExtra(Intent.EXTRA_TEXT, exportJson());
                startActivity(Intent.createChooser(i, "Save backup to…"));
            }
        });
        imp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                restoreDialog();
            }
        });
        lib.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                restoreLibrary();
            }
        });
        page.addView(dc);

        TextView about = Ui.text(this, "Muhasabah " + versionName() + "\nMade For Mahdi Kanani\n" + HadithCard.label("All data stays on this phone",
                "બધો ડેટા આ ફોનમાં જ રહે છે", "سارا ڈیٹا اسی فون پر رہتا ہے", "सारा डेटा इसी फ़ोन पर रहता है")
                + "\nOpen source (AGPL-3.0) · github.com/kananimahdi3097-a11y/Muhasabah/tree/main/source"
                + "\nScreen guard: NudeNet (AGPL-3.0) · nsfwjs model (MIT)", 12, Ui.MUTED, false);
        about.setGravity(Gravity.CENTER);
        about.setPadding(0, Ui.dp(24), 0, 0);
        page.addView(about);
        page.addView(noHits);
        if (query.length() > 0) applyFilter();
    }

    // ---------- search
    private static String textOf(View v) {
        StringBuilder b = new StringBuilder();
        collect(v, b);
        return b.toString().toLowerCase(java.util.Locale.ROOT);
    }

    private static void collect(View v, StringBuilder b) {
        if (v instanceof EditText) return;
        if (v instanceof TextView) {
            CharSequence t = ((TextView) v).getText();
            if (t != null) b.append(t).append(' ');
        }
        if (v instanceof android.view.ViewGroup) {
            android.view.ViewGroup g = (android.view.ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) collect(g.getChildAt(i), b);
        }
    }

    private void setVis(View v, boolean show) {
        if (!origVis.containsKey(v)) origVis.put(v, v.getVisibility());
        Integer o = origVis.get(v);
        v.setVisibility(show ? (o == null ? View.VISIBLE : o) : View.GONE);
    }

    /** Shows only the rows (and their sections) that contain the search words; empty search restores everything. */
    private void applyFilter() {
        String q = query.toLowerCase(java.util.Locale.ROOT);
        boolean empty = q.length() == 0;
        int hits = 0;
        View header = null;
        boolean headerHit = false, sectionHasHit = false;
        // page children: [0]=title row, [1]=search box, then sections/cards …, last = noHits
        for (int i = 2; i < page.getChildCount(); i++) {
            View c = page.getChildAt(i);
            if (c == noHits) continue;
            if ("sec".equals(c.getTag())) {
                if (header != null) setVis(header, empty || sectionHasHit);
                header = c;
                headerHit = !empty && textOf(c).contains(q);
                sectionHasHit = headerHit;
                continue;
            }
            if (empty || headerHit) {
                restore(c);
                if (headerHit) hits++;
                continue;
            }
            boolean any = false;
            if (c instanceof LinearLayout && ((LinearLayout) c).getChildCount() > 0) {
                LinearLayout card = (LinearLayout) c;
                boolean prevShown = false;
                for (int k = 0; k < card.getChildCount(); k++) {
                    View r = card.getChildAt(k);
                    String t = textOf(r);
                    boolean show = t.trim().length() == 0 ? prevShown : t.contains(q);
                    setVis(r, show);
                    if (show && t.trim().length() > 0) any = true;
                    prevShown = show;
                }
                if (!any) any = textOf(c).contains(q) && card.getChildCount() == 0;
            } else any = textOf(c).contains(q);
            setVis(c, any);
            if (any) {
                hits++;
                sectionHasHit = true;
            }
        }
        if (header != null) setVis(header, empty || sectionHasHit);
        noHits.setVisibility(!empty && hits == 0 ? View.VISIBLE : View.GONE);
    }

    private void restore(View c) {
        setVis(c, true);
        if (c instanceof LinearLayout) {
            LinearLayout card = (LinearLayout) c;
            for (int k = 0; k < card.getChildCount(); k++) setVis(card.getChildAt(k), true);
        }
    }

    private String versionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "2";
        }
    }

    private void fontRow(LinearLayout parent, String title, String value, final int req, final java.io.File file) {
        LinearLayout r = Ui.row(this);
        r.setPadding(0, Ui.dp(12), 0, Ui.dp(12));
        r.addView(Ui.text(this, title, 15, Ui.TEXT, true), Ui.weight(1));
        r.addView(Ui.text(this, value + "  ›", 14, Ui.GOLD, true));
        r.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"font/ttf", "font/otf", "application/x-font-ttf",
                        "application/x-font-otf", "application/octet-stream", "font/*"});
                try {
                    startActivityForResult(i, req);
                } catch (Exception e) {
                    Toast.makeText(SettingsActivity.this, "No file picker found", Toast.LENGTH_SHORT).show();
                }
            }
        });
        r.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                if (file.exists() && file.delete()) {
                    Fonts.reload();
                    Toast.makeText(SettingsActivity.this, Lang.pick("Using built-in font", "બિલ્ટ-ઇન ફોન્ટ વપરાશે"), Toast.LENGTH_SHORT).show();
                }
                rebuild();
                return true;
            }
        });
        parent.addView(r);
    }

    private void downloadBooks() {
        Toast.makeText(this, Lang.pick("Downloading… you can keep using the app.", "ડાઉનલોડ થાય છે… ઍપ વાપરતા રહો."), Toast.LENGTH_SHORT).show();
        Content.sync(this, true, new Content.Done() {
            @Override
            public void done(int added, String error) {
                Toast.makeText(SettingsActivity.this, error != null ? Lang.pick("Couldn't download: ", "ડાઉનલોડ ન થયું: ") + error
                        : Lang.pick(added + " hadith added to your library ✨", added + " હદીસ લાઇબ્રેરીમાં ઉમેરાઈ ✨"), Toast.LENGTH_LONG).show();
                rebuild();
            }
        });
    }

    private void editList(String title, String help, String value, final boolean isWords) {
        LinearLayout body = Ui.col(this);
        body.addView(Ui.text(this, help, 13, Ui.SUB, false));
        body.addView(Ui.space(this, 10));
        final EditText box = Ui.input(this, "", value.replace(",", "\n"), false);
        box.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        box.setMinLines(8);
        box.setGravity(Gravity.TOP);
        body.addView(box);
        body.addView(Ui.space(this, 12));
        TextView ok = Ui.button(this, Lang.pick("Save", "સેવ"), Ui.EMERALD, Ui.TEAL, 0xFFFFFFFF);
        body.addView(ok, Ui.lp(Ui.MATCH, Ui.WRAP));
        final AlertDialog d = Dialogs.sheet(this, title, body);
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                java.util.List<String> oldL = isWords ? s.blockedWords() : s.blockedSites();
                java.util.List<String> newL = new java.util.ArrayList<String>();
                for (String x : box.getText().toString().split("[,\n]")) {
                    String t = x.trim().toLowerCase(java.util.Locale.US);
                    if (t.length() > 0 && !newL.contains(t)) newL.add(t);
                }
                StringBuilder keep = new StringBuilder(), removed = new StringBuilder();
                for (String w : oldL) {
                    keep.append(keep.length() > 0 ? "," : "").append(w);
                    if (!newL.contains(w)) removed.append(removed.length() > 0 ? "," : "").append(w);
                }
                for (String w : newL) if (!oldL.contains(w)) keep.append(keep.length() > 0 ? "," : "").append(w); // additions: instant
                if (isWords) s.setBlockedWords(keep.toString());
                else s.setBlockedSites(keep.toString());
                d.dismiss();
                if (removed.length() > 0) {
                    String rs = removed.toString().replace(",", ", ");
                    if (rs.length() > 60) rs = rs.substring(0, 57) + "…";
                    LockUi.loosen(SettingsActivity.this, Lock.change(isWords ? "words_remove" : "sites_remove", "", removed.toString(),
                            Lang.pick("Unblock: " + rs, "અનબ્લૉક: " + rs)), rebuildR);
                } else rebuild();
            }
        });
        d.show();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == 79 && res == RESULT_OK && data != null && data.getData() != null) {
            try {
                int n = Content.importStream(this, getContentResolver().openInputStream(data.getData()));
                Toast.makeText(this, n == 0 ? Lang.pick("Nothing found to import in that file", "એ ફાઇલમાં ઉમેરવા જેવું કંઈ મળ્યું નહીં")
                        : Lang.pick("Imported " + n + " ✓", n + " ઉમેરાયા ✓"), Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(this, Lang.pick("Couldn't read that file: ", "ફાઇલ વંચાઈ નહીં: ") + e.getMessage(), Toast.LENGTH_LONG).show();
            }
            rebuild();
            return;
        }
        if ((req != 77 && req != 78) || res != RESULT_OK || data == null || data.getData() == null) return;
        String which = req == 77 ? "arabic_font.ttf" : "gujarati_font.ttf";
        boolean ok;
        try {
            ok = Fonts.importFont(this, getContentResolver().openInputStream(data.getData()), which);
        } catch (Exception e) {
            ok = false;
        }
        Toast.makeText(this, ok ? Lang.pick("Font set ✓", "ફોન્ટ સેટ ✓") : Lang.pick("That file isn't a usable font", "એ ફાઇલ યોગ્ય ફોન્ટ નથી"),
                Toast.LENGTH_SHORT).show();
        rebuild();
    }

    private final Runnable reb = new Runnable() {
        @Override
        public void run() {
            rebuild();
        }
    };

    // ---------- row helpers
    private void section(String t) {
        TextView v = Ui.text(this, t, 12, Ui.GOLD, true);
        v.setLetterSpacing(0.06f);
        v.setPadding(Ui.dp(4), Ui.dp(22), 0, Ui.dp(8));
        v.setTag("sec");
        page.addView(v);
    }

    private void permRow(LinearLayout parent, String emoji, String title, String sub, boolean ok, final Intent intent) {
        LinearLayout r = Ui.row(this);
        r.setPadding(0, Ui.dp(8), 0, Ui.dp(8));
        r.addView(Ui.text(this, emoji, 20, Ui.TEXT, false), Ui.lpm(Ui.dp(34), Ui.WRAP, 0, 0, 6, 0));
        LinearLayout c = Ui.col(this);
        c.addView(Ui.text(this, title, 15, Ui.TEXT, true));
        c.addView(Ui.text(this, sub, 12, Ui.SUB, false));
        r.addView(c, Ui.weight(1));
        r.addView(ok ? Ui.pill(this, "✓ On", Ui.alpha(Ui.EMERALD, 0.18f), Ui.EMERALD)
                : Ui.pill(this, "Turn on ›", Ui.alpha(Ui.ORANGE, 0.18f), Ui.ORANGE));
        if (!ok) {
            Ui.press(r);
            r.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        startActivity(intent);
                    } catch (Exception e) {
                        startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())));
                    }
                }
            });
        }
        parent.addView(r);
    }

    private void toggle(LinearLayout parent, String title, String sub, final String key, boolean def) {
        LinearLayout r = Ui.row(this);
        r.setPadding(0, Ui.dp(8), 0, Ui.dp(8));
        LinearLayout c = Ui.col(this);
        c.addView(Ui.text(this, title, 15, Ui.TEXT, true));
        c.addView(Ui.text(this, sub, 12, Ui.SUB, false));
        r.addView(c, Ui.weight(1));
        Switch sw = new Switch(this);
        sw.setChecked(s.b(key, def));
        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean on) {
                Haptics.play(Haptics.TOGGLE);
                if (!on && key.equals(Store.K_MONITOR)) {
                    b.setOnCheckedChangeListener(null);
                    b.setChecked(true);
                    LockUi.loosen(SettingsActivity.this, Lock.change("bool", key, false, Lang.pick("Switch the habit guardian off", "હેબિટ ગાર્ડિયન બંધ")), rebuildR);
                    return;
                }
                s.put(key, on);
                if (key.equals(Store.K_MONITOR)) {
                    if (on) WatchService.start(SettingsActivity.this);
                    else stopService(new Intent(SettingsActivity.this, WatchService.class));
                }
            }
        });
        r.addView(sw);
        parent.addView(r);
    }

    /** 🛡️ Screen guard: on/off, strictness and its status. */
    private void screenGuardRows(LinearLayout gc, boolean guard) {
        LinearLayout r = Ui.row(this);
        r.setPadding(0, Ui.dp(8), 0, Ui.dp(8));
        LinearLayout c = Ui.col(this);
        c.addView(Ui.text(this, HadithCard.label("🛡️  Screen guard — block vulgar scenes", "🛡️  સ્ક્રીન ગાર્ડ — અશ્લીલ દૃશ્ય બ્લૉક", "🛡️  اسکرین گارڈ — فحش مناظر بلاک", "🛡️  स्क्रीन गार्ड — अश्लील दृश्य ब्लॉक"), 15, Ui.TEXT, true));
        int err = s.i(ScreenGuard.K_ERR, 0);
        String sub;
        if (!guard) sub = HadithCard.label("Turn on the accessibility guardian above first.", "પહેલાં ઉપરનું ઍક્સેસિબિલિટી ગાર્ડિયન ચાલુ કરો.",
                "پہلے اوپر والا ایکسیسبلٹی گارڈین آن کریں۔", "पहले ऊपर वाला एक्सेसिबिलिटी गार्डियन चालू करें।");
        else if (err == android.accessibilityservice.AccessibilityService.ERROR_TAKE_SCREENSHOT_NO_ACCESSIBILITY_ACCESS)
            sub = HadithCard.label("⚠️ Needs permission: switch the Muhasabah accessibility service OFF and ON once.", "⚠️ પરવાનગી જોઈએ: Muhasabah ઍક્સેસિબિલિટી સર્વિસ એક વાર બંધ કરીને ફરી ચાલુ કરો.",
                    "⚠️ اجازت چاہیے: Muhasabah ایکسیسبلٹی سروس ایک بار بند کر کے پھر آن کریں۔", "⚠️ अनुमति चाहिए: Muhasabah एक्सेसिबिलिटी सर्विस एक बार बंद करके फिर चालू करें।");
        else sub = HadithCard.label("Any app — checks the screen on the phone itself and closes porn / hot scenes. Nothing is saved or sent. Blocked today: ",
                "દરેક ઍપમાં — ફોનમાં જ સ્ક્રીન તપાસે અને અશ્લીલ / ગંદા દૃશ્ય બંધ કરે. કંઈ સેવ કે મોકલાતું નથી. આજે બ્લૉક: ",
                "ہر ایپ میں — فون ہی میں اسکرین دیکھتا ہے اور فحش / گندے مناظر بند کرتا ہے۔ کچھ محفوظ یا بھیجا نہیں جاتا۔ آج بلاک: ",
                "हर ऐप में — फ़ोन में ही स्क्रीन देखता है और अश्लील / गंदे दृश्य बंद करता है। कुछ सेव या भेजा नहीं जाता। आज ब्लॉक: ") + ScreenGuard.blocksToday(s);
        c.addView(Ui.text(this, sub, 12, err != 0 && guard ? Ui.ORANGE : Ui.SUB, false));
        r.addView(c, Ui.weight(1));
        Switch sw = new Switch(this);
        sw.setChecked(ScreenGuard.on(s));
        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean on) {
                Haptics.play(Haptics.TOGGLE);
                if (!on && Lock.isLocked(s)) {
                    b.setOnCheckedChangeListener(null);
                    b.setChecked(true);
                    LockUi.loosen(SettingsActivity.this, Lock.change("bool", ScreenGuard.K_ON, false, Lang.pick("Switch the screen guard off", "સ્ક્રીન ગાર્ડ બંધ")), rebuildR);
                    return;
                }
                s.put(ScreenGuard.K_ON, on);
            }
        });
        r.addView(sw);
        gc.addView(r);
        final int lv = ScreenGuard.level(s);
        valueRow(gc, HadithCard.label("      Strictness", "      કડકાઈ", "      سختی", "      सख़्ती"), ScreenGuard.levelName(lv).split(" — ")[0], new Runnable() {
            @Override
            public void run() {
                LinearLayout list = Ui.col(SettingsActivity.this);
                final AlertDialog[] dd = new AlertDialog[1];
                for (int k = 0; k <= ScreenGuard.EXTREME; k++) {
                    final int l = k;
                    LinearLayout o = Ui.col(SettingsActivity.this);
                    o.setBackground(Ui.roundStroke(l == lv ? Ui.alpha(Ui.RED, 0.12f) : Ui.CARD2, 14, l == lv ? Ui.alpha(Ui.RED, 0.6f) : Ui.STROKE, 1));
                    o.setPadding(Ui.dp(14), Ui.dp(11), Ui.dp(14), Ui.dp(11));
                    String dots = l == 0 ? "●○○○" : l == 1 ? "●●○○" : l == 2 ? "●●●○" : "●●●●";
                    o.addView(Ui.text(SettingsActivity.this, dots + "  " + ScreenGuard.levelName(l), 14.5f, l == lv ? 0xFFFF8FA3 : Ui.TEXT, true));
                    TextView hp = Ui.text(SettingsActivity.this, ScreenGuard.levelHelp(l), 12, Ui.SUB, false);
                    hp.setPadding(0, Ui.dp(3), 0, 0);
                    o.addView(hp);
                    Ui.press(o);
                    o.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (l < lv && Lock.isLocked(s)) {
                                Toast.makeText(SettingsActivity.this, Lang.pick("Locked — can't loosen this now", "લૉક છે — હમણાં ઢીલું નહીં થાય"), Toast.LENGTH_SHORT).show();
                                return;
                            }
                            s.put(ScreenGuard.K_LVL, l);
                            s.put(ScreenGuard.K_RELAX, 0);
                            Haptics.play(Haptics.SELECT);
                            dd[0].dismiss();
                            rebuild();
                        }
                    });
                    list.addView(o, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 8));
                }
                TextView note = Ui.text(SettingsActivity.this, HadithCard.label("After a block, the guard checks the whole screen more often for 1 hour. No automatic filter is 100% right — tap 'That was a mistake' on a wrong block and it adjusts itself.",
                        "બ્લૉક પછી, ગાર્ડ 1 કલાક સુધી આખી સ્ક્રીન વધુ વાર તપાસે છે. કોઈ ઑટોમેટિક ફિલ્ટર 100% સાચું નથી — ખોટા બ્લૉક પર 'આ ભૂલ હતી' દબાવો, તે પોતે સુધરશે.",
                        "بلاک کے بعد، گارڈ 1 گھنٹے تک پوری اسکرین زیادہ بار دیکھتا ہے۔ کوئی خودکار فلٹر 100% درست نہیں — غلط بلاک پر 'یہ غلطی تھی' دبائیں، یہ خود کو درست کر لے گا۔",
                        "ब्लॉक के बाद, गार्ड 1 घंटे तक पूरी स्क्रीन ज़्यादा बार देखता है। कोई ऑटोमैटिक फ़िल्टर 100% सही नहीं — ग़लत ब्लॉक पर 'यह ग़लती थी' दबाएँ, यह ख़ुद सुधर जाएगा।"), 12, Ui.MUTED, false);
                list.addView(note);
                dd[0] = Dialogs.sheet(SettingsActivity.this, "🛡️  " + HadithCard.label("Strictness", "કડકાઈ", "سختی", "सख़्ती"), list);
                dd[0].show();
            }
        });
        long left = ScreenGuard.alertLeft(s);
        String st = "";
        if (left > 0) st = "🔴 " + HadithCard.label("Watching closely — " + (left / 60000 + 1) + " min left",
                "નજીકથી નજર — " + (left / 60000 + 1) + " મિનિટ બાકી", "قریب سے نظر — " + (left / 60000 + 1) + " منٹ باقی", "क़रीब से नज़र — " + (left / 60000 + 1) + " मिनट बाक़ी");
        if (ScreenGuard.relax(s) > 0) st += (st.length() > 0 ? "\n" : "") + HadithCard.label("Tuned less sensitive from your 'mistake' reports (choose a level again to reset).",
                "તમારા 'ભૂલ' રિપોર્ટથી થોડું ઓછું સંવેદનશીલ કર્યું (રીસેટ માટે લેવલ ફરી પસંદ કરો).",
                "آپ کی 'غلطی' رپورٹس سے کم حساس کیا گیا (ری سیٹ کے لیے لیول دوبارہ چنیں)۔",
                "आपकी 'ग़लती' रिपोर्ट से थोड़ा कम संवेदनशील किया (रीसेट के लिए लेवल फिर चुनें)।");
        String[] lst = s.s(ScreenGuard.K_LAST, "").split("\\|");
        if (lst.length == 3) {
            try {
                String ago = Compete.ago(Long.parseLong(lst[0]));
                st += (st.length() > 0 ? "\n" : "") + HadithCard.label("Last check: " + ago, "છેલ્લી તપાસ: " + ago, "آخری جانچ: " + ago, "आख़िरी जाँच: " + ago);
            } catch (Exception ignored) {
            }
        }
        if (st.length() > 0) {
            TextView stv = Ui.text(this, st, 12, left > 0 ? 0xFFFF8FA3 : Ui.MUTED, false);
            stv.setPadding(0, 0, 0, Ui.dp(6));
            gc.addView(stv);
        }
    }

    /** 📵 Daily hard limits: once used up, the app is locked until midnight. */
    private void capRows(LinearLayout gc) {
        TextView hd = Ui.text(this, HadithCard.label("📵  Daily hard limits — no extension", "📵  રોજની કડક મર્યાદા — કોઈ વધારો નહીં",
                "📵  روزانہ سخت حد — کوئی اضافہ نہیں", "📵  रोज़ की सख़्त सीमा — कोई बढ़ोतरी नहीं"), 15, Ui.TEXT, true);
        hd.setPadding(0, Ui.dp(14), 0, Ui.dp(2));
        gc.addView(hd);
        gc.addView(Ui.text(this, HadithCard.label("When the minutes are used up, the app is locked until tomorrow. Lowering a limit works now; raising or removing it only from tomorrow.",
                "મિનિટ પૂરી થાય એટલે ઍપ કાલ સુધી લૉક. મર્યાદા ઘટાડવી હમણાં જ લાગુ; વધારવી કે કાઢવી ફક્ત કાલથી.",
                "منٹ ختم ہوتے ہی ایپ کل تک لاک۔ حد کم کرنا ابھی لاگو؛ بڑھانا یا ہٹانا صرف کل سے۔",
                "मिनट ख़त्म होते ही ऐप कल तक लॉक। सीमा घटाना अभी लागू; बढ़ाना या हटाना सिर्फ़ कल से।"), 12, Ui.SUB, false));
        PackageManager pm = getPackageManager();
        for (final String[] a : AppLock.CAPPABLE) {
            try {
                pm.getApplicationInfo(a[0], 0);
            } catch (Exception e) {
                continue; // not installed
            }
            final int cap = AppLock.cap(s, a[0]);
            int pend = AppLock.pendingCap(s, a[0]);
            String v = cap <= 0 ? HadithCard.label("Off", "બંધ", "بند", "बंद")
                    : cap + " " + HadithCard.label("min", "મિ.", "منٹ", "मि.") + " · " + HadithCard.label("used ", "વપરાયું ", "استعمال ", "इस्तेमाल ") + AppLock.usedToday(this, a[0]);
            if (pend >= 0) v += HadithCard.label(" (tomorrow: ", " (કાલથી: ", " (کل سے: ", " (कल से: ") + (pend == 0 ? "off" : pend + "") + ")";
            valueRow(gc, "      " + AppLock.appName(this, a[0]), v, new Runnable() {
                @Override
                public void run() {
                    final int[] opts = {0, 15, 20, 30, 40, 60, 90, 120};
                    String[] names = new String[opts.length];
                    for (int i = 0; i < opts.length; i++)
                        names[i] = opts[i] == 0 ? HadithCard.label("No limit", "મર્યાદા નહીં", "کوئی حد نہیں", "कोई सीमा नहीं")
                                : opts[i] + " " + HadithCard.label("minutes a day", "મિનિટ રોજ", "منٹ روزانہ", "मिनट रोज़");
                    new AlertDialog.Builder(SettingsActivity.this).setTitle(AppLock.appName(SettingsActivity.this, a[0]))
                            .setItems(names, new android.content.DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(android.content.DialogInterface d, int which) {
                                    int min = opts[which];
                                    boolean raise = cap > 0 && (min == 0 || min > cap);
                                    if (raise && Lock.isLocked(s)) {
                                        Toast.makeText(SettingsActivity.this, Lang.pick("Locked — can't loosen this now", "લૉક છે — હમણાં ઢીલું નહીં થાય"), Toast.LENGTH_SHORT).show();
                                        return;
                                    }
                                    boolean now = AppLock.setCap(s, a[0], min);
                                    Toast.makeText(SettingsActivity.this, now ? HadithCard.label("Applied now", "હમણાં લાગુ", "ابھی لاگو", "अभी लागू")
                                            : HadithCard.label("Applies from tomorrow", "કાલથી લાગુ", "کل سے لاگو", "कल से लागू"), Toast.LENGTH_SHORT).show();
                                    rebuild();
                                }
                            }).show();
                }
            });
        }
    }

    private void valueRow(LinearLayout parent, String title, String value, final Runnable onTap) {
        LinearLayout r = Ui.row(this);
        r.setPadding(0, Ui.dp(12), 0, Ui.dp(12));
        r.addView(Ui.text(this, title, 15, Ui.TEXT, true), Ui.weight(1));
        r.addView(Ui.text(this, value + "  ›", 14, Ui.GOLD, true));
        r.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onTap.run();
            }
        });
        parent.addView(r);
    }

    private void timeRow(LinearLayout parent, String title, final String key, final int def) {
        final int cur = s.i(key, def);
        valueRow(parent, title, Ui.clock(cur), new Runnable() {
            @Override
            public void run() {
                new TimePickerDialog(SettingsActivity.this, android.R.style.Theme_DeviceDefault_Dialog_Alert,
                        new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker view, int h, int m) {
                                s.put(key, h * 60 + m);
                                rebuild();
                            }
                        }, cur / 60, cur % 60, false).show();
            }
        });
    }

    // ---------- app picker
    private void pickApp() {
        PackageManager pm = getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> list = pm.queryIntentActivities(main, 0);
        final List<String[]> apps = new ArrayList<String[]>();
        JSONArray cur = s.apps();
        StringBuilder have = new StringBuilder("|");
        for (int k = 0; k < cur.length(); k++) have.append(cur.optJSONObject(k).optString("pkg")).append('|');
        for (ResolveInfo ri : list) {
            String pkg = ri.activityInfo.packageName;
            if (pkg.equals(getPackageName()) || have.indexOf("|" + pkg + "|") >= 0) continue;
            boolean dup = false;
            for (String[] a : apps) if (a[0].equals(pkg)) dup = true;
            if (!dup) apps.add(new String[]{pkg, ri.loadLabel(pm).toString()});
        }
        Collections.sort(apps, new Comparator<String[]>() {
            @Override
            public int compare(String[] a, String[] b) {
                return a[1].compareToIgnoreCase(b[1]);
            }
        });
        LinearLayout body = Ui.col(this);
        final AlertDialog[] d = new AlertDialog[1];
        for (final String[] a : apps) {
            TextView r = Ui.text(this, a[1], 15, Ui.TEXT, true);
            r.setPadding(Ui.dp(6), Ui.dp(12), Ui.dp(6), Ui.dp(12));
            body.addView(r);
            r.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    JSONArray arr = s.apps();
                    try {
                        JSONObject o = new JSONObject();
                        o.put("pkg", a[0]);
                        o.put("name", a[1]);
                        o.put("limit", 20);
                        arr.put(o);
                    } catch (Exception ignored) {
                    }
                    s.saveApps(arr);
                    d[0].dismiss();
                    Toast.makeText(SettingsActivity.this, a[1] + " added with a 20 min limit — tap it to change", Toast.LENGTH_LONG).show();
                    rebuild();
                }
            });
        }
        d[0] = Dialogs.sheet(this, "Choose an app", body);
        d[0].show();
    }

    // ---------- backup
    private String exportJson() {
        JSONObject o = new JSONObject();
        try {
            o.put("app", "muhasabah");
            o.put("version", 1);
            JSONObject data = new JSONObject();
            for (Map.Entry<String, ?> e : s.p.getAll().entrySet()) {
                Object v = e.getValue();
                JSONObject cell = new JSONObject();
                cell.put("t", v instanceof Integer ? "i" : v instanceof Long ? "l" : v instanceof Boolean ? "b" : "s");
                cell.put("v", v == null ? "" : String.valueOf(v));
                data.put(e.getKey(), cell);
            }
            o.put("data", data);
        } catch (Exception ignored) {
        }
        return o.toString();
    }

    private void restoreDialog() {
        LinearLayout body = Ui.col(this);
        body.addView(Ui.text(this, "Paste the backup text you exported earlier. This replaces everything in the app.", 13, Ui.SUB, false));
        body.addView(Ui.space(this, 10));
        final EditText box = Ui.input(this, "{\"app\":\"muhasabah\"…", "", false);
        box.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        box.setMinLines(5);
        body.addView(box);
        body.addView(Ui.space(this, 12));
        TextView go = Ui.button(this, "Restore", Ui.RED, 0xFFBE123C, 0xFFFFFFFF);
        body.addView(go, Ui.lp(Ui.MATCH, Ui.WRAP));
        final AlertDialog d = Dialogs.sheet(this, "Restore backup", body);
        go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    JSONObject o = new JSONObject(box.getText().toString().trim());
                    if (!"muhasabah".equals(o.optString("app"))) throw new Exception();
                    JSONObject data = o.getJSONObject("data");
                    java.util.Map<String, ?> all = s.p.getAll();
                    java.util.Map<String, Object> keepP = new java.util.HashMap<String, Object>();
                    for (String k : Lock.PROTECTED_KEYS) if (all.containsKey(k)) keepP.put(k, all.get(k));
                    String oldWords = s.s("blocked_words", ""), oldSites = s.s("blocked_sites", "");
                    android.content.SharedPreferences.Editor ed = s.p.edit().clear();
                    java.util.Iterator<String> it = data.keys();
                    while (it.hasNext()) {
                        String k = it.next();
                        JSONObject cell = data.getJSONObject(k);
                        String t = cell.optString("t"), val = cell.optString("v");
                        if (t.equals("i")) ed.putInt(k, Integer.parseInt(val));
                        else if (t.equals("l")) ed.putLong(k, Long.parseLong(val));
                        else if (t.equals("b")) ed.putBoolean(k, Boolean.parseBoolean(val));
                        else ed.putString(k, val);
                    }
                    // A backup can never loosen your current rules: protected values stay; blocked lists are merged.
                    for (java.util.Map.Entry<String, Object> e : keepP.entrySet()) {
                        Object v2 = e.getValue();
                        if (v2 instanceof Integer) ed.putInt(e.getKey(), (Integer) v2);
                        else if (v2 instanceof Long) ed.putLong(e.getKey(), (Long) v2);
                        else if (v2 instanceof Boolean) ed.putBoolean(e.getKey(), (Boolean) v2);
                        else if (v2 != null) ed.putString(e.getKey(), v2.toString());
                    }
                    if (data.has("blocked_words")) ed.putString("blocked_words", oldWords + "," + data.getJSONObject("blocked_words").optString("v"));
                    if (data.has("blocked_sites")) ed.putString("blocked_sites", oldSites + "," + data.getJSONObject("blocked_sites").optString("v"));
                    ed.apply();
                    d.dismiss();
                    Toast.makeText(SettingsActivity.this, "Backup restored ✓", Toast.LENGTH_SHORT).show();
                    rebuild();
                } catch (Exception e) {
                    Toast.makeText(SettingsActivity.this, "That doesn't look like a Muhasabah backup", Toast.LENGTH_LONG).show();
                }
            }
        });
        d.show();
    }

    private void restoreLibrary() {
        try {
            java.io.BufferedReader r = new java.io.BufferedReader(new java.io.InputStreamReader(getAssets().open("wisdom.json"), "UTF-8"));
            StringBuilder b = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) b.append(line);
            r.close();
            JSONArray def = new JSONArray(b.toString());
            List<JSONObject> mine = s.wisdom();
            int added = 0;
            for (int k = 0; k < def.length(); k++) {
                JSONObject o = def.getJSONObject(k);
                boolean exists = false;
                for (JSONObject m : mine) if (m.optString("id").equals(o.optString("id"))) exists = true;
                if (!exists) {
                    mine.add(o);
                    added++;
                }
            }
            s.saveWisdom(mine);
            Toast.makeText(this, added == 0 ? "Library already complete" : "Restored " + added + " reminders", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Couldn't restore", Toast.LENGTH_SHORT).show();
        }
    }
}
