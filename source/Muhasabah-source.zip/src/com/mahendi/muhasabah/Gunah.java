package com.mahendi.muhasabah;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Iterator;
import java.util.Random;

/**
 * Private tawbah reminders. When you mark a sin (gheebat, lying, anger …) as done today, you get one
 * referenced reminder a day for 7 days, mixing the Quran, hadith, Ghurar al-Hikam / Bihar al-Anwar,
 * a general "growth" hadith, a tawbah reminder and a practical step.
 * Nothing here touches the score, streak or summaries; only the active 7-day series are stored, on this phone.
 */
public final class Gunah {
    public static final String CH = "gunah";
    public static final String ACTION_TICK = "com.mahendi.muhasabah.GUNAH_TICK";
    public static final String K_SERIES = "gunah_series", K_TIME = "gunah_time", K_TAWBAH = "gunah_tptr";
    /** Bad habits the user added: [{key, emoji, name, base, note}] — base = a built-in sin whose reminders to use, "" = general tawbah. */
    public static final String K_CUSTOM = "gunah_custom";
    /** Tawbah items used for the general set (days 1–4 and 7); day 6 then picks from the rest. */
    private static final int[] GEN = {0, 1, 9, 3, 8}, GEN_REST = {2, 4, 5, 6, 7};
    public static final int DAYS = 7;
    private static JSONObject data;
    private static final Random RND = new Random();

    private Gunah() {
    }

    // ---------------- content ----------------
    public static synchronized JSONObject data(Context c) {
        if (data != null) return data;
        try {
            InputStream in = c.getAssets().open("gunah.json");
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            in.close();
            data = new JSONObject(bo.toString("UTF-8"));
        } catch (Exception e) {
            data = new JSONObject();
        }
        return data;
    }

    /** The built-in list (from gunah.json). */
    public static JSONArray builtIn(Context c) {
        JSONArray a = data(c).optJSONArray("sins");
        return a == null ? new JSONArray() : a;
    }

    /** Built-in sins followed by the user's own bad habits. */
    public static JSONArray sins(Context c) {
        JSONArray b = builtIn(c), out = new JSONArray();
        for (int i = 0; i < b.length(); i++) out.put(b.optJSONObject(i));
        JSONArray cu = customRaw(c);
        for (int i = 0; i < cu.length(); i++) {
            JSONObject r = resolve(c, cu.optJSONObject(i));
            if (r != null) out.put(r);
        }
        return out;
    }

    // ---------------- the user's own bad habits ----------------
    public static JSONArray customRaw(Context c) {
        try {
            return new JSONArray(Store.get(c).s(K_CUSTOM, "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    public static JSONObject customOne(Context c, String key) {
        JSONArray a = customRaw(c);
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && key.equals(o.optString("key"))) return o;
        }
        return null;
    }

    public static boolean isCustom(String key) {
        return key != null && key.startsWith("u");
    }

    /** Add (key == null) or update one of the user's own bad habits. Returns its key. */
    public static String saveCustom(Context c, String key, String emoji, String name, String base, String note) {
        JSONArray a = customRaw(c), out = new JSONArray();
        if (key == null) key = "u" + System.currentTimeMillis();
        JSONObject o = new JSONObject();
        try {
            o.put("key", key);
            o.put("emoji", emoji == null || emoji.trim().length() == 0 ? "⚠️" : emoji.trim());
            o.put("name", name.trim());
            o.put("base", base == null ? "" : base);
            o.put("note", note == null ? "" : note.trim());
        } catch (Exception ignored) {
        }
        boolean put = false;
        for (int i = 0; i < a.length(); i++) {
            JSONObject x = a.optJSONObject(i);
            if (x == null) continue;
            if (key.equals(x.optString("key"))) {
                out.put(o);
                put = true;
            } else out.put(x);
        }
        if (!put) out.put(o);
        Store.get(c).put(K_CUSTOM, out.toString());
        return key;
    }

    public static void deleteCustom(Context c, String key) {
        JSONArray a = customRaw(c), out = new JSONArray();
        for (int i = 0; i < a.length(); i++) {
            JSONObject x = a.optJSONObject(i);
            if (x != null && !key.equals(x.optString("key"))) out.put(x);
        }
        stop(c, key);
        Store.get(c).put(K_CUSTOM, out.toString());
    }

    private static JSONObject builtInSin(Context c, String key) {
        if (key == null || key.length() == 0) return null;
        JSONArray a = builtIn(c);
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && key.equals(o.optString("key"))) return o;
        }
        return null;
    }

    /** A user habit in the same shape as a built-in sin (name in every language, items to show). */
    private static JSONObject resolve(Context c, JSONObject cu) {
        if (cu == null || cu.optString("name").length() == 0) return null;
        try {
            JSONObject o = new JSONObject();
            String n = cu.optString("name");
            o.put("key", cu.optString("key"));
            o.put("emoji", cu.optString("emoji", "⚠️"));
            for (String l : Lang.CODES) o.put(l, n);
            o.put("custom", true);
            o.put("base", cu.optString("base"));
            o.put("note", cu.optString("note"));
            JSONObject b = builtInSin(c, cu.optString("base"));
            o.put("items", b != null ? b.optJSONArray("items") : general(c));
            return o;
        } catch (Exception e) {
            return null;
        }
    }

    /** Reminders for any habit: tawbah ayat and hadith, plus a practical step. */
    private static JSONArray general(Context c) {
        JSONArray t = data(c).optJSONArray("tawbah"), out = new JSONArray();
        if (t != null) for (int i : GEN) if (i < t.length()) out.put(t.optJSONObject(i));
        try {
            JSONObject st = new JSONObject();
            st.put("id", "g-general-step");
            st.put("kind", "step");
            st.put("ar", "");
            st.put("en", "Write down when this habit usually happens — the time, the place, the people and how you feel then. Pick one of those and change it today (for example: keep the phone in another room, take another route, leave that gathering early). Every time you hold back, say \u201cAlhamdulillah\u201d and thank Allah.");
            st.put("gu", "આ આદત સામાન્ય રીતે ક્યારે થાય છે તે લખો — સમય, જગ્યા, લોકો અને એ વખતે તમને કેવું લાગે છે. તેમાંથી એક વસ્તુ આજે જ બદલો (દા.ત. ફોન બીજા રૂમમાં રાખો, બીજો રસ્તો લો, એ બેઠક વહેલી છોડો). દરેક વખતે તમે રોકાઈ જાઓ ત્યારે \u201cઅલ્હમ્દુલિલ્લાહ\u201d કહીને અલ્લાહનો શુક્ર કરો.");
            st.put("ur", "لکھیں کہ یہ عادت عام طور پر کب ہوتی ہے — وقت، جگہ، لوگ اور اس وقت آپ کی کیفیت۔ ان میں سے ایک چیز آج ہی بدلیں (مثلاً فون دوسرے کمرے میں رکھیں، دوسرا راستہ لیں، وہ محفل جلدی چھوڑ دیں)۔ ہر بار جب آپ رک جائیں تو \u201cالحمد للہ\u201d کہہ کر اللہ کا شکر ادا کریں۔");
            st.put("hi", "लिखें कि यह आदत आम तौर पर कब होती है — समय, जगह, लोग और उस वक़्त आपकी कैफ़ियत। उनमें से एक चीज़ आज ही बदलें (जैसे फ़ोन दूसरे कमरे में रखें, दूसरा रास्ता लें, वह महफ़िल जल्दी छोड़ दें)। हर बार जब आप रुक जाएँ तो \u201cअल्हम्दुलिल्लाह\u201d कहकर अल्लाह का शुक्र अदा करें।");
            st.put("ref", "Practical step (advice, not a hadith)");
            st.put("book", "Muhasabah");
            st.put("grade", new JSONArray());
            st.put("credit", "Muhasabah");
            out.put(st);
        } catch (Exception ignored) {
        }
        return out;
    }

    public static JSONObject sin(Context c, String key) {
        JSONArray a = sins(c);
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && key.equals(o.optString("key"))) return o;
        }
        return null;
    }

    public static int sinIndex(Context c, String key) {
        JSONArray a = sins(c);
        for (int i = 0; i < a.length(); i++) if (key.equals(a.optJSONObject(i).optString("key"))) return i;
        return 0;
    }

    /** Sin name in the UI language. */
    public static String name(JSONObject sin) {
        if (sin == null) return "";
        String v = sin.optString(Lang.CODES[Math.max(0, Math.min(3, Lang.get()))]);
        return v.length() > 0 ? v : sin.optString("en");
    }

    /** What the reminder of each day is about. */
    public static String dayLabel(int day) {
        switch (day) {
            case 1: return HadithCard.label("From the Quran", "કુરાનમાંથી", "قرآن سے", "क़ुरान से");
            case 2: return HadithCard.label("Hadith", "હદીસ", "حدیث", "हदीस");
            case 3: return HadithCard.label("A warning", "ચેતવણી", "تنبیہ", "चेतावनी");
            case 4: return HadithCard.label("The cure", "ઇલાજ", "علاج", "इलाज");
            case 5: return HadithCard.label("For your growth", "તમારી પ્રગતિ માટે", "آپ کی ترقی کے لیے", "आपकी तरक़्क़ी के लिए");
            case 6: return HadithCard.label("The door of tawbah is open", "તૌબાનો દરવાજો ખુલ્લો છે", "توبہ کا دروازہ کھلا ہے", "तौबा का दरवाज़ा खुला है");
            default: return HadithCard.label("Your practical step", "તમારું વ્યવહારુ પગલું", "آپ کا عملی قدم", "आपका अमली क़दम");
        }
    }

    /** The item(s) for a given day of a series (day 7 has a short saying plus the practical step). */
    public static JSONObject[] items(Context c, String key, int day) {
        JSONObject sin = sin(c, key);
        if (sin == null) return new JSONObject[0];
        JSONArray it = sin.optJSONArray("items");
        JSONObject ser = series(c).optJSONObject(key);
        if (ser == null) ser = new JSONObject();
        switch (day) {
            case 1: return one(it.optJSONObject(0));
            case 2: return one(it.optJSONObject(1));
            case 3: return one(it.optJSONObject(2));
            case 4: return one(it.optJSONObject(3));
            case 5: {
                JSONArray books = Daily.list(c, Daily.BOOKS);
                if (books.length() == 0) return one(it.optJSONObject(3));
                return one(books.optJSONObject(Math.abs(ser.optInt("g", 0)) % books.length()));
            }
            case 6: {
                JSONArray t = data(c).optJSONArray("tawbah");
                if (t == null || t.length() == 0) return one(it.optJSONObject(0));
                return one(t.optJSONObject(Math.abs(ser.optInt("t", 0)) % t.length()));
            }
            default: {
                String note = sin.optString("note");
                if (note.length() == 0) return new JSONObject[]{it.optJSONObject(4), it.optJSONObject(5)};
                JSONObject mine = new JSONObject();
                try {
                    mine.put("kind", "mine");
                    mine.put("en", note); // one field only, so it isn't repeated for each chosen language
                    mine.put("ref", HadithCard.label("In your own words", "તમારા પોતાના શબ્દોમાં", "آپ کے اپنے الفاظ میں", "आपके अपने शब्दों में"));
                } catch (Exception ignored) {
                }
                return new JSONObject[]{it.optJSONObject(4), it.optJSONObject(5), mine};
            }
        }
    }

    private static JSONObject[] one(JSONObject o) {
        return o == null ? new JSONObject[0] : new JSONObject[]{o};
    }

    // ---------------- state ----------------
    public static JSONObject series(Context c) {
        try {
            return new JSONObject(Store.get(c).s(K_SERIES, "{}"));
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    private static void save(Context c, JSONObject s) {
        Store.get(c).put(K_SERIES, s.toString());
    }

    public static int time(Context c) {
        return Store.get(c).i(K_TIME, 20 * 60);
    }

    public static void setTime(Context c, int minuteOfDay) {
        Store.get(c).put(K_TIME, minuteOfDay);
        schedule(c);
    }

    /** Day number (1..7) of a running series, or 0 when it is over / not running. */
    public static int dayOf(Context c, String key) {
        JSONObject o = series(c).optJSONObject(key);
        if (o == null) return 0;
        int d = Store.daysBetween(o.optString("s", Store.today()), Store.today()) + 1;
        return d >= 1 && d <= DAYS ? d : 0;
    }

    /** Start (or restart) the 7 days for this sin. Day 1 is shown right away in the app. */
    public static void start(Context c, String key) {
        JSONObject all = series(c);
        JSONObject o = new JSONObject();
        Store st = Store.get(c);
        JSONArray t = data(c).optJSONArray("tawbah");
        int tp = st.i(K_TAWBAH, 0);
        st.put(K_TAWBAH, tp + 1);
        try {
            o.put("s", Store.today());
            o.put("sent", 1);
            JSONObject sn = sin(c, key);
            boolean gen = sn != null && sn.optBoolean("custom") && builtInSin(c, sn.optString("base")) == null;
            o.put("t", t == null || t.length() == 0 ? 0 : gen ? GEN_REST[tp % GEN_REST.length] : tp % t.length());
            o.put("g", RND.nextInt(100000));
            all.put(key, o);
        } catch (Exception ignored) {
        }
        save(c, all);
        cancel(c, key);
        schedule(c);
    }

    public static void stop(Context c, String key) {
        JSONObject all = series(c);
        all.remove(key);
        save(c, all);
        cancel(c, key);
        schedule(c);
    }

    // ---------------- the daily check ----------------
    public static synchronized void check(Context c) {
        JSONObject all = series(c);
        if (all.length() == 0) return;
        int mod = Store.minuteOfDay(), at = time(c);
        String today = Store.today();
        boolean changed = false;
        JSONArray keys = all.names();
        for (int i = 0; keys != null && i < keys.length(); i++) {
            String key = keys.optString(i);
            JSONObject o = all.optJSONObject(key);
            if (o == null || sin(c, key) == null) {
                all.remove(key);
                changed = true;
                continue;
            }
            int day = Store.daysBetween(o.optString("s", today), today) + 1;
            if (day > DAYS || day < 1) {
                all.remove(key);
                changed = true;
                continue;
            }
            if (day > o.optInt("sent", 0) && mod >= at) {
                try {
                    o.put("sent", day);
                } catch (Exception ignored) {
                }
                changed = true;
                post(c, key, day);
            }
        }
        if (changed) save(c, all);
    }

    private static int notifId(Context c, String key) {
        return 6100 + sinIndex(c, key);
    }

    private static void cancel(Context c, String key) {
        try {
            c.getSystemService(NotificationManager.class).cancel(notifId(c, key));
        } catch (Exception ignored) {
        }
    }

    public static void channel(Context c) {
        NotificationChannel ch = new NotificationChannel(CH, "Tawbah reminders (private)", NotificationManager.IMPORTANCE_DEFAULT);
        ch.setDescription("One referenced reminder a day for 7 days after you mark a sin. Details are hidden on the lock screen.");
        ch.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
        c.getSystemService(NotificationManager.class).createNotificationChannel(ch);
    }

    /** Short notification body: the translation in the UI language and a short reference. */
    private static String body(JSONObject[] its) {
        StringBuilder b = new StringBuilder();
        for (JSONObject it : its) {
            if (it == null) continue;
            String t = Lang.one(it, Lang.F_TEXT);
            if (b.length() > 0) b.append("\n\n");
            String kd = it.optString("kind");
            if ("step".equals(kd)) b.append("🛠️ ");
            if ("mine".equals(kd)) b.append("✍️ ");
            b.append(t);
            String ref = it.optString("ref");
            if (ref.length() > 0 && !"step".equals(kd) && !"mine".equals(kd)) {
                int cut = ref.indexOf(" · ");
                b.append("\n— ").append(cut > 0 && ref.startsWith("Ghurar") ? "Ghurar al-Hikam" : ref.length() > 70 ? ref.substring(0, 70) + "…" : ref);
            }
        }
        return b.toString();
    }

    private static void post(Context c, String key, int day) {
        Lang.init(c);
        channel(c);
        JSONObject sin = sin(c, key);
        JSONObject[] its = items(c, key, day);
        if (sin == null || its.length == 0) return;
        String title = sin.optString("emoji") + " " + HadithCard.label("Day " + day + " of 7 · ", "દિવસ " + day + " / 7 · ",
                "دن " + day + " / 7 · ", "दिन " + day + " / 7 · ") + name(sin);
        String text = dayLabel(day) + "\n" + body(its);
        Intent open = new Intent(c, GunahActivity.class).putExtra("key", key).putExtra("day", day);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        int id = notifId(c, key);
        PendingIntent pi = PendingIntent.getActivity(c, id, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification pub = new Notification.Builder(c, CH)
                .setSmallIcon(R.drawable.ic_stat)
                .setColor(Ui.EMERALD)
                .setContentTitle("Muhasabah")
                .setContentText(HadithCard.label("A private reminder for you", "તમારા માટે એક ખાનગી રિમાઇન્ડર",
                        "آپ کے لیے ایک نجی یاد دہانی", "आपके लिए एक निजी रिमाइंडर"))
                .build();
        Notification.Builder b = new Notification.Builder(c, CH)
                .setSmallIcon(R.drawable.ic_stat)
                .setColor(Ui.EMERALD)
                .setContentTitle(title)
                .setContentText(dayLabel(day))
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setContentIntent(pi)
                .setAutoCancel(true)
                .setVisibility(Notification.VISIBILITY_PRIVATE)
                .setPublicVersion(pub)
                .setCategory(Notification.CATEGORY_REMINDER);
        try {
            c.getSystemService(NotificationManager.class).notify(id, b.build());
        } catch (SecurityException ignored) {
        }
    }

    // ---------------- scheduling ----------------
    public static void schedule(Context c) {
        AlarmManager am = c.getSystemService(AlarmManager.class);
        Intent i = new Intent(c, ReminderReceiver.class).setAction(ACTION_TICK);
        PendingIntent pi = PendingIntent.getBroadcast(c, 4998, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        am.cancel(pi);
        JSONObject all = series(c);
        if (all.length() == 0) return;
        long now = System.currentTimeMillis();
        long todayAt = Store.startOfToday() + time(c) * 60000L;
        boolean pendingToday = false;
        String today = Store.today();
        Iterator<String> it = all.keys();
        while (it.hasNext()) {
            String key = it.next();
            JSONObject o = all.optJSONObject(key);
            if (o == null) continue;
            int day = Store.daysBetween(o.optString("s", today), today) + 1;
            if (day >= 1 && day <= DAYS && day > o.optInt("sent", 0)) pendingToday = true;
        }
        long next;
        if (pendingToday) next = now < todayAt ? todayAt : now + 15000;
        else next = todayAt + 86400000L;
        try {
            if (am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi);
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi);
        } catch (Exception e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi);
        }
    }
}
