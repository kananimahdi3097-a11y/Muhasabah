package com.mahendi.muhasabah;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.view.View;

/**
 * A Discover card drawn directly on the canvas (gradient, category pill, counter, emoji, title, body
 * in English and/or Gujarati). It measures its own height from the text, so nothing can collapse.
 */
public class FeedCard extends View {
    private int c1, c2;
    private String cat = "", counter = "", emoji = "", hint = "";
    private CharSequence ar = "", arSrc = "";
    /** One block per chosen language: {title, body, lang code}. */
    private final java.util.List<Object[]> secs = new java.util.ArrayList<Object[]>();
    private final java.util.List<StaticLayout[]> lays = new java.util.ArrayList<StaticLayout[]>();
    private final TextPaint pill = new TextPaint(Paint.ANTI_ALIAS_FLAG), small = new TextPaint(Paint.ANTI_ALIAS_FLAG),
            emo = new TextPaint(Paint.ANTI_ALIAS_FLAG), title = new TextPaint(Paint.ANTI_ALIAS_FLAG),
            body = new TextPaint(Paint.ANTI_ALIAS_FLAG), guTitle = new TextPaint(Paint.ANTI_ALIAS_FLAG),
            guBody = new TextPaint(Paint.ANTI_ALIAS_FLAG), arP = new TextPaint(Paint.ANTI_ALIAS_FLAG),
            arSrcP = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG), pillBg = new Paint(Paint.ANTI_ALIAS_FLAG),
            line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private StaticLayout lEmo, lAr, lArSrc, lSrc;
    private CharSequence srcText = "";
    private final TextPaint urTitle = new TextPaint(Paint.ANTI_ALIAS_FLAG), urBody = new TextPaint(Paint.ANTI_ALIAS_FLAG),
            hiTitle = new TextPaint(Paint.ANTI_ALIAS_FLAG), hiBody = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arBox = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int laidW = -1;
    private final RectF r = new RectF();

    public FeedCard(Context c) {
        super(c);
        float sp = c.getResources().getDisplayMetrics().scaledDensity;
        pill.setTextSize(12 * sp);
        pill.setColor(0xFFFFFFFF);
        pill.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        pill.setLetterSpacing(0.08f);
        small.setTextSize(13 * sp);
        small.setColor(0xBFFFFFFF);
        small.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        emo.setTextSize(52 * sp);
        title.setTextSize(24 * sp);
        title.setColor(0xFFFFFFFF);
        title.setTypeface(Typeface.create("sans-serif-black", Typeface.NORMAL));
        body.setTextSize(16 * sp);
        body.setColor(0xE6FFFFFF);
        guTitle.setTextSize(22 * sp);
        guTitle.setColor(0xFFFFFFFF);
        guTitle.setFakeBoldText(true);
        guBody.setTextSize(16.5f * sp);
        guBody.setColor(0xE6FFFFFF);
        if (Fonts.gujarati() != null) {
            guTitle.setTypeface(Fonts.gujarati());
            guBody.setTypeface(Fonts.gujarati());
        }
        urTitle.setTextSize(23 * sp);
        urTitle.setColor(0xFFFFFFFF);
        urBody.setTextSize(17.5f * sp);
        urBody.setColor(0xE6FFFFFF);
        if (Fonts.urdu() != null) {
            urTitle.setTypeface(Fonts.urdu());
            urBody.setTypeface(Fonts.urdu());
        }
        hiTitle.setTextSize(22 * sp);
        hiTitle.setColor(0xFFFFFFFF);
        hiTitle.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        hiBody.setTextSize(16.5f * sp);
        hiBody.setColor(0xE6FFFFFF);
        arP.setTextSize(25 * sp);
        arP.setColor(0xFFFDE68A);
        if (Fonts.arabic() != null) arP.setTypeface(Fonts.arabic());
        arSrcP.setTextSize(11.5f * sp);
        arSrcP.setColor(0xB3FFFFFF);
        arBox.setColor(0x33000000);
        pillBg.setColor(0x4D000000);
        line.setColor(0x33FFFFFF);
        line.setStrokeWidth(Ui.dp(1));
    }

    public void setArabic(String arabic, String source) {
        ar = arabic == null ? "" : arabic;
        arSrc = source == null ? "" : "— " + source;
        laidW = -1;
        requestLayout();
        invalidate();
    }

    private static final String[] F_T = {"t", "gt", "ut", "ht"}, F_B = {"b", "gb", "ub", "hb"}, F_X = {"x", "gx", "ux", "hx"};

    /** Where a fact comes from (shown small under the text). */
    public void setSource(String src) {
        srcText = src == null || src.length() == 0 ? "" : "📚 " + src;
        laidW = -1;
        requestLayout();
        invalidate();
    }

    /** item: a feed card JSON with t/b (English), gt/gb, ut/ub, ht/hb. */
    public void set(int col1, int col2, String category, String count, String e, org.json.JSONObject item, String hintText) {
        c1 = col1;
        c2 = col2;
        cat = category == null ? "" : category;
        counter = count;
        emoji = e == null ? "" : e;
        secs.clear();
        java.util.List<String[]> ts = Lang.texts(item, F_T), bs = Lang.texts(item, F_B), xs = Lang.texts(item, F_X);
        for (String[] t : ts) {
            String body = "";
            for (String[] b : bs) if (b[0].equals(t[0])) body = b[1];
            for (String[] x : xs) if (x[0].equals(t[0]) && x[1].length() > 0) body = body + "\n\n✅ " + x[1]; // "try today"
            secs.add(new Object[]{t[0].equals("gu") ? Fonts.mixed(t[1]) : t[1], t[0].equals("gu") ? Fonts.mixed(body) : body, t[0]});
        }
        hint = hintText;
        laidW = -1;
        requestLayout();
        invalidate();
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }

    private StaticLayout lay(CharSequence s, TextPaint p, int w, float extra) {
        if (s == null || s.length() == 0 || w <= 0) return null;
        return StaticLayout.Builder.obtain(s, 0, s.length(), p, w).setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setLineSpacing(extra, 1f).setIncludePad(true).build();
    }

    private void build(int width) {
        if (width == laidW) return;
        laidW = width;
        int inner = Math.max(1, width - Ui.dp(44));
        lEmo = lay(emoji, emo, inner, 0);
        lAr = ar.length() == 0 ? null : StaticLayout.Builder.obtain(ar, 0, ar.length(), arP, inner - Ui.dp(28))
                .setAlignment(Layout.Alignment.ALIGN_CENTER).setTextDirection(android.text.TextDirectionHeuristics.RTL)
                .setLineSpacing(Ui.dp(8), 1f).setIncludePad(true).build();
        lArSrc = arSrc.length() == 0 || lAr == null ? null : StaticLayout.Builder.obtain(arSrc, 0, arSrc.length(), arSrcP, inner - Ui.dp(28))
                .setAlignment(Layout.Alignment.ALIGN_CENTER).setIncludePad(true).build();
        lSrc = srcText.length() == 0 ? null : StaticLayout.Builder.obtain(srcText, 0, srcText.length(), arSrcP, inner)
                .setIncludePad(true).build();
        lays.clear();
        for (Object[] sc : secs) {
            String code = (String) sc[2];
            TextPaint tp = code.equals("gu") ? guTitle : code.equals("ur") ? urTitle : code.equals("hi") ? hiTitle : title;
            TextPaint bp = code.equals("gu") ? guBody : code.equals("ur") ? urBody : code.equals("hi") ? hiBody : body;
            float ex = code.equals("ur") ? Ui.dp(10) : code.equals("en") ? Ui.dp(4) : Ui.dp(5);
            lays.add(new StaticLayout[]{lay((CharSequence) sc[0], tp, inner, code.equals("ur") ? Ui.dp(8) : Ui.dp(2)), lay((CharSequence) sc[1], bp, inner, ex)});
        }
    }

    private int contentHeight() {
        int h = Ui.dp(22) + Ui.dp(30); // padding + pill row
        if (lEmo != null) h += Ui.dp(18) + lEmo.getHeight();
        if (lAr != null) h += Ui.dp(14) + Ui.dp(32) + lAr.getHeight() + (lArSrc != null ? Ui.dp(6) + lArSrc.getHeight() : 0);
        for (int k = 0; k < lays.size(); k++) {
            StaticLayout[] l = lays.get(k);
            if (k > 0) h += Ui.dp(28);
            if (l[0] != null) h += Ui.dp(k == 0 ? 12 : 4) + l[0].getHeight();
            if (l[1] != null) h += Ui.dp(10) + l[1].getHeight();
        }
        if (lSrc != null) h += Ui.dp(16) + lSrc.getHeight();
        h += Ui.dp(22) + Ui.dp(26); // hint + padding
        return h;
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        int w = MeasureSpec.getSize(wSpec);
        build(w);
        int want = Math.max(contentHeight(), Math.round(getResources().getDisplayMetrics().heightPixels * 0.5f));
        setMeasuredDimension(w, resolveSize(want, hSpec));
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        build(w);
        bg.setShader(new LinearGradient(0, 0, w, h, c1, c2, Shader.TileMode.CLAMP));
        r.set(0, 0, w, h);
        c.drawRoundRect(r, Ui.dp(28), Ui.dp(28), bg);

        float pad = Ui.dp(22), y = pad;
        // pill + counter
        float pw = pill.measureText(cat) + Ui.dp(22);
        r.set(pad, y, pad + pw, y + Ui.dp(28));
        c.drawRoundRect(r, Ui.dp(14), Ui.dp(14), pillBg);
        c.drawText(cat, pad + Ui.dp(11), y + Ui.dp(19), pill);
        c.drawText(counter, w - pad - small.measureText(counter), y + Ui.dp(19), small);
        y += Ui.dp(30);

        if (lEmo != null) {
            y += Ui.dp(18);
            y = drawL(c, lEmo, pad, y);
        }
        if (lAr != null) {
            y += Ui.dp(14);
            float boxH = Ui.dp(32) + lAr.getHeight() + (lArSrc != null ? Ui.dp(6) + lArSrc.getHeight() : 0);
            r.set(pad, y, w - pad, y + boxH);
            c.drawRoundRect(r, Ui.dp(18), Ui.dp(18), arBox);
            float yy = drawL(c, lAr, pad + Ui.dp(14), y + Ui.dp(16));
            if (lArSrc != null) drawL(c, lArSrc, pad + Ui.dp(14), yy + Ui.dp(6));
            y += boxH;
        }
        for (int k = 0; k < lays.size(); k++) {
            StaticLayout[] l = lays.get(k);
            if (k > 0) {
                y += Ui.dp(14);
                c.drawLine(pad, y, w - pad, y, line);
                y += Ui.dp(14);
            }
            if (l[0] != null) {
                y += Ui.dp(k == 0 ? 12 : 4);
                y = drawL(c, l[0], pad, y);
            }
            if (l[1] != null) {
                y += Ui.dp(10);
                y = drawL(c, l[1], pad, y);
            }
        }
        if (lSrc != null) {
            y += Ui.dp(16);
            drawL(c, lSrc, pad, y);
        }
        small.setColor(0x80FFFFFF);
        float hw = small.measureText(hint);
        c.drawText(hint, (w - hw) / 2f, h - Ui.dp(20), small);
        small.setColor(0xBFFFFFFF);
    }

    private float drawL(Canvas c, StaticLayout l, float x, float y) {
        c.save();
        c.translate(x, y);
        l.draw(c);
        c.restore();
        return y + l.getHeight();
    }
}
