package com.mahendi.muhasabah;

import android.content.Context;
import android.util.Base64;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * Compete with friends (off by default; turned on in Settings).
 * A group is a short code. Each phone posts a tiny encrypted update (name, daily scores, tasks done, streak)
 * to a relay topic derived from the code (ntfy.sh); the others read it back. The relay only sees
 * encrypted bytes; the key never leaves the phones that know the code. Nothing else is shared.
 */
public final class Compete {
    public static final String K_ON = "cmp_on", K_ROOM = "cmp_room", K_ME = "cmp_me", K_MEMBERS = "cmp_members",
            K_PUB = "cmp_pub_at", K_PUB_SIG = "cmp_pub_sig", K_FETCH = "cmp_fetch_at", K_EMOJI = "cmp_emoji";
    private static final String RELAY = "https://ntfy.sh/";
    private static final String ALPHA = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"; // no 0/O/1/I/L
    private static final SecureRandom RND = new SecureRandom();
    private static volatile boolean busy;

    private Compete() {
    }

    public static boolean on(Store s) {
        return s.b(K_ON, false);
    }

    public static String room(Store s) {
        return s.s(K_ROOM, "");
    }

    public static boolean inRoom(Store s) {
        return on(s) && room(s).length() > 0;
    }

    public static String me(Store s) {
        String id = s.s(K_ME, "");
        if (id.length() == 0) {
            StringBuilder b = new StringBuilder();
            for (int i = 0; i < 12; i++) b.append(ALPHA.charAt(RND.nextInt(ALPHA.length())));
            id = b.toString();
            s.put(K_ME, id);
        }
        return id;
    }

    public static String emoji(Store s) {
        return s.s(K_EMOJI, "🙂");
    }

    // ---------------- codes ----------------
    public static String newCode() {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < 12; i++) {
            if (i > 0 && i % 4 == 0) b.append('-');
            b.append(ALPHA.charAt(RND.nextInt(ALPHA.length())));
        }
        return b.toString();
    }

    /** "k7qm 29xp-4dfa" → "K7QM-29XP-4DFA"; null when it isn't a valid code. */
    public static String clean(String raw) {
        if (raw == null) return null;
        StringBuilder b = new StringBuilder();
        String u = raw.toUpperCase(java.util.Locale.US);
        for (int i = 0; i < u.length(); i++) {
            char ch = u.charAt(i);
            if (ALPHA.indexOf(ch) >= 0) b.append(ch);
        }
        String k = b.toString();
        if (k.length() != 12) return null;
        return k.substring(0, 4) + "-" + k.substring(4, 8) + "-" + k.substring(8);
    }

    private static byte[] sha(String s) throws Exception {
        return MessageDigest.getInstance("SHA-256").digest(s.getBytes("UTF-8"));
    }

    private static String topic(String code) throws Exception {
        byte[] h = sha("muhasabah-topic|" + code);
        StringBuilder b = new StringBuilder("muhasabah_");
        for (int i = 0; i < 16; i++) b.append(String.format("%02x", h[i] & 0xff));
        return b.toString();
    }

    private static String seal(String code, String plain) throws Exception {
        byte[] iv = new byte[12];
        RND.nextBytes(iv);
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(sha("muhasabah-key|" + code), "AES"), new GCMParameterSpec(128, iv));
        byte[] ct = c.doFinal(plain.getBytes("UTF-8"));
        byte[] all = new byte[iv.length + ct.length];
        System.arraycopy(iv, 0, all, 0, iv.length);
        System.arraycopy(ct, 0, all, iv.length, ct.length);
        return "m1:" + Base64.encodeToString(all, Base64.NO_WRAP);
    }

    private static String open(String code, String msg) {
        try {
            if (msg == null || !msg.startsWith("m1:")) return null;
            byte[] all = Base64.decode(msg.substring(3), Base64.NO_WRAP);
            if (all.length < 29) return null;
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE, new SecretKeySpec(sha("muhasabah-key|" + code), "AES"), new GCMParameterSpec(128, all, 0, 12));
            return new String(c.doFinal(all, 12, all.length - 12), "UTF-8");
        } catch (Exception e) {
            return null;
        }
    }

    // ---------------- my update ----------------
    static JSONObject myUpdate(Context ctx) throws Exception {
        Store s = Store.get(ctx);
        JSONObject o = new JSONObject();
        o.put("v", 1);
        o.put("id", me(s));
        o.put("n", s.s(Store.K_NAME, "Mahdi"));
        o.put("e", emoji(s));
        o.put("at", System.currentTimeMillis());
        JSONObject d = new JSONObject();
        for (int k = 0; k > -14; k--) {
            String date = Store.date(k);
            if (k < 0 && !Score.hasData(s, date) && !s.p.contains("score_" + date)) continue;
            d.put(date, Score.dayScore(s, date));
        }
        o.put("d", d);
        int done = 0, total = 0;
        String today = Store.today();
        for (Task t : s.tasksOn(today)) {
            total++;
            if (t.frac(Score.liveValue(s, t, today)) >= 0.999) done++;
        }
        o.put("dn", done);
        o.put("tt", total);
        o.put("st", Score.streak(s));
        return o;
    }

    // ---------------- members ----------------
    public static JSONObject members(Store s) {
        try {
            return new JSONObject(s.s(K_MEMBERS, "{}"));
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    /** Merge one update; newer wins. Returns true when something changed. */
    private static boolean merge(JSONObject all, JSONObject u) {
        try {
            String id = u.optString("id");
            if (id.length() == 0) return false;
            JSONObject old = all.optJSONObject(id);
            if (old != null && old.optLong("at") >= u.optLong("at")) return false;
            if (u.optBoolean("left")) {
                all.remove(id);
                return old != null;
            }
            // keep older day scores the new update no longer carries
            if (old != null && old.optJSONObject("d") != null) {
                JSONObject nd = u.optJSONObject("d");
                if (nd == null) {
                    nd = new JSONObject();
                    u.put("d", nd);
                }
                JSONObject od = old.optJSONObject("d");
                Iterator<String> it = od.keys();
                while (it.hasNext()) {
                    String k = it.next();
                    if (!nd.has(k) && Store.daysBetween(k, Store.today()) < 40) nd.put(k, od.optInt(k));
                }
            }
            all.put(id, u);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static class Row {
        public String id, name, emoji;
        public boolean mine;
        public int today, week, streak, done, total;
        public long at;
    }

    /** Everyone in the group (me included, always fresh), best first for the chosen view. */
    public static List<Row> board(Context c, final boolean week) {
        Store s = Store.get(c);
        JSONObject all = members(s);
        try {
            all.put(me(s), myUpdate(c));
        } catch (Exception ignored) {
        }
        String[] wk = Summary.weekOf(Store.today());
        List<Row> out = new ArrayList<Row>();
        Iterator<String> it = all.keys();
        while (it.hasNext()) {
            JSONObject u = all.optJSONObject(it.next());
            if (u == null) continue;
            Row r = new Row();
            r.id = u.optString("id");
            r.mine = r.id.equals(me(s));
            r.name = u.optString("n", "?");
            r.emoji = u.optString("e", "🙂");
            r.at = u.optLong("at");
            JSONObject d = u.optJSONObject("d");
            if (d == null) d = new JSONObject();
            r.today = d.optInt(Store.today(), 0);
            for (String day = wk[0]; day.compareTo(wk[1]) <= 0 && day.compareTo(Store.today()) <= 0; day = Summary.shift(day, 1))
                r.week += d.optInt(day, 0);
            // a stale update ("today" from another day) shouldn't show yesterday's tasks as today's
            boolean fresh = Store.fmt(cal(r.at)).equals(Store.today());
            r.done = fresh ? u.optInt("dn") : 0;
            r.total = fresh ? u.optInt("tt") : 0;
            r.streak = u.optInt("st");
            out.add(r);
        }
        Collections.sort(out, new Comparator<Row>() {
            @Override
            public int compare(Row a, Row b) {
                int x = week ? b.week - a.week : b.today - a.today;
                if (x != 0) return x;
                x = b.streak - a.streak;
                return x != 0 ? x : a.name.compareToIgnoreCase(b.name);
            }
        });
        return out;
    }

    private static java.util.Calendar cal(long ms) {
        java.util.Calendar c = java.util.Calendar.getInstance();
        c.setTimeInMillis(ms);
        return c;
    }

    // ---------------- network ----------------
    public interface Done {
        void done(boolean ok);
    }

    /** Publish my update (when changed or every 3 h) and read the group. Runs off the main thread. */
    public static void sync(final Context ctx, final boolean force, final Done cb) {
        final Context c = ctx.getApplicationContext();
        final Store s = Store.get(c);
        if (!inRoom(s) || busy) {
            if (cb != null) cb.done(false);
            return;
        }
        long now = System.currentTimeMillis();
        if (!force && now - s.l(K_FETCH, 0) < 30 * 60_000L) {
            if (cb != null) cb.done(true);
            return;
        }
        busy = true;
        new Thread(new Runnable() {
            @Override
            public void run() {
                boolean ok = false;
                try {
                    String code = room(s);
                    JSONObject mine = myUpdate(c);
                    String sig = mine.optJSONObject("d").toString() + mine.optInt("dn") + "/" + mine.optInt("tt") + mine.optString("n") + mine.optString("e") + mine.optInt("st");
                    long last = s.l(K_PUB, 0);
                    if (!sig.equals(s.s(K_PUB_SIG, "")) && System.currentTimeMillis() - last > 10 * 60_000L
                            || System.currentTimeMillis() - last > 3 * 3600_000L || force && System.currentTimeMillis() - last > 60_000L) {
                        if (post(topic(code), seal(code, mine.toString()))) {
                            s.put(K_PUB, System.currentTimeMillis());
                            s.put(K_PUB_SIG, sig);
                        }
                    }
                    ok = fetch(c, code);
                    if (ok) s.put(K_FETCH, System.currentTimeMillis());
                } catch (Throwable ignored) {
                } finally {
                    busy = false;
                }
                if (cb != null) cb.done(ok);
            }
        }).start();
    }

    private static boolean post(String topic, String body) {
        try {
            HttpURLConnection h = (HttpURLConnection) new URL(RELAY + topic).openConnection();
            h.setRequestMethod("POST");
            h.setConnectTimeout(10000);
            h.setReadTimeout(10000);
            h.setDoOutput(true);
            h.setRequestProperty("Content-Type", "text/plain; charset=utf-8");
            byte[] b = body.getBytes("UTF-8");
            OutputStream o = h.getOutputStream();
            o.write(b);
            o.close();
            int code = h.getResponseCode();
            h.disconnect();
            return code >= 200 && code < 300;
        } catch (Exception e) {
            return false;
        }
    }

    private static boolean fetch(Context c, String code) {
        try {
            HttpURLConnection h = (HttpURLConnection) new URL(RELAY + topic(code) + "/json?poll=1&since=all").openConnection();
            h.setConnectTimeout(10000);
            h.setReadTimeout(15000);
            h.setUseCaches(false);
            if (h.getResponseCode() != 200) return false;
            BufferedReader r = new BufferedReader(new InputStreamReader(h.getInputStream(), "UTF-8"));
            Store s = Store.get(c);
            JSONObject all = members(s);
            boolean changed = false;
            String line;
            while ((line = r.readLine()) != null) {
                if (line.trim().length() == 0) continue;
                JSONObject ev = new JSONObject(line);
                if (!"message".equals(ev.optString("event"))) continue;
                String plain = open(code, ev.optString("message"));
                if (plain == null) continue;
                JSONObject u = new JSONObject(plain);
                if (u.optString("id").equals(me(s))) continue;
                if (merge(all, u)) changed = true;
            }
            r.close();
            h.disconnect();
            if (changed && code.equals(room(s))) s.put(K_MEMBERS, all.toString());
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // ---------------- joining / leaving ----------------
    public static void join(Context c, String code) {
        Store s = Store.get(c);
        s.put(K_ROOM, code);
        s.put(K_MEMBERS, "{}");
        s.put(K_PUB, 0L);
        s.put(K_PUB_SIG, "");
        s.put(K_FETCH, 0L);
    }

    /** Tell the group I left (best effort), then forget it here. */
    public static void leave(Context ctx) {
        final Store s = Store.get(ctx);
        final String code = room(s);
        final String id = me(s);
        s.put(K_ROOM, "");
        s.put(K_MEMBERS, "{}");
        if (code.length() == 0) return;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    JSONObject o = new JSONObject();
                    o.put("v", 1);
                    o.put("id", id);
                    o.put("left", true);
                    o.put("at", System.currentTimeMillis());
                    post(topic(code), seal(code, o.toString()));
                } catch (Exception ignored) {
                }
            }
        }).start();
    }

    /** "just now", "25 min ago", "3 h ago", "2 days ago". */
    public static String ago(long at) {
        long m = Math.max(0, (System.currentTimeMillis() - at) / 60000);
        if (m < 2) return HadithCard.label("just now", "હમણાં", "ابھی", "अभी");
        if (m < 60) return HadithCard.label(m + " min ago", m + " મિનિટ પહેલાં", m + " منٹ پہلے", m + " मिनट पहले");
        long hh = m / 60;
        if (hh < 24) return HadithCard.label(hh + " h ago", hh + " કલાક પહેલાં", hh + " گھنٹے پہلے", hh + " घंटे पहले");
        long d = hh / 24;
        return HadithCard.label(d + (d == 1 ? " day ago" : " days ago"), d + " દિવસ પહેલાં", d + " دن پہلے", d + " दिन पहले");
    }
}
