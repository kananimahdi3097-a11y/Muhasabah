package com.mahendi.muhasabah;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * Reminders that keep coming back (default 4 times, every 10 minutes) until you tap Done.
 * A reminder can be linked to a task: tapping Done then also completes that task.
 */
public final class Reminders {
    public static final String CH = "reminders";
    public static final String K_REPEAT = "rem_repeat", K_INTERVAL = "rem_interval", K_SNOOZE = "rem_snooze";

    public static class R {
        public String id, title = "", taskId = "";
        public int time = 9 * 60, days = 127, repeat = 4, interval = 10;
        public boolean active = true;

        JSONObject json() {
            JSONObject o = new JSONObject();
            try {
                o.put("id", id);
                o.put("title", title);
                o.put("taskId", taskId);
                o.put("time", time);
                o.put("days", days);
                o.put("repeat", repeat);
                o.put("interval", interval);
                o.put("active", active);
            } catch (Exception ignored) {
            }
            return o;
        }

        static R from(JSONObject o) {
            R r = new R();
            r.id = o.optString("id");
            r.title = o.optString("title");
            r.taskId = o.optString("taskId", "");
            r.time = o.optInt("time", 540);
            r.days = o.optInt("days", 127);
            r.repeat = o.optInt("repeat", 4);
            r.interval = o.optInt("interval", 10);
            r.active = o.optBoolean("active", true);
            return r;
        }

        public boolean onDay(Calendar c) {
            int bit = c.get(Calendar.DAY_OF_WEEK) - 1; // Sunday = 0
            return (days & (1 << bit)) != 0;
        }
    }

    public static R newDefault(Context c) {
        Store s = Store.get(c);
        R r = new R();
        r.id = "r" + System.currentTimeMillis();
        r.repeat = s.i(K_REPEAT, 4);
        r.interval = s.i(K_INTERVAL, 10);
        return r;
    }

    // ---------- storage ----------
    public static List<R> all(Context c) {
        List<R> l = new ArrayList<R>();
        try {
            JSONArray a = new JSONArray(Store.get(c).s("reminders", "[]"));
            for (int i = 0; i < a.length(); i++) l.add(R.from(a.getJSONObject(i)));
        } catch (Exception ignored) {
        }
        return l;
    }

    private static void saveAll(Context c, List<R> l) {
        JSONArray a = new JSONArray();
        for (R r : l) a.put(r.json());
        Store.get(c).put("reminders", a.toString());
        schedule(c);
    }

    public static void upsert(Context c, R r) {
        List<R> l = all(c);
        boolean found = false;
        for (int i = 0; i < l.size(); i++) if (l.get(i).id.equals(r.id)) {
            l.set(i, r);
            found = true;
        }
        if (!found) l.add(r);
        saveAll(c, l);
    }

    public static void delete(Context c, String id) {
        List<R> l = all(c);
        for (int i = l.size() - 1; i >= 0; i--) if (l.get(i).id.equals(id)) l.remove(i);
        saveAll(c, l);
        cancelNotif(c, id);
    }

    /** Keep a task's own reminder in step with its schedule (days + time + "remind" switch). */
    public static void syncTask(Context c, Task t) {
        R r = forTask(c, t.id);
        if (t.remind && t.time >= 0 && t.active) {
            if (r == null) r = newDefault(c);
            r.taskId = t.id;
            r.title = t.emoji + " " + t.display();
            r.time = t.time;
            r.days = t.days;
            r.active = true;
            upsert(c, r);
        } else if (r != null && r.active && (t.time >= 0 || !t.active)) {
            r.active = false;
            upsert(c, r);
        }
    }

    public static R forTask(Context c, String taskId) {
        for (R r : all(c)) if (taskId.equals(r.taskId)) return r;
        return null;
    }

    // ---------- per-day state ----------
    private static JSONObject state(Context c, String id) {
        try {
            return new JSONObject(Store.get(c).s("rs_" + id + "_" + Store.today(), "{}"));
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    private static void saveState(Context c, String id, JSONObject st) {
        Store.get(c).put("rs_" + id + "_" + Store.today(), st.toString());
    }

    public static boolean doneToday(Context c, R r) {
        if (state(c, r.id).optBoolean("done")) return true;
        Task t = task(c, r.taskId);
        return t != null && t.frac(Store.get(c).value(Store.today(), t)) >= 0.999;
    }

    public static int firedToday(Context c, R r) {
        return state(c, r.id).optInt("n", 0);
    }

    /** The reminder's days, narrowed to the linked task's own dates (e.g. a one-time task). */
    private static boolean onDay(Context c, R r, Calendar cal) {
        if (!r.onDay(cal)) return false;
        Task t = task(c, r.taskId);
        return t == null || t.onCal(cal);
    }

    private static Task task(Context c, String id) {
        if (id == null || id.length() == 0) return null;
        for (Task t : Store.get(c).tasks()) if (t.id.equals(id)) return t;
        return null;
    }

    // ---------- actions ----------
    public static void markDone(Context c, String id) {
        R r = null;
        for (R x : all(c)) if (x.id.equals(id)) r = x;
        JSONObject st = state(c, id);
        try {
            st.put("done", true);
        } catch (Exception ignored) {
        }
        saveState(c, id, st);
        if (r != null) {
            Task t = task(c, r.taskId);
            if (t != null) complete(c, t);
        }
        cancelNotif(c, id);
        schedule(c);
    }

    /** Fully complete a task (used by reminder Done buttons). */
    public static void complete(Context c, Task t) {
        Store s = Store.get(c);
        String d = Store.today();
        if (t.type == Task.CHOICE) {
            int best = 0;
            for (int i = 0; i < t.optionScores.length; i++) if (t.optionScores[i] > t.optionScores[best]) best = i;
            s.setValue(d, t, best);
        } else if (t.type == Task.CHECK) s.setValue(d, t, 1);
        else s.setValue(d, t, Math.max(s.value(d, t), t.target));
        s.setTimer(t.id, 0);
    }

    public static void snooze(Context c, String id) {
        JSONObject st = state(c, id);
        try {
            st.put("snooze", System.currentTimeMillis() + Store.get(c).i(K_SNOOZE, 10) * 60000L);
        } catch (Exception ignored) {
        }
        saveState(c, id, st);
        cancelNotif(c, id);
        schedule(c);
    }

    private static int notifId(String id) {
        return 5000 + Math.abs(id.hashCode() % 4000);
    }

    private static void cancelNotif(Context c, String id) {
        try {
            c.getSystemService(NotificationManager.class).cancel(notifId(id));
        } catch (Exception ignored) {
        }
    }

    // ---------- the check (called by alarm + the always-on service) ----------
    public static void check(Context c) {
        long now = System.currentTimeMillis();
        Calendar cal = Calendar.getInstance();
        int mod = Store.minuteOfDay();
        for (R r : all(c)) {
            if (!r.active || !onDay(c, r, cal) || mod < r.time) continue;
            if (doneToday(c, r)) continue;
            JSONObject st = state(c, r.id);
            int n = st.optInt("n", 0);
            if (n >= r.repeat) continue;
            long last = st.optLong("last", 0), snooze = st.optLong("snooze", 0);
            if (now < snooze) continue;
            if (n > 0 && now - last < r.interval * 60000L - 20000L) continue;
            n++;
            try {
                st.put("n", n);
                st.put("last", now);
            } catch (Exception ignored) {
            }
            saveState(c, r.id, st);
            post(c, r, n);
        }
    }

    private static void post(Context c, R r, int n) {
        channel(c);
        Intent done = new Intent(c, ReminderReceiver.class).setAction(ReminderReceiver.DONE).putExtra("id", r.id);
        Intent snz = new Intent(c, ReminderReceiver.class).setAction(ReminderReceiver.SNOOZE).putExtra("id", r.id);
        int nid = notifId(r.id);
        PendingIntent pd = PendingIntent.getBroadcast(c, nid, done, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent ps = PendingIntent.getBroadcast(c, nid + 1, snz, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Intent open = new Intent(c, r.taskId.length() > 0 ? TaskActivity.class : MainActivity.class);
        open.putExtra("task", r.taskId);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent po = PendingIntent.getActivity(c, nid + 2, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        boolean last = n >= r.repeat;
        String body = Lang.pick("Reminder " + n + " of " + r.repeat + " — tap Done when finished.",
                "રિમાઇન્ડર " + n + " / " + r.repeat + " — પૂરું થાય ત્યારે 'થઈ ગયું' દબાવો.");
        if (last && Store.get(c).b(Store.K_STRICT, true)) body = Lines.make(Store.get(c), Lines.BAD_DAY, true) + "\n" + body;
        Notification.Builder b = new Notification.Builder(c, CH)
                .setSmallIcon(R_drawable())
                .setColor(Ui.GOLD)
                .setContentTitle("⏰ " + r.title)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setContentIntent(po)
                .setAutoCancel(false)
                .setOnlyAlertOnce(false)
                .setCategory(Notification.CATEGORY_REMINDER)
                .addAction(new Notification.Action.Builder(null, Lang.pick("✅ Done", "✅ થઈ ગયું"), pd).build())
                .addAction(new Notification.Action.Builder(null,
                        Lang.pick("Snooze " + Store.get(c).i(K_SNOOZE, 10) + " min", "પછી " + Store.get(c).i(K_SNOOZE, 10) + " મિ"), ps).build());
        try {
            c.getSystemService(NotificationManager.class).notify(nid, b.build());
        } catch (SecurityException ignored) {
        }
    }

    private static int R_drawable() {
        return com.mahendi.muhasabah.R.drawable.ic_stat;
    }

    public static void channel(Context c) {
        NotificationChannel ch = new NotificationChannel(CH, "Reminders", NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("Your reminders — repeat until you tap Done");
        ch.enableVibration(true);
        c.getSystemService(NotificationManager.class).createNotificationChannel(ch);
    }

    // ---------- scheduling the next exact wake-up ----------
    public static void schedule(Context c) {
        long now = System.currentTimeMillis(), next = Long.MAX_VALUE;
        Calendar today = Calendar.getInstance();
        long midnight = Store.startOfToday();
        for (R r : all(c)) {
            if (!r.active) continue;
            // today
            if (onDay(c, r, today) && !doneToday(c, r)) {
                JSONObject st = state(c, r.id);
                int n = st.optInt("n", 0);
                if (n < r.repeat) {
                    long at = n == 0 ? midnight + r.time * 60000L : st.optLong("last", 0) + r.interval * 60000L;
                    at = Math.max(at, st.optLong("snooze", 0));
                    if (at < now) at = now + 15000;
                    next = Math.min(next, at);
                }
            }
            // next days (first occurrence)
            for (int d = 1; d <= 7; d++) {
                Calendar k = Calendar.getInstance();
                k.add(Calendar.DAY_OF_YEAR, d);
                if (onDay(c, r, k)) {
                    next = Math.min(next, midnight + d * 86400000L + r.time * 60000L);
                    break;
                }
            }
        }
        AlarmManager am = c.getSystemService(AlarmManager.class);
        Intent i = new Intent(c, ReminderReceiver.class).setAction(ReminderReceiver.TICK);
        PendingIntent pi = PendingIntent.getBroadcast(c, 4999, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        am.cancel(pi);
        if (next == Long.MAX_VALUE) return;
        try {
            if (am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi);
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi);
        } catch (Exception e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi);
        }
    }

    public static String days(int mask) {
        if (mask == 127) return Lang.pick("Every day", "દરરોજ");
        String[] en = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
        String[] gu = {"રવિ", "સોમ", "મંગળ", "બુધ", "ગુરુ", "શુક્ર", "શનિ"};
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < 7; i++) if ((mask & (1 << i)) != 0) {
            if (b.length() > 0) b.append(", ");
            b.append(Lang.dayShort(i));
        }
        return b.length() == 0 ? Lang.pick("Never", "ક્યારેય નહીં") : b.toString();
    }
}
