package com.mahendi.muhasabah;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * On-phone database for large source books (Quran, Hadith collections, Tafsir) that you add later.
 * The short reminders used for nudges stay in the Wisdom list; the Ask tab searches both.
 */
public final class Library extends SQLiteOpenHelper {
    private static Library inst;

    public static synchronized Library get(Context c) {
        if (inst == null) inst = new Library(c.getApplicationContext());
        return inst;
    }

    private Library(Context c) {
        super(c, "library.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE lib (id TEXT PRIMARY KEY, book TEXT, ref TEXT, ar TEXT, en TEXT, gu TEXT, topics TEXT, norm TEXT)");
        db.execSQL("CREATE INDEX lib_book ON lib(book)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int o, int n) {
    }

    /** Lower-case, strip Arabic diacritics/tatweel, unify alif/ya/ta-marbuta so searches match. */
    public static String norm(String s) {
        if (s == null) return "";
        StringBuilder b = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch >= 0x064B && ch <= 0x065F || ch == 0x0670 || ch == 0x0640 || ch >= 0x06D6 && ch <= 0x06ED) continue;
            if (ch == 'أ' || ch == 'إ' || ch == 'آ' || ch == 'ٱ') ch = 'ا';
            else if (ch == 'ى') ch = 'ي';
            else if (ch == 'ة') ch = 'ه';
            b.append(ch);
        }
        return b.toString().toLowerCase(Locale.US);
    }

    /** Insert/replace items of one book. Returns how many were written. */
    public int add(String book, JSONArray items) {
        SQLiteDatabase db = getWritableDatabase();
        int n = 0;
        db.beginTransaction();
        try {
            for (int k = 0; k < items.length(); k++) {
                JSONObject o = items.optJSONObject(k);
                if (o == null) continue;
                String en = o.optString("en"), gu = o.optString("gu"), ar = o.optString("ar");
                if (en.length() == 0 && gu.length() == 0 && ar.length() == 0) continue;
                String ref = o.optString("ref", o.optString("src"));
                String bk = o.optString("book", book);
                String id = o.optString("id", bk + "#" + k);
                JSONArray tp = o.optJSONArray("topics");
                String topics = tp == null ? "" : tp.toString();
                ContentValues v = new ContentValues();
                v.put("id", id);
                v.put("book", bk);
                v.put("ref", ref);
                v.put("ar", ar);
                v.put("en", en);
                v.put("gu", gu);
                v.put("topics", topics);
                v.put("norm", norm(en + " " + gu + " " + ar + " " + ref + " " + bk + " " + topics));
                db.insertWithOnConflict("lib", null, v, SQLiteDatabase.CONFLICT_REPLACE);
                n++;
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
        return n;
    }

    public int count() {
        Cursor c = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM lib", null);
        int n = c.moveToFirst() ? c.getInt(0) : 0;
        c.close();
        return n;
    }

    public List<String[]> books() {
        List<String[]> l = new ArrayList<String[]>();
        Cursor c = getReadableDatabase().rawQuery("SELECT book, COUNT(*) FROM lib GROUP BY book ORDER BY book", null);
        while (c.moveToNext()) l.add(new String[]{c.getString(0), String.valueOf(c.getInt(1))});
        c.close();
        return l;
    }

    public void deleteBook(String book) {
        getWritableDatabase().delete("lib", "book = ?", new String[]{book});
    }

    // ---------------- search ----------------
    public static class Hit {
        public JSONObject item; // ar, en, gu, src, topics
        public double score;
    }

    /** Common words in English / Gujarati / Hindi-in-English mapped to each other for better matching. */
    private static final String[][] SYN = {
            {"mahdi", "imam zaman", "imam-e-zamana", "zamana", "qaim", "qa'im", "hujjah", "hujjat", "imamzaman", "ઇમામે ઝમાના", "ઝમાના", "કાઇમ", "હુજ્જત", "مهدي", "قائم", "حجه"},
            {"wait", "intizar", "awaiting", "faraj", "ઇન્તેઝાર", "ફરજ", "انتظار", "فرج"},
            {"time", "samay", "waqt", "સમય", "وقت", "عصر"},
            {"prayer", "namaz", "salat", "salah", "નમાઝ", "صلاه"},
            {"gaze", "nazar", "glance", "eyes", "નજર", "આંખ", "نظر", "عيون"},
            {"parents", "mother", "father", "maa", "baap", "માતા", "પિતા", "વાલિદૈન", "والدين"},
            {"anger", "gussa", "angry", "ગુસ્સો", "غضب"},
            {"patience", "sabr", "સબ્ર", "صبر"},
            {"knowledge", "ilm", "learn", "ઇલ્મ", "علم"},
            {"sleep", "nind", "ઊંઘ", "نوم"},
            {"lazy", "laziness", "alas", "આળસ", "كسل"},
            {"society", "samaj", "people", "neighbour", "neighbor", "સમાજ", "પડોશી", "ناس", "جار"},
            {"justice", "adl", "insaf", "અદલ", "ઇન્સાફ", "عدل"},
            {"desire", "lust", "nafs", "khwahish", "ખ્વાહિશ", "નફસ", "هوي", "نفس"},
            {"work", "kaam", "business", "rozi", "કામ", "ધંધો", "રોજી", "عمل"},
            {"grateful", "shukr", "thanks", "શુક્ર", "شكر"},
            {"death", "maut", "grave", "મોત", "કબર", "موت"},
    };

    private static List<String> expand(String q) {
        String nq = norm(q);
        List<String> terms = new ArrayList<String>();
        for (String w : nq.split("[\\s,.;:!?()\\[\\]\"'—–\\-/]+")) {
            w = w.trim();
            if (w.length() >= 2 && !STOP.contains("|" + w + "|")) terms.add(w);
        }
        for (String[] group : SYN) {
            boolean hit = false;
            for (String g : group) if (nq.contains(norm(g))) hit = true;
            if (hit) for (String g : group) {
                String ng = norm(g);
                if (!terms.contains(ng)) terms.add(ng);
            }
        }
        return terms;
    }

    private static final String STOP = "|the|a|an|of|to|in|is|are|what|how|why|who|which|for|and|or|on|me|my|i|do|does|about|with|be|it|this|that|tell|say|says|"
            + "su|shu|che|chhe|ma|nu|ni|no|na|ne|ke|ane|વિશે|શું|છે|માં|નું|ની|નો|ના|ને|કે|અને|શા|માટે|કેમ|કઈ|કયો|";

    public List<Hit> search(Store s, String query, int max) {
        List<String> terms = expand(query);
        List<Hit> hits = new ArrayList<Hit>();
        if (terms.isEmpty()) return hits;
        // 1) short reminders (Wisdom)
        for (JSONObject o : s.wisdom()) {
            String text = norm(o.optString("en") + " " + o.optString("gu") + " " + o.optString("ur") + " " + o.optString("hi") + " " + o.optString("ar") + " " + o.optString("src") + " " + o.optJSONArray("topics"));
            double sc = score(text, terms);
            if (sc > 0) {
                Hit h = new Hit();
                h.item = o;
                h.score = sc + 0.5;
                hits.add(h);
            }
        }
        // 2) books in the database
        StringBuilder where = new StringBuilder();
        List<String> args = new ArrayList<String>();
        for (String t : terms) {
            if (where.length() > 0) where.append(" OR ");
            where.append("norm LIKE ?");
            args.add("%" + t + "%");
        }
        try {
            Cursor c = getReadableDatabase().rawQuery("SELECT id, book, ref, ar, en, gu, topics, norm FROM lib WHERE " + where + " LIMIT 400",
                    args.toArray(new String[0]));
            while (c.moveToNext()) {
                double sc = score(c.getString(7), terms);
                if (sc <= 0) continue;
                JSONObject o = new JSONObject();
                o.put("id", c.getString(0));
                o.put("ar", c.getString(3));
                o.put("en", c.getString(4));
                o.put("gu", c.getString(5));
                String ref = c.getString(2);
                o.put("src", c.getString(1) + (ref == null || ref.length() == 0 ? "" : " — " + ref));
                try {
                    o.put("topics", new JSONArray(c.getString(6)));
                } catch (Exception ignored) {
                }
                Hit h = new Hit();
                h.item = o;
                h.score = sc;
                hits.add(h);
            }
            c.close();
        } catch (Exception ignored) {
        }
        Collections.sort(hits, new Comparator<Hit>() {
            @Override
            public int compare(Hit a, Hit b) {
                return Double.compare(b.score, a.score);
            }
        });
        return hits.size() > max ? new ArrayList<Hit>(hits.subList(0, max)) : hits;
    }

    private static double score(String text, List<String> terms) {
        double sc = 0;
        for (String t : terms) {
            int idx = text.indexOf(t);
            if (idx >= 0) {
                sc += 1 + Math.min(3, t.length() / 4.0);
                if (text.indexOf(t, idx + t.length()) >= 0) sc += 0.3;
            }
        }
        return sc;
    }
}
