package com.mahendi.muhasabah;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;

/**
 * The guardian. An AccessibilityService that:
 *   • counts Reels / Shorts and closes them once past the daily limit,
 *   • blocks adult websites by host and blocks blocked-words in browser address/search bars,
 * then shows a full-screen reminder with a Quran/Hadith line and an activity suggestion.
 * Everything is on-device; it reads only what's needed to block, and stores nothing about pages.
 */
public class GuardService extends AccessibilityService {
    private static GuardService alive;

    private long lastBlockAction, offReelSince, lastBurst, lastLook;
    private String reelApp;
    private int lastIdx = -1, maxIdx = -1;
    private float accum;

    public static boolean isOn() {
        return alive != null;
    }

    /** False in the "lite" build, which ships without the accessibility guardian. */
    public static boolean available(android.content.Context c) {
        try {
            android.content.pm.PackageInfo pi = c.getPackageManager().getPackageInfo(c.getPackageName(),
                    android.content.pm.PackageManager.GET_SERVICES);
            if (pi.services != null) for (android.content.pm.ServiceInfo si : pi.services)
                if (si.name.endsWith(".GuardService")) return true;
        } catch (Exception ignored) {
        }
        return false;
    }

    @Override
    protected void onServiceConnected() {
        alive = this;
        if (screen == null) {
            screen = new ScreenGuard(this);
            screen.start();
        }
    }

    private ScreenGuard screen;

    /**
     * Muhasabah's block screen over a locked app (screen guard catch, private tab, daily limit, reels limit).
     * It opens straight on top of the app — the app stays locked, so going back to it just opens this again.
     */
    void blockApp(String pkg, String kind) {
        long now = SystemClock.elapsedRealtime();
        if (now - lastAppBlock < 1200) return;
        lastAppBlock = now;
        Intent i = new Intent(this, BlockActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
        i.putExtra("kind", kind);
        i.putExtra("app", pkg);
        try {
            startActivity(i);
        } catch (Exception e) {
            performGlobalAction(GLOBAL_ACTION_HOME);
        }
    }

    private long lastAppBlock, lastCapCheck;
    private String lastCapPkg;

    public static boolean isBrowserPkg(String pkg) {
        return isBrowser(pkg);
    }

    /** Daily hard limits (Instagram 40 min by default): once used up, the app is locked until midnight. */
    private void checkCap(Store s, String pkg) {
        int cap = AppLock.cap(s, pkg);
        if (cap <= 0) return;
        long now = SystemClock.elapsedRealtime();
        if (pkg.equals(lastCapPkg) && now - lastCapCheck < 10000) return;
        lastCapPkg = pkg;
        lastCapCheck = now;
        int used = AppLock.usedToday(this, pkg);
        String warnKey = "capwarn_" + pkg + "_" + Store.today();
        if (used >= cap - 5 && used < cap && !s.b(warnKey, false)) {
            s.put(warnKey, true);
            Notify.post(this, 452, Notify.CH_NUDGE, HadithCard.label("⏳ " + (cap - used) + " min of " + AppLock.appName(this, pkg) + " left today",
                    "⏳ આજે " + AppLock.appName(this, pkg) + " ની " + (cap - used) + " મિનિટ બાકી",
                    "⏳ آج " + AppLock.appName(this, pkg) + " کے " + (cap - used) + " منٹ باقی", "⏳ आज " + AppLock.appName(this, pkg) + " के " + (cap - used) + " मिनट बाक़ी"),
                    HadithCard.label("Then it locks until tomorrow — no extension.", "પછી કાલ સુધી લૉક — કોઈ વધારો નહીં.", "پھر کل تک لاک — کوئی اضافہ نہیں۔", "फिर कल तक लॉक — कोई बढ़ोतरी नहीं।"), null);
        }
        if (used >= cap) {
            AppLock.lock(s, pkg, AppLock.endOfToday(), "cap");
            blockApp(pkg, "cap");
        }
    }

    @Override
    public void onDestroy() {
        if (screen != null) screen.stop();
        screen = null;
        if (alive == this) alive = null;
        super.onDestroy();
    }

    @Override
    public void onInterrupt() {
    }

    // ------- browser packages whose URL/search bars we inspect -------
    private static boolean isBrowser(String pkg) {
        if (pkg == null) return false;
        return pkg.contains("chrome") || pkg.contains("browser") || pkg.equals("org.mozilla.firefox")
                || pkg.contains("brave") || pkg.contains("opera") || pkg.contains("duckduckgo")
                || pkg.contains("microsoft.emmx") || pkg.contains("samsung") && pkg.contains("sbrowser")
                || pkg.contains("uc") && pkg.contains("browser");
    }

    private static boolean isReelApp(String pkg) {
        return "com.instagram.android".equals(pkg) || "com.google.android.youtube".equals(pkg)
                || "com.google.android.apps.youtube.music".equals(pkg) || "com.facebook.katana".equals(pkg) || "com.facebook.lite".equals(pkg)
                || "com.snapchat.android".equals(pkg) || "in.mohalla.sharechat".equals(pkg)
                || "com.ss.android.ugc.trill".equals(pkg) || "com.zhiliaoapp.musically".equals(pkg)
                || "com.google.android.youtube".equals(pkg);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        Store s = Store.get(this);
        boolean locked = Lock.isLocked(s);
        if (!s.b(Store.K_MONITOR, true) && !locked) return; // during a lock the guardian can't be switched off
        CharSequence pkgc = event.getPackageName();
        if (pkgc == null) return;
        String pkg = pkgc.toString();
        if (screen != null && event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) screen.foreground(pkg);
        if (pkg.equals(getPackageName())) return;
        int type = event.getEventType();
        if (locked && isSystemGate(pkg)) {
            try {
                checkBackdoor(s, pkg);
            } catch (Throwable ignored) {
            }
            return;
        }

        try {
            if (AppLock.locked(s, pkg)) { // a locked app can't be used at all
                if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED || type == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) blockApp(pkg, "applock");
                return;
            }
            checkCap(s, pkg);
            boolean blockOn = s.b(Store.K_BLOCK_ON, true);
            if (blockOn && isBrowser(pkg)) checkBrowser(s, pkg);
            else if (blockOn && isSocial(pkg)) checkSocialText(s, pkg);
            if (isReelApp(pkg)) checkReels(s, pkg, type, event);
        } catch (Throwable ignored) {
        }
    }

    // ---------------- reels / shorts ----------------
    /*
     * Counting rule: one reel = one reel you actually landed on in the full-screen Reels / Shorts player.
     * Each reel is recognised by who posted it (the @username / channel shown on it): when the name on
     * screen changes to a new one and stays for half a second, that's one more reel. Going back to a reel
     * already seen, opening comments or expanding the caption doesn't count. If an app hides the name,
     * the older swipe-based count is used instead.
     */
    private String reelSig, pendSig;
    private long pendSince, sigMissingSince;
    private final java.util.LinkedHashSet<String> seenSigs = new java.util.LinkedHashSet<String>();

    private void checkReels(Store s, String pkg, int type, AccessibilityEvent ev) {
        long t = SystemClock.elapsedRealtime();
        if (type == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED && t - lastLook < 350) return;
        lastLook = t;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        int screenH = dm.heightPixels, screenW = dm.widthPixels;
        boolean onReel = isWholeAppReels(pkg) || detectReelSurface(root, pkg, screenH);
        String sig = onReel ? reelSignature(root, screenW, screenH) : null;
        root.recycle();
        long now = SystemClock.elapsedRealtime();
        if (!onReel) {
            if (reelApp != null && offReelSince == 0) offReelSince = now;
            if (reelApp != null && now - offReelSince > 2500) {
                reelApp = null;
                reelSig = null;
                pendSig = null;
            }
            return;
        }
        offReelSince = 0;
        boolean fresh = !pkg.equals(reelApp);
        if (fresh) {
            reelApp = pkg;
            lastIdx = -1;
            maxIdx = -1;
            accum = 0;
            reelSig = null;
            pendSig = null;
            sigMissingSince = 0;
            if (seenSigs.size() > 400) seenSigs.clear();
        }
        boolean swiped = type == AccessibilityEvent.TYPE_VIEW_SCROLLED && ev != null && reelSwipe(ev, screenH, now);
        if ("".equals(sig)) return; // comments / a sheet is open: hold
        if (sig == null) { // no name readable: count swipes
            if (fresh || swiped) countReel(s, pkg, now);
            return;
        }
        if (fresh && seenSigs.contains(pkg + "|" + sig)) reelSig = sig;
        if (!sig.equals(reelSig)) {
            if (!sig.equals(pendSig)) {
                pendSig = sig;
                pendSince = now;
            } else if (now - pendSince >= 450) { // stayed on screen a moment (not mid-swipe)
                reelSig = sig;
                pendSig = null;
                if (seenSigs.add(pkg + "|" + sig)) {
                    countReel(s, pkg, now);
                    lastSigCount = now;
                    swipeAt = 0;
                }
            }
        } else pendSig = null;
        // a full swipe that didn't change the name (same creator twice, or a name we can't read) still counts
        if (swiped && now - lastSigCount > 1500 && swipeAt == 0) swipeAt = now;
        if (swipeAt > 0 && now - swipeAt > 1600) {
            swipeAt = 0;
            if (now - lastSigCount > 1600) countReel(s, pkg, now);
        }
    }

    private long lastSigCount, swipeAt;

    /** A scroll of the full-screen player onto a new item. */
    private boolean reelSwipe(AccessibilityEvent ev, int screenH, long now) {
        AccessibilityNodeInfo src = ev.getSource();
        if (src != null) {
            android.graphics.Rect r = new android.graphics.Rect();
            src.getBoundsInScreen(r);
            src.recycle();
            if (r.height() < screenH * 0.6f) return false;
        }
        int from = ev.getFromIndex();
        if (ev.getItemCount() > 0 && from >= 0) {
            if (lastIdx < 0) {
                lastIdx = from;
                maxIdx = from;
                return false;
            }
            if (from == lastIdx) return false;
            lastIdx = from;
            if (from > maxIdx) {
                maxIdx = from;
                return true;
            }
            return false;
        }
        int dy = ev.getScrollDeltaY();
        if (dy != 0) {
            accum += dy;
            if (accum < 0) accum = 0;
            if (accum >= screenH * 0.45f) {
                accum = 0;
                return true;
            }
            return false;
        }
        boolean burst = now - lastBurst > 900;
        lastBurst = now;
        return burst;
    }

    private static final java.util.regex.Pattern HANDLE = java.util.regex.Pattern.compile("@?[A-Za-z0-9][A-Za-z0-9._]{2,29}");
    private static final java.util.Set<String> UI = new java.util.HashSet<String>(java.util.Arrays.asList(
            "like", "likes", "liked", "comment", "comments", "share", "send", "save", "saved", "follow", "following", "subscribe",
            "subscribed", "remix", "audio", "more", "less", "reels", "reel", "shorts", "short", "sponsored", "original", "home",
            "search", "explore", "profile", "create", "camera", "back", "options", "menu", "mute", "unmute", "play", "pause",
            "dislike", "view", "views", "verified", "paid", "partnership", "music", "sound", "live", "spotlight", "stories",
            "photo", "video", "image", "avatar", "picture", "tap", "double", "open", "watch", "see", "translation", "translated",
            "suggested", "for", "you", "new", "trending", "edited", "ad", "shop", "buy", "learn", "install", "visit", "sign", "join",
            "the", "and", "this", "add", "reply", "replies", "hide", "show", "close", "sound", "volume", "captions", "subtitles"));

    /**
     * Who posted the reel on screen: the first @username-like name in the lower part of the player.
     * Returns "" while a comments / bottom sheet is open (don't count then), null if no name is readable.
     */
    private String reelSignature(AccessibilityNodeInfo root, int W, int H) {
        java.util.List<Object[]> found = new java.util.ArrayList<Object[]>();
        boolean[] sheet = {false};
        collectNames(root, W, H, found, sheet, new int[]{900}, 0);
        if (sheet[0]) return "";
        if (found.isEmpty()) return null;
        java.util.Collections.sort(found, new java.util.Comparator<Object[]>() {
            @Override
            public int compare(Object[] a, Object[] b) {
                boolean ha = ((String) a[0]).startsWith("@"), hb = ((String) b[0]).startsWith("@");
                if (ha != hb) return ha ? -1 : 1; // an @handle is the surest name
                return Integer.compare((Integer) a[1], (Integer) b[1]); // then the top-most
            }
        });
        return ((String) found.get(0)[0]).toLowerCase().replaceFirst("^@", "");
    }

    private void collectNames(AccessibilityNodeInfo n, int W, int H, java.util.List<Object[]> out, boolean[] sheet, int[] budget, int depth) {
        if (n == null || budget[0]-- <= 0 || depth > 35 || !n.isVisibleToUser()) return;
        String id = n.getViewIdResourceName();
        String low = id == null ? "" : id.toLowerCase();
        android.graphics.Rect r = new android.graphics.Rect();
        n.getBoundsInScreen(r);
        if ((low.contains("comment") || low.contains("bottom_sheet") || low.contains("bottomsheet")) && r.height() > H * 0.35f && r.top > H * 0.1f) {
            sheet[0] = true;
            return;
        }
        if (low.contains("tab_bar") || low.contains("navigation") || low.contains("composer")) return;
        CharSequence t = n.getText();
        if (t == null || t.length() == 0) t = n.getContentDescription();
        if (t != null && r.centerY() > H * 0.45f && r.centerY() < H * 0.97f && r.left < W * 0.8f && r.height() < H * 0.12f) {
            String v = t.toString().trim();
            // "username" or "@channel", sometimes followed by " • Follow" / " · Original audio"
            String first = v.split("[\\s•·|]+")[0];
            if (HANDLE.matcher(first).matches() && !UI.contains(first.toLowerCase().replaceFirst("^@", ""))
                    && !first.matches("[0-9.,]+[kKmM]?") && (first.startsWith("@") || first.length() >= 3))
                out.add(new Object[]{first, r.top});
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo c = n.getChild(i);
            if (c == null) continue;
            collectNames(c, W, H, out, sheet, budget, depth + 1);
            c.recycle();
        }
    }

    private void countReel(Store s, String pkg, long now) {
        String today = Store.today();
        int count = s.incReels(today);
        int limit = s.reelsLimit();
        if (count == Math.max(1, limit - 3))
            Notify.post(this, 450, Notify.CH_NUDGE,
                    Lang.pick("🎬 " + (limit - count) + " reels left today", "🎬 " + (limit - count) + " રીલ્સ બાકી"),
                    Lang.pick("Almost at your limit. Make the next one the last.",
                            "લગભગ મર્યાદા પર. હવે પછીની છેલ્લી બનાવો."), null);
        if (count > limit && s.b(Store.K_BLOCK_ON, true) && now - lastBlockAction > 4000) {
            lastBlockAction = now;
            if (pkg.startsWith("com.instagram") || pkg.startsWith("com.facebook") || isWholeAppReels(pkg)) {
                // no back door through previews / pop-ups / the feed: the whole app is done for today
                AppLock.lock(s, pkg, AppLock.endOfToday(), "reels");
                blockApp(pkg, "reels");
            } else {
                performGlobalAction(GLOBAL_ACTION_BACK);
                block("reels", pkg, count);
            }
        }
    }

    /** Apps where the main screen itself is a reel feed. */
    private static boolean isWholeAppReels(String pkg) {
        return "com.ss.android.ugc.trill".equals(pkg) || "com.zhiliaoapp.musically".equals(pkg);
    }

    /** True only when the full-screen Reels / Shorts player is showing (not the home feed or a Shorts shelf). */
    private boolean detectReelSurface(AccessibilityNodeInfo root, String pkg, int screenH) {
        String[] hints;
        if (pkg.equals("com.instagram.android"))
            hints = new String[]{"clips_viewer", "clips_video_container", "reel_viewer", "clips_swipe", "clips_ufi"};
        else if (pkg.equals("com.google.android.youtube"))
            hints = new String[]{"reel_recycler", "reel_player", "reel_watch", "shorts_video_cell", "reel_time_bar", "shorts_player"};
        else if (pkg.equals("com.facebook.katana"))
            hints = new String[]{"reels_viewer", "reel_viewer", "fb_shorts", "video_reels"};
        else if (pkg.equals("com.snapchat.android"))
            hints = new String[]{"spotlight"};
        else hints = new String[]{"reel", "clips", "shorts"};
        int[] budget = {600};
        if (findIdHint(root, hints, screenH, budget, 0)) return true;
        // fallback when an app update renames its views: the Reels / Shorts tab is the SELECTED tab
        int[] b2 = {600};
        return selectedTab(root, b2, 0);
    }

    private boolean selectedTab(AccessibilityNodeInfo n, int[] budget, int depth) {
        if (n == null || budget[0]-- <= 0 || depth > 25) return false;
        if (n.isSelected()) {
            CharSequence t = n.getText(), d = n.getContentDescription();
            String v = (t != null ? t.toString() : "") + "|" + (d != null ? d.toString() : "");
            if (v.matches("(?i).*\\b(reels|shorts|spotlight)\\b.*")) return true;
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo c = n.getChild(i);
            if (c == null) continue;
            boolean hit = selectedTab(c, budget, depth + 1);
            c.recycle();
            if (hit) return true;
        }
        return false;
    }

    private boolean findIdHint(AccessibilityNodeInfo n, String[] hints, int screenH, int[] budget, int depth) {
        if (n == null || budget[0]-- <= 0 || depth > 25) return false;
        String id = n.getViewIdResourceName();
        if (id != null && n.isVisibleToUser()) {
            String low = id.toLowerCase();
            for (String h : hints)
                if (low.contains(h)) {
                    android.graphics.Rect r = new android.graphics.Rect();
                    n.getBoundsInScreen(r);
                    if (r.height() >= screenH * 0.6f) return true; // the full-screen player, not a small shelf/tab
                }
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo c = n.getChild(i);
            if (c == null) continue;
            boolean hit = findIdHint(c, hints, screenH, budget, depth + 1);
            c.recycle();
            if (hit) return true;
        }
        return false;
    }

    private boolean findText(AccessibilityNodeInfo node, String[] needles, int depth) {
        if (node == null || depth < 0) return false;
        CharSequence t = node.getText();
        CharSequence d = node.getContentDescription();
        for (String n : needles) {
            if (t != null && t.toString().equalsIgnoreCase(n)) return true;
            if (d != null && d.toString().equalsIgnoreCase(n)) return true;
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo c = node.getChild(i);
            if (c != null) {
                boolean r = findText(c, needles, depth - 1);
                c.recycle();
                if (r) return true;
            }
        }
        return false;
    }

    // ---------------- websites / words ----------------
    /** Video / social apps where searches and titles are checked for explicit words. */
    static boolean isSocial(String pkg) {
        return isReelApp(pkg) || pkg.startsWith("com.facebook") || pkg.startsWith("com.instagram") || "com.twitter.android".equals(pkg)
                || "com.instagram.barcelona".equals(pkg) || pkg.contains("moj") || pkg.contains("josh") || pkg.contains("takatak")
                || "com.pinterest".equals(pkg) || "com.reddit.frontpage".equals(pkg);
    }

    /** Phrases that mean an explicit / hot video when they appear in a title or result on screen. */
    private static final String[] EXPLICIT = {"hot song", "hot songs", "hot video", "hot videos", "hot dance", "hot scene", "hot scenes",
            "hot romance", "hot reels", "item song", "item songs", "item number", "sexy", "bikini", "lingerie", "kissing scene", "kiss scene",
            "kissing scenes", "bold scene", "bold scenes", "bed scene", "intimate scene", "hot photoshoot", "hot actress", "hot web series",
            "uncut scene", "porn", "xxx", "hot bhabhi", "desi bhabhi", "hot girl", "hot girls",
            "हॉट सॉन्ग", "हॉट गाना", "हॉट वीडियो", "हॉट सीन", "सेक्सी", "बोल्ड सीन", "किसिंग सीन", "हॉट डांस",
            "હોટ સોંગ", "હોટ વીડિયો", "સેક્સી"};
    private long lastSocialCheck;

    /** In video / social apps: an explicit search, or explicit titles on screen, lock the app like a browser. */
    private void checkSocialText(Store s, String pkg) {
        long t = SystemClock.elapsedRealtime();
        if (t - lastSocialCheck < 1000) return;
        lastSocialCheck = t;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        String bad = null;
        String typed = readEditText(root);
        if (typed != null) {
            String low = typed.toLowerCase();
            for (String w : s.blockedWords()) if (containsWord(low, w)) {
                bad = w;
                break;
            }
            if (bad == null) for (String w : EXPLICIT) if (containsWord(low, w)) {
                bad = w;
                break;
            }
        }
        if (bad == null) {
            StringBuilder sb = new StringBuilder();
            collectText(root, sb, new int[]{1200}, 0);
            String low = sb.toString().toLowerCase();
            for (String w : EXPLICIT) if (containsWord(low, w)) {
                bad = w;
                break;
            }
        }
        root.recycle();
        if (bad != null && t - lastBlockAction > 2500) {
            lastBlockAction = t;
            AppLock.lock(s, pkg, System.currentTimeMillis() + AppLock.CATCH_MS, "word");
            performGlobalAction(GLOBAL_ACTION_BACK);
            blockApp(pkg, "word");
        }
    }

    private static void collectText(AccessibilityNodeInfo n, StringBuilder sb, int[] budget, int depth) {
        if (n == null || budget[0]-- <= 0 || depth > 40 || sb.length() > 8000) return;
        if (!n.isVisibleToUser()) return;
        CharSequence tx = n.getText();
        if (tx != null && tx.length() > 0) sb.append(tx).append(" \n ");
        CharSequence d = n.getContentDescription();
        if (d != null && d.length() > 0) sb.append(d).append(" \n ");
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo c = n.getChild(i);
            if (c == null) continue;
            collectText(c, sb, budget, depth + 1);
            c.recycle();
        }
    }

    private void checkBrowser(Store s, String pkg) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        String url = readUrl(root, pkg);
        String bad = null, kind = null;
        if (url != null) {
            String host = url.toLowerCase();
            for (String site : s.blockedSites())
                if (host.contains(site)) {
                    bad = site;
                    kind = "site";
                    break;
                }
            if (bad == null)
                for (String w : s.blockedWords())
                    if (containsWord(host, w)) {
                        bad = w;
                        kind = "word";
                        break;
                    }
        }
        if (bad == null) {
            // scan focused edit field (search box / address bar text being typed)
            String typed = readEditText(root);
            if (typed != null) {
                String low = typed.toLowerCase();
                for (String w : s.blockedWords())
                    if (containsWord(low, w)) {
                        bad = w;
                        kind = "word";
                        break;
                    }
            }
        }
        root.recycle();
        long now = SystemClock.elapsedRealtime();
        if (bad != null && now - lastBlockAction > 2500) {
            lastBlockAction = now;
            AppLock.lock(s, pkg, System.currentTimeMillis() + AppLock.CATCH_MS, "word");
            performGlobalAction(GLOBAL_ACTION_BACK); // leave that page
            blockApp(pkg, "word");
        }
    }

    public static boolean hasWord(String haystack, String word) {
        return containsWord(haystack, word);
    }

    private static boolean containsWord(String haystack, String word) {
        if (haystack == null) return false;
        if (word.contains(" ")) return haystack.contains(word);
        int idx = haystack.indexOf(word);
        while (idx >= 0) {
            boolean lb = idx == 0 || !Character.isLetterOrDigit(haystack.charAt(idx - 1));
            int end = idx + word.length();
            boolean rb = end >= haystack.length() || !Character.isLetterOrDigit(haystack.charAt(end));
            if (lb && rb) return true;
            idx = haystack.indexOf(word, idx + 1);
        }
        return false;
    }

    private String readUrl(AccessibilityNodeInfo root, String pkg) {
        String[] ids = {pkg + ":id/url_bar", pkg + ":id/location_bar_edit_text", pkg + ":id/url_field",
                pkg + ":id/editor", "com.android.chrome:id/url_bar", pkg + ":id/address_bar", pkg + ":id/omnibar"};
        for (String id : ids) {
            List<AccessibilityNodeInfo> f = root.findAccessibilityNodeInfosByViewId(id);
            if (f != null && !f.isEmpty()) {
                for (AccessibilityNodeInfo n : f) {
                    CharSequence t = n.getText();
                    String r = t == null ? null : t.toString();
                    n.recycle();
                    if (r != null && r.length() > 1) return r;
                }
            }
        }
        return null;
    }

    private String readEditText(AccessibilityNodeInfo node) {
        if (node == null) return null;
        if (node.isEditable() || node.isFocused()) {
            CharSequence t = node.getText();
            if (t != null && t.length() > 1) return t.toString();
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo c = node.getChild(i);
            if (c != null) {
                String r = readEditText(c);
                c.recycle();
                if (r != null) return r;
            }
        }
        return null;
    }

    // ---------------- blocking action ----------------
    // ---------------- back doors (only while a lock is running) ----------------
    private long lastGate;

    private static boolean isSystemGate(String pkg) {
        return pkg.contains("settings") || pkg.contains("packageinstaller") || pkg.contains("permissioncontroller")
                || pkg.contains("securitycenter") || pkg.contains("safecenter") || pkg.equals("com.oplus.battery")
                || pkg.contains("devicepolicy") || pkg.contains("managedprovisioning");
    }

    /** Words that only appear on screens that could switch Muhasabah off, kill it, wipe it or uninstall it (case-insensitive). */
    private static final String[] DANGER = {"Force stop", "Uninstall", "Clear storage", "Clear data", "Storage & cache", "Storage and cache",
            "Deactivate", "Use Muhasabah", "Muhasabah shortcut", "Stop Muhasabah", "Allow background", "Battery optimi", "Background activity",
            "Pause app activity", "Unused app", "Remove permissions", "Restricted", "Disable"};

    private void checkBackdoor(Store s, String pkg) {
        long now = SystemClock.elapsedRealtime();
        if (now - lastGate < 700) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        boolean hit = false;
        List<AccessibilityNodeInfo> me = root.findAccessibilityNodeInfosByText("Muhasabah");
        if (me != null && !me.isEmpty() && !AdminReceiver.active(this)) {
            // turning ON uninstall protection must stay possible during a lock
            for (AccessibilityNodeInfo n : root.findAccessibilityNodeInfosByText("Activate")) {
                CharSequence t = n.getText();
                if (t != null && t.toString().trim().startsWith("Activate")) {
                    root.recycle();
                    return;
                }
            }
        }
        if (me != null && !me.isEmpty()) {
            for (String w : DANGER) {
                List<AccessibilityNodeInfo> l = root.findAccessibilityNodeInfosByText(w);
                if (l != null && !l.isEmpty()) {
                    hit = true;
                    break;
                }
            }
        }
        root.recycle();
        if (!hit) return;
        lastGate = now;
        Lock.log(s, "tamper", pkg);
        performGlobalAction(GLOBAL_ACTION_BACK);
        block("lock", pkg, 0);
    }

    private void block(String kind, String pkg, int count) {
        // open the block screen straight over the app (pressing Home first let the launcher cover it)
        Intent i = new Intent(this, BlockActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        i.putExtra("kind", kind);
        i.putExtra("count", count);
        i.putExtra("app", pkg);
        try {
            startActivity(i);
        } catch (Exception ignored) {
        }
    }
}
