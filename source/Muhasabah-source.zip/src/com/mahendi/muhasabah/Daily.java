package com.mahendi.muhasabah;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;

/**
 * Daily content: "From the books" (authentic, graded hadith with full references) and "Tip of the day".
 * Each list lives in a file, grows through content packs (merged by id, so later packs can also add
 * translations to existing items), and is shown one item per day without repeats.
 */
public final class Daily {
    public static final String BOOKS = "books", TIPS = "tips";
    private static JSONArray books, tips;

    private Daily() {
    }

    private static File file(Context c, String kind) {
        return new File(c.getFilesDir(), "daily_" + kind + ".json");
    }

    public static synchronized JSONArray list(Context c, String kind) {
        JSONArray cached = BOOKS.equals(kind) ? books : tips;
        if (cached != null) return cached;
        JSONArray a = null;
        try {
            File f = file(c, kind);
            if (f.exists()) a = new JSONArray(read(new FileInputStream(f)));
        } catch (Exception ignored) {
        }
        if (a == null) a = new JSONArray();
        // bundled sets (work offline from day one); merged so they never duplicate
        for (int set = 1; set <= 9; set++) {
            try {
                String asset = (BOOKS.equals(kind) ? "daily-" : "tips-") + set + ".json";
                JSONObject pack = new JSONObject(read(c.getAssets().open(asset)));
                a = merge(a, pack.optJSONArray("items"), true);
            } catch (Exception e) {
                break;
            }
        }
        if (BOOKS.equals(kind)) books = a;
        else tips = a;
        return a;
    }

    /** Adds new items (by id) and updates existing ones field by field. Returns how many were new. */
    public static synchronized int add(Context c, String kind, JSONArray items) {
        JSONArray a = list(c, kind);
        int before = a.length();
        JSONArray m = merge(a, items, false);
        try {
            FileOutputStream out = new FileOutputStream(file(c, kind));
            out.write(m.toString().getBytes("UTF-8"));
            out.close();
        } catch (Exception ignored) {
        }
        if (BOOKS.equals(kind)) books = m;
        else tips = m;
        return m.length() - before;
    }

    private static JSONArray merge(JSONArray a, JSONArray items, boolean addOnly) {
        if (items == null) return a;
        java.util.Map<String, JSONObject> byId = new java.util.HashMap<String, JSONObject>();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null) byId.put(o.optString("id"), o);
        }
        for (int i = 0; i < items.length(); i++) {
            JSONObject n = items.optJSONObject(i);
            if (n == null || n.optString("id").isEmpty()) continue;
            JSONObject old = byId.get(n.optString("id"));
            if (old == null) {
                a.put(n);
                byId.put(n.optString("id"), n);
            } else if (!addOnly) {
                java.util.Iterator<String> it = n.keys();
                while (it.hasNext()) {
                    String k = it.next();
                    try {
                        Object v = n.get(k);
                        if (!(v instanceof String) || ((String) v).length() > 0) old.put(k, v);
                    } catch (Exception ignored) {
                    }
                }
            }
        }
        return a;
    }

    /** Today's item; each new day moves forward one, and "next" moves forward too (never repeats until all are seen). */
    public static JSONObject today(Context c, String kind) {
        JSONArray a = list(c, kind);
        if (a.length() == 0) return null;
        Store s = Store.get(c);
        String day = s.s("dday_" + kind, ""), td = Store.today();
        int ptr = s.i("dptr_" + kind, 0);
        if (!td.equals(day)) {
            if (day.length() > 0) ptr++;
            s.put("dday_" + kind, td);
            s.put("dptr_" + kind, ptr);
        }
        return a.optJSONObject(((ptr % a.length()) + a.length()) % a.length());
    }

    public static void next(Context c, String kind) {
        Store s = Store.get(c);
        s.put("dptr_" + kind, s.i("dptr_" + kind, 0) + 1);
        s.put("dday_" + kind, Store.today());
    }

    public static int position(Context c, String kind) {
        JSONArray a = list(c, kind);
        return a.length() == 0 ? 0 : (Store.get(c).i("dptr_" + kind, 0) % a.length()) + 1;
    }

    /** Localized name of who said it (from the chain of narration). */
    public static String speaker(String code) {
        if (code == null || code.isEmpty()) return "";
        String[] v;
        switch (code) {
            case "prophet": v = new String[]{"The Prophet Muhammad (s.a.w.)", "રસૂલે ખુદા (સ.અ.વ.)", "رسول خدا صلی اللہ علیہ وآلہ", "रसूल-ए-ख़ुदा (स.अ.व.)"}; break;
            case "ali": v = new String[]{"Imam Ali (a.s.)", "ઇમામ અલી (અ.સ.)", "امام علی علیہ السلام", "इमाम अली (अ.स.)"}; break;
            case "fatima": v = new String[]{"Lady Fatima (s.a.)", "જનાબે ફાતેમા (સ.અ.)", "حضرت فاطمہ سلام اللہ علیہا", "जनाब-ए-फ़ातिमा (स.अ.)"}; break;
            case "hasan": v = new String[]{"Imam al-Hasan (a.s.)", "ઇમામ હસન (અ.સ.)", "امام حسن علیہ السلام", "इमाम हसन (अ.स.)"}; break;
            case "husayn": v = new String[]{"Imam al-Husayn (a.s.)", "ઇમામ હુસૈન (અ.સ.)", "امام حسین علیہ السلام", "इमाम हुसैन (अ.स.)"}; break;
            case "sajjad": v = new String[]{"Imam Zayn al-Abidin (a.s.)", "ઇમામ ઝૈનુલ આબેદીન (અ.સ.)", "امام زین العابدین علیہ السلام", "इमाम ज़ैनुल आबिदीन (अ.स.)"}; break;
            case "baqir": v = new String[]{"Imam al-Baqir (a.s.)", "ઇમામ મોહમ્મદ બાકિર (અ.સ.)", "امام محمد باقر علیہ السلام", "इमाम मुहम्मद बाक़िर (अ.स.)"}; break;
            case "sadiq": v = new String[]{"Imam al-Sadiq (a.s.)", "ઇમામ જઅફર સાદિક (અ.સ.)", "امام جعفر صادق علیہ السلام", "इमाम जाफ़र सादिक़ (अ.स.)"}; break;
            case "kadhim": v = new String[]{"Imam al-Kadhim (a.s.)", "ઇમામ મૂસા કાઝિમ (અ.સ.)", "امام موسیٰ کاظم علیہ السلام", "इमाम मूसा काज़िम (अ.स.)"}; break;
            case "rida": v = new String[]{"Imam al-Rida (a.s.)", "ઇમામ અલી રઝા (અ.સ.)", "امام علی رضا علیہ السلام", "इमाम अली रज़ा (अ.स.)"}; break;
            case "jawad": v = new String[]{"Imam al-Jawad (a.s.)", "ઇમામ મોહમ્મદ તકી (અ.સ.)", "امام محمد تقی علیہ السلام", "इमाम मुहम्मद तक़ी (अ.स.)"}; break;
            case "hadi": v = new String[]{"Imam al-Hadi (a.s.)", "ઇમામ અલી નકી (અ.સ.)", "امام علی نقی علیہ السلام", "इमाम अली नक़ी (अ.स.)"}; break;
            case "askari": v = new String[]{"Imam al-Askari (a.s.)", "ઇમામ હસન અસ્કરી (અ.સ.)", "امام حسن عسکری علیہ السلام", "इमाम हसन अस्करी (अ.स.)"}; break;
            default: return "";
        }
        return v[Math.max(0, Math.min(3, Lang.get()))];
    }

    private static String read(InputStream in) throws Exception {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        in.close();
        return bo.toString("UTF-8");
    }
}
