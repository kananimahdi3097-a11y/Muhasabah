package com.mahendi.muhasabah;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.widget.RemoteViews;

import org.json.JSONObject;

/**
 * Home-screen widget: today's score ring, namaz and tasks done, the next namaz time and a short hadith.
 * Drawn as one picture so Gujarati / Arabic use the app's own fonts.
 */
public class Widget extends AppWidgetProvider {
    private static long last;

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        for (int id : ids) draw(c, m, id);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context c, AppWidgetManager m, int id, Bundle o) {
        draw(c, m, id);
    }

    /** Refresh every widget (throttled; cheap to call after a task changes). */
    public static void update(Context c) {
        long now = System.currentTimeMillis();
        if (now - last < 20_000) return;
        last = now;
        try {
            AppWidgetManager m = AppWidgetManager.getInstance(c);
            int[] ids = m.getAppWidgetIds(new ComponentName(c, Widget.class));
            for (int id : ids) draw(c, m, id);
        } catch (Throwable ignored) {
        }
    }

    private static void draw(Context c, AppWidgetManager m, int id) {
        try {
            Store s = Store.get(c);
            Fonts.init(c);
            Bundle o = m.getAppWidgetOptions(id);
            float dens = c.getResources().getDisplayMetrics().density;
            int wDp = Math.max(250, o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, 320));
            int hDp = Math.max(110, o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 150));
            Bitmap b = render(c, s, Math.round(wDp * dens), Math.round(hDp * dens), dens);
            RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget);
            rv.setImageViewBitmap(R.id.w_img, b);
            Intent open = new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            rv.setOnClickPendingIntent(R.id.w_root, PendingIntent.getActivity(c, 7001, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
            m.updateAppWidget(id, rv);
        } catch (Throwable ignored) {
        }
    }

    static Bitmap render(Context c, Store s, int W, int H, float d) {
        Bitmap bm = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bm);
        Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        bg.setShader(new LinearGradient(0, 0, W, H, 0xF0123B37, 0xF00B1224, Shader.TileMode.CLAMP));
        RectF r = new RectF(0, 0, W, H);
        cv.drawRoundRect(r, 24 * d, 24 * d, bg);

        String today = Store.today();
        int score = Score.dayScore(s, today);
        // ring
        float pad = 14 * d, ringR = Math.min(H / 2f - pad, 46 * d), cx = pad + ringR, cy = H / 2f;
        Paint tr = new Paint(Paint.ANTI_ALIAS_FLAG);
        tr.setStyle(Paint.Style.STROKE);
        tr.setStrokeWidth(8 * d);
        tr.setColor(0x33FFFFFF);
        cv.drawCircle(cx, cy, ringR - 4 * d, tr);
        tr.setStrokeCap(Paint.Cap.ROUND);
        tr.setColor(score >= 80 ? 0xFF34D399 : score >= 55 ? 0xFFFBBF24 : score >= 30 ? 0xFFFB923C : 0xFFF87171);
        RectF ar = new RectF(cx - ringR + 4 * d, cy - ringR + 4 * d, cx + ringR - 4 * d, cy + ringR - 4 * d);
        cv.drawArc(ar, -90, 360f * Math.max(0.02f, score / 100f), false, tr);
        Paint num = new Paint(Paint.ANTI_ALIAS_FLAG);
        num.setColor(0xFFFFFFFF);
        num.setTextAlign(Paint.Align.CENTER);
        num.setTypeface(Typeface.create("sans-serif-black", Typeface.NORMAL));
        num.setTextSize(ringR * 0.62f);
        cv.drawText(String.valueOf(score), cx, cy + ringR * 0.2f, num);
        num.setTypeface(Typeface.DEFAULT);
        num.setTextSize(ringR * 0.22f);
        num.setColor(0xB3FFFFFF);
        cv.drawText("/ 100", cx, cy + ringR * 0.52f, num);

        // right side
        float x = cx + ringR + 14 * d, tw = W - x - pad;
        float y = pad;
        TextPaint small = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        small.setColor(0xFFFDE68A);
        small.setTextSize(11.5f * d);
        small.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        y = line(cv, "MUHASABAH  ·  " + HadithCard.label("TODAY", "આજે", "آج", "आज"), small, x, y, tw);

        int done = 0, total = 0, nm = -1, nmT = 5;
        for (Task t : s.tasksOn(today)) {
            total++;
            double v = Score.liveValue(s, t, today);
            if (t.frac(v) >= 0.999) done++;
            if ("namaz".equals(t.id)) {
                nm = (int) Math.max(0, Math.round(v));
                nmT = t.target;
            }
        }
        TextPaint big = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        big.setColor(0xFFFFFFFF);
        big.setTextSize(14.5f * d);
        big.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        String st = (nm >= 0 ? "🕌 " + nm + "/" + nmT + "   " : "") + "✅ " + done + "/" + total + "   🔥 " + Score.streak(s);
        y = line(cv, st, big, x, y + 4 * d, tw);

        int[] nx = Prayer.next(s);
        TextPaint mid = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        mid.setColor(0xFF93C5FD);
        mid.setTextSize(12.5f * d);
        y = line(cv, "🕰 " + HadithCard.label("Next: ", "આગળ: ", "اگلی: ", "अगली: ") + Prayer.name(nx[0]) + " " + Ui.clock(nx[1]) + " (≈)", mid, x, y + 3 * d, tw);

        // hadith of the day
        JSONObject h = Daily.today(c, Daily.BOOKS);
        if (h != null) {
            String tx = Lang.one(h, new String[]{"en", "gu", "ur", "hi"});
            TextPaint hp = new TextPaint(Paint.ANTI_ALIAS_FLAG);
            hp.setColor(0xE6FFFFFF);
            hp.setTextSize(12 * d);
            CharSequence cs = Fonts.mixed(tx);
            float left = H - pad - (y + 6 * d);
            int maxLines = Math.max(1, (int) (left / (hp.getFontSpacing() * 1.05f)));
            StaticLayout sl = StaticLayout.Builder.obtain(cs, 0, cs.length(), hp, (int) tw).setMaxLines(maxLines)
                    .setEllipsize(TextUtils.TruncateAt.END).setAlignment(Layout.Alignment.ALIGN_NORMAL).build();
            cv.save();
            cv.translate(x, y + 6 * d);
            sl.draw(cv);
            cv.restore();
        }
        return bm;
    }

    private static float line(Canvas cv, String t, TextPaint p, float x, float y, float w) {
        CharSequence cs = TextUtils.ellipsize(Fonts.mixed(t), p, w, TextUtils.TruncateAt.END);
        StaticLayout sl = StaticLayout.Builder.obtain(cs, 0, cs.length(), p, (int) w).setMaxLines(1).build();
        cv.save();
        cv.translate(x, y);
        sl.draw(cv);
        cv.restore();
        return y + sl.getHeight();
    }
}
