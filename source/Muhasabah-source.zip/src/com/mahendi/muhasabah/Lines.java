package com.mahendi.muhasabah;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * Builds a fresh nudge line every time: opener + body + closer, each drawn from a "shuffle bag"
 * (no repeat until the whole pool is used), filled with live facts (time, hours left, score, next task).
 */
public final class Lines {
    public static final int SLEEP = 0, WAKE = 1, SCROLL = 2, BAD_DAY = 3;
    private static final Random RND = new Random();

    // ---------------- strict Gujarati (Gujlish, as the user writes it) ----------------
    private static final String[][] GU_SLEEP = {
            { // openers
                    "Bhai, {t} thai gaya!", "Oye, haju jagto che?", "Bas bhai, bahu thayu.", "{t} — aa koi jaagvano time che?",
                    "Bhai, ek vaat sambhal.", "Suvano time {late} pehla j vaiti gayo.", "Ae {name}!", "Phone ne pan aaram joie che bhai.",
                    "Raat ni khamoshi kahe che — sui ja.", "Chal bhai, have bas.", "Bhai, saachu bolje —", "Dimag thaki gayu che bhai.",
                    "Aankh laal thai gai hase bhai.", "Haji screen saame? {t} vagya che.", "Bhai, aa chhelli yaad-dahani che —", "Jo bhai,"},
            { // bodies
                    "Kaale {wake} e uthvanu che — fakt {left} uungh bachi che.",
                    "Je raat bagaade, eni savaar pan bagde.",
                    "Fajr chuki gai to aakho divas bhaare jase.",
                    "Aa screen kai nai aape — uungh badhu aapse.",
                    "Allah e raat ne libaas banaavi che (Surah Naba 78:10) — aaram maate, scroll maate nai.",
                    "Suvaa pehla aajno hisaab kari le — Muhasabah no matlab j aa che.",
                    "Kaale nu '{task}' tari raah jove che — ene fresh dimag joie.",
                    "Aaje score {score} che. Kaale vadhaarvo hoy to atyaare suvu padse.",
                    "Reels khatam nai thay bhai, raat khatam thai jase.",
                    "Mobile ni light uungh ne bhagaave che — muki de.",
                    "Moda sudhi jaagvu e bahaduri nathi, aadat che. Aaje tod.",
                    "Je savaare vehlo uthe e j jeete che. Tu kai team ma che?",
                    "Business, padhai, ghar — badhaane kaale fresh {name} joie.",
                    "Tasbih-e-Fatema (s.a.) padh ane aankh band kar — 34, 33, 33.",
                    "Suvaa pehla wuzu kari le — sawaab pan, sukoon pan.",
                    "Aayatul Kursi padhi ne sui ja — hifaazat pan, sukoon pan.",
                    "Aaje je thayu e thayu. Kaale nava jor thi.",
                    "Puri uungh = kaale double focus. Hisaab saaf che.",
                    "Andhara ma screen = aankh ane dimag banne nu nuksaan.",
                    "Je kaam savaare 30 minute ma thase, e atyaare 2 kalak ma pan nai thay.",
                    "'Haji ek video... haji ek...' — aa chakkar ahi j tod.",
                    "Tari niyat saari che, pan shareer ne uungh joie.",
                    "Raat na chhella kalak qeemti che — kaa ibaadat, kaa uungh. Scrolling nai.",
                    "Kaale tu potano best version banvano che — eni sharuaat atyaare thi.",
                    "Akl kahe che: thakelu dimag khota faisla le che.",
                    "Je samay jato rahyo e pacho nai aave — kam se kam uungh to bachaavi le.",
                    "Duniya ni koi notification tari Fajr karta vadhu important nathi.",
                    "Uungh pan ibaadat bani shake — jo niyat Fajr maate uthvani hoy.",
                    "Atyaare {left} bachya che. Ek ek minute keemti che.",
                    "Kaale no divas aaje raate j bane che."},
            { // closers
                    "Phone muki de. Atyaare j.", "Good night bhai — Fi amanillah.", "Shab bakhair.", "Chal, light band.",
                    "Allah hafiz — kaale Fajr ma malie.", "Bas. Sui ja.", "Charger par muk ane door thai ja.",
                    "Kaale tu potane thank you kahish.", "Niyat kar ane aankh band kar.", "Allah barkat aape — have sui ja.",
                    "Bismillah kahi ne aankh band kar.", "Kaale jeetvanu che — sui ja."}};

    private static final String[] GU_SLEEP_TITLES = {
            "🌙 {t} — sui javano time", "😴 {t} thai gaya, bhai", "🛌 Bas bhai, have aaram", "🌌 Raat ghani thai gai — {t}",
            "⏰ Kaale {wake} — fakt {left} bachya", "✨ Uungh pan ibaadat bani shake", "📵 Phone ne pan good night", "🌙 Fajr yaad che ne?"};

    private static final String[][] GU_WAKE = {
            {"Uth ja bhai!", "Oye {name}, {wlate} moda!", "Bhai, suraj tara karta vehlo uthi gayo.", "Bas bhai, bahu suyo.",
                    "Chal bhai, uth.", "Bhai, aankh kholi ne jo —", "Good morning — moda pan, saav moda nai."},
            {"Divas sharu thai gayo che — pachal rahi gayo to pakadvu padse.",
                    "Je divas moda sharu thay, ema barkat ochi lage. Have speed vadhaar.",
                    "Pehlu kaam '{task}' — atyaare j sharu kar.",
                    "Kaal no score {yscore} hato. Aaje ene harawvano che.",
                    "Savaar ni barkat to gai — pan baaki no divas haju taro che.",
                    "Pani pi, moh dho, ane 10 minute ma kaam par.",
                    "Aalas shaitan no dost che — ene ghar ma na rakh.",
                    "Je moda uthe ene be gana jor thi doDvu pade.",
                    "Akl kahe che: aaje sudhaaro, kaale nai."},
            {"Chal, Bismillah!", "Uth ane jeet.", "Have bahana nai.", "Aaje kaal karta saru.", "Lagi ja bhai."}};

    private static final String[][] GU_SCROLL = {
            {"Bas kar bhai!", "Oye {name}!", "Bhai, {used} thai gaya.", "Bhai, ek vaat —", "Haji pan?", "Ruk ja bhai.", "Bhai, jaago!"},
            {"Phone muki de — kaam baaki che.",
                    "Reels thi kai nai male bhai. Kaam thi j male.",
                    "Ek ek minute no hisaab aapvano che.",
                    "Aa time pacho nai aave.",
                    "Feed kadi khatam nai thay — tari limit thai gai.",
                    "Je {used} ahi gaya, ema '{task}' thai jaat.",
                    "Algorithm tane jeetva maate banyu che. Tu ene haraav.",
                    "Bijana video jova karta potani life banaav.",
                    "Aankh no pan hisaab che bhai — shu joyu, kem joyu.",
                    "Scroll karvathi koi aagal nathi aavyu."},
            {"Band kar. Atyaare j.", "Uth ane kaam kar.", "Tu aana karta vadhu saro che.", "Chal, ek kaam puru kar.", "Allah jove che bhai."}};

    private static final String[][] GU_BAD_DAY = {
            {"Bhai!", "Oye {name},", "Bhai, score {score} j che.", "Bhai, aaje to kai j nathi thayu!", "Sambhal bhai —", "Jo bhai,"},
            {"Have to kari le bhai — Allah ne javab aapvano che.",
                    "Have to padhi le bhai. Samay pacho nai aave.",
                    "Kaal karta aaje vadhu saru karvanu che — yaad che ne?",
                    "Haji pan time che. Ek kaam to puru kar!",
                    "'{task}' haju baaki che — 20 minute aap ene.",
                    "Kaal no score {yscore} hato. Aaje haju {gap} pachal che.",
                    "Divas puro thay e pehla potano hisaab kar — Muhasabah.",
                    "Nano step pan step j che. Uth ane ek kaam kar.",
                    "Je aaje nai kare, e kaale pan nai kare. Aadat atyaare bane che."},
            {"Chal, lagi ja.", "Bismillah kar ane sharu kar.", "Haji divas taro che.", "Tu kari shake che.", "Bahana bandh."}};

    // ---------------- calm English ----------------
    private static final String[][] EN_SLEEP = {
            {"It's {t}.", "Hey {name},", "Time check: {t}.", "One last reminder —", "Quick truth:"},
            {"You wake at {wake} — only {left} of sleep left.", "Tomorrow's Fajr needs you rested.",
                    "The feed won't end. The night will.", "A tired mind makes poor choices tomorrow.",
                    "'{task}' tomorrow deserves a fresh mind.", "The night was made for rest (Quran 78:10).",
                    "Do a quick muhasabah of today, then sleep.", "Tasbih of Fatima (s.a.), then lights out."},
            {"Put the phone down.", "Good night.", "Sleep now.", "Fi amanillah.", "Win tomorrow — sleep tonight."}};
    private static final String[][] EN_WAKE = {
            {"Rise and shine,", "Morning, {name} —", "You're {wlate} late —"},
            {"the day has started. First up: '{task}'.", "yesterday scored {yscore}. Beat it today.", "water, wudu, and straight to work."},
            {"Bismillah.", "Go.", "Make today count."}};
    private static final String[][] EN_SCROLL = {
            {"{used} today.", "Hey {name},", "Pause."},
            {"Your future self is watching.", "You set this limit for a reason.", "Nothing in that feed builds your goals.",
                    "Every minute here is taken from '{task}'.", "One more reel never ends."},
            {"Close the app.", "Scroll less. Build more.", "Stop at this one."}};
    private static final String[][] EN_BAD_DAY = {
            {"Score {score} so far.", "Hey {name},", "The day is slipping —"},
            {"pick one task and finish it in the next hour.", "'{task}' is still waiting.", "you're {gap} behind yesterday."},
            {"You can still win today.", "Start now.", "Small steps count."}};

    private Lines() {
    }

    /** Fresh body line for a nudge. */
    public static String make(Store s, int kind, boolean strict) {
        String[][] pool = strict ? (kind == SLEEP ? GU_SLEEP : kind == WAKE ? GU_WAKE : kind == SCROLL ? GU_SCROLL : GU_BAD_DAY)
                : (kind == SLEEP ? EN_SLEEP : kind == WAKE ? EN_WAKE : kind == SCROLL ? EN_SCROLL : EN_BAD_DAY);
        String key = (strict ? "gu" : "en") + kind;
        StringBuilder b = new StringBuilder();
        for (int part = 0; part < 3; part++) {
            // sometimes skip the opener or closer so the shape varies too
            if (part != 1 && RND.nextInt(5) == 0) continue;
            String piece = pool[part][next(s, key + "_" + part, pool[part].length)];
            if (!strict) piece = Lang.tr(piece, false);
            if (b.length() > 0) b.append(' ');
            b.append(piece);
        }
        return fill(s, b.toString());
    }

    /** Fresh title for the sleep nudge. */
    public static String sleepTitle(Store s, boolean strict) {
        if (!strict) return fill(s, Lang.tr("🌙 It's {t} — time to sleep", false));
        return fill(s, GU_SLEEP_TITLES[next(s, "gu_sleep_title", GU_SLEEP_TITLES.length)]);
    }

    /** Shuffle bag: every item comes once before any repeats; never the same twice in a row. */
    private static synchronized int next(Store s, String key, int n) {
        String k = "bag_" + key;
        List<Integer> left = new ArrayList<Integer>();
        try {
            JSONArray a = new JSONArray(s.s(k, "[]"));
            for (int i = 0; i < a.length(); i++) if (a.getInt(i) < n) left.add(a.getInt(i));
        } catch (Exception ignored) {
        }
        int last = s.i(k + "_last", -1);
        if (left.isEmpty()) {
            for (int i = 0; i < n; i++) left.add(i);
            Collections.shuffle(left, RND);
            if (n > 1 && left.get(0) == last) Collections.swap(left, 0, n - 1);
        }
        int pick = left.remove(0);
        s.put(k, new JSONArray(left).toString());
        s.put(k + "_last", pick);
        return pick;
    }

    private static String fill(Store s, String t) {
        if (t.indexOf('{') < 0) return t;
        int mod = Store.minuteOfDay();
        int wake = s.i(Store.K_WAKE, 315), sleep = s.i(Store.K_SLEEP, 1380);
        int left = ((wake - mod) % 1440 + 1440) % 1440;
        int late = ((mod - sleep) % 1440 + 1440) % 1440;
        if (late > 720) late = 0;
        int lateWake = Math.max(0, mod - wake);
        String today = Store.today();
        int score = Score.compute(s, today).score, y = Score.dayScore(s, Store.date(-1));
        String name = s.s(Store.K_NAME, "");
        if (name.trim().isEmpty()) name = "bhai";
        else name = name.trim().split("\\s+")[0];
        return t.replace("{t}", Ui.clock(mod))
                .replace("{wake}", Ui.clock(wake))
                .replace("{left}", Ui.hm(left))
                .replace("{late}", Ui.hm(late))
                .replace("{wlate}", Ui.hm(lateWake))
                .replace("{score}", String.valueOf(score))
                .replace("{yscore}", String.valueOf(y))
                .replace("{gap}", String.valueOf(Math.max(0, y - score)))
                .replace("{used}", Ui.hm(s.timepassMinutes(today)))
                .replace("{name}", name)
                .replace("{task}", nextTask(s));
    }

    /** The first unfinished task (today, or tomorrow's first task late at night). */
    private static String nextTask(Store s) {
        boolean night = Store.minuteOfDay() >= s.i(Store.K_SLEEP, 1380) - 60;
        String date = night ? Store.date(1) : Store.today();
        try {
            for (Task t : s.tasksOn(date)) {
                if (!night && t.frac(Score.liveValue(s, t, date)) >= 0.999) continue;
                return t.name;
            }
        } catch (Exception ignored) {
        }
        return night ? "kaal nu pehlu kaam" : "taru kaam";
    }
}
