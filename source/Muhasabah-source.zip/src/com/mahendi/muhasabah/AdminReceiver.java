package com.mahendi.muhasabah;

import android.app.admin.DeviceAdminReceiver;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;

/**
 * Uninstall protection: while Muhasabah is an active device admin, Android won't uninstall it.
 * It asks for no powers at all (no lock-screen, no wipe) — the admin role is used only for that.
 */
public class AdminReceiver extends DeviceAdminReceiver {
    public static ComponentName name(Context c) {
        return new ComponentName(c, AdminReceiver.class);
    }

    public static boolean active(Context c) {
        try {
            DevicePolicyManager dpm = (DevicePolicyManager) c.getSystemService(Context.DEVICE_POLICY_SERVICE);
            return dpm.isAdminActive(name(c));
        } catch (Exception e) {
            return false;
        }
    }

    public static Intent enableIntent(Context c) {
        return new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, name(c))
                .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                        "Uninstall protection: while this is on, Muhasabah can't be uninstalled on impulse. It asks for no other powers.");
    }

    @Override
    public CharSequence onDisableRequested(Context c, Intent intent) {
        Store s = Store.get(c);
        Lock.log(s, "admin_off_try", "");
        return Lang.pick("You promised yourself. Turning this off removes uninstall protection — is this really what you want right now?",
                "તમે તમારી જાતને વચન આપ્યું હતું. આ બંધ કરવાથી અનઇન્સ્ટૉલ સુરક્ષા જશે — શું ખરેખર અત્યારે આ જ જોઈએ છે?");
    }

    @Override
    public void onDisabled(Context c, Intent intent) {
        Lock.log(Store.get(c), "admin_off", "");
    }
}
