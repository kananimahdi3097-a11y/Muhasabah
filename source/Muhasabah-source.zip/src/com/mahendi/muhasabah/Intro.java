package com.mahendi.muhasabah;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Branded opening: the emblem glows and spins into place, then name, Arabic and tagline rise in. */
public final class Intro extends FrameLayout {
    public static final String K_ON = "intro_on";
    private static boolean shownThisProcess;

    public static void maybeShow(FrameLayout root) {
        Context c = root.getContext();
        if (shownThisProcess || !Store.get(c).b(K_ON, true)) return;
        shownThisProcess = true;
        root.addView(new Intro(c), new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
    }

    private boolean leaving;

    private Intro(Context c) {
        super(c);
        setBackgroundColor(Ui.BG);
        setClickable(true);
        addView(new Views.GeoPattern(c), new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));

        LinearLayout col = Ui.col(c);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        Emblem em = new Emblem(c);
        col.addView(em, new LinearLayout.LayoutParams(Ui.dp(190), Ui.dp(190)));

        TextView name = Ui.title(c, "Muhasabah", 34);
        name.setGravity(Gravity.CENTER);
        name.setTextColor(Ui.TEXT);
        name.setShadowLayer(Ui.dp(14), 0, 0, Ui.alpha(Ui.GOLD, 0.45f));
        col.addView(name, Ui.lpm(Ui.WRAP, Ui.WRAP, 0, 6, 0, 0));

        TextView ar = Ui.text(c, "مُحَاسَبَة", 30, Ui.GOLD, false);
        ar.setGravity(Gravity.CENTER);
        Ui.arabic(ar);
        col.addView(ar, Ui.lpm(Ui.WRAP, Ui.WRAP, 0, 2, 0, 0));

        TextView tag = Ui.text(c, Lang.pick("Today better than yesterday", "ગઈકાલ કરતાં આજ બહેતર"), 14, Ui.SUB, true);
        tag.setGravity(Gravity.CENTER);
        tag.setLetterSpacing(0.08f);
        col.addView(tag, Ui.lpm(Ui.WRAP, Ui.WRAP, 0, 10, 0, 0));
        addView(col, new FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.CENTER));

        em.setScaleX(0.55f);
        em.setScaleY(0.55f);
        em.setAlpha(0f);
        em.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(650).setInterpolator(new OvershootInterpolator(1.6f)).start();
        rise(name, 380);
        rise(ar, 560);
        rise(tag, 740);
        name.setLetterSpacing(0.45f);
        ValueAnimator ls = ValueAnimator.ofFloat(0.45f, -0.01f);
        ls.setStartDelay(380);
        ls.setDuration(700);
        ls.setInterpolator(new DecelerateInterpolator());
        final TextView nm = name;
        ls.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator a) {
                nm.setLetterSpacing((Float) a.getAnimatedValue());
            }
        });
        ls.start();

        setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                leave();
            }
        });
        postDelayed(new Runnable() {
            @Override
            public void run() {
                leave();
            }
        }, 1900);
    }

    private static void rise(View v, long delay) {
        v.setAlpha(0f);
        v.setTranslationY(Ui.dp(18));
        v.animate().alpha(1f).translationY(0).setStartDelay(delay).setDuration(480).setInterpolator(new DecelerateInterpolator()).start();
    }

    private void leave() {
        if (leaving) return;
        leaving = true;
        animate().alpha(0f).scaleX(1.06f).scaleY(1.06f).setDuration(380).withEndAction(new Runnable() {
            @Override
            public void run() {
                ViewGroup p = (ViewGroup) getParent();
                if (p != null) p.removeView(Intro.this);
            }
        }).start();
    }

    /** Glowing, slowly turning star rings around the launcher emblem. */
    private static final class Emblem extends View {
        private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG), ring = new Paint(Paint.ANTI_ALIAS_FLAG), dot = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Drawable fg;
        private final Path sq = new Path();
        private float t;
        private ValueAnimator spin;

        Emblem(Context c) {
            super(c);
            fg = c.getDrawable(R.drawable.ic_fg);
            ring.setStyle(Paint.Style.STROKE);
            ring.setStrokeWidth(Ui.dp(1.2f));
            dot.setColor(Ui.GOLD_L);
        }

        @Override
        protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            spin = ValueAnimator.ofFloat(0, 1);
            spin.setDuration(6000);
            spin.setRepeatCount(ValueAnimator.INFINITE);
            spin.setInterpolator(null);
            spin.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator a) {
                    t = (Float) a.getAnimatedValue();
                    invalidate();
                }
            });
            spin.start();
        }

        @Override
        protected void onDetachedFromWindow() {
            if (spin != null) spin.cancel();
            super.onDetachedFromWindow();
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight(), cx = w / 2f, cy = h / 2f, r = Math.min(w, h) / 2f;
            float pulse = 0.75f + 0.25f * (float) Math.sin(t * Math.PI * 4);
            glow.setShader(new RadialGradient(cx, cy, r, new int[]{Ui.alpha(Ui.GOLD, 0.38f * pulse), Ui.alpha(Ui.GOLD, 0.10f * pulse), 0},
                    new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, r, glow);
            // two counter-rotating 8-point star rings
            for (int k = 0; k < 2; k++) {
                float rr = r * (k == 0 ? 0.93f : 0.80f);
                ring.setColor(Ui.alpha(Ui.GOLD, k == 0 ? 0.35f : 0.22f));
                c.save();
                c.rotate((k == 0 ? 1 : -1) * t * 360f / (k == 0 ? 2 : 3), cx, cy);
                for (int j = 0; j < 2; j++) {
                    c.save();
                    c.rotate(j * 45f, cx, cy);
                    float hh = rr / 1.4142f;
                    sq.reset();
                    sq.addRect(cx - hh, cy - hh, cx + hh, cy + hh, Path.Direction.CW);
                    c.drawPath(sq, ring);
                    c.restore();
                }
                c.restore();
            }
            // orbiting sparks
            for (int k = 0; k < 6; k++) {
                double a = (t + k / 6f) * Math.PI * 2;
                float rr = r * 0.93f;
                dot.setAlpha((int) (120 + 120 * Math.sin(t * Math.PI * 6 + k)));
                c.drawCircle(cx + (float) Math.cos(a) * rr, cy + (float) Math.sin(a) * rr, Ui.dp(k % 2 == 0 ? 2.2f : 1.4f), dot);
            }
            if (fg != null) {
                int s = (int) (r * 1.25f);
                fg.setBounds((int) cx - s, (int) cy - s, (int) cx + s, (int) cy + s);
                fg.draw(c);
            }
        }
    }
}
