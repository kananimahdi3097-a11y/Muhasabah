package com.mahendi.muhasabah;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

import java.util.Random;

/** Custom drawn views: score ring, bar chart, confetti. */
public final class Views {

    /** Animated circular score ring with gradient. */
    public static class ScoreRing extends View {
        private float value, shown;
        private String sub = "";
        private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG), arc = new Paint(Paint.ANTI_ALIAS_FLAG),
                big = new Paint(Paint.ANTI_ALIAS_FLAG), small = new Paint(Paint.ANTI_ALIAS_FLAG),
                glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();

        public ScoreRing(Context c) {
            super(c);
            track.setStyle(Paint.Style.STROKE);
            track.setColor(Ui.alpha(Color.WHITE, 0.10f));
            arc.setStyle(Paint.Style.STROKE);
            arc.setStrokeCap(Paint.Cap.ROUND);
            glow.setStyle(Paint.Style.STROKE);
            glow.setStrokeCap(Paint.Cap.ROUND);
            big.setColor(Ui.TEXT);
            big.setTextAlign(Paint.Align.CENTER);
            big.setTypeface(Typeface.create("sans-serif-black", Typeface.NORMAL));
            small.setColor(Ui.SUB);
            small.setTextAlign(Paint.Align.CENTER);
            small.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        }

        public void set(int score, String subText, boolean animate) {
            value = score;
            sub = subText;
            if (!animate) {
                shown = value;
                invalidate();
                return;
            }
            ValueAnimator a = ValueAnimator.ofFloat(shown, value);
            a.setDuration(900);
            a.setInterpolator(new DecelerateInterpolator());
            a.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator an) {
                    shown = (Float) an.getAnimatedValue();
                    invalidate();
                }
            });
            a.start();
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight(), s = Math.min(w, h);
            float stroke = s * 0.09f;
            track.setStrokeWidth(stroke);
            arc.setStrokeWidth(stroke);
            glow.setStrokeWidth(stroke * 1.9f);
            r.set((w - s) / 2 + stroke, (h - s) / 2 + stroke, (w + s) / 2 - stroke, (h + s) / 2 - stroke);
            c.drawArc(r, 0, 360, false, track);
            float sweep = 360f * Math.max(0, Math.min(100, shown)) / 100f;
            SweepGradient g = new SweepGradient(w / 2, h / 2,
                    new int[]{Ui.EMERALD, Ui.BLUE, Ui.PURPLE, Ui.GOLD, Ui.EMERALD}, null);
            Matrix m = new Matrix();
            m.setRotate(-90, w / 2, h / 2);
            g.setLocalMatrix(m);
            arc.setShader(g);
            glow.setShader(g);
            glow.setAlpha(45);
            if (sweep > 0.5f) {
                c.drawArc(r, -90, sweep, false, glow);
                c.drawArc(r, -90, sweep, false, arc);
            }
            big.setTextSize(s * 0.30f);
            c.drawText(String.valueOf(Math.round(shown)), w / 2, h / 2 + s * 0.07f, big);
            small.setTextSize(s * 0.095f);
            c.drawText(sub, w / 2, h / 2 + s * 0.22f, small);
        }
    }

    /** Simple rounded bar chart; last bar highlighted. */
    public static class Bars extends View {
        private int[] values = new int[0];
        private String[] labels = new String[0];
        private final Paint bar = new Paint(Paint.ANTI_ALIAS_FLAG), lbl = new Paint(Paint.ANTI_ALIAS_FLAG),
                num = new Paint(Paint.ANTI_ALIAS_FLAG), line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rr = new RectF();

        public Bars(Context c) {
            super(c);
            lbl.setColor(Ui.MUTED);
            lbl.setTextAlign(Paint.Align.CENTER);
            num.setColor(Ui.SUB);
            num.setTextAlign(Paint.Align.CENTER);
            num.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            line.setColor(Ui.alpha(Color.WHITE, 0.06f));
            line.setStrokeWidth(Ui.dp(1));
        }

        public void set(int[] v, String[] l) {
            values = v;
            labels = l;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            int n = values.length;
            if (n == 0) return;
            float w = getWidth(), h = getHeight();
            float bottom = h - Ui.dp(20), top = Ui.dp(18);
            for (int k = 0; k <= 4; k++) {
                float y = bottom - (bottom - top) * k / 4f;
                c.drawLine(0, y, w, y, line);
            }
            float slot = w / n, bw = slot * 0.56f;
            lbl.setTextSize(Ui.dp(10));
            num.setTextSize(Ui.dp(10));
            for (int k = 0; k < n; k++) {
                float x = slot * k + (slot - bw) / 2;
                float hh = (bottom - top) * Math.max(0, Math.min(100, values[k])) / 100f;
                rr.set(x, bottom - Math.max(hh, Ui.dp(3)), x + bw, bottom);
                boolean last = k == n - 1;
                int c1 = last ? Ui.EMERALD : Ui.GOLD, c2 = last ? Ui.TEAL : Ui.GOLD_D;
                bar.setShader(new LinearGradient(0, rr.top, 0, rr.bottom, c1, Ui.alpha(c2, 0.55f), Shader.TileMode.CLAMP));
                c.drawRoundRect(rr, bw / 2.2f, bw / 2.2f, bar);
                if (values[k] > 0) c.drawText(String.valueOf(values[k]), x + bw / 2, rr.top - Ui.dp(4), num);
                c.drawText(labels[k], x + bw / 2, h - Ui.dp(4), lbl);
            }
        }
    }

    /** Full-screen confetti burst overlay (touch-transparent). */
    public static class Confetti extends View {
        private static final int[] COLORS = {Ui.GOLD, Ui.EMERALD, Ui.PURPLE, Ui.PINK, Ui.BLUE, Ui.ORANGE, Color.WHITE};
        private float[] x, y, vx, vy, rot, vr, size;
        private int[] col;
        private int count;
        private long start;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Random rnd = new Random();

        public Confetti(Context c) {
            super(c);
            setClickable(false);
            setFocusable(false);
        }

        public void burst(int n) {
            count = n;
            x = new float[n];
            y = new float[n];
            vx = new float[n];
            vy = new float[n];
            rot = new float[n];
            vr = new float[n];
            size = new float[n];
            col = new int[n];
            float w = getWidth(), h = getHeight();
            for (int k = 0; k < n; k++) {
                boolean left = k % 2 == 0;
                x[k] = left ? w * 0.1f : w * 0.9f;
                y[k] = h * 0.45f;
                double ang = Math.toRadians((left ? -60 : -120) + (rnd.nextFloat() - 0.5f) * 50);
                float sp = (0.9f + rnd.nextFloat() * 1.4f) * Ui.dp(1) * 1.0f;
                vx[k] = (float) Math.cos(ang) * sp * 14;
                vy[k] = (float) Math.sin(ang) * sp * 22;
                rot[k] = rnd.nextFloat() * 360;
                vr[k] = (rnd.nextFloat() - 0.5f) * 24;
                size[k] = Ui.dp(5 + rnd.nextFloat() * 6);
                col[k] = COLORS[rnd.nextInt(COLORS.length)];
            }
            start = System.currentTimeMillis();
            setVisibility(VISIBLE);
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            if (count == 0) return;
            long t = System.currentTimeMillis() - start;
            if (t > 2600) {
                count = 0;
                return;
            }
            float g = Ui.dp(1) * 0.9f;
            float fade = t > 1800 ? 1f - (t - 1800) / 800f : 1f;
            for (int k = 0; k < count; k++) {
                vy[k] += g;
                vx[k] *= 0.985f;
                x[k] += vx[k];
                y[k] += vy[k];
                rot[k] += vr[k];
                p.setColor(col[k]);
                p.setAlpha((int) (255 * Math.max(0, fade)));
                c.save();
                c.rotate(rot[k], x[k], y[k]);
                c.drawRect(x[k] - size[k] / 2, y[k] - size[k] / 4, x[k] + size[k] / 2, y[k] + size[k] / 4, p);
                c.restore();
            }
            postInvalidateOnAnimation();
        }
    }

    /** Faint Islamic 8-point-star lattice with a soft glow — used behind the Home header. */
    public static class GeoPattern extends View {
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG), glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final android.graphics.Path star = new android.graphics.Path();
        private float phase;
        private ValueAnimator drift;

        public GeoPattern(Context c) {
            super(c);
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeWidth(Ui.dp(1));
        }

        @Override
        protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            drift = ValueAnimator.ofFloat(0, 1);
            drift.setDuration(16000);
            drift.setRepeatCount(ValueAnimator.INFINITE);
            drift.setRepeatMode(ValueAnimator.REVERSE);
            drift.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator a) {
                    phase = (Float) a.getAnimatedValue();
                    invalidate();
                }
            });
            drift.start();
        }

        @Override
        protected void onDetachedFromWindow() {
            if (drift != null) drift.cancel();
            super.onDetachedFromWindow();
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            // glow blobs
            glow.setShader(new android.graphics.RadialGradient(w * (0.15f + 0.1f * phase), h * 0.25f, w * 0.6f,
                    Ui.alpha(Ui.EMERALD, 0.16f), 0x00000000, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, glow);
            glow.setShader(new android.graphics.RadialGradient(w * (0.9f - 0.1f * phase), h * 0.1f, w * 0.5f,
                    Ui.alpha(Ui.GOLD, 0.12f), 0x00000000, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, glow);
            // star lattice, fading downwards
            float cell = Ui.dp(46), r = cell * 0.36f;
            float off = phase * cell * 0.5f;
            for (float y = -cell; y < h + cell; y += cell) {
                float fade = Math.max(0f, 1f - y / (h * 0.95f));
                line.setColor(Ui.alpha(Ui.GOLD, 0.07f * fade + 0.01f));
                for (float x = -cell + ((int) (y / cell) % 2 == 0 ? 0 : cell / 2); x < w + cell; x += cell) {
                    drawStar(c, x + off, y, r);
                }
            }
        }

        private void drawStar(Canvas c, float cx, float cy, float r) {
            star.reset();
            for (int k = 0; k < 16; k++) {
                double a = Math.PI / 8 * k;
                float rr = k % 2 == 0 ? r : r * 0.62f;
                float x = cx + (float) (rr * Math.sin(a)), y = cy - (float) (rr * Math.cos(a));
                if (k == 0) star.moveTo(x, y);
                else star.lineTo(x, y);
            }
            star.close();
            c.drawPath(star, line);
        }
    }
}
