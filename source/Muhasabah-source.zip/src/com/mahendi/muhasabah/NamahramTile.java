package com.mahendi.muhasabah;

import android.app.PendingIntent;
import android.content.Intent;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;
import android.widget.Toast;

/** Quick Settings tile: one tap logs a na-mahram glance and shows a short reminder. */
public class NamahramTile extends TileService {
    @Override
    public void onStartListening() {
        Tile t = getQsTile();
        if (t == null) return;
        Store s = Store.get(this);
        t.setLabel(Lang.pick("Lower gaze", "નજર નીચી"));
        t.setSubtitle(Lang.pick("Today: " + s.namahram(Store.today()), "આજ: " + s.namahram(Store.today())));
        t.setState(Tile.STATE_INACTIVE);
        t.updateTile();
    }

    @Override
    public void onClick() {
        Store s = Store.get(this);
        int n = s.incNamahram(Store.today());
        String msg = Lang.pick("Logged (" + n + " today). Astaghfirullah — lower your gaze.",
                "નોંધાયું (આજ " + n + "). અસ્તગફિરુલ્લાહ — નજર નીચી રાખો.");
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        JSONObjectReminder();
        onStartListening();
    }

    private void JSONObjectReminder() {
        Store s = Store.get(this);
        Notify.channels(this);
        org.json.JSONObject w = s.pick("gaze", "purity", "akl");
        Notify.post(this, 460, Notify.CH_NUDGE,
                Lang.pick("👁️ Guard your gaze", "👁️ નજર સાચવો"),
                Lang.pick("Astaghfirullah. Lower your gaze.", "અસ્તગફિરુલ્લાહ. નજર નીચી રાખો."), w);
    }
}
