package com.mahendi.muhasabah;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

/**
 * A small on-device image classifier (MobileNetV2, 224×224 RGB in 0..1) that says how likely a picture is
 * Drawing / Hentai / Neutral / Porn / Sexy. Weights: the nsfwjs MobileNetV2 model (MIT licence,
 * trained by GantMan / Infinite Red), stored as uint8 with batch-norm folded in at load time.
 * Pure Java — no native libraries; everything runs on the phone and nothing leaves it.
 */
public final class NsfwNet {
    public static final int SIZE = 224;
    public static final int DRAWING = 0, HENTAI = 1, NEUTRAL = 2, PORN = 3, SEXY = 4;

    private static final int CONV = 1, DW = 2, ADD = 3, GAP = 4, DENSE = 5;

    private static final class Op {
        int type, in, in2, out, kh, kw, st, pt, pl, pb, pr, cin, cout, act;
        float[] w, b;
    }

    private final Op[] ops;
    private final int nbuf;
    private final int[] lastUse;
    private final ExecutorService pool;
    private final int threads;

    public NsfwNet(InputStream raw) throws IOException {
        DataInputStream in = new DataInputStream(new BufferedInputStream(raw, 1 << 16));
        byte[] magic = new byte[4];
        in.readFully(magic);
        if (magic[0] != 'N' || magic[1] != 'S' || magic[2] != 'F' || magic[3] != '2') throw new IOException("bad model");
        int n = in.readInt();
        nbuf = in.readInt();
        ops = new Op[n];
        for (int k = 0; k < n; k++) {
            Op o = new Op();
            o.type = in.readByte();
            switch (o.type) {
                case CONV:
                case DW: {
                    o.in = in.readInt();
                    o.out = in.readInt();
                    o.kh = in.readInt();
                    o.kw = in.readInt();
                    o.st = in.readInt();
                    o.pt = in.readInt();
                    o.pl = in.readInt();
                    o.pb = in.readInt();
                    o.pr = in.readInt();
                    o.cin = in.readInt();
                    o.cout = in.readInt();
                    o.act = in.readInt();
                    float mn = in.readFloat(), sc = in.readFloat();
                    int len = o.type == CONV ? o.kh * o.kw * o.cin * o.cout : o.kh * o.kw * o.cout;
                    byte[] q = new byte[len];
                    in.readFully(q);
                    float[] f = readF(in, o.cout);
                    o.b = readF(in, o.cout);
                    // Keras layout [kh][kw][cin][cout] (or [kh][kw][C]); the last index is the output channel
                    o.w = new float[len];
                    for (int i = 0; i < len; i++) o.w[i] = (mn + sc * (q[i] & 0xff)) * f[i % o.cout];
                    break;
                }
                case ADD:
                    o.in = in.readInt();
                    o.in2 = in.readInt();
                    o.out = in.readInt();
                    break;
                case GAP:
                    o.in = in.readInt();
                    o.out = in.readInt();
                    break;
                case DENSE: {
                    o.in = in.readInt();
                    o.out = in.readInt();
                    o.cin = in.readInt();
                    o.cout = in.readInt();
                    o.act = in.readInt();
                    float mn = in.readFloat(), sc = in.readFloat();
                    byte[] q = new byte[o.cin * o.cout];
                    in.readFully(q);
                    o.w = new float[q.length]; // [in][out]
                    for (int i = 0; i < q.length; i++) o.w[i] = mn + sc * (q[i] & 0xff);
                    o.b = readF(in, o.cout);
                    break;
                }
                default:
                    throw new IOException("bad op " + o.type);
            }
            ops[k] = o;
        }
        in.close();
        lastUse = new int[nbuf];
        for (int k = 0; k < n; k++) {
            lastUse[ops[k].in] = k;
            if (ops[k].type == ADD) lastUse[ops[k].in2] = k;
        }
        threads = Math.max(1, Math.min(4, Runtime.getRuntime().availableProcessors() - 1));
        pool = Executors.newFixedThreadPool(threads, new ThreadFactory() {
            @Override
            public Thread newThread(Runnable r) {
                Thread t = new Thread(r, "nsfw-net");
                t.setDaemon(true);
                t.setPriority(Thread.MIN_PRIORITY + 1);
                return t;
            }
        });
    }

    private static float[] readF(DataInputStream in, int n) throws IOException {
        float[] a = new float[n];
        for (int i = 0; i < n; i++) a[i] = in.readFloat();
        return a;
    }

    public void close() {
        pool.shutdownNow();
    }

    /** rgb: SIZE×SIZE×3, row-major, values 0..1. Returns the 5 class probabilities. */
    public synchronized float[] classify(float[] rgb) throws Exception {
        float[][] buf = new float[nbuf][];
        int[] H = new int[nbuf], W = new int[nbuf], C = new int[nbuf];
        buf[0] = rgb;
        H[0] = SIZE;
        W[0] = SIZE;
        C[0] = 3;
        for (int k = 0; k < ops.length; k++) {
            final Op o = ops[k];
            switch (o.type) {
                case CONV:
                case DW: {
                    final int h = H[o.in], w = W[o.in];
                    final int ho = (h + o.pt + o.pb - o.kh) / o.st + 1, wo = (w + o.pl + o.pr - o.kw) / o.st + 1;
                    final float[] src = buf[o.in], dst = new float[ho * wo * o.cout];
                    parallel(ho, new Rows() {
                        @Override
                        public void run(int y0, int y1) {
                            if (o.type == CONV) conv(o, src, h, w, dst, wo, y0, y1);
                            else dw(o, src, h, w, dst, wo, y0, y1);
                        }
                    });
                    buf[o.out] = dst;
                    H[o.out] = ho;
                    W[o.out] = wo;
                    C[o.out] = o.cout;
                    break;
                }
                case ADD: {
                    float[] a = buf[o.in], b = buf[o.in2], d = new float[a.length];
                    for (int i = 0; i < a.length; i++) d[i] = a[i] + b[i];
                    buf[o.out] = d;
                    H[o.out] = H[o.in];
                    W[o.out] = W[o.in];
                    C[o.out] = C[o.in];
                    break;
                }
                case GAP: {
                    float[] a = buf[o.in];
                    int c = C[o.in], px = H[o.in] * W[o.in];
                    float[] d = new float[c];
                    for (int p = 0; p < px; p++) for (int j = 0; j < c; j++) d[j] += a[p * c + j];
                    for (int j = 0; j < c; j++) d[j] /= px;
                    buf[o.out] = d;
                    H[o.out] = 1;
                    W[o.out] = 1;
                    C[o.out] = c;
                    break;
                }
                default: { // DENSE
                    float[] a = buf[o.in], d = o.b.clone();
                    for (int i = 0; i < o.cin; i++) {
                        float v = a[i];
                        if (v == 0f) continue;
                        int base = i * o.cout;
                        for (int j = 0; j < o.cout; j++) d[j] += v * o.w[base + j];
                    }
                    if (o.act == 1) for (int j = 0; j < d.length; j++) d[j] = Math.max(0f, d[j]);
                    if (o.act == 2) {
                        float mx = Float.NEGATIVE_INFINITY, sum = 0;
                        for (float v : d) mx = Math.max(mx, v);
                        for (int j = 0; j < d.length; j++) sum += d[j] = (float) Math.exp(d[j] - mx);
                        for (int j = 0; j < d.length; j++) d[j] /= sum;
                    }
                    buf[o.out] = d;
                    H[o.out] = 1;
                    W[o.out] = 1;
                    C[o.out] = o.cout;
                }
            }
            // free what's no longer needed (keeps memory around 10 MB)
            if (lastUse[o.in] == k && o.in != 0) buf[o.in] = null;
            if (o.type == ADD && lastUse[o.in2] == k) buf[o.in2] = null;
        }
        return buf[ops[ops.length - 1].out];
    }

    private interface Rows {
        void run(int y0, int y1);
    }

    private void parallel(final int rows, final Rows r) throws Exception {
        int parts = Math.min(threads, rows);
        if (parts <= 1) {
            r.run(0, rows);
            return;
        }
        List<Callable<Void>> jobs = new ArrayList<Callable<Void>>();
        for (int p = 0; p < parts; p++) {
            final int y0 = rows * p / parts, y1 = rows * (p + 1) / parts;
            jobs.add(new Callable<Void>() {
                @Override
                public Void call() {
                    r.run(y0, y1);
                    return null;
                }
            });
        }
        for (java.util.concurrent.Future<Void> f : pool.invokeAll(jobs)) f.get();
    }

    /** Full convolution (NHWC, weights [kh][kw][cin][cout]), bias + optional ReLU6. */
    private static void conv(Op o, float[] src, int h, int w, float[] dst, int wo, int y0, int y1) {
        final int cin = o.cin, cout = o.cout, kh = o.kh, kw = o.kw, st = o.st;
        final float[] wt = o.w, b = o.b;
        float[] acc = new float[cout];
        for (int y = y0; y < y1; y++) {
            for (int x = 0; x < wo; x++) {
                System.arraycopy(b, 0, acc, 0, cout);
                for (int i = 0; i < kh; i++) {
                    int iy = y * st + i - o.pt;
                    if (iy < 0 || iy >= h) continue;
                    for (int j = 0; j < kw; j++) {
                        int ix = x * st + j - o.pl;
                        if (ix < 0 || ix >= w) continue;
                        int sp = (iy * w + ix) * cin, wp = (i * kw + j) * cin * cout;
                        for (int c = 0; c < cin; c++) {
                            float v = src[sp + c];
                            if (v == 0f) continue;
                            int row = wp + c * cout;
                            for (int d = 0; d < cout; d++) acc[d] += v * wt[row + d];
                        }
                    }
                }
                int op = (y * wo + x) * cout;
                if (o.act == 1) for (int d = 0; d < cout; d++) dst[op + d] = Math.min(6f, Math.max(0f, acc[d]));
                else System.arraycopy(acc, 0, dst, op, cout);
            }
        }
    }

    /** Depthwise convolution (weights [kh][kw][C]). */
    private static void dw(Op o, float[] src, int h, int w, float[] dst, int wo, int y0, int y1) {
        final int c = o.cout, kh = o.kh, kw = o.kw, st = o.st;
        final float[] wt = o.w, b = o.b;
        float[] acc = new float[c];
        for (int y = y0; y < y1; y++) {
            for (int x = 0; x < wo; x++) {
                System.arraycopy(b, 0, acc, 0, c);
                for (int i = 0; i < kh; i++) {
                    int iy = y * st + i - o.pt;
                    if (iy < 0 || iy >= h) continue;
                    for (int j = 0; j < kw; j++) {
                        int ix = x * st + j - o.pl;
                        if (ix < 0 || ix >= w) continue;
                        int sp = (iy * w + ix) * c, wp = (i * kw + j) * c;
                        for (int d = 0; d < c; d++) acc[d] += src[sp + d] * wt[wp + d];
                    }
                }
                int op = (y * wo + x) * c;
                if (o.act == 1) for (int d = 0; d < c; d++) dst[op + d] = Math.min(6f, Math.max(0f, acc[d]));
                else System.arraycopy(acc, 0, dst, op, c);
            }
        }
    }
}
