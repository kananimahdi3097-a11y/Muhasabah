package com.mahendi.muhasabah;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

/**
 * Content packs: new Quran / Hadith / Tafsir collections published to the GitHub repo
 * (content/index.json) are downloaded on app open and merged into the library — no app update needed.
 * Users can also import a pack file (.json) or plain text from their phone.
 *
 * Pack format: {"id":"imam-zaman-2","version":1,"title":"…","items":[{id, ar, en, gu, src, topics:[…]}]}
 */
public final class Content {
    public interface Done {
        void done(int added, String error);
    }

    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    public static void sync(final Context c, final boolean force, final Done cb) {
        final Store s = Store.get(c);
        if (!force && s.p.contains("packs_index") && System.currentTimeMillis() - s.l("packs_checked", 0) < 6 * 3600000L) return;
        new Thread(new Runnable() {
            @Override
            public void run() {
                int added = 0;
                String err = null;
                try {
                    JSONObject idx = new JSONObject(new String(Updater.get(Updater.BASE + "content/index.json?t=" + System.currentTimeMillis(), null), "UTF-8"));
                    JSONArray packs = idx.optJSONArray("packs");
                    if (packs != null) s.put("packs_index", packs.toString());
                    if (packs != null) for (int k = 0; k < packs.length(); k++) {
                        JSONObject p = packs.getJSONObject(k);
                        String id = p.optString("id");
                        int ver = p.optInt("version", 1);
                        if (s.i("pack_" + id, 0) >= ver) continue;
                        if (p.optBoolean("optional") && !s.b("want_" + id, false)) continue; // big books: only on request
                        JSONObject pack;
                        try {
                            pack = new JSONObject(new String(Updater.get(Updater.BASE + p.optString("file") + "?t=" + System.currentTimeMillis(), null), "UTF-8"));
                        } catch (Throwable e) {
                            err = String.valueOf(e.getMessage());
                            continue; // try the other packs
                        }
                        JSONArray items = pack.optJSONArray("items") == null ? new JSONArray() : pack.optJSONArray("items");
                        String type = pack.optString("type");
                        if ("library".equals(type)) added += Library.get(c).add(pack.optString("book", pack.optString("title", id)), items);
                        else if ("daily".equals(type)) added += Daily.add(c, Daily.BOOKS, items);
                        else if ("tips".equals(type)) added += Daily.add(c, Daily.TIPS, items);
                        else added += s.mergeItems(items);
                        s.put("pack_" + id, ver);
                        s.put("pack_title_" + id, p.optString("title", id));
                    }
                    s.put("packs_checked", System.currentTimeMillis());
                } catch (Exception e) {
                    err = e.getMessage();
                }
                final int fa = added;
                final String fe = err;
                if (cb != null) MAIN.post(new Runnable() {
                    @Override
                    public void run() {
                        cb.done(fa, fe);
                    }
                });
            }
        }).start();
    }

    /** Import a file picked by the user: a pack (.json with "items"), a plain JSON array, or text. */
    public static int importStream(android.app.Activity a, InputStream in) throws Exception {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        in.close();
        String txt = new String(bo.toByteArray(), "UTF-8").trim();
        if (txt.startsWith("﻿")) txt = txt.substring(1);
        Store s = Store.get(a);
        if (txt.startsWith("{")) {
            JSONObject o = new JSONObject(txt);
            JSONArray items = o.optJSONArray("items");
            if (items == null) return 0;
            if ("library".equals(o.optString("type")) || items.length() > 300)
                return Library.get(a).add(o.optString("book", o.optString("title", "Imported book")), items);
            return s.mergeItems(withIds(items, o.optString("id", "file")));
        }
        if (txt.startsWith("[")) {
            JSONArray items = new JSONArray(txt);
            if (items.length() > 300) return Library.get(a).add("Imported book", items);
            return s.mergeItems(withIds(items, "file"));
        }
        return Dialogs.importText(a, txt);
    }

    private static JSONArray withIds(JSONArray items, String prefix) throws Exception {
        for (int k = 0; k < items.length(); k++) {
            JSONObject o = items.getJSONObject(k);
            if (o.optString("id").length() == 0) o.put("id", prefix + "_" + k + "_" + Math.abs(o.optString("en").hashCode()));
            if (o.optJSONArray("topics") == null) o.put("topics", new JSONArray().put("knowledge"));
        }
        return items;
    }
}
