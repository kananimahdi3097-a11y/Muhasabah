package com.mahendi.muhasabah;

import android.accessibilityservice.AccessibilityService;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.hardware.HardwareBuffer;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.PowerManager;
import android.os.SystemClock;
import android.view.Display;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;

/**
 * 🛡️ Screen guard. While the screen is on it looks at what is on it — every photo / video / thumbnail
 * separately (found through the accessibility tree, so grids, previews and pop-ups count too), plus the whole
 * screen in parts for pages that don't describe their pictures (browsers). Each picture is checked on the
 * phone by {@link BodyNet} (faces male / female and covered or exposed body parts) and, for porn scenes,
 * {@link NsfwNet}. It acts only on women in revealing clothes, intimate scenes with a woman, nudity and porn;
 * men, children with a parent, objects and ordinary photos are left alone. When it acts, the whole app is
 * locked for 30 minutes and Muhasabah opens. Nothing is saved or sent anywhere.
 */
public final class ScreenGuard {
    public static final String K_ON = "nsfw_on", K_LEVEL = "nsfw_level", K_LVL = "nsfw_lvl", K_ERR = "nsfw_err", K_BLOCKS = "nsfw_blocks_",
            K_ALERT = "nsfw_alert_until", K_LAST = "nsfw_last", K_REASON = "nsfw_reason";
    /** Strictness: 0 Normal … 3 Extreme. */
    public static final int NORMAL = 0, STRICT = 1, VERY = 2, EXTREME = 3;
    /** After a block, check more often (not more strictly) for an hour. */
    public static final long ALERT_MS = 3600_000L;
    private static final long EVERY = 1500, ALERT_EVERY = 900, CONFIRM = 350, BUDGET = 1600;
    private static final int MW = 720; // the screen is looked at 720 px wide

    private final AccessibilityService svc;
    private final HandlerThread th;
    private final Handler h;
    private NsfwNet net;
    private BodyNet body;
    private boolean running, busy;
    private long busySince;
    private volatile String pkg = "";
    private final Map<String, Long> seen = new HashMap<String, Long>(); // region → picture hash
    private final Map<String, Long> seenAt = new HashMap<String, Long>();
    private String maybeKey; // region that looked bad once and is waiting for a second look
    private long maybeAt;
    private int secure; // browser screens Android won't let us see (incognito)

    public ScreenGuard(AccessibilityService s) {
        svc = s;
        th = new HandlerThread("screen-guard", android.os.Process.THREAD_PRIORITY_BACKGROUND);
        th.start();
        h = new Handler(th.getLooper());
    }

    public static boolean on(Store s) {
        return s.b(K_ON, true);
    }

    /** The chosen strictness (0 Normal … 3 Extreme). */
    public static int level(Store s) {
        if (!s.b("nsfw_lvl_v3", false)) { // new body-part detector: everyone starts on Very strict once
            s.put("nsfw_lvl_v3", true);
            s.put(K_LVL, VERY);
            s.put(K_RELAX, 0);
        }
        return Math.max(NORMAL, Math.min(EXTREME, s.i(K_LVL, VERY)));
    }

    public static int effective(Store s) {
        return level(s);
    }

    /** "That was a mistake" taps make the guard a little less sensitive (up to +0.12), until the level is changed. */
    public static final String K_RELAX = "nsfw_relax";

    public static float relax(Store s) {
        return Math.min(0.12f, s.i(K_RELAX, 0) / 100f);
    }

    /** A wrong block: less sensitive, no close watching, and the app it locked is usable again. */
    public static void reportWrong(Store s, String pkg) {
        s.put(K_RELAX, Math.min(12, s.i(K_RELAX, 0) + 3));
        s.put(K_ALERT, 0L);
        String key = K_BLOCKS + Store.today();
        s.put(key, Math.max(0, s.i(key, 0) - 1));
        if (pkg != null && "vulgar".equals(AppLock.why(s, pkg))) AppLock.unlock(s, pkg);
    }

    public static long alertLeft(Store s) {
        return Math.max(0, s.l(K_ALERT, 0) - System.currentTimeMillis());
    }

    public static String levelName(int l) {
        switch (l) {
            case NORMAL: return HadithCard.label("Normal — nudity / porn", "સામાન્ય — નગ્નતા / પોર્ન", "عام — عریانی / پورن", "सामान्य — नग्नता / पोर्न");
            case STRICT: return HadithCard.label("Strict — + bikini, underwear", "કડક — + બિકિની, અંડરવેર", "سخت — + بکنی، زیر جامہ", "सख़्त — + बिकिनी, अंडरवियर");
            case VERY: return HadithCard.label("Very strict — + short clothes, back / side, kissing", "ખૂબ કડક — + ટૂંકા કપડાં, પાછળ / બાજુથી, કિસિંગ", "بہت سخت — + چھوٹے کپڑے، پیچھے / پہلو سے، بوس و کنار", "बहुत सख़्त — + छोटे कपड़े, पीछे / बगल से, किसिंग");
            default: return HadithCard.label("Extreme — any exposed female body", "અત્યંત — સ્ત્રીનું કોઈ પણ ખુલ્લું શરીર", "انتہائی — عورت کا کوئی بھی کھلا جسم", "बेहद सख़्त — औरत का कोई भी खुला शरीर");
        }
    }

    public static String levelHelp(int l) {
        switch (l) {
            case NORMAL: return HadithCard.label("Only nudity and porn.", "ફક્ત નગ્નતા અને પોર્ન.", "صرف عریانی اور پورن۔", "सिर्फ़ नग्नता और पोर्न।");
            case STRICT: return HadithCard.label("Also women in bikini / underwear.", "બિકિની / અંડરવેરમાં સ્ત્રી પણ.", "بکنی / زیر جامے میں عورت بھی۔", "बिकिनी / अंडरवियर में औरत भी।");
            case VERY: return HadithCard.label("Also very short or revealing clothes, women shown from the back or side, kissing. Recommended.",
                    "ખૂબ ટૂંકા કે ખુલ્લા કપડાં, પાછળ કે બાજુથી દેખાતી સ્ત્રી, કિસિંગ પણ. ભલામણ.",
                    "بہت چھوٹے یا کھلے کپڑے، پیچھے یا پہلو سے دکھتی عورت، بوس و کنار بھی۔ تجویز کردہ۔",
                    "बहुत छोटे या खुले कपड़े, पीछे या बगल से दिखती औरत, किसिंग भी। सुझाया गया।");
            default: return HadithCard.label("Also any woman with exposed belly, legs or arms. Some wrong blocks possible.",
                    "ખુલ્લા પેટ, પગ કે હાથ વાળી કોઈ પણ સ્ત્રી. ક્યારેક ખોટા બ્લૉક થઈ શકે.",
                    "کھلے پیٹ، ٹانگوں یا بازوؤں والی کوئی بھی عورت۔ کبھی غلط بلاک ہو سکتا ہے۔",
                    "खुले पेट, पैर या बाँह वाली कोई भी औरत। कभी ग़लत ब्लॉक हो सकता है।");
        }
    }

    public static String reasonText(String r) {
        if ("nudity".equals(r)) return HadithCard.label("nudity", "નગ્નતા", "عریانی", "नग्नता");
        if ("porn".equals(r)) return HadithCard.label("an adult scene", "એડલ્ટ દૃશ્ય", "فحش منظر", "अश्लील दृश्य");
        if ("bikini".equals(r)) return HadithCard.label("a woman in bikini / underwear", "બિકિની / અંડરવેરમાં સ્ત્રી", "بکنی / زیر جامے میں عورت", "बिकिनी / अंडरवियर में औरत");
        if ("back".equals(r)) return HadithCard.label("a woman shown from the back", "પાછળથી દેખાતી સ્ત્રી", "پیچھے سے دکھتی عورت", "पीछे से दिखती औरत");
        if ("revealing".equals(r)) return HadithCard.label("a woman in revealing clothes", "ખુલ્લા કપડાંમાં સ્ત્રી", "کھلے کپڑوں میں عورت", "खुले कपड़ों में औरत");
        if ("kissing".equals(r)) return HadithCard.label("an intimate / kissing scene", "નજીકનું / કિસિંગ દૃશ્ય", "قریبی / بوس و کنار کا منظر", "क़रीबी / किसिंग दृश्य");
        if ("skin".equals(r)) return HadithCard.label("a woman's uncovered body", "સ્ત્રીનું ખુલ્લું શરીર", "عورت کا کھلا جسم", "औरत का खुला शरीर");
        if ("incognito".equals(r)) return HadithCard.label("a private / incognito tab", "પ્રાઇવેટ / ઇન્કૉગ્નિટો ટૅબ", "پرائیویٹ / انکوگنیٹو ٹیب", "प्राइवेट / इनकॉग्निटो टैब");
        return r;
    }

    public void foreground(String p) {
        if (p != null) pkg = p;
    }

    public void start() {
        if (running) return;
        running = true;
        h.postDelayed(tick, 1500);
    }

    public void stop() {
        running = false;
        h.removeCallbacksAndMessages(null);
        th.quitSafely();
        if (net != null) net.close();
        if (body != null) body.close();
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            long next = EVERY;
            try {
                next = scanIfNeeded();
            } catch (Throwable ignored) {
            }
            if (running) h.postDelayed(this, next);
        }
    };

    private long scanIfNeeded() {
        Store s = Store.get(svc);
        if (!on(s) || !(s.b(Store.K_MONITOR, true) || Lock.isLocked(s))) return 5000;
        long t = SystemClock.elapsedRealtime();
        if (busy && t - busySince > 10000) busy = false;
        if (busy) return 300;
        PowerManager pm = svc.getSystemService(PowerManager.class);
        if (pm != null && !pm.isInteractive()) return 4000;
        android.app.KeyguardManager km = svc.getSystemService(android.app.KeyguardManager.class);
        if (km != null && km.isKeyguardLocked()) return 4000;
        final AccessibilityWindowInfo win = frontWindow();
        String p = win == null ? null : packageOf(win);
        if (p != null) pkg = p;
        else p = pkg;
        long gap = maybeKey != null ? CONFIRM : alertLeft(s) > 0 ? ALERT_EVERY : EVERY;
        if (p.equals(svc.getPackageName()) || p.equals("com.android.systemui")) return gap;
        if (AppLock.locked(s, p)) { // a locked app can't be used at all
            post(p, "applock");
            return gap;
        }
        final List<Rect> media = mediaRegions(win);
        boostNow = contextBoost(screenText.toString());
        final String front = p;
        busy = true;
        busySince = t;
        try {
            svc.takeScreenshot(Display.DEFAULT_DISPLAY, new Executor() {
                @Override
                public void execute(Runnable r) {
                    h.post(r);
                }
            }, new AccessibilityService.TakeScreenshotCallback() {
                @Override
                public void onSuccess(AccessibilityService.ScreenshotResult res) {
                    try {
                        Store.get(svc).put(K_ERR, 0);
                        check(res, front, media);
                    } catch (Throwable ignored) {
                    } finally {
                        busy = false;
                    }
                }

                @Override
                public void onFailure(int code) {
                    busy = false;
                    Store.get(svc).put(K_ERR, code == 6 ? 0 : code);
                    if (code == 6) secureScreen(front); // ERROR_TAKE_SCREENSHOT_SECURE_WINDOW
                }
            });
        } catch (Throwable e) {
            busy = false;
        }
        return gap;
    }

    // ---------------- what's on the screen ----------------
    private AccessibilityWindowInfo frontWindow() {
        try {
            AccessibilityWindowInfo any = null;
            for (AccessibilityWindowInfo w : svc.getWindows()) {
                if (w.getType() != AccessibilityWindowInfo.TYPE_APPLICATION) continue;
                if (w.isActive() || w.isFocused()) return w;
                if (any == null) any = w;
            }
            return any;
        } catch (Throwable e) {
            return null;
        }
    }

    private static String packageOf(AccessibilityWindowInfo w) {
        AccessibilityNodeInfo r = w.getRoot();
        if (r == null) return null;
        CharSequence pk = r.getPackageName();
        return pk == null ? null : pk.toString();
    }

    private final StringBuilder screenText = new StringBuilder();
    private volatile float boostNow;

    /** Words on screen that make a hot scene likely: the pictures there are judged a little more strictly. */
    private static final String[] CONTEXT = {"hot", "item song", "item number", "romantic", "romance", "kiss", "bold", "sexy", "bikini",
            "dance", "song", "photoshoot", "actress", "bhabhi", "honeymoon", "gf", "girlfriend", "hottest", "glamour", "lingerie",
            "हॉट", "रोमांटिक", "गाना", "डांस", "હોટ", "ગીત"};

    static float contextBoost(String text) {
        if (text.length() == 0) return 0f;
        String low = text.toLowerCase(java.util.Locale.ROOT);
        int hits = 0;
        for (String w : CONTEXT) if (GuardService.hasWord(low, w)) hits++;
        return hits >= 2 ? 0.10f : hits == 1 ? 0.05f : 0f;
    }

    /** Every picture / video on screen big enough to judge (thumbnails in a grid count separately). */
    private List<Rect> mediaRegions(AccessibilityWindowInfo win) {
        List<Rect> out = new ArrayList<Rect>();
        screenText.setLength(0);
        if (win == null) return out;
        AccessibilityNodeInfo root = win.getRoot();
        if (root == null) return out;
        android.util.DisplayMetrics dm = svc.getResources().getDisplayMetrics();
        int W = dm.widthPixels, H = dm.heightPixels, min = W / 5;
        walk(root, out, W, H, min, new int[]{1500}, 0, screenText);
        java.util.Collections.sort(out, new java.util.Comparator<Rect>() { // biggest first
            @Override
            public int compare(Rect a, Rect b) {
                return Long.compare((long) b.width() * b.height(), (long) a.width() * a.height());
            }
        });
        List<Rect> keep = new ArrayList<Rect>();
        for (Rect r : out) {
            boolean dup = false;
            for (Rect k : keep) {
                Rect i = new Rect();
                if (i.setIntersect(r, k) && (long) i.width() * i.height() > 0.8 * (long) r.width() * r.height()
                        && (long) r.width() * r.height() > 0.6 * (long) k.width() * k.height()) {
                    dup = true;
                    break;
                }
            }
            if (!dup) keep.add(r);
            if (keep.size() >= 16) break;
        }
        return keep;
    }

    private static void walk(AccessibilityNodeInfo n, List<Rect> out, int W, int H, int min, int[] budget, int depth, StringBuilder text) {
        if (n == null || budget[0]-- <= 0 || depth > 40) return;
        if (!n.isVisibleToUser()) return;
        if (text.length() < 6000) {
            CharSequence tx = n.getText();
            if (tx == null) tx = n.getContentDescription();
            if (tx != null && tx.length() > 0) text.append(tx).append(" \n ");
        }
        CharSequence cn = n.getClassName();
        String c = cn == null ? "" : cn.toString();
        String id = n.getViewIdResourceName();
        id = id == null ? "" : id.toLowerCase();
        CharSequence dsc = n.getContentDescription();
        String d = dsc == null ? "" : dsc.toString().toLowerCase();
        boolean media = c.endsWith("ImageView") || c.endsWith("TextureView") || c.endsWith("SurfaceView") || c.endsWith("VideoView")
                || c.equals("android.widget.Image") || id.contains("image") || id.contains("video") || id.contains("media")
                || id.contains("thumbnail") || id.contains("preview") || id.contains("clips") || id.contains("reel") || id.contains("player")
                || d.startsWith("photo") || d.startsWith("video") || d.startsWith("reel") || d.contains("photo by") || d.contains("video by")
                || d.contains("reel by") || d.startsWith("image");
        if (media) {
            Rect r = new Rect();
            n.getBoundsInScreen(r);
            if (r.intersect(0, 0, W, H) && r.width() >= min && r.height() >= min) out.add(r);
        }
        for (int i = 0; i < n.getChildCount(); i++) walk(n.getChild(i), out, W, H, min, budget, depth + 1, text);
    }

    // ---------------- checking ----------------
    private void check(AccessibilityService.ScreenshotResult res, String front, List<Rect> media) throws Exception {
        HardwareBuffer hb = res.getHardwareBuffer();
        Bitmap hw = Bitmap.wrapHardwareBuffer(hb, res.getColorSpace());
        hb.close();
        if (hw == null) return;
        int W = hw.getWidth(), H = hw.getHeight();
        int mw = Math.min(MW, W), mh = Math.max(2, Math.round(mw * (float) H / W));
        Bitmap mid;
        try {
            Bitmap g = Bitmap.createScaledBitmap(hw, mw, mh, true);
            mid = g.copy(Bitmap.Config.ARGB_8888, false);
            if (g != hw) g.recycle();
        } catch (Throwable e) {
            Bitmap full = hw.copy(Bitmap.Config.ARGB_8888, false);
            mid = Bitmap.createScaledBitmap(full, mw, mh, true);
            if (mid != full) full.recycle();
        }
        hw.recycle();
        if (mid == null) return;
        try {
            if (allBlack(mid)) {
                secureScreen(front);
                return;
            }
            secure = 0;
            scan(mid, W, front, media);
        } finally {
            mid.recycle();
        }
    }

    private static boolean allBlack(Bitmap b) {
        int w = b.getWidth(), hh = b.getHeight();
        for (int y = hh / 10; y < hh * 9 / 10; y += Math.max(1, hh / 40))
            for (int x = 0; x < w; x += Math.max(1, w / 20)) if ((b.getPixel(x, y) & 0xffffff) != 0) return false;
        return true;
    }

    /** Android hides this screen from the guard. In a browser that means an incognito / private tab. */
    private void secureScreen(String front) {
        if (!GuardService.isBrowserPkg(front)) {
            secure = 0;
            return;
        }
        if (++secure < 2) return;
        secure = 0;
        Store s = Store.get(svc);
        s.put(K_REASON, "incognito");
        AppLock.lock(s, front, System.currentTimeMillis() + AppLock.CATCH_MS, "incognito");
        post(front, "incognito");
    }

    private static final class Region {
        final String key;
        final Rect r; // in mid-bitmap pixels

        Region(String key, Rect r) {
            this.key = key;
            this.r = r;
        }
    }

    private void scan(Bitmap mid, int screenW, String front, List<Rect> media) throws Exception {
        Store s = Store.get(svc);
        float f = mid.getWidth() / (float) screenW;
        int mw = mid.getWidth(), mh = mid.getHeight();
        List<Region> regions = new ArrayList<Region>();
        long screenArea = (long) mw * mh, biggest = 0;
        for (Rect r : media) {
            Rect m = new Rect(Math.round(r.left * f), Math.round(r.top * f), Math.round(r.right * f), Math.round(r.bottom * f));
            if (!m.intersect(0, 0, mw, mh) || m.width() < 24 || m.height() < 24) continue;
            biggest = Math.max(biggest, (long) m.width() * m.height());
            regions.add(new Region("m" + m.toShortString(), m));
        }
        // the whole screen in squares too, unless one picture already fills most of it (full-screen reel / video)
        if (biggest < screenArea * 0.5) {
            int n = Math.max(1, (int) Math.ceil((double) mh / mw));
            for (int k = 0; k < n; k++) {
                int y0 = n == 1 ? 0 : Math.round((float) (mh - mw) * k / (n - 1));
                regions.add(new Region("s" + k, new Rect(0, y0, mw, Math.min(mh, y0 + mw))));
            }
        }
        long t0 = SystemClock.elapsedRealtime();
        float boost = boostNow;
        String waiting = maybeKey;
        String newMaybe = null;
        if (waiting != null) // the region waiting for a second look goes first
            for (int i = 0; i < regions.size(); i++)
                if (regions.get(i).key.equals(waiting)) {
                    regions.add(0, regions.remove(i));
                    break;
                }
        for (Region rg : regions) {
            boolean isWaiting = rg.key.equals(waiting);
            long hash = hash(mid, rg.r);
            Long old = seen.get(rg.key), at = seenAt.get(rg.key);
            boolean due = isWaiting || old == null || old != hash || at == null || t0 - at > 20000;
            if (!due) continue;
            if (!isWaiting && SystemClock.elapsedRealtime() - t0 > BUDGET) break; // the rest next time
            Verdict v = look(mid, rg.r, s, boost);
            seen.put(rg.key, hash);
            seenAt.put(rg.key, SystemClock.elapsedRealtime());
            if (v.level == 2 || (v.level == 1 && isWaiting)) {
                maybeKey = null;
                block(s, front, v.reason);
                return;
            }
            if (v.level == 1 && newMaybe == null) newMaybe = rg.key;
        }
        if (newMaybe != null && !newMaybe.equals(waiting)) {
            maybeKey = newMaybe; // look once more at a fresh screenshot before acting
            maybeAt = SystemClock.elapsedRealtime();
        } else maybeKey = null;
        if (seen.size() > 300) {
            seen.clear();
            seenAt.clear();
        }
        s.put(K_LAST, System.currentTimeMillis() + "|0|0");
    }

    private static long hash(Bitmap b, Rect r) {
        long hsh = 1125899906842597L;
        for (int y = 0; y < 8; y++)
            for (int x = 0; x < 8; x++) {
                int c = b.getPixel(r.left + (r.width() - 1) * x / 7, r.top + (r.height() - 1) * y / 7);
                int g = (((c >> 16) & 0xff) * 3 + ((c >> 8) & 0xff) * 6 + (c & 0xff)) / 10 / 12; // coarse, ignores small noise
                hsh = 31 * hsh + g;
            }
        return hsh;
    }

    /** Body parts and porn / "sexy" scores of one part of the screen. */
    private static final class Look {
        List<BodyNet.Det> dets = new ArrayList<BodyNet.Det>();
        float porn, sexy;
    }

    /** One picture: letterboxed to 320 for the body-part detector, stretched to 224 for the scene check. */
    private Look see(Bitmap mid, Rect r) throws Exception {
        if (body == null) body = new BodyNet(svc.getAssets().open("nudenet320.bin"));
        Look lk = new Look();
        Bitmap crop = Bitmap.createBitmap(mid, r.left, r.top, r.width(), r.height());
        float sc = BodyNet.SIZE / (float) Math.max(r.width(), r.height());
        Bitmap box = Bitmap.createBitmap(BodyNet.SIZE, BodyNet.SIZE, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(box);
        cv.drawColor(0xFF000000);
        cv.drawBitmap(crop, null, new Rect(0, 0, Math.max(1, Math.round(r.width() * sc)), Math.max(1, Math.round(r.height() * sc))),
                new Paint(Paint.FILTER_BITMAP_FLAG));
        float[] in = pixels(box, BodyNet.SIZE);
        box.recycle();
        lk.dets = body.detect(in, 0.25f);
        // boxes back into this crop's own 0..1 coordinates (the detector saw it letterboxed)
        float fx = Math.max(r.width(), r.height()) / (float) r.width(), fy = Math.max(r.width(), r.height()) / (float) r.height();
        for (BodyNet.Det d : lk.dets) {
            d.x0 *= fx;
            d.x1 *= fx;
            d.y0 *= fy;
            d.y1 *= fy;
        }
        if (hasPerson(lk.dets)) { // the scene check only where there is a person
            if (net == null) net = new NsfwNet(svc.getAssets().open("nsfw_mv2.bin"));
            Bitmap sq = Bitmap.createScaledBitmap(crop, NsfwNet.SIZE, NsfwNet.SIZE, true);
            float[] p = net.classify(pixels(sq, NsfwNet.SIZE));
            if (sq != crop) sq.recycle();
            lk.porn = p[NsfwNet.PORN] + p[NsfwNet.HENTAI];
            lk.sexy = p[NsfwNet.SEXY];
        }
        if (crop != mid) crop.recycle();
        return lk;
    }

    /**
     * Look at a part of the screen; when it holds small people (a thumbnail, a dancer in a wide shot),
     * zoom in on each woman (and on any bare body) and look again at full detail. The strongest verdict wins.
     */
    private Verdict look(Bitmap mid, Rect r, Store s, float boost) throws Exception {
        int lv = effective(s);
        float rx = relax(s);
        Look whole = see(mid, r);
        Verdict best = judge(whole.dets, whole.porn, whole.sexy, lv, rx, boost);
        if (best.level == 2) return best;
        List<Rect> zooms = new ArrayList<Rect>();
        for (BodyNet.Det d : whole.dets) {
            if (zooms.size() >= 3) break;
            boolean woman = d.cls == BodyNet.FACE_F && d.score >= 0.35f;
            boolean body = d.score >= 0.30f && (d.cls == BodyNet.F_BREAST_COV || d.cls == BodyNet.BELLY_EXP || d.cls == BodyNet.F_GEN_COV
                    || d.cls == BodyNet.BUTT_COV || d.cls == BodyNet.F_BREAST_EXP || d.cls == BodyNet.BUTT_EXP);
            if (!woman && !body) continue;
            float bw = d.x1 - d.x0, bh = d.y1 - d.y0;
            if (Math.max(bw, bh) > 0.35f) continue; // already big enough
            // a face: the whole person is below it (about 3 face-widths wide, 7 tall); a body part: around it
            float cx = (d.x0 + d.x1) / 2, top, side;
            if (woman) {
                side = Math.max(bw * 7f, bh * 7f);
                top = d.y0 - bh * 0.8f;
            } else {
                side = Math.max(bw, bh) * 4f;
                top = (d.y0 + d.y1) / 2 - side / 2;
            }
            int px = r.width(), py = r.height();
            int sidePx = Math.round(Math.min(Math.max(side * Math.max(px, py), 64), Math.min(px, py)));
            int l = Math.round(cx * px - sidePx / 2f), t = Math.round(top * py);
            l = Math.max(0, Math.min(px - sidePx, l));
            t = Math.max(0, Math.min(py - sidePx, t));
            Rect z = new Rect(r.left + l, r.top + t, r.left + l + sidePx, r.top + t + sidePx);
            boolean dup = false;
            for (Rect o : zooms) if (Rect.intersects(o, z)) {
                Rect i = new Rect();
                i.setIntersect(o, z);
                if ((long) i.width() * i.height() > 0.6 * (long) z.width() * z.height()) dup = true;
            }
            if (!dup) zooms.add(z);
        }
        for (Rect z : zooms) {
            Look zl = see(mid, z);
            // the wide view's scene score still counts (the zoom may cut the context away)
            Verdict v = judge(zl.dets, Math.max(zl.porn, whole.porn * 0.8f), Math.max(zl.sexy, whole.sexy * 0.8f), lv, rx, boost);
            if (v.level > best.level) best = v;
            if (best.level == 2) break;
        }
        return best;
    }

    private static float[] pixels(Bitmap b, int n) {
        int[] px = new int[n * n];
        b.getPixels(px, 0, n, 0, 0, n, n);
        float[] in = new float[n * n * 3];
        for (int i = 0, q = 0; i < px.length; i++) {
            int c = px[i];
            in[q++] = ((c >> 16) & 0xff) / 255f;
            in[q++] = ((c >> 8) & 0xff) / 255f;
            in[q++] = (c & 0xff) / 255f;
        }
        return in;
    }

    private static boolean hasPerson(List<BodyNet.Det> d) {
        for (BodyNet.Det x : d) if (x.score >= 0.35f) return true;
        return false;
    }

    // ---------------- the rules ----------------
    public static final class Verdict {
        public final int level; // 0 fine, 1 looks bad (confirm with a second look), 2 block now
        public final String reason;

        Verdict(int level, String reason) {
            this.level = level;
            this.reason = reason;
        }
    }

    private static final Verdict OK = new Verdict(0, "");

    /**
     * Two independent models must agree before anything that isn't plain nudity is blocked:
     * the body-part detector must see a woman (her face or her body) and the scene model must rate the
     * picture "sexy" / porn. That stops both kinds of mistakes — men, objects and ordinary family photos
     * (one model alone) and missed dance songs / hot scenes (now caught by the pair, also when zoomed in).
     *  P = porn score, S = "sexy" score (0..1), rx = "mistake" relaxation, boost = on-screen words like "hot song".
     *  every level — exposed breast / genitals / anus / buttocks; porn scene with a woman or bare body;
     *  Strict      — + bikini / underwear;
     *  Very strict — + a woman in revealing clothes or a hot dance (bare belly, armpits, legs, tight back) with S high,
     *                  kissing / intimate scene with a woman;
     *  Extreme     — + any woman with bare skin and a moderate S.
     */
    public static Verdict judge(List<BodyNet.Det> d, float porn, float sexy, int lv, float rx, float boost) {
        float[] m = new float[BodyNet.LABELS.length];
        for (BodyNet.Det x : d) m[x.cls] = Math.max(m[x.cls], x.score);
        float t = rx - boost + (lv == EXTREME ? -0.05f : 0f);
        boolean female = m[BodyNet.FACE_F] >= 0.45f + t || m[BodyNet.F_BREAST_COV] >= 0.50f + t || m[BodyNet.F_GEN_COV] >= 0.45f + t
                || m[BodyNet.F_BREAST_EXP] >= 0.45f + t || m[BodyNet.F_GEN_EXP] >= 0.40f + t;
        boolean menOnly = !female && m[BodyNet.FACE_M] >= 0.45f;
        float skin = Math.max(Math.max(m[BodyNet.BELLY_EXP], m[BodyNet.ARMPIT_EXP]), Math.max(m[BodyNet.FEET_EXP] * 0.8f, m[BodyNet.BUTT_COV] * 0.9f));

        // nudity — every level (a single model is enough here: the detector names the exposed part)
        float nude = Math.max(Math.max(m[BodyNet.F_BREAST_EXP] - 0.50f, m[BodyNet.F_GEN_EXP] - 0.45f),
                Math.max(Math.max(m[BodyNet.M_GEN_EXP] - 0.50f, m[BodyNet.ANUS_EXP] - 0.45f), m[BodyNet.BUTT_EXP] - 0.55f)) - t;
        if (nude >= 0.20f || (nude >= 0f && porn >= 0.6f)) return new Verdict(2, "nudity");
        if (nude >= 0f) return new Verdict(1, "nudity");
        float exposed = Math.max(Math.max(m[BodyNet.F_BREAST_EXP], m[BodyNet.F_GEN_EXP]), Math.max(m[BodyNet.BUTT_EXP], m[BodyNet.M_GEN_EXP]));
        if (!menOnly && (female || exposed >= 0.30f)) {
            if (porn >= 0.95f + t) return new Verdict(2, "porn");
            if (porn >= 0.85f + t) return new Verdict(1, "porn");
        }
        if (lv < STRICT || !female) return OK; // everything below is about women only

        // bikini / underwear
        if (m[BodyNet.F_GEN_COV] >= 0.50f + t && (sexy >= 0.45f + t || m[BodyNet.BELLY_EXP] >= 0.40f + t))
            return new Verdict(sexy >= 0.75f + t || m[BodyNet.F_GEN_COV] >= 0.70f + t ? 2 : 1, "bikini");
        if (m[BodyNet.F_BREAST_COV] >= 0.45f + t && m[BodyNet.BELLY_EXP] >= 0.45f + t && sexy >= 0.40f + t)
            return new Verdict(sexy >= 0.75f + t ? 2 : 1, "revealing");
        if (lv < VERY) return OK;

        // revealing clothes / hot dance / tight back view
        if (sexy >= 0.60f + t && skin >= 0.35f + t) return new Verdict(sexy >= 0.85f + t ? 2 : 1, "revealing");
        if (sexy >= 0.75f + t && m[BodyNet.F_BREAST_COV] >= 0.45f + t) return new Verdict(1, "revealing");
        if (m[BodyNet.BUTT_COV] >= 0.55f + t && sexy >= 0.45f + t) return new Verdict(1, "back");
        if (kissing(d, 0.40f + t) && sexy >= 0.35f + t) return new Verdict(1, "kissing");
        if (lv < EXTREME) return OK;
        if (sexy >= 0.45f + rx - boost && skin >= 0.30f) return new Verdict(1, "skin");
        if (sexy >= 0.70f + rx - boost) return new Verdict(1, "skin");
        return OK;
    }

    /** Older form kept for tests. */
    public static Verdict judge(List<BodyNet.Det> d, float porn, int lv, float rx) {
        return judge(d, porn, 0f, lv, rx, 0f);
    }

    private static boolean hasAny(float[] m, float min) {
        for (float v : m) if (v >= min) return true;
        return false;
    }

    /** A woman's face touching another face of similar size (and not a crowd). */
    private static boolean kissing(List<BodyNet.Det> d, float min) {
        List<BodyNet.Det> faces = new ArrayList<BodyNet.Det>();
        for (BodyNet.Det x : d)
            if ((x.cls == BodyNet.FACE_F || x.cls == BodyNet.FACE_M) && x.score >= min) faces.add(x);
        if (faces.size() < 2 || faces.size() > 3) return false;
        for (BodyNet.Det a : faces) {
            if (a.cls != BodyNet.FACE_F) continue;
            for (BodyNet.Det b : faces) {
                if (a == b) continue;
                float wa = a.x1 - a.x0, wb = b.x1 - b.x0;
                if (wa < 0.06f || wb < 0.06f) continue;
                float ratio = wa / wb;
                if (ratio < 0.6f || ratio > 1.67f) continue;
                float dx = (a.x0 + a.x1 - b.x0 - b.x1) / 2, dy = (a.y0 + a.y1 - b.y0 - b.y1) / 2;
                if (Math.sqrt(dx * dx + dy * dy) < 0.85f * (wa + wb) / 2) return true;
            }
        }
        return false;
    }

    // ---------------- acting ----------------
    private void block(Store s, String front, String reason) {
        s.put(K_ALERT, System.currentTimeMillis() + ALERT_MS);
        s.put(K_REASON, reason);
        String key = K_BLOCKS + Store.today();
        s.put(key, s.i(key, 0) + 1);
        AppLock.lock(s, front, System.currentTimeMillis() + AppLock.CATCH_MS, "vulgar");
        seen.clear();
        seenAt.clear();
        post(front, "vulgar");
    }

    private long lastPost;

    private void post(final String p, final String kind) {
        long t = SystemClock.elapsedRealtime();
        if (t - lastPost < 1500) return;
        lastPost = t;
        new Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                if (svc instanceof GuardService) ((GuardService) svc).blockApp(p, kind);
            }
        });
    }

    public static int blocksToday(Store s) {
        return s.i(K_BLOCKS + Store.today(), 0);
    }
}
