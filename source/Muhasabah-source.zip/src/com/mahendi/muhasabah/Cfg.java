package com.mahendi.muhasabah;

/** Every adjustable number in the app, with its default, range and labels — shown in Settings → Fine-tune. */
public final class Cfg {
    public static final class Item {
        public final String group, key, en, gu, unit;
        public final int def, min, max;
        public final boolean time;

        Item(String group, String key, String en, String gu, int def, int min, int max, String unit, boolean time) {
            this.group = group;
            this.key = key;
            this.en = en;
            this.gu = gu;
            this.def = def;
            this.min = min;
            this.max = max;
            this.unit = unit;
            this.time = time;
        }
    }

    public static final String G_SCORE = "score", G_NUDGE = "nudge", G_APPS = "apps", G_REM = "rem", G_CAL = "cal";

    public static final Item[] ALL = {
            new Item(G_SCORE, "better_thr", "A day at or above this score always counts as a good day", "આટલા કે વધુ સ્કોરવાળો દિવસ હંમેશા સારો ગણાય", 90, 50, 100, "", false),
            new Item(G_SCORE, "pen_tp_per", "Timepass: lose 1 point for every … minutes over your limits", "ટાઇમપાસ: મર્યાદાથી દર … મિનિટ વધુ માટે 1 પોઇન્ટ ઓછો", 3, 1, 30, "min", false),
            new Item(G_SCORE, "pen_tp_cap", "Timepass: most points you can lose in a day", "ટાઇમપાસ: દિવસમાં વધુમાં વધુ કેટલા પોઇન્ટ ઓછા", 25, 0, 60, "pts", false),
            new Item(G_SCORE, "pen_reel_each", "Reels: points lost for each reel over the limit", "રીલ્સ: મર્યાદા પછીની દરેક રીલ માટે ઓછા પોઇન્ટ", 1, 0, 10, "pts", false),
            new Item(G_SCORE, "pen_reel_cap", "Reels: most points you can lose in a day", "રીલ્સ: દિવસમાં વધુમાં વધુ ઓછા પોઇન્ટ", 10, 0, 50, "pts", false),
            new Item(G_SCORE, "pen_nm_each", "Na-mahram: points lost for each logged glance", "નામહરમ: દરેક નોંધેલી નજર માટે ઓછા પોઇન્ટ", 2, 0, 10, "pts", false),
            new Item(G_SCORE, "pen_nm_cap", "Na-mahram: most points you can lose in a day", "નામહરમ: દિવસમાં વધુમાં વધુ ઓછા પોઇન્ટ", 12, 0, 50, "pts", false),
            new Item(G_SCORE, "pen_total_cap", "All penalties together: most points lost in a day", "બધી સજા મળીને: દિવસમાં વધુમાં વધુ ઓછા પોઇન્ટ", 40, 0, 100, "pts", false),
            new Item(G_SCORE, "better_bonus", "Bonus XP for every Better Day", "દરેક બહેતર દિવસ માટે બોનસ XP", 20, 0, 200, "XP", false),

            new Item(G_NUDGE, "n_oversleep", "Oversleep alert if you first use the phone this long after wake-up time", "ઊઠવાના સમય પછી આટલું મોડું ફોન વાપરો તો 'વધુ ઊંઘ' યાદ", 60, 15, 240, "min", false),
            new Item(G_NUDGE, "n_afternoon", "Afternoon check time", "બપોરનો ચેક", 960, 0, 1439, "", true),
            new Item(G_NUDGE, "n_afternoon_thr", "Afternoon nudge if your score is below", "સ્કોર આનાથી ઓછો હોય તો બપોરે યાદ", 30, 0, 100, "", false),
            new Item(G_NUDGE, "n_final", "Last-chance reminder this long after the evening check", "સાંજના ચેક પછી આટલા સમયે છેલ્લી યાદ", 105, 15, 240, "min", false),
            new Item(G_NUDGE, "n_night_start", "Late-night nudges start this long after sleep time", "સૂવાના સમય પછી આટલા સમયે રાતની યાદ શરૂ", 30, 0, 180, "min", false),
            new Item(G_NUDGE, "n_night_gap", "Gap between late-night nudges", "રાતની બે યાદ વચ્ચેનો સમય", 20, 5, 120, "min", false),

            new Item(G_APPS, "a_warn", "Warn this many minutes before an app's limit", "ઍપની મર્યાદા પહેલાં આટલી મિનિટે ચેતવણી", 5, 0, 30, "min", false),
            new Item(G_APPS, "a_step", "Stronger warning this many minutes over the limit", "મર્યાદાથી આટલી મિનિટ વધુ થાય ત્યારે કડક ચેતવણી", 15, 5, 60, "min", false),
            new Item(G_APPS, "a_pause", "Full-screen pause this many minutes over the limit", "મર્યાદાથી આટલી મિનિટ વધુ થાય ત્યારે પૂરી સ્ક્રીન રોક", 30, 5, 120, "min", false),
            new Item(G_APPS, "a_pause_gap", "Repeat the pause every", "રોક ફરી દર", 5, 1, 60, "min", false),

            new Item(G_CAL, "hijri_adj", "Hijri date adjustment (days) — match your local moon sighting", "હિજરી તારીખ ફેરફાર (દિવસ) — સ્થાનિક ચાંદ પ્રમાણે", 0, -3, 3, "", false),

            new Item(G_REM, Reminders.K_REPEAT, "Default: how many times a reminder repeats", "ડિફૉલ્ટ: રિમાઇન્ડર કેટલી વાર", 4, 1, 6, "×", false),
            new Item(G_REM, Reminders.K_INTERVAL, "Default: minutes between repeats", "ડિફૉલ્ટ: બે રિમાઇન્ડર વચ્ચે મિનિટ", 10, 5, 60, "min", false),
            new Item(G_REM, Reminders.K_SNOOZE, "Snooze length", "સ્નૂઝ સમય", 10, 5, 60, "min", false),
    };

    public static int get(Store s, String key) {
        for (Item it : ALL) if (it.key.equals(key)) return s.i(key, it.def);
        return s.i(key, 0);
    }

    public static String groupTitle(String g) {
        if (G_SCORE.equals(g)) return Lang.pick("Score & penalties", "સ્કોર અને સજા");
        if (G_NUDGE.equals(g)) return Lang.pick("Nudges & timing", "યાદ અને સમય");
        if (G_APPS.equals(g)) return Lang.pick("App-limit warnings", "ઍપ-મર્યાદા ચેતવણી");
        if (G_CAL.equals(g)) return Lang.pick("Calendar", "કૅલેન્ડર");
        return Lang.pick("Reminders", "રિમાઇન્ડર");
    }
}
