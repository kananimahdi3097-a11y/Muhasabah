package com.mahendi.muhasabah;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/** All app data lives on the phone in one SharedPreferences file. */
public class Store {
    private static Store inst;
    public final SharedPreferences p;
    private final Context ctx;
    private static JSONArray feedCache, activityCache;

    // Settings keys
    public static final String K_NAME = "name", K_SLEEP = "sleep_min", K_WAKE = "wake_min", K_CHECK = "check_min",
            K_FEEDCAP = "feed_cap", K_STRICT = "strict_guj", K_MONITOR = "monitor_on",
            K_LANG = "lang", K_CLANG = "content_lang", K_REELS_LIMIT = "reels_limit", K_BLOCK_ON = "block_on", K_GUARD_TIP = "guard_tip", K_CMASK = "content_mask";

    private Store(Context c) {
        ctx = c.getApplicationContext();
        p = ctx.getSharedPreferences("muhasabah", Context.MODE_PRIVATE);
        seed();
        Lang.init(ctx);
        applyLang();
    }

    /** Pushes the saved UI language and content languages into Lang. */
    public void applyLang() {
        Lang.set(i(K_LANG, 0));
        Lang.setMask(contentMask());
    }

    public int contentMask() {
        if (p.contains(K_CMASK)) return i(K_CMASK, Lang.M_EN | Lang.M_GU);
        int c = i(K_CLANG, 0);
        return c == Lang.C_EN ? Lang.M_EN : c == Lang.C_GU ? Lang.M_GU : Lang.M_EN | Lang.M_GU;
    }

    public static synchronized Store get(Context c) {
        if (inst == null) inst = new Store(c);
        return inst;
    }

    // ---------- dates ----------
    public static String date(int offsetDays) {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_YEAR, offsetDays);
        return fmt(c);
    }

    public static String fmt(Calendar c) {
        return String.format(Locale.US, "%04d-%02d-%02d", c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH));
    }

    /** Calendar for a "yyyy-MM-dd" date string. */
    public static Calendar cal(String date) {
        Calendar c = Calendar.getInstance();
        try {
            String[] p = date.split("-");
            c.set(Integer.parseInt(p[0]), Integer.parseInt(p[1]) - 1, Integer.parseInt(p[2]), 12, 0, 0);
        } catch (Exception ignored) {
        }
        return c;
    }

    /** Days between two date strings (b − a). */
    public static int daysBetween(String a, String b) {
        return (int) Math.round((cal(b).getTimeInMillis() - cal(a).getTimeInMillis()) / 86400000.0);
    }

    public static String today() {
        return date(0);
    }

    public static long startOfToday() {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    public static int minuteOfDay() {
        Calendar c = Calendar.getInstance();
        return c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE);
    }

    public static int dayNumber() {
        return (int) ((startOfToday() + Calendar.getInstance().get(Calendar.ZONE_OFFSET)) / 86400000L);
    }

    // ---------- primitive helpers ----------
    public int i(String k, int d) { return p.getInt(k, d); }
    public long l(String k, long d) { return p.getLong(k, d); }
    public boolean b(String k, boolean d) { return p.getBoolean(k, d); }
    public String s(String k, String d) { return p.getString(k, d); }
    public void put(String k, int v) { p.edit().putInt(k, v).apply(); }
    public void put(String k, long v) { p.edit().putLong(k, v).apply(); }
    public void put(String k, boolean v) { p.edit().putBoolean(k, v).apply(); }
    public void put(String k, String v) { p.edit().putString(k, v).apply(); }

    /** True the first time it is called for this key today. */
    public boolean once(String key) {
        String k = "once_" + key + "_" + today();
        if (p.getBoolean(k, false)) return false;
        p.edit().putBoolean(k, true).apply();
        return true;
    }

    public boolean firedToday(String key) {
        return p.getBoolean("once_" + key + "_" + today(), false);
    }

    // ---------- seed ----------
    private void seed() {
        if (!p.contains("tasks")) saveTasks(defaultTasks());
        if (!p.contains("apps")) put("apps", defaultApps().toString());
        if (!p.contains("wisdom")) put("wisdom", asset("wisdom.json"));
        if (i("builtin_ver", 0) < BUILTIN_VER) {
            try {
                mergeItems(new JSONArray(asset("wisdom.json")));
            } catch (Exception ignored) {
            }
            put("builtin_ver", BUILTIN_VER);
        }
        if (!p.contains(K_SLEEP)) {
            p.edit().putInt(K_SLEEP, 23 * 60).putInt(K_WAKE, 5 * 60 + 15).putInt(K_CHECK, 21 * 60)
                    .putInt(K_FEEDCAP, 12).putBoolean(K_STRICT, true).putBoolean(K_MONITOR, true)
                    .putString(K_NAME, "Mahdi").putLong("installed", System.currentTimeMillis()).apply();
        }
        // owner name is now "Mahdi" (was "Mahendi"); keep any other name the user typed
        if ("Mahendi".equals(p.getString(K_NAME, ""))) p.edit().putString(K_NAME, "Mahdi").apply();
        if (!p.contains(K_REELS_LIMIT)) p.edit().putInt(K_REELS_LIMIT, 15).putBoolean(K_BLOCK_ON, true).apply();
        if (!p.contains("blocked_words")) put("blocked_words", defaultWords());
        if (!p.contains("blocked_sites")) put("blocked_sites", defaultSites());
    }

    /** Bump when assets/wisdom.json changes so existing installs pick up new/updated items. */
    public static final int BUILTIN_VER = 5;

    /**
     * Merge items (built-in or from a content pack) into the library: updates items with the same id,
     * adds new ones, never touches the user's own items, and never brings back something they deleted.
     * Returns how many were added.
     */
    public synchronized int mergeItems(JSONArray items) {
        List<JSONObject> lib = wisdom();
        String deleted = s("wisdom_deleted", "|");
        int added = 0;
        for (int k = 0; k < items.length(); k++) {
            JSONObject o = items.optJSONObject(k);
            if (o == null || o.optString("id").length() == 0 || o.optString("en").length() == 0 && o.optString("gu").length() == 0) continue;
            String id = o.optString("id");
            if (deleted.contains("|" + id + "|")) continue;
            int at = -1;
            for (int i = 0; i < lib.size(); i++) if (id.equals(lib.get(i).optString("id"))) at = i;
            if (at >= 0) {
                if (!lib.get(at).optBoolean("mine")) lib.set(at, o);
            } else {
                lib.add(o);
                added++;
            }
        }
        saveWisdom(lib);
        return added;
    }

    private static String defaultWords() {
        return "porn,xxx,sex,sexy,nude,nudes,naked,xvideo,xvideos,xnxx,xhamster,brazzers,pornhub,"
                + "onlyfans,hentai,bikini,escort,camgirl,boobs,milf,erotic,fuck,bhabhi hot,desi mms,"
                + "sexy video,hot scene,web series hot,mallu,hot reels";
    }

    private static String defaultSites() {
        return "pornhub.com,xvideos.com,xnxx.com,xhamster.com,onlyfans.com,brazzers.com,redtube.com,"
                + "youporn.com,spankbang.com,chaturbate.com,stripchat.com,bongacams.com,hentaihaven.xxx,"
                + "nhentai.net,rule34.xxx,eporner.com,hqporner.com,motherless.com";
    }

    public List<String> blockedWords() {
        return splitList(s("blocked_words", ""));
    }

    public List<String> blockedSites() {
        return splitList(s("blocked_sites", ""));
    }

    private static List<String> splitList(String csv) {
        List<String> l = new ArrayList<String>();
        for (String x : csv.split("[,\n]")) {
            String t = x.trim().toLowerCase(Locale.US);
            if (t.length() > 0) l.add(t);
        }
        return l;
    }

    public void setBlockedWords(String csv) {
        put("blocked_words", csv);
    }

    public void setBlockedSites(String csv) {
        put("blocked_sites", csv);
    }

    // ---------- reels & na-mahram counters (per day) ----------
    public int reels(String date) {
        return i("reels_" + date, 0);
    }

    public int incReels(String date) {
        int v = reels(date) + 1;
        put("reels_" + date, v);
        return v;
    }

    public int namahram(String date) {
        return i("nm_" + date, 0);
    }

    public int incNamahram(String date) {
        int v = namahram(date) + 1;
        put("nm_" + date, v);
        return v;
    }

    public int reelsLimit() {
        return i(K_REELS_LIMIT, 15);
    }

    public List<JSONObject> activities() {
        if (activityCache == null) {
            try {
                activityCache = new JSONArray(asset("activities.json"));
            } catch (Exception e) {
                activityCache = new JSONArray();
            }
        }
        List<JSONObject> l = new ArrayList<JSONObject>();
        for (int k = 0; k < activityCache.length(); k++) l.add(activityCache.optJSONObject(k));
        return l;
    }

    /** A random activity suggestion matching a tag. */
    public JSONObject activity(String tag) {
        List<JSONObject> all = activities(), match = new ArrayList<JSONObject>();
        for (JSONObject o : all) {
            JSONArray t = o.optJSONArray("tags");
            if (t != null) for (int k = 0; k < t.length(); k++) if (tag.equals(t.optString(k))) {
                match.add(o);
                break;
            }
        }
        List<JSONObject> src = match.isEmpty() ? all : match;
        return src.isEmpty() ? new JSONObject() : src.get(new Random().nextInt(src.size()));
    }

    private String asset(String name) {
        try {
            BufferedReader r = new BufferedReader(new InputStreamReader(ctx.getAssets().open(name), "UTF-8"));
            StringBuilder b = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) b.append(line).append('\n');
            r.close();
            return b.toString();
        } catch (Exception e) {
            return "[]";
        }
    }

    public static List<Task> defaultTasks() {
        List<Task> l = new ArrayList<Task>();
        l.add(Task.make("fajr", "🌅", "Fajr on time", Task.CHECK, 1, "", 3).guName("ફજર સમયસર"));
        l.add(Task.make("namaz", "🕌", "Namaz (all 5)", Task.COUNT, 5, "namaz", 3).guName("નમાઝ (પાંચેય)"));
        l.add(Task.make("quran", "📖", "Quran recitation", Task.MINUTES, 15, "", 3).guName("કુરઆન તિલાવત"));
        l.add(Task.make("work", "💼", "Deep work (business)", Task.MINUTES, 120, "", 3).guName("ધ્યાનથી કામ (ધંધો)"));
        l.add(Task.make("read", "📚", "Reading / Study", Task.MINUTES, 45, "", 2).guName("વાંચન / અભ્યાસ"));
        l.add(Task.make("exercise", "🏃", "Exercise / Walk", Task.MINUTES, 20, "", 2).guName("કસરત / ચાલવું"));
        l.add(Task.make("dua", "📿", "Dua & Dhikr", Task.CHECK, 1, "", 1).guName("દુઆ અને ઝિક્ર"));
        l.add(Task.make("sleep", "😴", "Slept on time last night", Task.CHOICE, 1, "", 2)
                .choices(new String[]{"Before 11 PM", "11 PM – 12 AM", "After 12 AM", "Barely slept"}, new int[]{100, 60, 20, 0})
                .guName("ગઈકાલ સમયસર સૂતા").optGu(new String[]{"11 વાગ્યા પહેલાં", "11 – 12 વાગ્યે", "12 પછી", "ભાગ્યે જ સૂતા"}));
        l.add(Task.make("family", "🤝", "Family time / Good deed", Task.CHECK, 1, "", 1).guName("કુટુંબ સમય / નેકી"));
        l.add(Task.make("focus", "🧭", "Honest check: today I was…", Task.CHOICE, 1, "", 1)
                .choices(new String[]{"Fully focused", "Mostly focused", "Distracted", "Wasted the day"}, new int[]{100, 70, 30, 0})
                .guName("સાચો જવાબ: આજે હું…").optGu(new String[]{"પૂરો ધ્યાનમાં", "મોટેભાગે ધ્યાનમાં", "ભટકેલો", "દિવસ બરબાદ કર્યો"}));
        return l;
    }

    private static JSONArray defaultApps() {
        JSONArray a = new JSONArray();
        String[][] d = {
                {"com.instagram.android", "Instagram", "20"},
                {"com.google.android.youtube", "YouTube", "30"},
                {"com.facebook.katana", "Facebook", "15"},
                {"com.snapchat.android", "Snapchat", "10"},
                {"com.twitter.android", "X (Twitter)", "15"}};
        try {
            for (String[] r : d) {
                JSONObject o = new JSONObject();
                o.put("pkg", r[0]);
                o.put("name", r[1]);
                o.put("limit", Integer.parseInt(r[2]));
                a.put(o);
            }
        } catch (Exception ignored) {
        }
        return a;
    }

    // ---------- tasks ----------
    public List<Task> tasks() {
        List<Task> l = new ArrayList<Task>();
        try {
            JSONArray a = new JSONArray(s("tasks", "[]"));
            for (int k = 0; k < a.length(); k++) l.add(Task.from(a.getJSONObject(k)));
        } catch (Exception ignored) {
        }
        return l;
    }

    /** Active tasks scheduled for that date. */
    public List<Task> tasksOn(String date) {
        Calendar c = cal(date);
        List<Task> l = new ArrayList<Task>();
        Calendar e = cal(date);
        e.set(Calendar.HOUR_OF_DAY, 0);
        e.set(Calendar.MINUTE, 0);
        e.set(Calendar.SECOND, 0);
        e.set(Calendar.MILLISECOND, 0);
        long endOfDay = e.getTimeInMillis() + 86400000L;
        for (Task t : tasks()) if (t.active && t.onCal(c) && createdAt(t) < endOfDay) l.add(t);
        return l;
    }

    /** When a user-made task was created (its id is "t" + millis); 0 for built-in tasks. */
    public static long createdAt(Task t) {
        if (t.id == null || t.id.length() < 11 || t.id.charAt(0) != 't') return 0;
        try {
            return Long.parseLong(t.id.substring(1));
        } catch (Exception e) {
            return 0;
        }
    }

    public List<Task> activeTasks() {
        List<Task> l = new ArrayList<Task>();
        for (Task t : tasks()) if (t.active) l.add(t);
        return l;
    }

    public void saveTasks(List<Task> l) {
        JSONArray a = new JSONArray();
        try {
            for (Task t : l) a.put(t.toJson());
        } catch (Exception ignored) {
        }
        put("tasks", a.toString());
    }

    public void upsertTask(Task t) {
        List<Task> l = tasks();
        boolean found = false;
        for (int k = 0; k < l.size(); k++) {
            if (l.get(k).id.equals(t.id)) {
                l.set(k, t);
                found = true;
            }
        }
        if (!found) l.add(t);
        saveTasks(l);
    }

    public void deleteTask(String id) {
        List<Task> l = tasks();
        for (int k = l.size() - 1; k >= 0; k--) if (l.get(k).id.equals(id)) l.remove(k);
        saveTasks(l);
    }

    public void moveTask(String id, int dir) {
        List<Task> l = tasks();
        for (int k = 0; k < l.size(); k++) {
            if (l.get(k).id.equals(id)) {
                int j = k + dir;
                if (j >= 0 && j < l.size()) {
                    Task t = l.get(k);
                    l.set(k, l.get(j));
                    l.set(j, t);
                    saveTasks(l);
                }
                return;
            }
        }
    }

    // ---------- daily entries ----------
    public JSONObject day(String date) {
        try {
            return new JSONObject(s("day_" + date, "{}"));
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    public double value(String date, Task t) {
        JSONObject d = day(date);
        return d.has(t.id) ? d.optDouble(t.id, t.emptyValue()) : t.emptyValue();
    }

    public void setValue(String date, Task t, double v) {
        JSONObject d = day(date);
        try {
            d.put(t.id, v);
        } catch (Exception ignored) {
        }
        put("day_" + date, d.toString());
        if (t.autoDone) markDone(date, t, v);
    }

    /** For "remove when completed" tasks: remember the first day it was completed (hidden from the next day). */
    private void markDone(String date, Task t, double v) {
        boolean full = t.frac(v) >= 0.999;
        List<Task> l = tasks();
        for (Task x : l) {
            if (!x.id.equals(t.id)) continue;
            String nd = x.doneOn == null ? "" : x.doneOn;
            if (full && (nd.length() == 0 || date.compareTo(nd) < 0)) nd = date;
            else if (!full && date.equals(nd)) nd = "";
            if (!nd.equals(x.doneOn)) {
                x.doneOn = nd;
                t.doneOn = nd;
                saveTasks(l);
            }
            return;
        }
    }

    // ---------- timers ----------
    public long timerStart(String taskId) {
        return l("timer_" + taskId, 0);
    }

    public void setTimer(String taskId, long start) {
        put("timer_" + taskId, start);
    }

    // ---------- monitored apps ----------
    public JSONArray apps() {
        try {
            return new JSONArray(s("apps", "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    public void saveApps(JSONArray a) {
        put("apps", a.toString());
    }

    public JSONObject usage(String date) {
        try {
            return new JSONObject(s("use_" + date, "{}"));
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    public void saveUsage(String date, JSONObject o) {
        put("use_" + date, o.toString());
    }

    /** Minutes over each app's limit, summed. */
    public int overMinutes(String date) {
        JSONObject u = usage(date);
        JSONArray a = apps();
        int over = 0;
        for (int k = 0; k < a.length(); k++) {
            JSONObject o = a.optJSONObject(k);
            if (o == null) continue;
            int used = u.optInt(o.optString("pkg"), 0);
            over += Math.max(0, used - o.optInt("limit", 30));
        }
        return over;
    }

    public int timepassMinutes(String date) {
        JSONObject u = usage(date);
        JSONArray a = apps();
        int sum = 0;
        for (int k = 0; k < a.length(); k++) {
            JSONObject o = a.optJSONObject(k);
            if (o != null) sum += u.optInt(o.optString("pkg"), 0);
        }
        return sum;
    }

    public int timepassLimit() {
        JSONArray a = apps();
        int sum = 0;
        for (int k = 0; k < a.length(); k++) {
            JSONObject o = a.optJSONObject(k);
            if (o != null) sum += o.optInt("limit", 30);
        }
        return sum;
    }

    // ---------- wisdom ----------
    public List<JSONObject> wisdom() {
        List<JSONObject> l = new ArrayList<JSONObject>();
        try {
            JSONArray a = new JSONArray(s("wisdom", "[]"));
            for (int k = 0; k < a.length(); k++) l.add(a.getJSONObject(k));
        } catch (Exception ignored) {
        }
        return l;
    }

    public void saveWisdom(List<JSONObject> l) {
        JSONArray a = new JSONArray();
        for (JSONObject o : l) a.put(o);
        put("wisdom", a.toString());
    }

    public void addWisdom(String ar, String en, String src, String topics) {
        List<JSONObject> l = wisdom();
        try {
            JSONObject o = new JSONObject();
            o.put("id", "u" + System.currentTimeMillis() + l.size());
            o.put("ar", ar == null ? "" : ar.trim());
            o.put("en", en.trim());
            o.put("gu", en.trim()); // user-pasted text shows in both languages
            o.put("src", src == null ? "" : src.trim());
            JSONArray t = new JSONArray();
            for (String s : topics.toLowerCase(Locale.US).split("[,;/ ]+")) if (s.trim().length() > 0) t.put(s.trim());
            if (t.length() == 0) t.put("discipline");
            o.put("topics", t);
            o.put("mine", true);
            l.add(o);
        } catch (Exception ignored) {
        }
        saveWisdom(l);
    }

    public void deleteWisdom(String id) {
        put("wisdom_deleted", s("wisdom_deleted", "|") + id + "|");
        List<JSONObject> l = wisdom();
        for (int k = l.size() - 1; k >= 0; k--) if (id.equals(l.get(k).optString("id"))) l.remove(k);
        saveWisdom(l);
    }

    public boolean isFav(String id) {
        return s("favs", "").contains("|" + id + "|");
    }

    public void toggleFav(String id) {
        String f = s("favs", "");
        if (f.contains("|" + id + "|")) f = f.replace("|" + id + "|", "");
        else f = f + "|" + id + "|";
        put("favs", f);
    }

    public static boolean hasTopic(JSONObject o, String topic) {
        JSONArray t = o.optJSONArray("topics");
        if (t == null) return false;
        for (int k = 0; k < t.length(); k++) if (topic.equalsIgnoreCase(t.optString(k))) return true;
        return false;
    }

    /** Random wisdom matching any of the topics (falls back to anything). */
    public JSONObject pick(String... topics) {
        List<JSONObject> all = wisdom(), match = new ArrayList<JSONObject>();
        for (JSONObject o : all) for (String t : topics) if (hasTopic(o, t)) {
            match.add(o);
            break;
        }
        List<JSONObject> src = match.isEmpty() ? all : match;
        if (src.isEmpty()) return new JSONObject();
        return src.get(new Random().nextInt(src.size()));
    }

    /** A new item every day (cycles through everything before repeating). Stable for the whole day. */
    public JSONObject wisdomOfDay() {
        String key = "wod_" + today();
        JSONObject cur = byId(s(key, ""));
        if (cur != null) return cur;
        List<JSONObject> all = wisdom();
        if (all.isEmpty()) return new JSONObject();
        String seen = s("wod_seen", "|");
        List<JSONObject> fresh = new ArrayList<JSONObject>();
        for (JSONObject o : all) if (!seen.contains("|" + o.optString("id") + "|")) fresh.add(o);
        if (fresh.isEmpty()) {
            seen = "|";
            fresh = all;
        }
        JSONObject pick = fresh.get(new Random().nextInt(fresh.size()));
        put("wod_seen", seen + pick.optString("id") + "|");
        put(key, pick.optString("id"));
        return pick;
    }

    public static final String K_REFRESH = "refresh_topics";

    /** "Refresh" on the wisdom card: a different item from the chosen topics, avoiding recent repeats. */
    public JSONObject refreshWisdom() {
        String topics = s(K_REFRESH, "imamzaman,society");
        List<JSONObject> pool = new ArrayList<JSONObject>();
        for (JSONObject o : wisdom()) {
            if (topics.equals("all")) {
                pool.add(o);
                continue;
            }
            for (String t : topics.split(",")) if (hasTopic(o, t.trim())) {
                pool.add(o);
                break;
            }
        }
        if (pool.isEmpty()) pool = wisdom();
        if (pool.isEmpty()) return new JSONObject();
        String recent = s("refresh_recent", "|");
        List<JSONObject> fresh = new ArrayList<JSONObject>();
        for (JSONObject o : pool) if (!recent.contains("|" + o.optString("id") + "|")) fresh.add(o);
        if (fresh.isEmpty()) {
            recent = "|";
            fresh = pool;
        }
        JSONObject pick = fresh.get(new Random().nextInt(fresh.size()));
        put("refresh_recent", recent + pick.optString("id") + "|");
        put("wod_" + today(), pick.optString("id"));
        return pick;
    }

    public JSONObject byId(String id) {
        for (JSONObject o : wisdom()) if (id.equals(o.optString("id"))) return o;
        return null;
    }

    // ---------- feed ----------
    public synchronized JSONArray feed() {
        if (feedCache == null) {
            try {
                feedCache = new JSONArray(asset("feed.json"));
            } catch (Exception e) {
                feedCache = new JSONArray();
            }
        }
        return feedCache;
    }

    /** Today's ordered list of feed indices (deterministic per day, avoids repeats across days). */
    public static final String[] FEED_CATS = {"Health", "Habits", "Business", "Islam", "Quran", "Success", "Mind"};

    public boolean feedCatOn(String cat) {
        return !s("feed_off", "|").contains("|" + cat + "|");
    }

    public void setFeedCat(String cat, boolean on) {
        String off = s("feed_off", "|").replace("|" + cat + "|", "|");
        if (!on) off = off + cat + "|";
        put("feed_off", off);
    }

    /** Today's ordered list of feed indices (deterministic per day, only enabled categories). */
    public int[] todaysFeed() {
        JSONArray f = feed();
        List<Integer> ok = new ArrayList<Integer>();
        for (int k = 0; k < f.length(); k++) {
            JSONObject o = f.optJSONObject(k);
            if (o != null && feedCatOn(o.optString("cat"))) ok.add(k);
        }
        if (ok.isEmpty()) for (int k = 0; k < f.length(); k++) ok.add(k);
        int n = ok.size();
        int cap = Math.min(n, i(K_FEEDCAP, 12));
        int seed = i("feed_seed_" + today(), 0);
        Random r = new Random(1234567L + seed * 7919L);
        for (int k = n - 1; k > 0; k--) {
            int j = r.nextInt(k + 1);
            Integer t = ok.get(k);
            ok.set(k, ok.get(j));
            ok.set(j, t);
        }
        int start = Math.abs(dayNumber() * cap + seed * 5) % Math.max(1, n);
        int[] out = new int[cap];
        for (int k = 0; k < cap; k++) out[k] = ok.get((start + k) % n);
        return out;
    }
}
