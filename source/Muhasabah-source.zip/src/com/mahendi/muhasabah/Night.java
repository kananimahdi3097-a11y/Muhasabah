package com.mahendi.muhasabah;

/**
 * 🌙 Night shield: from a chosen time at night until the morning, social apps and browsers are locked —
 * the hours when most slips happen. While the night is running it can't be switched off, shortened or
 * have apps removed (only made stricter); the commitment lock protects it too.
 */
public final class Night {
    public static final String K_ON = "night_on", K_FROM = "night_from", K_TO = "night_to", K_OFF_APPS = "night_off_apps";
    public static final String BROWSERS = "browsers";
    /** What the shield covers: package (or "browsers") and a name. */
    public static final String[][] APPS = {
            {"com.instagram.android", "Instagram"}, {"com.instagram.lite", "Instagram Lite"},
            {"com.google.android.youtube", "YouTube"}, {"com.facebook.katana", "Facebook"},
            {"com.snapchat.android", "Snapchat"}, {"com.zhiliaoapp.musically", "TikTok"},
            {"in.mohalla.sharechat", "ShareChat"}, {"com.twitter.android", "X (Twitter)"},
            {BROWSERS, "Browsers (Chrome & others)"}};

    private Night() {
    }

    public static boolean on(Store s) {
        return s.b(K_ON, true);
    }

    public static int from(Store s) {
        return s.i(K_FROM, 23 * 60);
    }

    public static int to(Store s) {
        return s.i(K_TO, 5 * 60);
    }

    /** True while the night window is running right now. */
    public static boolean active(Store s) {
        if (!on(s)) return false;
        int m = Store.minuteOfDay(), f = from(s), t = to(s);
        if (f == t) return false;
        return f < t ? m >= f && m < t : m >= f || m < t;
    }

    public static boolean covers(Store s, String key) {
        return !s.s(K_OFF_APPS, "|").contains("|" + key + "|");
    }

    public static void setCovers(Store s, String key, boolean on) {
        String off = s.s(K_OFF_APPS, "|").replace("|" + key + "|", "|");
        if (!on) off = off + key + "|";
        s.put(K_OFF_APPS, off);
    }

    /** Is this app locked by the night shield right now? */
    public static boolean blocks(Store s, String pkg) {
        if (pkg == null || !active(s)) return false;
        if (GuardService.isBrowserPkg(pkg)) return covers(s, BROWSERS);
        for (String[] a : APPS) if (a[0].equals(pkg)) return covers(s, pkg);
        return false;
    }

    /** When tonight's shield ends (epoch ms). */
    public static long endsAt(Store s) {
        java.util.Calendar c = java.util.Calendar.getInstance();
        int t = to(s);
        c.set(java.util.Calendar.HOUR_OF_DAY, t / 60);
        c.set(java.util.Calendar.MINUTE, t % 60);
        c.set(java.util.Calendar.SECOND, 0);
        c.set(java.util.Calendar.MILLISECOND, 0);
        if (c.getTimeInMillis() <= System.currentTimeMillis()) c.add(java.util.Calendar.DAY_OF_YEAR, 1);
        return c.getTimeInMillis();
    }

    /** Settings may only be made stricter while the night is running or a commitment lock is on. */
    public static boolean frozen(Store s) {
        return active(s) || Lock.isLocked(s);
    }
}
