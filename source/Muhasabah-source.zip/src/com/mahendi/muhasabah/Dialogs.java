package com.mahendi.muhasabah;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.drawable.ColorDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/** All pop-up editors: tasks, wisdom, choices, minutes. */
public final class Dialogs {

    public interface IntCallback {
        void done(int value);
    }

    /** Dark rounded dialog with a scrollable body. */
    public static AlertDialog sheet(Activity a, String title, View body) {
        LinearLayout box = Ui.col(a);
        box.setPadding(Ui.dp(20), Ui.dp(20), Ui.dp(20), Ui.dp(16));
        box.setBackground(Ui.roundStroke(Ui.CARD, 26, Ui.STROKE, 1));
        if (title != null) {
            TextView t = Ui.title(a, title, 20);
            t.setPadding(0, 0, 0, Ui.dp(14));
            box.addView(t);
        }
        ScrollView sv = new ScrollView(a);
        sv.addView(body);
        box.addView(sv, new LinearLayout.LayoutParams(Ui.MATCH, 0, 1f));
        LinearLayout wrap = new LinearLayout(a) {
            @Override
            public boolean dispatchTouchEvent(android.view.MotionEvent ev) {
                Haptics.touch(this, ev);
                return super.dispatchTouchEvent(ev);
            }
        };
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.addView(box, new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        AlertDialog d = new AlertDialog.Builder(a).setView(wrap).create();
        if (d.getWindow() != null) d.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        return d;
    }

    private static TextView label(Activity a, String s) {
        TextView t = Ui.text(a, s, 12, Ui.SUB, true);
        t.setPadding(0, Ui.dp(12), 0, Ui.dp(6));
        return t;
    }

    /** Row of selectable pills. holder[0] keeps the selection. */
    public static View selector(final Activity a, final String[] labels, final int[] holder, final Runnable onChange) {
        HorizontalScrollView hs = new HorizontalScrollView(a);
        hs.setHorizontalScrollBarEnabled(false);
        final LinearLayout r = Ui.row(a);
        hs.addView(r);
        final Runnable[] paint = new Runnable[1];
        paint[0] = new Runnable() {
            @Override
            public void run() {
                for (int k = 0; k < r.getChildCount(); k++) {
                    TextView t = (TextView) r.getChildAt(k);
                    boolean sel = k == holder[0];
                    t.setBackground(sel ? Ui.grad(Ui.GOLD, Ui.GOLD_D, 50, android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT)
                            : Ui.roundStroke(Ui.CARD2, 50, Ui.STROKE, 1));
                    t.setTextColor(sel ? 0xFF1A1205 : Ui.SUB);
                }
            }
        };
        for (int k = 0; k < labels.length; k++) {
            final int idx = k;
            TextView t = Ui.text(a, labels[k], 13, Ui.SUB, true);
            t.setPadding(Ui.dp(14), Ui.dp(8), Ui.dp(14), Ui.dp(8));
            LinearLayout.LayoutParams p = Ui.lp(Ui.WRAP, Ui.WRAP);
            p.setMargins(0, 0, Ui.dp(8), 0);
            r.addView(t, p);
            t.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Haptics.play(Haptics.SELECT);
                    holder[0] = idx;
                    paint[0].run();
                    if (onChange != null) onChange.run();
                }
            });
        }
        paint[0].run();
        return hs;
    }

    // ---------------- task editor ----------------
    public static void editTask(final Activity a, Task existing, final Runnable onSaved) {
        final boolean isNew = existing == null;
        final Task t = isNew ? new Task() : existing;
        if (isNew) {
            t.id = "t" + System.currentTimeMillis();
            t.emoji = "⭐";
            t.type = Task.CHECK;
            t.target = 1;
            t.importance = 2;
        }
        LinearLayout body = Ui.col(a);
        LinearLayout top = Ui.row(a);
        final EditText emoji = Ui.input(a, "🙂", t.emoji, false);
        emoji.setGravity(Gravity.CENTER);
        top.addView(emoji, Ui.lpm(Ui.dp(64), Ui.WRAP, 0, 0, 10, 0));
        final EditText name = Ui.input(a, "Task name (e.g. Read 10 pages)", t.name, false);
        top.addView(name, Ui.weight(1));
        body.addView(top);

        body.addView(label(a, "HOW DO YOU MEASURE IT?"));
        final int[] type = {t.type};
        final LinearLayout targetBox = Ui.col(a), optBox = Ui.col(a);
        final TextView targetLbl = label(a, "DAILY TARGET");
        final EditText target = Ui.input(a, "Target", String.valueOf(t.target), true);
        final EditText unit = Ui.input(a, "Unit (pages, namaz, glasses…)", t.unit, false);
        final Runnable showHide = new Runnable() {
            @Override
            public void run() {
                targetBox.setVisibility(type[0] == Task.COUNT || type[0] == Task.MINUTES ? View.VISIBLE : View.GONE);
                unit.setVisibility(type[0] == Task.COUNT ? View.VISIBLE : View.GONE);
                optBox.setVisibility(type[0] == Task.CHOICE ? View.VISIBLE : View.GONE);
                targetLbl.setText(type[0] == Task.MINUTES ? "DAILY TARGET (MINUTES)" : "DAILY TARGET");
            }
        };
        body.addView(selector(a, Task.TYPE_NAMES, type, showHide));
        targetBox.addView(targetLbl);
        targetBox.addView(target);
        targetBox.addView(Ui.space(a, 8));
        targetBox.addView(unit);
        body.addView(targetBox);

        optBox.addView(label(a, "ANSWER OPTIONS — one per line, \"Answer = score %\""));
        final EditText opts = Ui.input(a, "Fully done = 100\nHalf done = 50\nNot done = 0", t.optionsAsText(), false);
        opts.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        opts.setMinLines(4);
        opts.setGravity(Gravity.TOP);
        optBox.addView(opts);
        body.addView(optBox);

        body.addView(label(a, "IMPORTANCE (more points)"));
        final int[] imp = {Math.max(0, Math.min(2, t.importance - 1))};
        body.addView(selector(a, new String[]{"Low · 1x", "Medium · 2x", "High · 3x"}, imp, null));

        // ---- schedule: which days + optional fixed time ----
        body.addView(label(a, Lang.pick("WHICH DAYS?", "કયા દિવસે?")));
        final int[] days = {t.days == 0 ? 127 : t.days};
        // one-time task: "" = repeats on the chosen days; otherwise only on this date (yyyy-MM-dd)
        final String[] onlyD = {isNew || !t.oneTime() ? "" : t.onlyDate};
        final TextView onlyBtn = Ui.pill(a, "📌 " + HadithCard.label("Today only", "ફક્ત આજે", "صرف آج", "सिर्फ़ आज"), Ui.alpha(Ui.EMERALD, 0.12f), Ui.EMERALD);
        final TextView dateBtn = Ui.pill(a, "", Ui.alpha(Ui.EMERALD, 0.12f), Ui.EMERALD);
        final LinearLayout dr = Ui.row(a);
        final String[] dn = Lang.dayInitials();
        final Runnable[] paintDays = new Runnable[1];
        paintDays[0] = new Runnable() {
            @Override
            public void run() {
                for (int k = 0; k < 7; k++) {
                    TextView d = (TextView) dr.getChildAt(k);
                    boolean on = (days[0] & (1 << k)) != 0;
                    d.setBackground(on ? Ui.circle(Ui.GOLD) : Ui.roundStroke(Ui.CARD2, 50, Ui.STROKE, 1));
                    d.setTextColor(on ? 0xFF1A1205 : Ui.SUB);
                }
                boolean one = onlyD[0].length() > 0, isToday = one && onlyD[0].equals(Store.today());
                dr.setAlpha(one ? 0.35f : 1f);
                paintPill(onlyBtn, isToday);
                paintPill(dateBtn, one && !isToday);
                dateBtn.setText(one && !isToday ? "📅 " + prettyDate(onlyD[0])
                        : "📅 " + HadithCard.label("On a date…", "કોઈ તારીખે…", "کسی تاریخ کو…", "किसी तारीख़ को…"));
            }
        };
        for (int k = 0; k < 7; k++) {
            final int bit = k;
            TextView d = Ui.text(a, dn[k], 13, Ui.SUB, true);
            d.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(Ui.dp(36), Ui.dp(36));
            p.setMargins(0, 0, Ui.dp(5), 0);
            dr.addView(d, p);
            d.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (onlyD[0].length() > 0) {
                        onlyD[0] = "";
                        days[0] = 0;
                    }
                    days[0] ^= (1 << bit);
                    paintDays[0].run();
                }
            });
        }
        body.addView(dr);
        LinearLayout quick = Ui.row(a);
        quick.setPadding(0, Ui.dp(8), 0, 0);
        String[][] qs = {{Lang.pick("Every day", "દરરોજ"), "127"}, {Lang.pick("Mon–Fri", "સોમ–શુક્ર"), "62"}, {Lang.pick("Weekend", "શનિ–રવિ"), "65"}};
        for (final String[] q : qs) {
            TextView b = Ui.pill(a, q[0], Ui.alpha(Ui.GOLD, 0.12f), Ui.GOLD);
            b.setPadding(Ui.dp(12), Ui.dp(6), Ui.dp(12), Ui.dp(6));
            LinearLayout.LayoutParams p = Ui.lp(Ui.WRAP, Ui.WRAP);
            p.setMargins(0, 0, Ui.dp(8), 0);
            quick.addView(b, p);
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onlyD[0] = "";
                    days[0] = Integer.parseInt(q[1]);
                    paintDays[0].run();
                }
            });
        }
        body.addView(quick);
        // one-time options on their own row
        LinearLayout once = Ui.row(a);
        once.setPadding(0, Ui.dp(8), 0, 0);
        for (TextView b : new TextView[]{onlyBtn, dateBtn}) {
            b.setPadding(Ui.dp(12), Ui.dp(6), Ui.dp(12), Ui.dp(6));
            LinearLayout.LayoutParams p = Ui.lp(Ui.WRAP, Ui.WRAP);
            p.setMargins(0, 0, Ui.dp(8), 0);
            once.addView(b, p);
        }
        body.addView(once);
        onlyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Haptics.play(Haptics.SELECT);
                if (onlyD[0].equals(Store.today())) {
                    onlyD[0] = "";
                    days[0] = 127;
                } else {
                    onlyD[0] = Store.today();
                    days[0] = 1 << (Store.cal(onlyD[0]).get(java.util.Calendar.DAY_OF_WEEK) - 1);
                }
                paintDays[0].run();
            }
        });
        dateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Haptics.play(Haptics.SELECT);
                java.util.Calendar c = onlyD[0].length() > 0 ? Store.cal(onlyD[0]) : java.util.Calendar.getInstance();
                if (onlyD[0].length() == 0) c.add(java.util.Calendar.DAY_OF_YEAR, 1);
                android.app.DatePickerDialog dp = new android.app.DatePickerDialog(a, android.R.style.Theme_DeviceDefault_Dialog_Alert,
                        new android.app.DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(android.widget.DatePicker view, int y, int m, int d) {
                                java.util.Calendar k = java.util.Calendar.getInstance();
                                k.set(y, m, d, 12, 0, 0);
                                onlyD[0] = Store.fmt(k);
                                days[0] = 1 << (k.get(java.util.Calendar.DAY_OF_WEEK) - 1);
                                paintDays[0].run();
                            }
                        }, c.get(java.util.Calendar.YEAR), c.get(java.util.Calendar.MONTH), c.get(java.util.Calendar.DAY_OF_MONTH));
                dp.getDatePicker().setMinDate(Store.startOfToday());
                dp.show();
            }
        });
        paintDays[0].run();

        // remove the task once it is completed (gone from the next day)
        final Switch autoDel = new Switch(a);
        autoDel.setText(HadithCard.label("🗑️ Remove this task once it's completed (it won't show from the next day)",
                "🗑️ પૂરું થાય પછી આ કામ દૂર કરો (બીજા દિવસથી નહીં દેખાય)",
                "🗑️ مکمل ہونے کے بعد یہ کام ہٹا دیں (اگلے دن سے نظر نہیں آئے گا)",
                "🗑️ पूरा होने के बाद यह काम हटा दें (अगले दिन से नहीं दिखेगा)"));
        autoDel.setTextColor(Ui.TEXT);
        autoDel.setChecked(t.autoDone);
        autoDel.setPadding(0, Ui.dp(12), 0, 0);
        body.addView(autoDel);

        body.addView(label(a, Lang.pick("AT A FIXED TIME? (optional)", "નક્કી સમયે? (વૈકલ્પિક)")));
        final int[] time = {t.time};
        LinearLayout tr = Ui.row(a);
        final TextView tbtn = Ui.ghost(a, "", Ui.GOLD);
        final TextView clear = Ui.text(a, "✕", 16, Ui.MUTED, true);
        clear.setPadding(Ui.dp(14), Ui.dp(8), Ui.dp(6), Ui.dp(8));
        final Switch remind = new Switch(a);
        final Runnable paintTime = new Runnable() {
            @Override
            public void run() {
                tbtn.setText(time[0] >= 0 ? "🕘  " + Ui.clock(time[0]) : Lang.pick("Any time — tap to set a time", "કોઈ પણ સમયે — સમય રાખવા ટૅપ કરો"));
                clear.setVisibility(time[0] >= 0 ? View.VISIBLE : View.GONE);
                remind.setVisibility(time[0] >= 0 ? View.VISIBLE : View.GONE);
            }
        };
        tr.addView(tbtn, Ui.weight(1));
        tr.addView(clear);
        body.addView(tr);
        tbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int cur = time[0] >= 0 ? time[0] : 21 * 60;
                new android.app.TimePickerDialog(a, android.R.style.Theme_DeviceDefault_Dialog_Alert, new android.app.TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(android.widget.TimePicker view, int h, int m) {
                        time[0] = h * 60 + m;
                        if (!remind.isChecked()) remind.setChecked(true);
                        paintTime.run();
                    }
                }, cur / 60, cur % 60, false).show();
            }
        });
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                time[0] = -1;
                paintTime.run();
            }
        });
        remind.setText(Lang.pick("Remind me at this time (repeats until I tap Done)", "આ સમયે યાદ કરાવો ('થઈ ગયું' દબાવું ત્યાં સુધી)"));
        remind.setTextColor(Ui.TEXT);
        remind.setChecked(t.remind || t.time < 0);
        remind.setPadding(0, Ui.dp(10), 0, 0);
        body.addView(remind);
        paintTime.run();

        final Switch active = new Switch(a);
        active.setText(Lang.pick("Task is active (turn off to pause it)", "કામ ચાલુ છે (થોભાવવા બંધ કરો)"));
        active.setTextColor(Ui.TEXT);
        active.setChecked(t.active);
        active.setPadding(0, Ui.dp(14), 0, 0);
        body.addView(active);
        showHide.run();

        body.addView(Ui.space(a, 18));
        TextView save = Ui.button(a, isNew ? "Add task" : "Save changes", Ui.EMERALD, Ui.TEAL, 0xFFFFFFFF);
        body.addView(save, Ui.lp(Ui.MATCH, Ui.WRAP));
        final AlertDialog d = sheet(a, isNew ? Lang.pick("New task", "નવું કામ") : Lang.pick("Edit task", "કામ બદલો"), body);
        if (!isNew) {
            body.addView(Ui.space(a, 10));
            TextView del = Ui.ghost(a, "Delete task", Ui.RED);
            body.addView(del, Ui.lp(Ui.MATCH, Ui.WRAP));
            del.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    confirm(a, "Delete \"" + t.name + "\"?", "Its history stays, but it won't show anymore.", new Runnable() {
                        @Override
                        public void run() {
                            Store.get(a).deleteTask(t.id);
                            Reminders.R lr = Reminders.forTask(a, t.id);
                            if (lr != null) Reminders.delete(a, lr.id);
                            d.dismiss();
                            if (onSaved != null) onSaved.run();
                        }
                    });
                }
            });
        }
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String n = name.getText().toString().trim();
                if (n.length() == 0) {
                    Toast.makeText(a, "Give the task a name", Toast.LENGTH_SHORT).show();
                    return;
                }
                t.name = n;
                String e = emoji.getText().toString().trim();
                t.emoji = e.length() == 0 ? "⭐" : e;
                t.type = type[0];
                t.importance = imp[0] + 1;
                t.active = active.isChecked();
                t.unit = unit.getText().toString().trim();
                try {
                    t.target = Math.max(1, Integer.parseInt(target.getText().toString().trim()));
                } catch (Exception ex) {
                    t.target = t.type == Task.MINUTES ? 30 : 1;
                }
                if (t.type == Task.CHECK) t.target = 1;
                if (t.type == Task.CHOICE) {
                    t.parseOptions(opts.getText().toString());
                    if (t.options.length < 2) {
                        Toast.makeText(a, "Add at least 2 answer options", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }
                if (days[0] == 0) {
                    Toast.makeText(a, Lang.pick("Pick at least one day", "ઓછામાં ઓછો એક દિવસ પસંદ કરો"), Toast.LENGTH_SHORT).show();
                    return;
                }
                t.days = days[0];
                t.onlyDate = onlyD[0];
                t.autoDone = autoDel.isChecked();
                if (!t.autoDone) t.doneOn = "";
                t.time = time[0];
                t.remind = time[0] >= 0 && remind.isChecked();
                Store.get(a).upsertTask(t);
                Reminders.syncTask(a, t);
                d.dismiss();
                if (onSaved != null) onSaved.run();
            }
        });
        d.show();
    }

    private static void paintPill(TextView b, boolean on) {
        b.setBackground(on ? Ui.grad(Ui.EMERALD, Ui.TEAL, 50, android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT)
                : Ui.round(Ui.alpha(Ui.EMERALD, 0.12f), 50));
        b.setTextColor(on ? 0xFFFFFFFF : Ui.EMERALD);
    }

    /** "Wed 28 Oct" in the UI language. */
    public static String prettyDate(String date) {
        java.util.Calendar c = Store.cal(date);
        return Lang.dayShort(c.get(java.util.Calendar.DAY_OF_WEEK) - 1) + " " + c.get(java.util.Calendar.DAY_OF_MONTH) + " "
                + c.getDisplayName(java.util.Calendar.MONTH, java.util.Calendar.SHORT, Lang.locale());
    }

    // ---------------- choice / minutes / count ----------------
    public static void chooseOption(final Activity a, Task t, int current, final IntCallback cb) {
        LinearLayout body = Ui.col(a);
        final AlertDialog[] d = new AlertDialog[1];
        String[] disp = t.displayOptions();
        for (int k = 0; k < t.options.length; k++) {
            final int idx = k;
            LinearLayout r = Ui.row(a);
            r.setPadding(Ui.dp(16), Ui.dp(14), Ui.dp(16), Ui.dp(14));
            boolean sel = k == current;
            r.setBackground(sel ? Ui.roundStroke(Ui.alpha(Ui.GOLD, 0.15f), 16, Ui.GOLD, 1.2f) : Ui.roundStroke(Ui.CARD2, 16, Ui.STROKE, 1));
            TextView n = Ui.text(a, k < disp.length ? disp[k] : t.options[k], 16, Ui.TEXT, true);
            r.addView(n, Ui.weight(1));
            int sc = k < t.optionScores.length ? t.optionScores[k] : 0;
            r.addView(Ui.pill(a, sc + "%", Ui.alpha(sc >= 70 ? Ui.EMERALD : sc >= 40 ? Ui.GOLD : Ui.RED, 0.2f),
                    sc >= 70 ? Ui.EMERALD : sc >= 40 ? Ui.GOLD : Ui.RED));
            body.addView(r, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 8));
            Ui.press(r);
            r.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    d[0].dismiss();
                    cb.done(idx);
                }
            });
        }
        d[0] = sheet(a, t.emoji + "  " + t.display(), body);
        d[0].show();
    }

    /** Localized label for a wisdom topic key. */
    public static String topicLabel(String topic) {
        String l = topicLabel0(topic);
        return Lang.gu() ? l : Lang.tr(l);
    }

    private static String topicLabel0(String topic) {
        if (Lang.gu()) {
            if (topic.equals("time")) return "સમય";
            if (topic.equals("discipline")) return "શિસ્ત";
            if (topic.equals("laziness")) return "આળસ";
            if (topic.equals("sleep")) return "ઊંઘ";
            if (topic.equals("work")) return "કામ";
            if (topic.equals("accountability")) return "હિસાબ";
            if (topic.equals("betterday")) return "બહેતર દિવસ";
            if (topic.equals("gratitude")) return "શુક્ર";
            if (topic.equals("patience")) return "સબ્ર";
            if (topic.equals("knowledge")) return "ઇલ્મ";
            if (topic.equals("gaze")) return "નજર";
            if (topic.equals("purity")) return "પાકીઝગી";
            if (topic.equals("akl")) return "અક્લ";
            if (topic.equals("reels")) return "રીલ્સ";
            if (topic.equals("imamzaman")) return "ઇમામે ઝમાના (અ.ત.ફ.શ.)";
            if (topic.equals("society")) return "સમાજ";
        }
        if (topic.equals("imamzaman")) return "Imam-e-Zamana (a.t.f.s.)";
        if (topic.equals("society")) return "Society";
        if (topic.equals("betterday")) return "Better day";
        return Character.toUpperCase(topic.charAt(0)) + topic.substring(1);
    }

    /** Small reminder popup used by the na-mahram counter. */
    public static void reminderToast(final Activity a, String msg, org.json.JSONObject w) {
        android.widget.Toast.makeText(a, msg, android.widget.Toast.LENGTH_SHORT).show();
        try {
            Notify.channels(a);
            Notify.post(a, 461, Notify.CH_NUDGE, Lang.pick("👁️ Guard your gaze", "👁️ નજર સાચવો"),
                    msg, w);
        } catch (Exception ignored) {
        }
    }

    public static void addAmount(final Activity a, final Task t, final IntCallback cb) {
        LinearLayout body = Ui.col(a);
        final AlertDialog[] d = new AlertDialog[1];
        boolean minutes = t.type == Task.MINUTES;
        TextView hint = Ui.text(a, minutes ? "Add minutes you already did:" : "Add to today's count:", 14, Ui.SUB, false);
        body.addView(hint);
        body.addView(Ui.space(a, 10));
        int[] quick = minutes ? new int[]{5, 10, 15, 30, 45, 60} : new int[]{1, 2, 3, 5, 10, 20};
        LinearLayout grid = Ui.col(a);
        LinearLayout row = null;
        for (int k = 0; k < quick.length; k++) {
            if (k % 3 == 0) {
                row = Ui.row(a);
                grid.addView(row, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 8));
            }
            final int q = quick[k];
            TextView b = Ui.text(a, "+" + q + (minutes ? " min" : ""), 15, Ui.GOLD_L, true);
            b.setGravity(Gravity.CENTER);
            b.setPadding(0, Ui.dp(12), 0, Ui.dp(12));
            b.setBackground(Ui.roundStroke(Ui.CARD2, 14, Ui.STROKE, 1));
            Ui.press(b);
            LinearLayout.LayoutParams p = Ui.weight(1);
            p.setMargins(k % 3 == 0 ? 0 : Ui.dp(4), 0, k % 3 == 2 ? 0 : Ui.dp(4), 0);
            row.addView(b, p);
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    d[0].dismiss();
                    cb.done(q);
                }
            });
        }
        body.addView(grid);
        body.addView(label(a, "OR TYPE AN AMOUNT (use minus to correct, e.g. -10)"));
        final EditText custom = Ui.input(a, "e.g. 25", "", false);
        custom.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED);
        body.addView(custom);
        body.addView(Ui.space(a, 12));
        TextView ok = Ui.button(a, "Add", Ui.EMERALD, Ui.TEAL, 0xFFFFFFFF);
        body.addView(ok, Ui.lp(Ui.MATCH, Ui.WRAP));
        d[0] = sheet(a, t.emoji + "  " + t.name, body);
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    int n = Integer.parseInt(custom.getText().toString().trim());
                    d[0].dismiss();
                    cb.done(n);
                } catch (Exception e) {
                    Toast.makeText(a, "Type a number", Toast.LENGTH_SHORT).show();
                }
            }
        });
        d[0].show();
    }

    public static void confirm(Activity a, String title, String msg, final Runnable yes) {
        LinearLayout body = Ui.col(a);
        body.addView(Ui.text(a, msg, 15, Ui.SUB, false));
        body.addView(Ui.space(a, 16));
        LinearLayout r = Ui.row(a);
        TextView no = Ui.ghost(a, "Cancel", Ui.SUB);
        TextView ok = Ui.button(a, "Yes", Ui.RED, 0xFFBE123C, 0xFFFFFFFF);
        r.addView(no, Ui.weight(1));
        r.addView(Ui.space(a, 1), Ui.lp(Ui.dp(10), 1));
        r.addView(ok, Ui.weight(1));
        body.addView(r);
        final AlertDialog d = sheet(a, title, body);
        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                d.dismiss();
            }
        });
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Haptics.play(Haptics.WARN);
                d.dismiss();
                yes.run();
            }
        });
        d.show();
    }

    // ---------------- wisdom ----------------
    public static final String[] TOPICS = {"imamzaman", "society", "time", "purity", "gaze", "reels", "akl", "discipline", "laziness",
            "sleep", "work", "accountability", "betterday", "gratitude", "patience", "knowledge"};

    public static void addWisdom(final Activity a, final Runnable onSaved) {
        LinearLayout body = Ui.col(a);
        body.addView(label(a, "HADITH / AYAH (English or Gujarati)"));
        final EditText en = Ui.input(a, "Paste the translation here", "", false);
        en.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        en.setMinLines(3);
        en.setGravity(Gravity.TOP);
        body.addView(en);
        body.addView(label(a, "ARABIC TEXT (optional)"));
        final EditText ar = Ui.input(a, "النص العربي", "", false);
        ar.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        ar.setTextDirection(View.TEXT_DIRECTION_RTL);
        body.addView(ar);
        body.addView(label(a, "REFERENCE"));
        final EditText src = Ui.input(a, "e.g. Imam Ali (a.s.) — Nahj al-Balagha, Saying 21", "", false);
        body.addView(src);
        body.addView(label(a, "WHEN SHOULD IT APPEAR? (tap one)"));
        final int[] topic = {0};
        String[] tlabels = new String[TOPICS.length];
        for (int k = 0; k < TOPICS.length; k++) tlabels[k] = topicLabel(TOPICS[k]);
        body.addView(selector(a, tlabels, topic, null));
        body.addView(Ui.space(a, 18));
        TextView save = Ui.button(a, "Save to my library", Ui.GOLD, Ui.GOLD_D, 0xFF1A1205);
        body.addView(save, Ui.lp(Ui.MATCH, Ui.WRAP));
        final AlertDialog d = sheet(a, "Add Hadith / Ayah", body);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (en.getText().toString().trim().length() < 3) {
                    Toast.makeText(a, "Paste the text first", Toast.LENGTH_SHORT).show();
                    return;
                }
                Store.get(a).addWisdom(ar.getText().toString(), en.getText().toString(), src.getText().toString(), TOPICS[topic[0]]);
                d.dismiss();
                if (onSaved != null) onSaved.run();
            }
        });
        d.show();
    }

    private static boolean hasArabic(String s) {
        for (int k = 0; k < s.length(); k++) {
            char c = s.charAt(k);
            if (c >= 0x0600 && c <= 0x06FF) return true;
        }
        return false;
    }

    /**
     * Bulk import. Blocks are separated by a blank line. Inside a block:
     * Arabic lines → Arabic text; a line starting with "—", "-", "Ref:" or "Source:" → reference;
     * a line starting with "#" → topics (e.g. "#time #sleep"); everything else → translation.
     * Also accepts one-line "translation | reference | topic".
     */
    public static int importText(Activity a, String raw) {
        Store s = Store.get(a);
        int n = 0;
        String[] blocks = raw.replace("\r", "").split("\n\\s*\n");
        for (String block : blocks) {
            String b = block.trim();
            if (b.length() == 0) continue;
            if (!b.contains("\n") && b.contains("|")) {
                String[] parts = b.split("\\|");
                String en = parts[0].trim();
                String ref = parts.length > 1 ? parts[1].trim() : "";
                String tp = parts.length > 2 ? parts[2].trim() : "discipline";
                if (en.length() > 2) {
                    s.addWisdom(hasArabic(en) ? en : "", hasArabic(en) ? en : en, ref, tp);
                    n++;
                }
                continue;
            }
            StringBuilder ar = new StringBuilder(), en = new StringBuilder();
            String ref = "", tp = "";
            for (String line0 : b.split("\n")) {
                String line = line0.trim();
                if (line.length() == 0) continue;
                String low = line.toLowerCase();
                if (line.startsWith("#")) tp += " " + line.replace("#", " ");
                else if (line.startsWith("—") || line.startsWith("- ") || low.startsWith("ref:") || low.startsWith("source:")
                        || low.startsWith("reference:"))
                    ref = line.replaceFirst("^(—|- |[Rr]ef:|[Ss]ource:|[Rr]eference:)\\s*", "");
                else if (hasArabic(line) && en.length() == 0) ar.append(ar.length() > 0 ? " " : "").append(line);
                else en.append(en.length() > 0 ? " " : "").append(line);
            }
            String e = en.toString().trim();
            if (e.length() == 0 && ar.length() > 0) e = ar.toString();
            if (e.length() > 2) {
                s.addWisdom(ar.toString(), e, ref, tp.trim().length() == 0 ? "discipline" : tp);
                n++;
            }
        }
        return n;
    }

    public static void importWisdom(final Activity a, final Runnable onSaved) {
        LinearLayout body = Ui.col(a);
        body.addView(Ui.text(a, "Paste many at once. Leave a blank line between each one.\n\n"
                + "Example:\nقِيمَةُ كُلِّ امْرِئٍ مَا يُحْسِنُهُ\nThe worth of every person is in what he does well.\n— Nahj al-Balagha, Saying 81\n#work\n\n"
                + "Or one per line:  text | reference | topic", 13, Ui.SUB, false));
        body.addView(Ui.space(a, 12));
        final EditText box = Ui.input(a, "Paste here…", "", false);
        box.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        box.setMinLines(8);
        box.setGravity(Gravity.TOP);
        body.addView(box);
        body.addView(Ui.space(a, 14));
        TextView go = Ui.button(a, "Import", Ui.GOLD, Ui.GOLD_D, 0xFF1A1205);
        body.addView(go, Ui.lp(Ui.MATCH, Ui.WRAP));
        final AlertDialog d = sheet(a, "Import Hadith / Ayat", body);
        go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int n = importText(a, box.getText().toString());
                Toast.makeText(a, n == 0 ? "Nothing found to import" : "Imported " + n + " ✓", Toast.LENGTH_SHORT).show();
                if (n > 0) {
                    d.dismiss();
                    if (onSaved != null) onSaved.run();
                }
            }
        });
        d.show();
    }

    /** Simple single text input. */
    public static void prompt(final Activity a, String title, String value, final boolean number, final java.util.List<String> out, final Runnable done) {
        LinearLayout body = Ui.col(a);
        final EditText e = Ui.input(a, "", value, number);
        body.addView(e);
        body.addView(Ui.space(a, 14));
        TextView ok = Ui.button(a, "Save", Ui.EMERALD, Ui.TEAL, 0xFFFFFFFF);
        body.addView(ok, Ui.lp(Ui.MATCH, Ui.WRAP));
        final AlertDialog d = sheet(a, title, body);
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                out.clear();
                out.add(e.getText().toString().trim());
                d.dismiss();
                done.run();
            }
        });
        d.show();
    }

    static void unused(List<String> l) {
    }
}
