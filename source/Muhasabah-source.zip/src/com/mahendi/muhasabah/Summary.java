package com.mahendi.muhasabah;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/** Number-crunching for the Day / Week / Month summaries. */
public final class Summary {

    public static class TaskStat {
        public Task task;
        public int scheduled, done;
        public double total; // minutes or count summed
        public double avgFrac;

        public int pct() {
            return scheduled == 0 ? 0 : Math.round(done * 100f / scheduled);
        }
    }

    public static class Period {
        public String from, to; // inclusive, yyyy-MM-dd
        public List<String> dates = new ArrayList<String>(); // only up to today
        public int[] scores;
        public int avg, best = -1, worst = 101, betterDays, goodDays, daysWithData;
        public String bestDate = "", worstDate = "";
        public int timepass, reels, namahram;
        public List<TaskStat> tasks = new ArrayList<TaskStat>();
        public int completion; // all tasks, % of scheduled that were completed
    }

    public static String fmt(Calendar c) {
        return Store.fmt(c);
    }

    /** Monday-start week containing date. */
    public static String[] weekOf(String date) {
        Calendar c = Store.cal(date);
        int dow = c.get(Calendar.DAY_OF_WEEK); // Sun=1 … Sat=7
        int back = (dow + 5) % 7; // days since Monday
        c.add(Calendar.DAY_OF_YEAR, -back);
        String from = fmt(c);
        c.add(Calendar.DAY_OF_YEAR, 6);
        return new String[]{from, fmt(c)};
    }

    public static String[] monthOf(String date) {
        Calendar c = Store.cal(date);
        c.set(Calendar.DAY_OF_MONTH, 1);
        String from = fmt(c);
        c.set(Calendar.DAY_OF_MONTH, c.getActualMaximum(Calendar.DAY_OF_MONTH));
        return new String[]{from, fmt(c)};
    }

    public static String shift(String date, int days) {
        Calendar c = Store.cal(date);
        c.add(Calendar.DAY_OF_YEAR, days);
        return fmt(c);
    }

    public static String shiftMonth(String date, int months) {
        Calendar c = Store.cal(date);
        c.set(Calendar.DAY_OF_MONTH, 1);
        c.add(Calendar.MONTH, months);
        return fmt(c);
    }

    public static int score(Store s, String d) {
        return d.equals(Store.today()) ? Score.compute(s, d).score : Score.dayScore(s, d);
    }

    public static boolean hasData(Store s, String d) {
        return s.p.contains("day_" + d) || s.p.contains("use_" + d) || d.equals(Store.today());
    }

    public static Period compute(Store s, String from, String to) {
        Period p = new Period();
        p.from = from;
        p.to = to;
        String today = Store.today();
        for (String d = from; Store.daysBetween(d, to) >= 0; d = shift(d, 1)) {
            if (Store.daysBetween(d, today) < 0) break; // future
            p.dates.add(d);
        }
        p.scores = new int[p.dates.size()];
        int sum = 0;
        for (int i = 0; i < p.dates.size(); i++) {
            String d = p.dates.get(i);
            int sc = score(s, d);
            p.scores[i] = sc;
            p.timepass += s.timepassMinutes(d);
            p.reels += s.reels(d);
            p.namahram += s.namahram(d);
            if (!hasData(s, d)) continue;
            p.daysWithData++;
            sum += sc;
            if (sc > p.best) {
                p.best = sc;
                p.bestDate = d;
            }
            if (sc < p.worst) {
                p.worst = sc;
                p.worstDate = d;
            }
            int prev = score(s, shift(d, -1));
            if (sc > 0 && (sc > prev || sc >= Score.goodDay(s))) p.betterDays++;
            if (sc >= Score.goodDay(s)) p.goodDays++;
        }
        p.avg = p.daysWithData == 0 ? 0 : Math.round(sum / (float) p.daysWithData);
        if (p.best < 0) p.best = 0;
        if (p.worst > 100) p.worst = 0;

        int allSched = 0, allDone = 0;
        for (Task t : s.tasks()) {
            TaskStat ts = new TaskStat();
            ts.task = t;
            double fsum = 0;
            for (String d : p.dates) {
                if (!t.onDate(d) || !t.active && !s.day(d).has(t.id)) continue;
                double v = Math.max(0, d.equals(today) ? Score.liveValue(s, t, d) : s.value(d, t));
                double f = t.frac(t.type == Task.CHOICE ? s.value(d, t) : v);
                ts.scheduled++;
                fsum += f;
                if (f >= 0.999) ts.done++;
                if (t.type == Task.MINUTES || t.type == Task.COUNT) ts.total += v;
            }
            if (ts.scheduled == 0) continue;
            ts.avgFrac = fsum / ts.scheduled;
            allSched += ts.scheduled;
            allDone += ts.done;
            p.tasks.add(ts);
        }
        p.completion = allSched == 0 ? 0 : Math.round(allDone * 100f / allSched);
        return p;
    }

    /** Same-length period just before this one. */
    public static Period previous(Store s, Period p, boolean month) {
        if (month) {
            String[] m = monthOf(shiftMonth(p.from, -1));
            return compute(s, m[0], m[1]);
        }
        int len = Store.daysBetween(p.from, p.to) + 1;
        return compute(s, shift(p.from, -len), shift(p.from, -1));
    }

    public static TaskStat find(Period p, String taskId) {
        for (TaskStat t : p.tasks) if (t.task.id.equals(taskId)) return t;
        return null;
    }
}
