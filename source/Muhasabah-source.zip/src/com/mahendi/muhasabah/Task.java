package com.mahendi.muhasabah;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/** One daily task. Types: tick box, count, minutes, or multiple-choice answer. */
public class Task {
    public static final int CHECK = 0, COUNT = 1, MINUTES = 2, CHOICE = 3;
    public static final String[] TYPE_NAMES = {"Yes / No", "Count", "Minutes (timer)", "Choice (answers)"};
    public static final String[] IMPORTANCE_NAMES = {"Low", "Medium", "High"};

    public String id;
    public String name = "";
    public String gu = ""; // optional Gujarati name for default tasks
    public String emoji = "✅";
    public String unit = "";
    public int type = CHECK;
    public int target = 1;
    public int importance = 2; // 1 low, 2 medium, 3 high
    public String[] options = new String[0];
    public int[] optionScores = new int[0];
    public boolean active = true;
    /** Days of week this task is for (bit 0 = Sunday … bit 6 = Saturday). 127 = every day. */
    public int days = 127;
    /** Fixed time (minute of day) or -1 for any time. */
    public int time = -1;
    /** Remind at the fixed time (repeats until Done). */
    public boolean remind = false;
    /** One-time task: only on this date ("yyyy-MM-dd"); empty = repeats on {@link #days}. */
    public String onlyDate = "";
    /** Remove after completion: hidden from the day after it was completed (doneOn). */
    public boolean autoDone = false;
    public String doneOn = "";

    public boolean onCal(java.util.Calendar c) {
        if (autoDone && doneOn != null && doneOn.length() > 0 && Store.fmt(c).compareTo(doneOn) > 0) return false; // finished
        if (onlyDate != null && onlyDate.length() > 0) return onlyDate.equals(Store.fmt(c));
        return (days & (1 << (c.get(java.util.Calendar.DAY_OF_WEEK) - 1))) != 0;
    }

    public boolean oneTime() {
        return onlyDate != null && onlyDate.length() > 0;
    }

    /** A one-time task whose day has passed. */
    public boolean expired() {
        if (autoDone && doneOn != null && doneOn.length() > 0 && doneOn.compareTo(Store.today()) < 0) return true;
        return oneTime() && onlyDate.compareTo(Store.today()) < 0;
    }

    public boolean onDate(String date) {
        return onCal(Store.cal(date));
    }

    /** e.g. "Thu · 9:00 PM", "Every day", "Mon, Wed" — empty when it's every day with no time. */
    public String scheduleLabel() {
        String d = days == 127 ? "" : Reminders.days(days);
        if (oneTime()) d = onlyDate.equals(Store.today()) ? HadithCard.label("Today only", "ફક્ત આજે", "صرف آج", "सिर्फ़ आज") : Dialogs.prettyDate(onlyDate);
        String tm = time >= 0 ? Ui.clock(time) : "";
        if (autoDone) d = (d.length() > 0 ? d + " · " : "") + "🗑️ " + HadithCard.label("removed when done", "પૂરું થયે દૂર", "مکمل ہونے پر ختم", "पूरा होने पर हटेगा");
        if (d.length() == 0 && tm.length() == 0) return "";
        return (tm.length() > 0 ? "🕘 " + tm : "") + (d.length() > 0 && tm.length() > 0 ? " · " : "") + (d.length() > 0 ? (oneTime() ? "📌 " : "📅 ") + d : "");
    }

    public static Task make(String id, String emoji, String name, int type, int target, String unit, int importance) {
        Task t = new Task();
        t.id = id;
        t.emoji = emoji;
        t.name = name;
        t.type = type;
        t.target = target;
        t.unit = unit;
        t.importance = importance;
        return t;
    }

    public Task choices(String[] opts, int[] scores) {
        options = opts;
        optionScores = scores;
        return this;
    }

    public Task guName(String g) {
        gu = g;
        return this;
    }

    public String display() {
        if (Lang.ur() || Lang.hi()) return Lang.tr(name);
        return Lang.gu() && gu != null && gu.length() > 0 ? gu : name;
    }

    public int weight() {
        return importance >= 3 ? 3 : (importance <= 1 ? 1 : 2);
    }

    /** Localized option labels when running in Gujarati (default tasks only). */
    public String[] displayOptions() {
        if (Lang.ur() || Lang.hi()) {
            String[] o = new String[options.length];
            for (int i = 0; i < o.length; i++) o[i] = Lang.tr(options[i]);
            return o;
        }
        if (!Lang.gu() || optionsGu == null || optionsGu.length != options.length) return options;
        return optionsGu;
    }

    public String[] optionsGu = new String[0];

    public Task optGu(String[] g) {
        optionsGu = g;
        return this;
    }

    public double emptyValue() {
        return type == CHOICE ? -1 : 0;
    }

    public double frac(double v) {
        switch (type) {
            case CHECK:
                return v >= 1 ? 1 : 0;
            case CHOICE: {
                int i = (int) v;
                return (i >= 0 && i < optionScores.length) ? Math.max(0, Math.min(100, optionScores[i])) / 100.0 : 0;
            }
            default:
                return target <= 0 ? 0 : Math.min(1.0, v / target);
        }
    }

    public String progressText(double v) {
        switch (type) {
            case CHECK:
                return v >= 1 ? "Done ✓" : "Not yet";
            case COUNT:
                return (int) v + " / " + target + (unit.length() > 0 ? " " + unit : "");
            case MINUTES:
                return Ui.hm((int) v) + " / " + Ui.hm(target);
            default: {
                int i = (int) v;
                return (i >= 0 && i < options.length) ? options[i] : "Tap to answer";
            }
        }
    }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("name", name);
        o.put("emoji", emoji);
        o.put("unit", unit);
        o.put("type", type);
        o.put("target", target);
        o.put("imp", importance);
        o.put("active", active);
        JSONArray a = new JSONArray(), s = new JSONArray();
        for (int i = 0; i < options.length; i++) {
            a.put(options[i]);
            s.put(i < optionScores.length ? optionScores[i] : 0);
        }
        o.put("opts", a);
        o.put("scores", s);
        if (gu != null && gu.length() > 0) o.put("gu", gu);
        o.put("days", days);
        o.put("time", time);
        o.put("remind", remind);
        if (oneTime()) o.put("only", onlyDate);
        if (autoDone) o.put("auto", true);
        if (doneOn != null && doneOn.length() > 0) o.put("doneOn", doneOn);
        if (optionsGu != null && optionsGu.length > 0) {
            JSONArray og = new JSONArray();
            for (String x : optionsGu) og.put(x);
            o.put("optsGu", og);
        }
        return o;
    }

    public static Task from(JSONObject o) {
        Task t = new Task();
        t.id = o.optString("id");
        t.name = o.optString("name");
        t.emoji = o.optString("emoji", "✅");
        t.unit = o.optString("unit", "");
        t.type = o.optInt("type", CHECK);
        t.target = o.optInt("target", 1);
        t.importance = o.optInt("imp", 2);
        t.active = o.optBoolean("active", true);
        JSONArray a = o.optJSONArray("opts"), s = o.optJSONArray("scores");
        int n = a == null ? 0 : a.length();
        t.options = new String[n];
        t.optionScores = new int[n];
        for (int i = 0; i < n; i++) {
            t.options[i] = a.optString(i);
            t.optionScores[i] = s == null ? 0 : s.optInt(i, 0);
        }
        t.gu = o.optString("gu", "");
        t.days = o.optInt("days", 127);
        if (t.days == 0) t.days = 127;
        t.time = o.optInt("time", -1);
        t.remind = o.optBoolean("remind", false);
        t.onlyDate = o.optString("only", "");
        t.autoDone = o.optBoolean("auto", false);
        t.doneOn = o.optString("doneOn", "");
        JSONArray og = o.optJSONArray("optsGu");
        if (og != null) {
            t.optionsGu = new String[og.length()];
            for (int i = 0; i < og.length(); i++) t.optionsGu[i] = og.optString(i);
        }
        return t;
    }

    /** "Option = 80" lines, used by the editor. */
    public String optionsAsText() {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < options.length; i++) {
            if (i > 0) b.append('\n');
            b.append(options[i]).append(" = ").append(i < optionScores.length ? optionScores[i] : 0);
        }
        return b.toString();
    }

    public void parseOptions(String text) {
        String[] lines = text.split("\n");
        java.util.ArrayList<String> o = new java.util.ArrayList<String>();
        java.util.ArrayList<Integer> s = new java.util.ArrayList<Integer>();
        for (String line : lines) {
            String l = line.trim();
            if (l.length() == 0) continue;
            int eq = l.lastIndexOf('=');
            int score = 100;
            String name = l;
            if (eq > 0) {
                name = l.substring(0, eq).trim();
                try {
                    score = Integer.parseInt(l.substring(eq + 1).replace("%", "").trim());
                } catch (Exception ignored) {
                    score = 0;
                }
            }
            o.add(name);
            s.add(Math.max(0, Math.min(100, score)));
        }
        options = o.toArray(new String[0]);
        optionScores = new int[s.size()];
        for (int i = 0; i < s.size(); i++) optionScores[i] = s.get(i);
    }
}
