package com.mahendi.muhasabah;

import android.icu.util.IslamicCalendar;

import java.util.Calendar;

/** Greetings that change by time of day, by day, and on every refresh — plus the Hijri date. */
public final class Greet {
    private static final String[][] MORNING_EN = {{
            "Subh bakhair ☀️", "Bismillah — a fresh start ✨", "Rise and shine, the day is yours 🌅", "Assalamu Alaikum, early riser 🌤️",
            "May your morning be full of barakah 🤲", "Ya Ali madad — let's begin 💪", "New day, new chance to beat yesterday 🚀",
            "Alhamdulillah for another morning 🌿"}};
    private static final String[] MORNING_GU = {"સુબહ બખૈર ☀️", "બિસ્મિલ્લાહ — નવી શરૂઆત ✨", "ઊઠો, આજનો દિવસ તમારો છે 🌅",
            "અસ્સલામુ અલયકુમ 🌤️", "તમારી સવાર બરકતથી ભરેલી રહે 🤲", "યા અલી મદદ — ચાલો શરૂ કરીએ 💪",
            "નવો દિવસ, ગઈકાલને હરાવવાનો નવો મોકો 🚀", "બીજી સવાર માટે અલ્હમ્દુલિલ્લાહ 🌿"};
    private static final String[] DAY_EN = {"Assalamu Alaikum 👋", "Keep going — half the day is still yours ⏳", "Salam! Stay focused 🎯",
            "Ya Ali madad 💪", "Make this hour count ⚡", "You're doing well — push a little more 🔥", "Salam! One task at a time ✅"};
    private static final String[] DAY_GU = {"અસ્સલામુ અલયકુમ 👋", "ચાલુ રાખો — અડધો દિવસ હજી તમારો છે ⏳", "સલામ! ધ્યાન રાખો 🎯",
            "યા અલી મદદ 💪", "આ કલાકને કામનો બનાવો ⚡", "સરસ ચાલે છે — થોડું વધુ જોર 🔥", "સલામ! એક સમયે એક કામ ✅"};
    private static final String[] EVE_EN = {"Masa' al-khayr 🌇", "Evening check — how did today go? ⚖️", "Assalamu Alaikum 🌆",
            "Finish strong tonight 💫", "Time for a little muhasabah 🌙", "The day isn't over — win it 🏆"};
    private static final String[] EVE_GU = {"સાંજ મુબારક 🌇", "સાંજનો હિસાબ — આજ કેવો ગયો? ⚖️", "અસ્સલામુ અલયકુમ 🌆",
            "આજની રાત મજબૂત પૂરી કરો 💫", "થોડો મુહાસબો કરવાનો સમય 🌙", "દિવસ હજી બાકી છે — જીતી લો 🏆"};
    private static final String[] NIGHT_EN = {"Shab bakhair 🌙", "Rest well — Fajr is waiting 🌌", "Before sleep, count your blessings 🤲",
            "Put the phone down soon 😴", "Ya Sahib al-Zaman, adrikni 🤲", "Sleep with a clean heart 🤍"};
    private static final String[] NIGHT_GU = {"શબ બખૈર 🌙", "સારો આરામ કરો — ફજર રાહ જુએ છે 🌌", "સૂતાં પહેલાં નેમતો ગણો 🤲",
            "હવે ફોન મૂકી દો 😴", "યા સાહેબઝ્ઝમાન, અદરિકની 🤲", "સાફ દિલ સાથે સૂઈ જાઓ 🤍"};

    public static String greeting(Store s) {
        Calendar c = Calendar.getInstance();
        int h = c.get(Calendar.HOUR_OF_DAY);
        int n = Store.dayNumber() * 3 + s.i("greet_bump", 0);
        boolean friday = c.get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY;
        if (friday && s.i("greet_bump", 0) % 3 == 0) return Lang.pick("Jumu'ah Mubarak 🕌", "જુમ્આ મુબારક 🕌");
        String[] en, gu;
        if (h >= 4 && h < 12) {
            en = MORNING_EN[0];
            gu = MORNING_GU;
        } else if (h < 17 && h >= 12) {
            en = DAY_EN;
            gu = DAY_GU;
        } else if (h >= 17 && h < 21) {
            en = EVE_EN;
            gu = EVE_GU;
        } else {
            en = NIGHT_EN;
            gu = NIGHT_GU;
        }
        int i = Math.abs(n) % en.length;
        return Lang.pick(en[i], gu[i]);
    }

    /** Called on pull-to-refresh: next greeting. */
    public static void bump(Store s) {
        s.put("greet_bump", s.i("greet_bump", 0) + 1);
    }

    private static final String[] MONTHS_EN = {"Muharram", "Safar", "Rabi' al-Awwal", "Rabi' al-Thani", "Jumada al-Ula",
            "Jumada al-Akhirah", "Rajab", "Sha'ban", "Ramadan", "Shawwal", "Dhu al-Qa'dah", "Dhu al-Hijjah"};
    private static final String[] MONTHS_GU = {"મોહર્રમ", "સફર", "રબીઉલ અવ્વલ", "રબીઉલ આખર", "જમાદિલ અવ્વલ", "જમાદિલ આખર",
            "રજબ", "શાબાન", "રમઝાન", "શવ્વાલ", "ઝિલ્કાદ", "ઝિલ્હજ"};

    private static final String[] MONTHS_UR = {"محرم", "صفر", "ربیع الاول", "ربیع الثانی", "جمادی الاول", "جمادی الثانی",
            "رجب", "شعبان", "رمضان", "شوال", "ذیقعدہ", "ذی الحجہ"};
    private static final String[] MONTHS_HI = {"मुहर्रम", "सफ़र", "रबीउल अव्वल", "रबीउल आख़िर", "जमादिल अव्वल", "जमादिल आख़िर",
            "रजब", "शाबान", "रमज़ान", "शव्वाल", "ज़िलक़ाद", "ज़िलहिज्जा"};

    /** e.g. "11 Jumada al-Ula 1448" (Umm al-Qura, shifted by the user's adjustment). */
    public static String hijri(Store s) {
        try {
            IslamicCalendar ic = new IslamicCalendar();
            ic.setCalculationType(IslamicCalendar.CalculationType.ISLAMIC_UMALQURA);
            ic.setTimeInMillis(System.currentTimeMillis());
            int adj = Cfg.get(s, "hijri_adj");
            if (adj != 0) ic.add(IslamicCalendar.DAY_OF_MONTH, adj);
            int d = ic.get(IslamicCalendar.DAY_OF_MONTH), m = ic.get(IslamicCalendar.MONTH), y = ic.get(IslamicCalendar.YEAR);
            return d + " " + (Lang.gu() ? MONTHS_GU[m] : Lang.ur() ? MONTHS_UR[m] : Lang.hi() ? MONTHS_HI[m] : MONTHS_EN[m]) + " " + y;
        } catch (Throwable e) {
            return "";
        }
    }
}
