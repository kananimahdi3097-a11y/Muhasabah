package com.mahendi.muhasabah;

/** Start / pause / reset for minute-based tasks. State is always read fresh from storage. */
public final class Timers {
    public static boolean running(Store s, Task t) {
        return s.timerStart(t.id) > 0;
    }

    public static void start(Store s, Task t) {
        if (!running(s, t)) s.setTimer(t.id, System.currentTimeMillis());
    }

    /** Stops the timer and adds the elapsed time (to the second) to today's value. */
    public static void pause(Store s, Task t) {
        long st = s.timerStart(t.id);
        if (st <= 0) return;
        double mins = (System.currentTimeMillis() - st) / 60000.0;
        s.setTimer(t.id, 0);
        String d = Store.today();
        s.setValue(d, t, Math.max(0, s.value(d, t)) + mins);
    }

    public static void toggle(Store s, Task t) {
        if (running(s, t)) pause(s, t);
        else start(s, t);
    }

    /** Clears today's minutes and stops the timer. */
    public static void reset(Store s, Task t) {
        s.setTimer(t.id, 0);
        s.setValue(Store.today(), t, 0);
    }

    /** Seconds done today including the running part. */
    public static long secondsToday(Store s, Task t) {
        double v = Math.max(0, s.value(Store.today(), t)) * 60.0;
        long st = s.timerStart(t.id);
        if (st > 0) v += (System.currentTimeMillis() - st) / 1000.0;
        return (long) v;
    }

    public static String clock(long secs) {
        long h = secs / 3600, m = (secs % 3600) / 60, sec = secs % 60;
        String mm = (m < 10 && h > 0 ? "0" : "") + m, ss = (sec < 10 ? "0" : "") + sec;
        return h > 0 ? h + ":" + mm + ":" + ss : mm + ":" + ss;
    }
}
