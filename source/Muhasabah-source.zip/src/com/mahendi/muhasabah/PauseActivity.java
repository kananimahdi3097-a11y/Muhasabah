package com.mahendi.muhasabah;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONObject;

/** Full-screen pause shown when a timepass app goes far past its limit. */
public class PauseActivity extends Activity {
    @Override
    protected void attachBaseContext(android.content.Context b) {
        super.attachBaseContext(Ui.wrap(b));
    }

    @Override
    public boolean dispatchTouchEvent(android.view.MotionEvent ev) {
        Haptics.touch(getWindow().getDecorView(), ev);
        return super.dispatchTouchEvent(ev);
    }

    private TextView back, more, count;
    private String pkg;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.init(this);
        Store s = Store.get(this);
        Intent in = getIntent();
        pkg = in.getStringExtra("pkg");
        String name = in.getStringExtra("name");
        int used = in.getIntExtra("used", 0), lim = in.getIntExtra("limit", 0);

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFF0B3B33, 0xFF0A0E1A, 0xFF050811}));
        LinearLayout root = Ui.col(this);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(Ui.dp(24), Ui.dp(64), Ui.dp(24), Ui.dp(40));
        sv.addView(root);

        TextView chip = Ui.pill(this, "⏸  PAUSE", Ui.alpha(Ui.GOLD, 0.18f), Ui.GOLD);
        root.addView(chip);
        root.addView(Ui.space(this, 18));
        TextView big = Ui.title(this, used + " min", 54);
        big.setGravity(Gravity.CENTER);
        root.addView(big);
        TextView sub = Ui.text(this, "on " + name + " today · your limit was " + lim + " min", 15, Ui.SUB, false);
        sub.setGravity(Gravity.CENTER);
        root.addView(sub);
        if (s.b(Store.K_STRICT, true)) {
            root.addView(Ui.space(this, 14));
            TextView g = Ui.text(this, Lines.make(Store.get(this), Lines.SCROLL, true), 17, Ui.GOLD_L, true);
            g.setGravity(Gravity.CENTER);
            root.addView(g);
        }
        root.addView(Ui.space(this, 26));

        JSONObject w = s.pick("time", "accountability", "discipline", "laziness");
        LinearLayout card = Ui.col(this);
        card.setBackground(Ui.roundStroke(Ui.alpha(0xFF141A2B, 0.85f), 26, Ui.alpha(Ui.GOLD, 0.35f), 1.2f));
        card.setPadding(Ui.dp(20), Ui.dp(22), Ui.dp(20), Ui.dp(22));
        String ar = w.optString("ar");
        if (ar.length() > 0) {
            TextView a = Ui.text(this, ar, 24, Ui.GOLD_L, false);
            a.setGravity(Gravity.CENTER);
            a.setTextDirection(View.TEXT_DIRECTION_RTL);
            Ui.arabic(a);
            a.setLineSpacing(Ui.dp(6), 1f);
            card.addView(a);
            card.addView(Ui.space(this, 14));
        }
        LinearLayout tl = Ui.col(this);
        Ui.translations(this, tl, w, 17, true);
        for (int k = 0; k < tl.getChildCount(); k++) ((TextView) tl.getChildAt(k)).setGravity(Gravity.CENTER);
        card.addView(tl);
        TextView src = Ui.text(this, "— " + w.optString("src"), 12, Ui.SUB, false);
        src.setGravity(Gravity.CENTER);
        src.setPadding(0, Ui.dp(12), 0, 0);
        card.addView(src);
        root.addView(card, Ui.lp(Ui.MATCH, Ui.WRAP));

        root.addView(Ui.space(this, 26));
        count = Ui.text(this, "Take a breath…", 14, Ui.SUB, false);
        count.setGravity(Gravity.CENTER);
        root.addView(count);
        root.addView(Ui.space(this, 12));
        back = Ui.button(this, "🚀  Back to my goals", Ui.EMERALD, Ui.TEAL, 0xFFFFFFFF);
        root.addView(back, Ui.lp(Ui.MATCH, Ui.WRAP));
        root.addView(Ui.space(this, 10));
        more = Ui.ghost(this, "Give me 5 more minutes", Ui.SUB);
        root.addView(more, Ui.lp(Ui.MATCH, Ui.WRAP));
        setContentView(sv);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goHome();
            }
        });
        more.setEnabled(false);
        more.setAlpha(0.35f);
        more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Store.get(PauseActivity.this).put("snooze_" + pkg, System.currentTimeMillis() + 5 * 60000L);
                finish();
            }
        });
        new CountDownTimer(10000, 1000) {
            @Override
            public void onTick(long ms) {
                count.setText("Take a breath… " + (ms / 1000 + 1));
            }

            @Override
            public void onFinish() {
                if (Lock.isLocked(Store.get(PauseActivity.this))) {
                    count.setText(Lang.pick("🔒 Your rules are locked — no extra minutes now.", "🔒 નિયમ લૉક છે — હવે વધારાની મિનિટ નહીં."));
                    more.setVisibility(View.GONE);
                    return;
                }
                count.setText("Your choice. Choose wisely.");
                more.setEnabled(true);
                more.setAlpha(1f);
            }
        }.start();
        try {
            Vibrator vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            vib.vibrate(VibrationEffect.createWaveform(new long[]{0, 120, 80, 120}, -1));
        } catch (Exception ignored) {
        }
    }

    private void goHome() {
        Intent h = new Intent(Intent.ACTION_MAIN);
        h.addCategory(Intent.CATEGORY_HOME);
        h.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(h);
        finish();
    }

    @Override
    public void onBackPressed() {
        goHome();
    }
}
