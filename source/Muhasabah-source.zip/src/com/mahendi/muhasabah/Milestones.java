package com.mahendi.muhasabah;

/**
 * Clean days and milestones. A "clean day" is a recorded day with no screen-guard catch, no na-mahram glance
 * logged, reels within the limit and no private-tab attempt. Badges at 3, 7, 14, 30, 40 and 100 clean days in a row.
 */
public final class Milestones {
    public static final int[] BADGES = {3, 7, 14, 30, 40, 100};
    public static final String[] ICONS = {"🌱", "🌿", "🌳", "🌙", "⭐", "👑"};

    private Milestones() {
    }

    public static boolean clean(Store s, String date) {
        if (!Score.hasData(s, date)) return false;
        if (s.i(ScreenGuard.K_BLOCKS + date, 0) > 0) return false;
        if (s.namahram(date) > 0) return false;
        return s.reels(date) <= s.reelsLimit();
    }

    /** Clean days in a row, ending today (today counts once it's recorded and still clean). */
    public static int streak(Store s) {
        int n = 0;
        if (clean(s, Store.today())) n++;
        for (int k = -1; k > -1000; k--) {
            if (clean(s, Store.date(k))) n++;
            else break;
        }
        if (n > s.i("best_clean", 0)) s.put("best_clean", n);
        return n;
    }

    public static int best(Store s) {
        return Math.max(s.i("best_clean", 0), streak(s));
    }

    public static String name(int days) {
        switch (days) {
            case 3: return HadithCard.label("First steps", "પહેલાં પગલાં", "پہلے قدم", "पहले क़दम");
            case 7: return HadithCard.label("One clean week", "એક સાફ અઠવાડિયું", "ایک صاف ہفتہ", "एक साफ़ हफ़्ता");
            case 14: return HadithCard.label("Two weeks strong", "બે અઠવાડિયાં મજબૂત", "دو ہفتے مضبوط", "दो हफ़्ते मज़बूत");
            case 30: return HadithCard.label("A full month", "આખો મહિનો", "پورا مہینہ", "पूरा महीना");
            case 40: return HadithCard.label("Forty days", "ચાલીસ દિવસ", "چالیس دن", "चालीस दिन");
            default: return HadithCard.label("One hundred days", "સો દિવસ", "سو دن", "सौ दिन");
        }
    }
}
