package com.mahendi.muhasabah;

import android.content.Context;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Renders one referenced item (Quran ayah, graded hadith, Ghurar / Bihar saying or a practical step):
 * Arabic, the chosen translations, who said it, the full reference, grading / honesty label and credits.
 */
public final class HadithCard {
    private HadithCard() {
    }

    public static void fill(Context c, LinearLayout box, JSONObject it) {
        String ar = it.optString("ar");
        if (ar.length() > 0) {
            TextView a = Ui.text(c, ar, 19, Ui.GOLD_L, false);
            a.setTextDirection(View.TEXT_DIRECTION_RTL);
            Ui.arabic(a);
            a.setLineSpacing(Ui.dp(5), 1f);
            a.setPadding(0, Ui.dp(12), 0, Ui.dp(4));
            box.addView(a);
        }
        Ui.translations(c, box, it, 15.5f, false);
        String by = Daily.speaker(it.optString("by"));
        if (by.length() > 0) {
            TextView b = Ui.text(c, "— " + by, 13, Ui.TEXT, true);
            Fonts.applyMixed(b);
            b.setPadding(0, Ui.dp(6), 0, 0);
            box.addView(b);
        }
        TextView ref = Ui.text(c, "📚 " + it.optString("ref"), 12, Ui.SUB, false);
        Fonts.applyMixed(ref);
        ref.setPadding(0, Ui.dp(10), 0, 0);
        box.addView(ref);

        LinearLayout gl = Ui.row(c);
        gl.setPadding(0, Ui.dp(8), 0, 0);
        JSONArray gr = it.optJSONArray("grade");
        String kind = it.optString("kind");
        String note = it.optString("note");
        if (gr != null && gr.length() > 0) {
            for (int k = 0; k < gr.length() && k < 3; k++) {
                JSONObject g = gr.optJSONObject(k);
                if (g == null) continue;
                TextView chip = Ui.pill(c, "✓ " + g.optString("en") + " — " + g.optString("by"), Ui.alpha(Ui.EMERALD, 0.15f), Ui.EMERALD);
                chip.setTextSize(10.5f);
                LinearLayout.LayoutParams p = Ui.lp(Ui.WRAP, Ui.WRAP);
                p.setMargins(0, 0, Ui.dp(6), 0);
                gl.addView(chip, p);
            }
        } else if ("quran".equals(kind)) {
            gl.addView(Ui.pill(c, label("📖 Holy Quran", "📖 કુરાને મજીદ", "📖 قرآنِ مجید", "📖 क़ुरान-ए-मजीद"), Ui.alpha(Ui.GOLD, 0.14f), Ui.GOLD));
        } else if ("step".equals(kind)) {
            gl.addView(Ui.pill(c, label("🛠️ Practical step — advice, not a hadith", "🛠️ વ્યવહારુ પગલું — સલાહ, હદીસ નથી",
                    "🛠️ عملی قدم — مشورہ، حدیث نہیں", "🛠️ अमली क़दम — सलाह, हदीस नहीं"), Ui.alpha(Ui.BLUE, 0.14f), Ui.BLUE));
        } else if (note.startsWith("Compiled by") || it.optString("book").startsWith("Nahj")) {
            gl.addView(Ui.pill(c, label("Compiled by al-Sharif al-Radi", "સંકલન: શરીફ રઝી", "مرتب: سید رضی", "संकलन: शरीफ़ रज़ी"), Ui.alpha(Ui.GOLD, 0.14f), Ui.GOLD));
        } else if (it.optString("book").startsWith("Ghurar")) {
            gl.addView(Ui.pill(c, label("No chain · ungraded · attributed to Imam Ali (a.s.)", "સનદ વગર · ગ્રેડ નથી · ઇમામ અલી (અ.સ.)થી મન્સૂબ",
                    "بغیر سند · غیر درجہ بند · امام علیؑ سے منسوب", "बिना सनद · ग्रेड नहीं · इमाम अली (अ.स.) से मंसूब"), Ui.alpha(Ui.ORANGE, 0.14f), Ui.ORANGE));
        } else if (it.optString("book").startsWith("Bihar")) {
            gl.addView(Ui.pill(c, label("Not graded here — check the cited source", "અહીં ગ્રેડ નથી — મૂળ સ્રોત જુઓ",
                    "یہاں درجہ بندی نہیں — اصل ماخذ دیکھیں", "यहाँ ग्रेड नहीं — असल स्रोत देखें"), Ui.alpha(Ui.ORANGE, 0.14f), Ui.ORANGE));
        }
        if (gl.getChildCount() > 0) {
            HorizontalScrollView gs = new HorizontalScrollView(c);
            gs.setHorizontalScrollBarEnabled(false);
            gs.addView(gl);
            box.addView(gs);
        }
        String credit = it.optString("credit");
        if (credit.length() == 0) {
            String tr = it.optString("tr");
            credit = tr.length() > 0 ? "English: " + tr + " · Thaqalayn (CC BY 4.0)" + (it.optString("gu").length() > 0 ? " · other languages: Muhasabah" : "") : "";
        }
        if (credit.length() > 0) {
            TextView cr = Ui.text(c, credit + (it.optString("url").length() > 0 ? "   ↗" : ""), 10.5f, Ui.MUTED, false);
            cr.setPadding(0, Ui.dp(8), 0, 0);
            box.addView(cr);
        }
    }

    /** Opens the item's source page when the card is tapped (if it has one). */
    public static void link(final android.app.Activity a, View card, JSONObject it) {
        final String url = it.optString("url");
        if (url.length() == 0) return;
        Ui.press(card);
        card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    a.startActivity(new android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url)));
                } catch (Exception ignored) {
                }
            }
        });
    }

    static String label(String en, String gu, String ur, String hi) {
        switch (Lang.get()) {
            case Lang.GU:
                return gu;
            case Lang.UR:
                return ur;
            case Lang.HI:
                return hi;
            default:
                return en;
        }
    }
}
