package com.mahendi.muhasabah;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageInstaller;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;

/**
 * In-app updates. Reads update.json from the GitHub repo, and if a newer version exists,
 * downloads the APK for this variant (lite/full), checks its SHA-256, and hands it to Android's
 * PackageInstaller, which shows one "Update" confirmation. Same signing key → all data is kept.
 */
public final class Updater {
    /** Set to the raw GitHub folder that holds update.json, e.g. https://raw.githubusercontent.com/USER/muhasabah/main/ */
    public static final String BASE = "https://raw.githubusercontent.com/kananimahdi3097-a11y/muhasabah/main/";
    public static final String ACTION_STATUS = "com.mahendi.muhasabah.INSTALL_STATUS";

    public static class Info {
        public int versionCode;
        public String versionName, url, sha256, notes;
    }

    public interface Listener {
        void onResult(Info newer, String error); // newer == null → up to date

        void onProgress(int percent);
    }

    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    public static int installedCode(Context c) {
        try {
            PackageInfo pi = c.getPackageManager().getPackageInfo(c.getPackageName(), 0);
            return (int) pi.getLongVersionCode();
        } catch (Exception e) {
            return 0;
        }
    }

    public static String installedName(Context c) {
        try {
            return c.getPackageManager().getPackageInfo(c.getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "?";
        }
    }

    static byte[] get(String url, Listener progress) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
        con.setConnectTimeout(10000);
        con.setReadTimeout(20000);
        con.setRequestProperty("Cache-Control", "no-cache");
        con.setInstanceFollowRedirects(true);
        int code = con.getResponseCode();
        if (code != 200) throw new Exception("HTTP " + code);
        int len = con.getContentLength();
        InputStream in = con.getInputStream();
        ByteArrayOutputStream bo = new ByteArrayOutputStream(Math.max(len, 16384));
        byte[] buf = new byte[32768];
        int n, total = 0, lastPct = -1;
        while ((n = in.read(buf)) > 0) {
            bo.write(buf, 0, n);
            total += n;
            if (progress != null && len > 0) {
                final int pct = (int) (total * 100L / len);
                if (pct != lastPct) {
                    lastPct = pct;
                    final Listener l = progress;
                    MAIN.post(new Runnable() {
                        @Override
                        public void run() {
                            l.onProgress(pct);
                        }
                    });
                }
            }
        }
        in.close();
        con.disconnect();
        return bo.toByteArray();
    }

    /** Check in the background; result is delivered on the main thread. */
    public static void check(final Context c, final Listener l) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                Info info = null;
                String err = null;
                try {
                    String json = new String(get(BASE + "update.json?t=" + System.currentTimeMillis(), null), "UTF-8");
                    JSONObject o = new JSONObject(json);
                    int code = o.getInt("versionCode");
                    if (code > installedCode(c)) {
                        boolean full = GuardService.available(c);
                        info = new Info();
                        info.versionCode = code;
                        info.versionName = o.optString("versionName", String.valueOf(code));
                        info.url = BASE + (full ? o.optString("apk_full", "apk/Muhasabah.apk") : o.optString("apk_lite", "apk/Muhasabah_lite.apk"));
                        info.sha256 = full ? o.optString("sha256_full") : o.optString("sha256_lite");
                        info.notes = Lang.pick(o.optString("notes_en"), o.optString("notes_gu"));
                    }
                    Store.get(c).put("upd_checked", System.currentTimeMillis());
                } catch (Exception e) {
                    err = e.getMessage();
                }
                final Info fi = info;
                final String fe = err;
                MAIN.post(new Runnable() {
                    @Override
                    public void run() {
                        l.onResult(fi, fe);
                    }
                });
            }
        }).start();
    }

    /** True if Android lets this app install updates; otherwise opens the permission screen. */
    public static boolean ensureInstallPermission(Activity a) {
        if (a.getPackageManager().canRequestPackageInstalls()) return true;
        try {
            a.startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + a.getPackageName())));
        } catch (Exception ignored) {
        }
        return false;
    }

    /** Download, verify and start the install. Errors come back through the listener. */
    public static void downloadAndInstall(final Context c, final Info info, final Listener l) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    byte[] apk = get(info.url + "?t=" + System.currentTimeMillis(), l);
                    if (info.sha256 != null && info.sha256.length() == 64) {
                        String got = sha256(apk);
                        if (!got.equalsIgnoreCase(info.sha256)) throw new Exception("download damaged, try again");
                    }
                    File f = new File(c.getCacheDir(), "update.apk");
                    FileOutputStream fo = new FileOutputStream(f);
                    fo.write(apk);
                    fo.close();
                    install(c, f);
                } catch (final Exception e) {
                    MAIN.post(new Runnable() {
                        @Override
                        public void run() {
                            l.onResult(null, e.getMessage() == null ? "failed" : e.getMessage());
                        }
                    });
                }
            }
        }).start();
    }

    private static void install(Context c, File apk) throws Exception {
        PackageInstaller pi = c.getPackageManager().getPackageInstaller();
        PackageInstaller.SessionParams params = new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
        params.setAppPackageName(c.getPackageName());
        params.setSize(apk.length());
        int id = pi.createSession(params);
        PackageInstaller.Session s = pi.openSession(id);
        OutputStream out = s.openWrite("base.apk", 0, apk.length());
        InputStream in = new FileInputStream(apk);
        byte[] buf = new byte[65536];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        s.fsync(out);
        in.close();
        out.close();
        Intent cb = new Intent(c, InstallReceiver.class).setAction(ACTION_STATUS);
        PendingIntent pend = PendingIntent.getBroadcast(c, id, cb, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_MUTABLE);
        s.commit(pend.getIntentSender());
        s.close();
    }

    private static String sha256(byte[] b) throws Exception {
        byte[] d = MessageDigest.getInstance("SHA-256").digest(b);
        StringBuilder sb = new StringBuilder();
        for (byte x : d) sb.append(String.format("%02x", x));
        return sb.toString();
    }
}
