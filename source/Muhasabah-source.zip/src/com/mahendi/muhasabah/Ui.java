package com.mahendi.muhasabah;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Colours, sizes and small view factories shared by every screen. */
public final class Ui {
    public static final int BG = 0xFF0A0E1A;
    public static final int CARD = 0xFF141A2B;
    public static final int CARD2 = 0xFF1C2438;
    public static final int STROKE = 0xFF262F48;
    public static final int TEXT = 0xFFF3F5FA;
    public static final int SUB = 0xFF9AA3BC;
    public static final int MUTED = 0xFF5E6782;
    public static final int EMERALD = 0xFF10B981;
    public static final int EMERALD_D = 0xFF047857;
    public static final int TEAL = 0xFF0F766E;
    public static int GOLD = 0xFFF5C451;
    public static int GOLD_L = 0xFFFDE68A;
    public static int GOLD_D = 0xFFD99A1E;
    public static final int PURPLE = 0xFF8B5CF6;
    public static final int PINK = 0xFFEC4899;
    public static final int BLUE = 0xFF38BDF8;
    public static final int RED = 0xFFF43F5E;
    public static final int ORANGE = 0xFFFB923C;

    private static float density = 3f;

    /** Accent colours: main, light, dark. */
    public static final int[][] ACCENTS = {
            {0xFFF5C451, 0xFFFDE68A, 0xFFD99A1E}, // Gold
            {0xFF34D399, 0xFFA7F3D0, 0xFF059669}, // Emerald
            {0xFF60A5FA, 0xFFBFDBFE, 0xFF2563EB}, // Sapphire
            {0xFFF472B6, 0xFFFBCFE8, 0xFFDB2777}, // Rose
            {0xFFA78BFA, 0xFFDDD6FE, 0xFF7C3AED}, // Amethyst
    };
    public static final String[] ACCENT_NAMES = {"Gold", "Emerald", "Sapphire", "Rose", "Amethyst"};

    public static void init(Context c) {
        density = c.getResources().getDisplayMetrics().density;
        Fonts.init(c);
        Haptics.init(c);
        int[] a = ACCENTS[Math.max(0, Math.min(ACCENTS.length - 1, Store.get(c).i("accent", 0)))];
        GOLD = a[0];
        GOLD_L = a[1];
        GOLD_D = a[2];
    }

    public static int dp(float v) {
        return Math.round(v * density);
    }

    public static int alpha(int color, float a) {
        return (Math.round(a * 255) << 24) | (color & 0x00FFFFFF);
    }

    public static GradientDrawable round(int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    public static GradientDrawable roundStroke(int color, float radiusDp, int stroke, float strokeDp) {
        GradientDrawable g = round(color, radiusDp);
        g.setStroke(dp(strokeDp), stroke);
        return g;
    }

    public static GradientDrawable grad(int c1, int c2, float radiusDp, GradientDrawable.Orientation o) {
        GradientDrawable g = new GradientDrawable(o, new int[]{c1, c2});
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    public static GradientDrawable grad3(int c1, int c2, int c3, float radiusDp) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{c1, c2, c3});
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    public static GradientDrawable circle(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        return g;
    }

    public static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        t.setLineSpacing(0, 1.12f);
        t.setText(Fonts.mixed(Lang.tr(s, false)));
        fit(t, 0, sp * 0.6f);
        return t;
    }

    public static TextView title(Context c, String s, float sp) {
        TextView t = new TextView(c);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(TEXT);
        t.setTypeface(Typeface.create("sans-serif-black", Typeface.NORMAL));
        t.setLetterSpacing(-0.01f);
        t.setLineSpacing(0, 1.12f);
        t.setText(Fonts.mixed(Lang.tr(s, false)));
        fit(t, 0, sp * 0.6f);
        return t;
    }

    // ---------------- no broken words ----------------
    /** Largest system font size the app follows; bigger settings break the layout ("na-mahra / m"). */
    public static final float MAX_FONT = 1.1f;

    /** Use in every Activity's attachBaseContext. */
    public static Context wrap(Context b) {
        android.content.res.Configuration cf = b.getResources().getConfiguration();
        if (cf.fontScale <= MAX_FONT) return b;
        android.content.res.Configuration n = new android.content.res.Configuration(cf);
        n.fontScale = MAX_FONT;
        return b.createConfigurationContext(n);
    }

    private static final java.util.WeakHashMap<TextView, Fitter> FIT = new java.util.WeakHashMap<TextView, Fitter>();

    /**
     * Shrinks the text step by step (down to minSp) while a word is split across lines, or — when maxLines &gt; 0 —
     * while it needs more lines than that. Follows later setText / setTextSize calls.
     */
    public static void fit(TextView t, int maxLines, float minSp) {
        t.setHyphenationFrequency(android.text.Layout.HYPHENATION_FREQUENCY_NONE);
        if (maxLines > 0) {
            t.setMaxLines(maxLines);
            t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        }
        Fitter f = FIT.get(t);
        if (f == null) {
            f = new Fitter();
            FIT.put(t, f);
            t.addOnLayoutChangeListener(f);
        }
        f.maxLines = maxLines;
        f.minPx = minSp * t.getResources().getDisplayMetrics().scaledDensity;
    }

    private static final class Fitter implements View.OnLayoutChangeListener {
        int maxLines;
        float minPx, base = -1, lastSet = -1;
        String lastText;
        boolean pending;

        @Override
        public void onLayoutChange(View v, int l, int t, int r, int b, int ol, int ot, int or, int ob) {
            final TextView tv = (TextView) v;
            android.text.Layout lay = tv.getLayout();
            if (pending || lay == null || tv.getWidth() <= 0) return;
            float cur = tv.getTextSize();
            String txt = tv.getText().toString();
            if (base < 0 || (lastSet >= 0 && Math.abs(cur - lastSet) > 0.05f)) {
                base = cur; // first time, or someone set a new size
                lastSet = -1;
            } else if (lastText != null && !txt.equals(lastText) && cur < base - 0.05f) {
                lastText = txt; // new text: start again from the normal size
                set(tv, base);
                return;
            }
            lastText = txt;
            if (!broken(lay, txt)) return;
            float step = Math.max(0.5f, base / 24f), next = cur - step;
            if (next < minPx) return;
            set(tv, next);
        }

        private void set(final TextView tv, final float px) {
            lastSet = px;
            pending = true;
            tv.post(new Runnable() {
                @Override
                public void run() {
                    pending = false;
                    tv.setTextSize(TypedValue.COMPLEX_UNIT_PX, px);
                }
            });
        }

        /** A line ends in the middle of a word, or the text needs more than maxLines / got cut. */
        private boolean broken(android.text.Layout lay, String txt) {
            int lines = lay.getLineCount(), n = txt.length();
            if (maxLines > 0) {
                if (lines > maxLines) return true;
                for (int i = 0; i < Math.min(lines, maxLines); i++) if (lay.getEllipsisCount(i) > 0) return true;
            }
            for (int i = 0; i < lines - 1; i++) {
                int e = lay.getLineEnd(i);
                if (e <= 0 || e >= n) continue;
                if (wordChar(txt.charAt(e - 1)) && wordChar(txt.charAt(e))) return true;
            }
            return false;
        }

        private static boolean wordChar(char c) {
            if (Character.isLetterOrDigit(c)) return true;
            int t = Character.getType(c);
            return t == Character.NON_SPACING_MARK || t == Character.COMBINING_SPACING_MARK;
        }
    }

    public static LinearLayout col(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    public static LinearLayout row(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    public static LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    public static LinearLayout.LayoutParams lpm(int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    /** Equal-width cell for {@link #equalRow}. */
    public static LinearLayout.LayoutParams cell() {
        return new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
    }

    /** A row whose weighted children (tiles) all get the height of the tallest one, so the boxes line up. */
    public static LinearLayout equalRow(Context c) {
        LinearLayout l = new LinearLayout(c) {
            @Override
            protected void onMeasure(int wSpec, int hSpec) {
                super.onMeasure(wSpec, hSpec);
                int max = 0;
                for (int i = 0; i < getChildCount(); i++) {
                    View ch = getChildAt(i);
                    if (ch.getVisibility() != GONE && ((LinearLayout.LayoutParams) ch.getLayoutParams()).weight > 0)
                        max = Math.max(max, ch.getMeasuredHeight());
                }
                if (max <= 0) return;
                for (int i = 0; i < getChildCount(); i++) {
                    View ch = getChildAt(i);
                    if (ch.getVisibility() == GONE || ((LinearLayout.LayoutParams) ch.getLayoutParams()).weight <= 0) continue;
                    if (ch.getMeasuredHeight() != max)
                        ch.measure(MeasureSpec.makeMeasureSpec(ch.getMeasuredWidth(), MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(max, MeasureSpec.EXACTLY));
                }
                setMeasuredDimension(getMeasuredWidth(), Math.max(getMeasuredHeight(), max + getPaddingTop() + getPaddingBottom()));
            }
        };
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.TOP);
        return l;
    }

    public static LinearLayout.LayoutParams weight(float w) {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, w);
    }

    public static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    public static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    public static TextView pill(Context c, String s, int bg, int fg) {
        TextView t = text(c, s, 12, fg, true);
        t.setBackground(round(bg, 50));
        t.setPadding(dp(10), dp(4), dp(10), dp(4));
        t.setGravity(Gravity.CENTER);
        return t;
    }

    /** Big gradient button with press feedback. */
    public static TextView button(Context c, String s, int c1, int c2, int fg) {
        TextView t = text(c, s, 15, fg, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(grad(c1, c2, 16, GradientDrawable.Orientation.LEFT_RIGHT));
        t.setPadding(dp(18), dp(14), dp(18), dp(14));
        press(t);
        return t;
    }

    public static TextView ghost(Context c, String s, int fg) {
        TextView t = text(c, s, 14, fg, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(roundStroke(0x00000000, 14, alpha(fg, 0.5f), 1.2f));
        t.setPadding(dp(14), dp(10), dp(14), dp(10));
        press(t);
        return t;
    }

    public static void press(final View v) {
        v.setClickable(true);
        v.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    view.animate().scaleX(0.96f).scaleY(0.96f).setDuration(90).start();
                } else if (e.getAction() == MotionEvent.ACTION_UP || e.getAction() == MotionEvent.ACTION_CANCEL) {
                    view.animate().scaleX(1f).scaleY(1f).setDuration(140).start();
                }
                return false;
            }
        });
    }

    public static LinearLayout card(Context c) {
        LinearLayout l = col(c);
        l.setBackground(roundStroke(CARD, 22, STROKE, 1));
        l.setPadding(dp(16), dp(16), dp(16), dp(16));
        return l;
    }

    public static EditText input(Context c, String hint, String value, boolean number) {
        EditText e = new EditText(c);
        e.setHint(Lang.tr(hint, false));
        e.setText(value);
        e.setTextColor(TEXT);
        e.setHintTextColor(MUTED);
        e.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        e.setBackground(roundStroke(CARD2, 12, STROKE, 1));
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        if (number) e.setInputType(InputType.TYPE_CLASS_NUMBER);
        return e;
    }

    public static View space(Context c, int hdp) {
        View v = new View(c);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(hdp)));
        return v;
    }

    /** Thin progress bar made of two rounded rectangles. */
    public static View bar(Context c, float frac, int color, int heightDp) {
        LinearLayout track = row(c);
        track.setBackground(round(alpha(TEXT, 0.08f), 50));
        View fill = new View(c);
        fill.setBackground(grad(color, alpha(color, 0.75f), 50, GradientDrawable.Orientation.LEFT_RIGHT));
        float f = Math.max(0f, Math.min(1f, frac));
        track.setWeightSum(1f);
        track.addView(fill, new LinearLayout.LayoutParams(0, dp(heightDp), f));
        track.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(heightDp)));
        return track;
    }

    /** Adds the translation lines (English / Gujarati / Urdu / Hindi) the user chose, for a content item. */
    public static void translations(Context c, LinearLayout parent, org.json.JSONObject w, float sp, boolean quotes) {
        java.util.List<String[]> ts = Lang.texts(w, Lang.F_TEXT);
        String q1 = quotes ? "“" : "", q2 = quotes ? "”" : "";
        boolean first = true;
        for (String[] tx : ts) {
            String code = tx[0];
            TextView t = text(c, q1 + tx[1] + q2, code.equals("en") ? sp : sp + 0.5f, first ? TEXT : 0xFFE9DFC6, false);
            if (code.equals("gu")) {
                Fonts.applyGujarati(t, false);
                t.setLineSpacing(dp(2), 1f);
            } else if (code.equals("ur")) {
                Fonts.applyUrdu(t);
            }
            t.setPadding(0, dp(first ? 8 : 6), 0, 0);
            parent.addView(t);
            first = false;
        }
    }

    /** Kept for callers that only have English + Gujarati. */
    public static void translations(Context c, LinearLayout parent, String en, String gu, float sp, boolean quotes) {
        org.json.JSONObject o = new org.json.JSONObject();
        try {
            o.put("en", en == null ? "" : en);
            o.put("gu", gu == null ? "" : gu);
        } catch (Exception ignored) {
        }
        translations(c, parent, o, sp, quotes);
    }

    /** Round ⚙️ button that opens Settings. */
    public static TextView gear(final android.app.Activity a) {
        TextView g = text(a, "⚙️", 19, TEXT, false);
        g.setGravity(Gravity.CENTER);
        g.setBackground(circle(CARD2));
        press(g);
        g.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a.startActivity(new android.content.Intent(a, SettingsActivity.class));
            }
        });
        return g;
    }

    /** Applies the Al Qalam Quran Majeed Arabic font. */
    public static void arabic(TextView t) {
        Fonts.applyArabic(t);
    }

    public static String hm(int minutes) {
        if (minutes < 60) return minutes + (Lang.gu() ? " મિ" : Lang.ur() ? " منٹ" : Lang.hi() ? " मि" : " min");
        int h = minutes / 60, m = minutes % 60;
        if (Lang.ur()) return m == 0 ? h + " گھنٹے" : h + " گھنٹے " + m + " منٹ";
        if (Lang.hi()) return m == 0 ? h + " घंटे" : h + " घं " + m + " मि";
        return m == 0 ? h + "h" : h + "h " + m + "m";
    }

    public static String clock(int minuteOfDay) {
        int h = minuteOfDay / 60, m = minuteOfDay % 60;
        String ap = h < 12 ? "AM" : "PM";
        int hh = h % 12 == 0 ? 12 : h % 12;
        return hh + ":" + (m < 10 ? "0" : "") + m + " " + ap;
    }
    /** Puts the scroll position back BEFORE the first frame is drawn (no jump to the top). */
    public static void holdScroll(final android.widget.ScrollView sv, final int y) {
        if (y <= 0) return;
        sv.getViewTreeObserver().addOnPreDrawListener(new android.view.ViewTreeObserver.OnPreDrawListener() {
            int tries;

            @Override
            public boolean onPreDraw() {
                if (sv.getScrollY() != y && tries++ < 3 && sv.getChildCount() > 0 && sv.getChildAt(0).getHeight() > 0) {
                    sv.scrollTo(0, y);
                    if (sv.getScrollY() != y && tries < 3) return false; // content not tall enough yet; skip this frame
                }
                sv.getViewTreeObserver().removeOnPreDrawListener(this);
                return true;
            }
        });
    }

}
