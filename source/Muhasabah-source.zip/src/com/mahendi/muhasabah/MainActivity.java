package com.mahendi.muhasabah;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Insets;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.HapticFeedbackConstants;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    @Override
    protected void attachBaseContext(android.content.Context b) {
        super.attachBaseContext(Ui.wrap(b));
    }

    @Override
    public boolean dispatchTouchEvent(android.view.MotionEvent ev) {
        Haptics.touch(getWindow().getDecorView(), ev);
        return super.dispatchTouchEvent(ev);
    }

    private Store s;
    private FrameLayout root;
    private FrameLayout content;
    private LinearLayout main, nav;
    private Views.Confetti confetti;
    private TextView floater;
    private int tab = 0;
    private ScrollView currentScroll;
    private final int[] scrollY = new int[4];
    private String wisdomQuery = "";
    private final Handler h = new Handler(Looper.getMainLooper());
    private final List<Object[]> timerLabels = new ArrayList<Object[]>();
    private String wisdomFilter = "all";
    private int lastRingScore = -1;
    private Updater.Info pendingUpdate;
    private boolean animateNext = true;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.init(this);
        s = Store.get(this);
        Notify.channels(this);

        root = new FrameLayout(this);
        root.setBackgroundColor(Ui.BG);
        main = Ui.col(this);
        content = new FrameLayout(this);
        main.addView(content, new LinearLayout.LayoutParams(Ui.MATCH, 0, 1f));
        nav = Ui.row(this);
        main.addView(nav, Ui.lp(Ui.MATCH, Ui.WRAP));
        root.addView(main, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        confetti = new Views.Confetti(this);
        root.addView(confetti, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        floater = Ui.title(this, "", 30);
        floater.setTextColor(Ui.GOLD);
        floater.setBackground(Ui.roundStroke(0xF20F1424, 50, Ui.alpha(Ui.GOLD, 0.6f), 1.2f));
        floater.setPadding(Ui.dp(18), Ui.dp(6), Ui.dp(18), Ui.dp(6));
        floater.setElevation(Ui.dp(14));
        floater.setAlpha(0f);
        root.addView(floater, new FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.CENTER));
        setContentView(root);
        Intro.maybeShow(root);

        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View v, WindowInsets in) {
                Insets i = in.getInsets(WindowInsets.Type.systemBars());
                main.setPadding(i.left, i.top, i.right, 0);
                nav.setPadding(Ui.dp(8), Ui.dp(8), Ui.dp(8), Ui.dp(8) + i.bottom);
                return WindowInsets.CONSUMED;
            }
        });

        buildNav();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
    }

    @Override
    protected void onResume() {
        super.onResume();
        s.applyLang();
        Lock.tick(this);
        Lock.syncNetwork(this);
        if (s.b(Store.K_MONITOR, true)) WatchService.start(this);
        buildNav();
        show(tab);
        checkLevelUp();
        checkForUpdate(false);
        Reminders.schedule(this);
        Gunah.schedule(this);
        Content.sync(this, false, new Content.Done() {
            @Override
            public void done(int added, String error) {
                if (added > 0) {
                    android.widget.Toast.makeText(MainActivity.this, Lang.pick(added + " new ayat/hadith added ✨", added + " નવી આયત/હદીસ ઉમેરાઈ ✨"),
                            android.widget.Toast.LENGTH_LONG).show();
                    refresh();
                }
            }
        });
        h.removeCallbacks(timerTick);
        h.postDelayed(timerTick, 1000);
    }

    @Override
    protected void onPause() {
        super.onPause();
        Widget.update(this);
        h.removeCallbacks(timerTick);
        if (currentScroll != null) scrollY[tab] = currentScroll.getScrollY();
    }

    private final Runnable timerTick = new Runnable() {
        @Override
        public void run() {
            long now = System.currentTimeMillis();
            for (Object[] o : new ArrayList<Object[]>(timerLabels)) updateTimerRow(o);
            h.postDelayed(this, 1000);
        }
    };

    // ===================================================== navigation
    private void buildNav() {
        nav.removeAllViews();
        nav.setBackground(Ui.roundStroke(Ui.CARD, 0, Ui.STROKE, 1));
        String[] names = {Lang.t("nav_today"), Lang.t("nav_discover"), Lang.t("nav_wisdom"), Lang.t("nav_progress")};
        String[] icons = {"🏠", "✨", "📿", "📊"};
        for (int k = 0; k < 4; k++) {
            final int idx = k;
            LinearLayout item = Ui.col(this);
            item.setGravity(Gravity.CENTER);
            item.setPadding(0, Ui.dp(6), 0, Ui.dp(6));
            boolean sel = k == tab;
            if (sel) item.setBackground(Ui.round(Ui.alpha(Ui.GOLD, 0.13f), 18));
            TextView ic = Ui.text(this, icons[k], 20, Ui.TEXT, false);
            ic.setGravity(Gravity.CENTER);
            ic.setAlpha(sel ? 1f : 0.55f);
            TextView lb = Ui.text(this, names[k], 11, sel ? Ui.GOLD : Ui.MUTED, true);
            lb.setGravity(Gravity.CENTER);
            item.addView(ic);
            item.addView(lb);
            LinearLayout.LayoutParams p = Ui.weight(1);
            p.setMargins(Ui.dp(4), 0, Ui.dp(4), 0);
            nav.addView(item, p);
            Ui.press(item);
            item.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (idx != tab) {
                        Haptics.play(Haptics.NAV);
                        if (currentScroll != null) scrollY[tab] = currentScroll.getScrollY();
                        tab = idx;
                        animateNext = true;
                        buildNav();
                        show(idx);
                    }
                }
            });
        }
    }

    private int shownTab = -1;

    private void show(int t) {
        timerLabels.clear();
        LinearLayout page = Ui.col(this);
        page.setPadding(Ui.dp(18), Ui.dp(12), Ui.dp(18), Ui.dp(28));
        if (t == 0) todayPage(page);
        else if (t == 1) feedPage(page);
        else if (t == 2) wisdomPage(page);
        else statsPage(page);

        // Same tab (a refresh after a tap): swap only the page inside the existing scroll view, so the
        // scroll position never moves and nothing flashes — not even for one frame.
        if (t == shownTab && currentScroll != null && currentScroll.getParent() != null && !animateNext) {
            final ScrollView sv = currentScroll;
            final int y = sv.getScrollY();
            sv.removeAllViews();
            sv.addView(page);
            Ui.holdScroll(sv, y);
            return;
        }
        content.removeAllViews();
        final ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        sv.addView(page);
        currentScroll = sv;
        shownTab = t;
        Ui.holdScroll(sv, scrollY[t]);
        PullRefresh pr = new PullRefresh(this, sv);
        pr.setListener(new PullRefresh.Listener() {
            @Override
            public void onRefresh(PullRefresh p) {
                pullRefresh(p);
            }
        });
        content.addView(pr, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        if (animateNext) {
            animateNext = false;
            for (int i = 0; i < page.getChildCount() && i < 12; i++) {
                View ch = page.getChildAt(i);
                ch.setAlpha(0f);
                ch.setTranslationY(Ui.dp(16));
                ch.animate().alpha(1f).translationY(0).setStartDelay(i * 35L).setDuration(260)
                        .setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
            }
        }
    }

    /** Page title with the ⚙️ Settings button on the right. */
    private void titleRow(LinearLayout page, String title) {
        LinearLayout r = Ui.row(this);
        r.addView(Ui.title(this, title, 28), Ui.weight(1));
        r.addView(gearButton(), Ui.lp(Ui.dp(46), Ui.dp(46)));
        page.addView(r);
    }

    private TextView gearButton() {
        TextView gear = Ui.text(this, "⚙️", 20, Ui.TEXT, false);
        gear.setGravity(Gravity.CENTER);
        gear.setBackground(Ui.circle(Ui.CARD2));
        Ui.press(gear);
        gear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
            }
        });
        return gear;
    }

    private void refresh() {
        if (currentScroll != null) scrollY[tab] = currentScroll.getScrollY();
        show(tab);
    }

    private void goTab(int t) {
        tab = t;
        buildNav();
        show(t);
    }

    // ===================================================== TODAY
    private void todayPage(LinearLayout page) {
        String today = Store.today();
        Score.Day d = Score.compute(s, today);
        int y = Score.dayScore(s, Store.date(-1));
        int streak = Score.streak(s);
        int xp = Score.xp(s);
        int lvl = Score.level(xp);
        s.put("score_" + today, d.score);

        LinearLayout head = Ui.row(this);
        LinearLayout hc = Ui.col(this);
        hc.addView(Ui.text(this, Greet.greeting(s), 14.5f, Ui.GOLD_L, true));
        hc.addView(Ui.title(this, s.s(Store.K_NAME, "Mahdi"), 28));
        head.addView(hc, Ui.weight(1));
        TextView gear = Ui.text(this, "⚙️", 20, Ui.TEXT, false);
        gear.setGravity(Gravity.CENTER);
        gear.setBackground(Ui.circle(Ui.CARD2));
        head.addView(gear, Ui.lp(Ui.dp(46), Ui.dp(46)));
        Ui.press(gear);
        gear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
            }
        });
        FrameLayout header = new FrameLayout(this);
        LinearLayout hcol2 = Ui.col(this);
        hcol2.setPadding(Ui.dp(4), Ui.dp(8), Ui.dp(4), Ui.dp(4));
        hcol2.addView(head);
        SimpleDateFormat df = new SimpleDateFormat("EEEE, d MMMM", Lang.locale());
        String hj = Greet.hijri(s);
        TextView dl = Ui.text(this, df.format(new Date()), 13, Ui.SUB, false);
        dl.setPadding(0, Ui.dp(4), 0, 0);
        hcol2.addView(dl);
        if (hj.length() > 0) {
            TextView hl = Ui.text(this, "☾  " + hj, 13, Ui.GOLD, true);
            hl.setPadding(0, Ui.dp(2), 0, 0);
            hcol2.addView(hl);
        }
        // how much of the waking day is left
        int wake = s.i(Store.K_WAKE, 315), sleep = s.i(Store.K_SLEEP, 1380), now = Store.minuteOfDay();
        int span = ((sleep - wake) % 1440 + 1440) % 1440, gone = ((now - wake) % 1440 + 1440) % 1440;
        float dayF = span == 0 ? 0 : Math.max(0, Math.min(1, gone / (float) span));
        int left = Math.max(0, span - gone);
        TextView dayLeft = Ui.text(this, Lang.pick("⏳  " + Ui.hm(left) + " of your day left", "⏳  તમારા દિવસના " + Ui.hm(left) + " બાકી"), 12, Ui.MUTED, false);
        dayLeft.setPadding(0, Ui.dp(10), 0, Ui.dp(6));
        hcol2.addView(dayLeft);
        hcol2.addView(Ui.bar(this, dayF, Ui.alpha(Ui.GOLD, 0.8f), 3));
        Views.GeoPattern geo = new Views.GeoPattern(this);
        header.addView(geo, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        header.addView(hcol2, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        page.addView(header, Ui.lpm(Ui.MATCH, Ui.WRAP, -18, -12, -18, 14));
        hcol2.setPadding(Ui.dp(22), Ui.dp(20), Ui.dp(22), Ui.dp(14));

        if (pendingUpdate != null) page.addView(updateBanner(), Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 14));
        View lockCard = LockUi.todayCard(this);
        if (lockCard != null) page.addView(lockCard, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 14));
        Calendar nowCal = Calendar.getInstance();
        boolean sundayEve = nowCal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY && nowCal.get(Calendar.HOUR_OF_DAY) >= 18;
        boolean monthStart = nowCal.get(Calendar.DAY_OF_MONTH) <= 2;
        if (sundayEve || monthStart) {
            final boolean month = !sundayEve;
            LinearLayout sbn = Ui.row(this);
            sbn.setBackground(Ui.grad(0xFF2E1065, 0xFF0F766E, 20, GradientDrawable.Orientation.LEFT_RIGHT));
            sbn.setPadding(Ui.dp(16), Ui.dp(14), Ui.dp(16), Ui.dp(14));
            sbn.addView(Ui.text(this, month ? Lang.pick("📆  Your monthly summary is ready  ›", "📆  તમારો માસિક સારાંશ તૈયાર છે  ›")
                    : Lang.pick("🗓  Your weekly summary is ready  ›", "🗓  તમારો અઠવાડિક સારાંશ તૈયાર છે  ›"), 14.5f, 0xFFFFFFFF, true), Ui.weight(1));
            page.addView(sbn, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 14));
            Ui.press(sbn);
            sbn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startActivity(new Intent(MainActivity.this, SummaryActivity.class).putExtra("mode", month ? SummaryActivity.MONTH : SummaryActivity.WEEK)
                            .putExtra("date", month ? Summary.shift(Summary.monthOf(Store.today())[0], -1) : Store.today()));
                }
            });
        }

        boolean usage = WatchService.hasUsage(this), notif = WatchService.hasNotif(this), overlay = WatchService.hasOverlay(this),
                guard = !GuardService.available(this) || GuardService.isOn();
        int missing = (usage ? 0 : 1) + (notif ? 0 : 1) + (overlay ? 0 : 1) + (guard ? 0 : 1);
        if (missing > 0) {
            LinearLayout warn = Ui.row(this);
            warn.setBackground(Ui.roundStroke(Ui.alpha(Ui.ORANGE, 0.12f), 18, Ui.alpha(Ui.ORANGE, 0.5f), 1));
            warn.setPadding(Ui.dp(14), Ui.dp(12), Ui.dp(14), Ui.dp(12));
            warn.addView(Ui.text(this, Lang.t("finish_setup", missing), 13, Ui.ORANGE, true), Ui.weight(1));
            page.addView(warn, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 14));
            Ui.press(warn);
            warn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startActivity(new Intent(MainActivity.this, SettingsActivity.class));
                }
            });
        }

        // hero
        LinearLayout hero = Ui.col(this);
        hero.setBackground(Ui.grad3(0xFF0F766E, 0xFF064E3B, 0xFF1E1B4B, 28));
        hero.setPadding(Ui.dp(18), Ui.dp(18), Ui.dp(18), Ui.dp(18));
        hero.setElevation(Ui.dp(6));
        LinearLayout hr = Ui.row(this);
        Views.ScoreRing ring = new Views.ScoreRing(this);
        if (lastRingScore >= 0) ring.set(lastRingScore, Lang.pick("of 100", "/ 100"), false);
        ring.set(d.score, Lang.pick("of 100", "/ 100"), lastRingScore != d.score);
        lastRingScore = d.score;
        hr.addView(ring, Ui.lp(Ui.dp(124), Ui.dp(124)));
        LinearLayout hcol = Ui.col(this);
        hcol.setPadding(Ui.dp(14), 0, 0, 0);
        hcol.addView(Ui.text(this, Lang.t("today_vs"), 11, Ui.GOLD_L, true));
        int good = Score.goodDay(s);
        boolean ahead = d.score > y || d.score >= good;
        String status = ahead ? (d.score >= good && d.score <= y ? Lang.t("excellent") : Lang.t("ahead_by", d.score - y))
                : Lang.t("need_win", y - d.score + 1);
        TextView st = Ui.title(this, status, 21);
        st.setPadding(0, Ui.dp(4), 0, Ui.dp(2));
        hcol.addView(st);
        String ptail = d.penalty > 0 ? Lang.t("timepass_minus", d.penalty) : "";
        hcol.addView(Ui.text(this, Lang.t("yesterday", y) + ptail, 13, d.penalty > 0 ? 0xFFFDA4AF : Ui.alpha(0xFFFFFFFF, 0.75f), false));
        LinearLayout pills = Ui.row(this);
        pills.setPadding(0, Ui.dp(10), 0, 0);
        pills.addView(Ui.pill(this, "🔥 " + streak, Ui.alpha(0xFF000000, 0.25f), Ui.GOLD_L));
        pills.addView(Ui.space(this, 1), Ui.lp(Ui.dp(6), 1));
        pills.addView(Ui.pill(this, "✅ " + d.done + "/" + d.total, Ui.alpha(0xFF000000, 0.25f), 0xFFFFFFFF));
        hcol.addView(pills);
        hr.addView(hcol, Ui.weight(1));
        hero.addView(hr);
        LinearLayout lr = Ui.row(this);
        lr.setPadding(0, Ui.dp(16), 0, Ui.dp(6));
        lr.addView(Ui.text(this, Lang.t("level", lvl + 1, Lang.tr(Score.LEVEL_NAMES[lvl])), 13, 0xFFFFFFFF, true), Ui.weight(1));
        String next = lvl + 1 < Score.LEVEL_XP.length ? " / " + String.format(Locale.US, "%,d", Score.LEVEL_XP[lvl + 1]) : "";
        lr.addView(Ui.text(this, String.format(Locale.US, "%,d", xp) + next + " XP", 12, Ui.GOLD_L, true));
        hero.addView(lr);
        hero.addView(Ui.bar(this, Score.levelProgress(xp), Ui.GOLD, 8));
        page.addView(hero, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 14));
        Ui.press(hero);
        hero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goTab(3);
            }
        });

        // guard card (timepass + reels + na-mahram)
        page.addView(guardCard(today, usage), Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 14));
        page.addView(ReminderUi.box(this, reb), Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 14));

        // wisdom of the day
        JSONObject w = s.wisdomOfDay();
        if (w.optString("en").length() > 0) page.addView(wisdomCard(w, true), Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 18));
        JSONObject book = Daily.today(this, Daily.BOOKS);
        if (book != null) page.addView(bookCard(book), Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 18));
        JSONObject tip = Daily.today(this, Daily.TIPS);
        if (tip != null) page.addView(tipCard(tip), Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 18));
        if (Compete.on(s)) page.addView(competeEntry(), Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 10));
        page.addView(tawbahEntry(), Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 18));

        // tasks
        LinearLayout th = Ui.row(this);
        th.addView(Ui.title(this, Lang.t("tasks_title"), 20), Ui.weight(1));
        TextView add = Ui.pill(this, Lang.t("add"), Ui.alpha(Ui.EMERALD, 0.18f), Ui.EMERALD);
        add.setPadding(Ui.dp(14), Ui.dp(7), Ui.dp(14), Ui.dp(7));
        Ui.press(add);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Dialogs.editTask(MainActivity.this, null, reb);
            }
        });
        th.addView(add);
        page.addView(th, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 4));
        page.addView(Ui.text(this, Lang.t("tap_hint"), 12, Ui.MUTED, false), Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 10));
        // fix the previous day(s) for a while after midnight
        List<String> past = PastDays.editable(s);
        if (!past.isEmpty()) {
            LinearLayout pr = Ui.row(this);
            for (final String pd : past) {
                TextView pc = Ui.pill(this, "✏️ " + HadithCard.label("Edit ", "સુધારો: ", "درست کریں: ", "ठीक करें: ") + PastDays.dayName(pd),
                        Ui.alpha(Ui.GOLD, 0.12f), Ui.GOLD);
                pc.setPadding(Ui.dp(12), Ui.dp(7), Ui.dp(12), Ui.dp(7));
                Ui.press(pc);
                pc.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Haptics.play(Haptics.TAP);
                        PastDays.sheet(MainActivity.this, pd, reb);
                    }
                });
                LinearLayout.LayoutParams pp = Ui.lp(Ui.WRAP, Ui.WRAP);
                pp.setMargins(0, 0, Ui.dp(8), 0);
                pr.addView(pc, pp);
            }
            page.addView(pr, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));
        }

        double sumW = 0;
        List<Task> todays = s.tasksOn(today);
        for (Task t : todays) sumW += t.weight();
        // tasks with a fixed time first (in time order), then the rest in your order
        List<Task> ordered = new ArrayList<Task>(todays);
        java.util.Collections.sort(ordered, new java.util.Comparator<Task>() {
            @Override
            public int compare(Task a, Task b) {
                int ta = a.time < 0 ? 100000 : a.time, tb = b.time < 0 ? 100000 : b.time;
                return ta == tb ? 0 : ta < tb ? -1 : 1;
            }
        });
        for (Task t : ordered) page.addView(taskCard(t, today, sumW), Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 10));
        final List<Task> other = new ArrayList<Task>();
        for (Task t : s.activeTasks()) if (!todays.contains(t) && !t.onDate(today) && !t.expired()) other.add(t);
        if (!other.isEmpty()) {
            TextView ot = Ui.text(this, Lang.pick("📅  " + other.size() + " more task" + (other.size() == 1 ? "" : "s") + " on other days  ›",
                    "📅  બીજા દિવસોના " + other.size() + " કામ  ›"), 13, Ui.GOLD, true);
            ot.setPadding(Ui.dp(4), Ui.dp(4), 0, Ui.dp(6));
            page.addView(ot);
            ot.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    otherDaysSheet(other);
                }
            });
        }

        TextView rule = Ui.text(this, Lang.t("rule_line"), 12, Ui.MUTED, false);
        rule.setGravity(Gravity.CENTER);
        rule.setPadding(Ui.dp(10), Ui.dp(12), Ui.dp(10), 0);
        page.addView(rule);
    }

    private final Runnable reb = new Runnable() {
        @Override
        public void run() {
            refresh();
        }
    };

    private View guardCard(final String today, boolean usage) {
        LinearLayout c = Ui.card(this);
        // timepass
        LinearLayout r = Ui.row(this);
        r.addView(Ui.text(this, Lang.t("timepass_today"), 15, Ui.TEXT, true), Ui.weight(1));
        int used = s.timepassMinutes(today), lim = Math.max(1, s.timepassLimit());
        float f = used / (float) lim;
        int col = f < 0.7f ? Ui.EMERALD : f <= 1f ? Ui.GOLD : Ui.RED;
        r.addView(Ui.text(this, used + " / " + lim + Lang.pick(" min", " મિ"), 14, col, true));
        c.addView(r);
        c.addView(Ui.space(this, 8));
        c.addView(Ui.bar(this, Math.min(1f, f), col, 7));
        if (!usage) {
            TextView t = Ui.text(this, Lang.t("usage_off"), 12, Ui.ORANGE, false);
            t.setPadding(0, Ui.dp(10), 0, 0);
            c.addView(t);
            Ui.press(c);
            c.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
                }
            });
        }

        // reels
        c.addView(Ui.space(this, 14));
        LinearLayout rr = Ui.row(this);
        rr.addView(Ui.text(this, Lang.t("reels_today"), 15, Ui.TEXT, true), Ui.weight(1));
        int reels = s.reels(today), rlim = s.reelsLimit();
        int rcol = reels < rlim * 0.7 ? Ui.EMERALD : reels <= rlim ? Ui.GOLD : Ui.RED;
        rr.addView(Ui.text(this, reels + " / " + rlim, 14, rcol, true));
        c.addView(rr);
        c.addView(Ui.space(this, 8));
        c.addView(Ui.bar(this, Math.min(1f, reels / (float) Math.max(1, rlim)), rcol, 7));

        // na-mahram counter with +1
        c.addView(Ui.space(this, 14));
        LinearLayout nr = Ui.row(this);
        LinearLayout nc = Ui.col(this);
        nc.addView(Ui.text(this, Lang.t("namahram_counter"), 15, Ui.TEXT, true));
        nc.addView(Ui.text(this, Lang.pick("Today: " + s.namahram(today) + " · tap + when it happens",
                "આજ: " + s.namahram(today) + " · થાય ત્યારે + દબાવો"), 12, Ui.SUB, false));
        nr.addView(nc, Ui.weight(1));
        TextView plus = Ui.text(this, "+1", 16, 0xFF1A1205, true);
        plus.setGravity(Gravity.CENTER);
        plus.setBackground(Ui.grad(Ui.GOLD, Ui.GOLD_D, 50, GradientDrawable.Orientation.LEFT_RIGHT));
        plus.setPadding(Ui.dp(18), Ui.dp(10), Ui.dp(18), Ui.dp(10));
        Ui.press(plus);
        nr.addView(plus);
        c.addView(nr);
        Ui.press(c);
        c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                guardDetail();
            }
        });
        plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Haptics.play(Haptics.WARN);
                s.incNamahram(today);
                JSONObject w = s.pick("gaze", "purity", "akl");
                Dialogs.reminderToast(MainActivity.this, Lang.t("logged"), w);
                refresh();
            }
        });
        return c;
    }

    private View taskCard(final Task t, final String today, double sumW) {
        final double v = Score.liveValue(s, t, today);
        double f = t.frac(v);
        final boolean done = f >= 0.999;
        int maxPts = sumW == 0 ? 0 : (int) Math.round(t.weight() / sumW * 100);
        int accent = t.importance >= 3 ? Ui.GOLD : t.importance == 2 ? Ui.PURPLE : Ui.BLUE;

        final LinearLayout card = Ui.col(this);
        card.setBackground(done ? Ui.roundStroke(Ui.alpha(Ui.EMERALD, 0.10f), 20, Ui.alpha(Ui.EMERALD, 0.55f), 1.2f)
                : Ui.roundStroke(Ui.CARD, 20, Ui.STROKE, 1));
        card.setPadding(Ui.dp(14), Ui.dp(12), Ui.dp(14), Ui.dp(12));
        LinearLayout r = Ui.row(this);
        TextView em = Ui.text(this, t.emoji, 22, Ui.TEXT, false);
        em.setGravity(Gravity.CENTER);
        em.setBackground(Ui.circle(Ui.alpha(accent, 0.16f)));
        r.addView(em, Ui.lpm(Ui.dp(46), Ui.dp(46), 0, 0, 12, 0));
        LinearLayout mid = Ui.col(this);
        TextView nm = Ui.text(this, t.display(), 15.5f, done ? Ui.alpha(Ui.TEXT, 0.75f) : Ui.TEXT, true);
        if (done) nm.setPaintFlags(nm.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        mid.addView(nm);
        String sch = t.scheduleLabel();
        if (sch.length() > 0) {
            TextView sc = Ui.text(this, sch, 11.5f, Ui.GOLD, true);
            sc.setPadding(0, Ui.dp(1), 0, Ui.dp(1));
            mid.addView(sc);
        }
        int earned = (int) Math.round(maxPts * f);
        final TextView prog = Ui.text(this, progressText(t, v) + "  ·  " + earned + "/" + maxPts + " " + Lang.t("pts"), 12.5f, done ? Ui.EMERALD : Ui.SUB, false);
        mid.addView(prog);
        r.addView(mid, Ui.weight(1));
        final int fMaxPts = maxPts;
        final LinearLayout[] barRef = new LinearLayout[1];

        if (t.type == Task.CHECK) {
            TextView box = Ui.text(this, done ? "✓" : "", 18, 0xFFFFFFFF, true);
            box.setGravity(Gravity.CENTER);
            box.setBackground(done ? Ui.circle(Ui.EMERALD) : Ui.roundStroke(0, 50, Ui.MUTED, 2));
            r.addView(box, Ui.lp(Ui.dp(38), Ui.dp(38)));
            box.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View vv) {
                    boolean isDone = t.frac(s.value(today, t)) >= 0.999; // state read NOW
                    change(t, isDone ? 0 : 1, vv, null);
                }
            });
        } else if (t.type == Task.COUNT) {
            TextView minus = roundBtn("−"), plus = roundBtn("+");
            final Object[] row = {null, t, prog, barRef, fMaxPts};
            r.addView(minus, Ui.lp(Ui.dp(36), Ui.dp(36)));
            r.addView(Ui.space(this, 1), Ui.lp(Ui.dp(8), 1));
            r.addView(plus, Ui.lp(Ui.dp(36), Ui.dp(36)));
            minus.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View vv) {
                    double cur = s.value(today, t);
                    if (cur <= 0) {
                        Haptics.play(Haptics.WARN);
                        return;
                    }
                    change(t, Math.max(0, cur - 1), vv, row);
                }
            });
            plus.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View vv) {
                    change(t, Math.max(0, s.value(today, t)) + 1, vv, row);
                }
            });
        } else if (t.type == Task.MINUTES) {
            final TextView tb = Ui.pill(this, "", 0, 0);
            tb.setPadding(Ui.dp(14), Ui.dp(9), Ui.dp(14), Ui.dp(9));
            tb.setMinWidth(Ui.dp(86));
            paintTimerPill(t, tb);
            Ui.press(tb);
            r.addView(tb);
            final Object[] entry = {tb, t, prog, barRef, fMaxPts};
            if (Timers.running(s, t)) timerLabels.add(entry);
            tb.setOnClickListener(new View.OnClickListener() {
                long lastTap;

                @Override
                public void onClick(View vv) {
                    long now = System.currentTimeMillis();
                    if (now - lastTap < 600) return; // ignore accidental double taps
                    lastTap = now;
                    Haptics.play(Timers.running(s, t) ? Haptics.STOP : Haptics.START);
                    if (Timers.running(s, t)) { // state read NOW
                        double oldF = t.frac(Score.liveValue(s, t, today));
                        Score.Day before = Score.compute(s, today);
                        Timers.pause(s, t);
                        timerLabels.remove(entry);
                        if (t.frac(Score.liveValue(s, t, today)) >= 0.999 && oldF < 0.999) {
                            afterChange(t, before, oldF, tb, null); // finished → celebrate
                            return;
                        }
                    } else {
                        Timers.start(s, t);
                        if (!timerLabels.contains(entry)) timerLabels.add(entry);
                    }
                    paintTimerPill(t, tb);
                    updateTimerRow(entry);
                }
            });
        } else {
            TextView ch = Ui.pill(this, (int) v >= 0 ? Lang.t("change") : Lang.t("answer"), Ui.alpha(accent, 0.16f), accent);
            ch.setPadding(Ui.dp(12), Ui.dp(9), Ui.dp(12), Ui.dp(9));
            r.addView(ch);
            ch.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View vv) {
                    Dialogs.chooseOption(MainActivity.this, t, (int) s.value(today, t), new Dialogs.IntCallback() {
                        @Override
                        public void done(int idx) {
                            change(t, idx, null, null);
                        }
                    });
                }
            });
        }
        // tapping the card itself opens the full detail screen
        card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View vv) {
                startActivity(new Intent(MainActivity.this, TaskActivity.class).putExtra("task", t.id));
            }
        });
        card.addView(r);
        if (t.type != Task.CHECK) {
            View bar = Ui.bar(this, (float) f, done ? Ui.EMERALD : accent, 4);
            barRef[0] = (LinearLayout) bar;
            LinearLayout.LayoutParams bp = Ui.lp(Ui.MATCH, Ui.dp(4));
            bp.setMargins(Ui.dp(58), Ui.dp(10), 0, 0);
            card.addView(bar, bp);
        }
        Ui.press(card);
        card.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View vv) {
                Haptics.play(Haptics.LONG);
                Dialogs.editTask(MainActivity.this, t, reb);
                return true;
            }
        });
        return card;
    }

    private void otherDaysSheet(List<Task> other) {
        LinearLayout body = Ui.col(this);
        final AlertDialog[] d = new AlertDialog[1];
        for (final Task t : other) {
            LinearLayout r = Ui.row(this);
            r.setPadding(Ui.dp(12), Ui.dp(12), Ui.dp(12), Ui.dp(12));
            r.setBackground(Ui.roundStroke(Ui.CARD2, 16, Ui.STROKE, 1));
            r.addView(Ui.text(this, t.emoji, 20, Ui.TEXT, false), Ui.lpm(Ui.dp(34), Ui.WRAP, 0, 0, 8, 0));
            LinearLayout c = Ui.col(this);
            c.addView(Ui.text(this, t.display(), 15, Ui.TEXT, true));
            c.addView(Ui.text(this, t.scheduleLabel(), 12, Ui.GOLD, true));
            r.addView(c, Ui.weight(1));
            body.addView(r, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 8));
            Ui.press(r);
            r.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    d[0].dismiss();
                    startActivity(new Intent(MainActivity.this, TaskActivity.class).putExtra("task", t.id));
                }
            });
        }
        d[0] = Dialogs.sheet(this, Lang.pick("Tasks on other days", "બીજા દિવસોના કામ"), body);
        d[0].show();
    }

    /** Detail sheet for the Timepass / Reels / Na-mahram box. */
    private void guardDetail() {
        LinearLayout body = Ui.col(this);
        String today = Store.today();
        body.addView(Ui.text(this, Lang.pick("TODAY BY APP", "આજે ઍપ પ્રમાણે"), 12, Ui.SUB, true));
        JSONObject u = s.usage(today);
        JSONArray apps = s.apps();
        for (int k = 0; k < apps.length(); k++) {
            JSONObject o = apps.optJSONObject(k);
            if (o == null) continue;
            int m = u.optInt(o.optString("pkg"), 0), l = o.optInt("limit", 30);
            LinearLayout r = Ui.row(this);
            r.setPadding(0, Ui.dp(8), 0, Ui.dp(2));
            r.addView(Ui.text(this, o.optString("name"), 14.5f, Ui.TEXT, true), Ui.weight(1));
            r.addView(Ui.text(this, m + " / " + l + Lang.pick(" min", " મિ"), 13.5f, m > l ? Ui.RED : Ui.SUB, true));
            body.addView(r);
            body.addView(Ui.bar(this, Math.min(1f, m / (float) Math.max(1, l)), m > l ? Ui.RED : Ui.EMERALD, 5));
        }
        String[][] rows = {{Lang.pick("LAST 7 DAYS — TIMEPASS (min)", "છેલ્લા 7 દિવસ — ટાઇમપાસ (મિ)"), "tp"},
                {Lang.pick("LAST 7 DAYS — REELS", "છેલ્લા 7 દિવસ — રીલ્સ"), "reels"},
                {Lang.pick("LAST 7 DAYS — NA-MAHRAM", "છેલ્લા 7 દિવસ — નામહરમ"), "nm"}};
        for (String[] rw : rows) {
            TextView h = Ui.text(this, rw[0], 12, Ui.SUB, true);
            h.setPadding(0, Ui.dp(18), 0, Ui.dp(4));
            body.addView(h);
            Views.Bars b = new Views.Bars(this);
            int[] vals = new int[7];
            String[] labs = new String[7];
            int max = 1;
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DAY_OF_YEAR, -6);
            for (int k = 0; k < 7; k++) {
                String d = Store.date(k - 6);
                vals[k] = rw[1].equals("tp") ? s.timepassMinutes(d) : rw[1].equals("reels") ? s.reels(d) : s.namahram(d);
                max = Math.max(max, vals[k]);
                labs[k] = String.valueOf(cal.get(Calendar.DAY_OF_MONTH));
                cal.add(Calendar.DAY_OF_YEAR, 1);
            }
            int[] pct = new int[7];
            for (int k = 0; k < 7; k++) pct[k] = Math.round(vals[k] * 100f / max);
            b.set(pct, labs);
            body.addView(b, Ui.lp(Ui.MATCH, Ui.dp(120)));
            int sum = 0;
            for (int v : vals) sum += v;
            body.addView(Ui.text(this, Lang.pick("Total: " + sum + " · Today: " + vals[6], "કુલ: " + sum + " · આજે: " + vals[6]), 12, Ui.MUTED, false));
        }
        body.addView(Ui.space(this, 14));
        TextView set = Ui.ghost(this, Lang.pick("Change limits in Settings", "સેટિંગ્સમાં મર્યાદા બદલો"), Ui.GOLD);
        body.addView(set, Ui.lp(Ui.MATCH, Ui.WRAP));
        final AlertDialog d = Dialogs.sheet(this, Lang.pick("📱 Screen & gaze", "📱 સ્ક્રીન અને નજર"), body);
        set.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                d.dismiss();
                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
            }
        });
        d.show();
    }

    private void paintTimerPill(Task t, TextView tb) {
        long secs = Timers.secondsToday(s, t);
        if (Timers.running(s, t)) {
            tb.setTextColor(0xFF1A1205);
            tb.setBackground(Ui.grad(Ui.GOLD, Ui.GOLD_D, 50, GradientDrawable.Orientation.LEFT_RIGHT));
            tb.setText("❚❚  " + Timers.clock(secs));
        } else if (secs > 0) {
            tb.setTextColor(Ui.EMERALD);
            tb.setBackground(Ui.roundStroke(Ui.alpha(Ui.EMERALD, 0.14f), 50, Ui.alpha(Ui.EMERALD, 0.5f), 1));
            tb.setText("▶\uFE0E  " + Timers.clock(secs));
        } else {
            tb.setTextColor(Ui.EMERALD);
            tb.setBackground(Ui.round(Ui.alpha(Ui.EMERALD, 0.18f), 50));
            tb.setText(Lang.t("start"));
        }
    }

    /** Live update of one minutes-task row (pill text, progress line, bar) without rebuilding the page. */
    private void updateTimerRow(Object[] e) {
        TextView tb = (TextView) e[0];
        Task t = (Task) e[1];
        TextView prog = (TextView) e[2];
        LinearLayout[] bar = (LinearLayout[]) e[3];
        int maxPts = (Integer) e[4];
        String today = Store.today();
        double v = Score.liveValue(s, t, today);
        double f = t.frac(v);
        if (tb != null && Timers.running(s, t)) tb.setText("❚❚  " + Timers.clock(Timers.secondsToday(s, t)));
        prog.setText(progressText(t, v) + "  ·  " + (int) Math.round(maxPts * f) + "/" + maxPts + " " + Lang.t("pts"));
        if (bar[0] != null && bar[0].getChildCount() > 0) {
            LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) bar[0].getChildAt(0).getLayoutParams();
            lp.weight = (float) Math.max(0, Math.min(1, f));
            bar[0].getChildAt(0).setLayoutParams(lp);
        }
    }

    private String progressText(Task t, double v) {
        switch (t.type) {
            case Task.CHECK:
                return v >= 1 ? Lang.t("done_tick") : Lang.t("not_yet");
            case Task.COUNT:
                return (int) v + " / " + t.target + (t.unit.length() > 0 ? " " + t.unit : "");
            case Task.MINUTES: {
                long secs = Math.round(Math.max(0, v) * 60);
                return (secs < 3600 ? Timers.clock(secs) : Ui.hm((int) v)) + " / " + Ui.hm(t.target);
            }
            default: {
                int i = (int) v;
                String[] opts = t.displayOptions();
                return (i >= 0 && i < opts.length) ? opts[i] : Lang.pick("Tap to answer", "જવાબ માટે ટૅપ કરો");
            }
        }
    }

    private TextView roundBtn(String label) {
        TextView b = Ui.text(this, label, 20, Ui.TEXT, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(Ui.roundStroke(Ui.CARD2, 50, Ui.STROKE, 1));
        Ui.press(b);
        return b;
    }

    /**
     * anchor: the button tapped (the +/− chip floats from it). row: when given, the card is updated in place
     * (no page rebuild, so rapid taps never flicker); the full page refreshes once taps stop.
     */
    private void change(Task t, double newValue, View anchor, Object[] row) {
        String today = Store.today();
        Score.Day before = Score.compute(s, today);
        double oldF = t.frac(Score.liveValue(s, t, today));
        s.setValue(today, t, newValue);
        afterChange(t, before, oldF, anchor, row);
    }

    private final Runnable lateRefresh = new Runnable() {
        @Override
        public void run() {
            refresh();
        }
    };

    private void afterChange(Task t, Score.Day before, double oldF, View anchor, Object[] row) {
        String today = Store.today();
        Score.Day after = Score.compute(s, today);
        double newF = t.frac(Score.liveValue(s, t, today));
        int y = Score.dayScore(s, Store.date(-1));
        boolean completed = newF >= 0.999 && oldF < 0.999;
        Haptics.play(completed ? Haptics.SUCCESS : Haptics.TOGGLE);
        h.removeCallbacks(lateRefresh);
        if (row != null) {
            updateTimerRow(row); // instant, in place
            h.postDelayed(lateRefresh, completed ? 650 : 1400);
        } else refresh();
        int gained = after.score - before.score;
        if (completed) {
            confetti.burst(70);
            floatText("+" + Math.max(gained, 1) + " XP");
        } else if (gained != 0) {
            if (anchor != null && anchor.isAttachedToWindow()) popAt(anchor, (gained > 0 ? "+" : "−") + Math.abs(gained), gained > 0 ? Ui.EMERALD : Ui.RED);
            else if (gained > 0) floatText("+" + gained);
        }
        int good = Score.goodDay(s);
        boolean beatNow = (after.score > y || after.score >= good) && !(before.score > y || before.score >= good);
        if (beatNow && after.score > 0 && s.once("beat_celebration"))
            h.postDelayed(new Runnable() {
                @Override
                public void run() {
                    bigCelebration("🏆", Lang.t("better_day_title"), Lang.t("better_day_msg"));
                }
            }, 700);
    }

    /** A small readable chip that rises from the tapped button and fades — never over the card's text. */
    private void popAt(View anchor, String txt, int color) {
        final TextView chip = Ui.text(this, txt, 13, color, true);
        chip.setBackground(Ui.roundStroke(0xF20F1424, 50, Ui.alpha(color, 0.6f), 1));
        chip.setPadding(Ui.dp(9), Ui.dp(3), Ui.dp(9), Ui.dp(3));
        chip.setElevation(Ui.dp(12));
        int[] a = new int[2], r = new int[2];
        anchor.getLocationInWindow(a);
        root.getLocationInWindow(r);
        chip.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        float x = a[0] - r[0] + anchor.getWidth() / 2f - chip.getMeasuredWidth() / 2f;
        float y = a[1] - r[1] - chip.getMeasuredHeight() - Ui.dp(2);
        root.addView(chip, new FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP));
        chip.setX(Math.max(Ui.dp(4), Math.min(root.getWidth() - chip.getMeasuredWidth() - Ui.dp(4), x)));
        chip.setY(y);
        chip.setAlpha(0f);
        chip.setScaleX(0.7f);
        chip.setScaleY(0.7f);
        chip.animate().alpha(1f).scaleX(1f).scaleY(1f).translationYBy(-Ui.dp(10)).setDuration(160).withEndAction(new Runnable() {
            @Override
            public void run() {
                chip.animate().alpha(0f).translationYBy(-Ui.dp(22)).setStartDelay(380).setDuration(420).withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        root.removeView(chip);
                    }
                }).start();
            }
        }).start();
    }

    private void floatText(String txt) {
        floater.animate().cancel();
        floater.setText(txt);
        floater.setAlpha(1f);
        floater.setTranslationY(0);
        floater.setScaleX(0.6f);
        floater.setScaleY(0.6f);
        floater.animate().scaleX(1.15f).scaleY(1.15f).translationY(-Ui.dp(110)).alpha(0f).setDuration(1200).start();
    }

    private void bigCelebration(String emoji, String title, String msg) {
        confetti.burst(180);
        LinearLayout body = Ui.col(this);
        body.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView e = Ui.text(this, emoji, 64, Ui.TEXT, false);
        e.setGravity(Gravity.CENTER);
        body.addView(e);
        TextView ti = Ui.title(this, title, 28);
        ti.setGravity(Gravity.CENTER);
        ti.setTextColor(Ui.GOLD);
        body.addView(ti);
        TextView m = Ui.text(this, msg, 15, Ui.SUB, false);
        m.setGravity(Gravity.CENTER);
        m.setPadding(0, Ui.dp(8), 0, Ui.dp(18));
        body.addView(m);
        TextView ok = Ui.button(this, Lang.t("alhamdulillah"), Ui.GOLD, Ui.GOLD_D, 0xFF1A1205);
        body.addView(ok, Ui.lp(Ui.MATCH, Ui.WRAP));
        final AlertDialog dg = Dialogs.sheet(this, null, body);
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dg.dismiss();
            }
        });
        dg.show();
    }

    private void checkLevelUp() {
        int lvl = Score.level(Score.xp(s));
        int last = s.i("last_level", -1);
        if (last < 0) {
            s.put("last_level", lvl);
            return;
        }
        if (lvl > last) {
            s.put("last_level", lvl);
            bigCelebration("🎖️", Lang.t("level_up", lvl + 1), Lang.t("level_up_msg", Lang.tr(Score.LEVEL_NAMES[lvl])));
        }
    }

    // ===================================================== wisdom card
    /** Small round "next" button used on the daily cards. */
    private TextView nextBtn(final String kind, int color) {
        final TextView nb = Ui.text(this, "↻", 20, color, true);
        nb.setGravity(Gravity.CENTER);
        nb.setBackground(Ui.circle(Ui.alpha(color, 0.14f)));
        Ui.press(nb);
        nb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Haptics.play(Haptics.REFRESH);
                v.animate().rotationBy(360).setDuration(450).start();
                Daily.next(MainActivity.this, kind);
                h.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        refresh();
                    }
                }, 250);
            }
        });
        return nb;
    }

    /** 📖 From the books — one graded hadith a day with the full reference. */
    private View bookCard(final JSONObject it) {
        LinearLayout c = Ui.col(this);
        c.setBackground(Ui.roundStroke(0xFF10171F, 22, Ui.alpha(Ui.EMERALD, 0.40f), 1));
        c.setPadding(Ui.dp(16), Ui.dp(16), Ui.dp(16), Ui.dp(14));
        LinearLayout top = Ui.row(this);
        String head = Lang.pick("📖  FROM THE BOOKS", "📖  પુસ્તકોમાંથી");
        if (it.optBoolean("tafsir")) head += Lang.pick("  ·  TAFSIR", "  ·  તફસીર");
        top.addView(Ui.text(this, head, 11, Ui.EMERALD, true), Ui.weight(1));
        top.addView(Ui.text(this, Daily.position(this, Daily.BOOKS) + "/" + Daily.list(this, Daily.BOOKS).length(), 11, Ui.MUTED, false),
                Ui.lpm(Ui.WRAP, Ui.WRAP, 0, 0, 10, 0));
        top.addView(nextBtn(Daily.BOOKS, Ui.EMERALD), Ui.lp(Ui.dp(36), Ui.dp(36)));
        c.addView(top);
        HadithCard.fill(this, c, it);
        HadithCard.link(this, c, it);
        return c;
    }

    /** 🏆 Friends leaderboard entry (only when turned on in Settings). */
    private View competeEntry() {
        LinearLayout c = Ui.row(this);
        c.setBackground(Ui.roundStroke(Ui.CARD, 18, Ui.alpha(Ui.BLUE, 0.45f), 1));
        c.setPadding(Ui.dp(14), Ui.dp(12), Ui.dp(14), Ui.dp(12));
        LinearLayout col = Ui.col(this);
        col.addView(Ui.text(this, HadithCard.label("🏆  Compete with friends", "🏆  મિત્રો સાથે સ્પર્ધા", "🏆  دوستوں سے مقابلہ", "🏆  दोस्तों से मुक़ाबला"), 14.5f, Ui.TEXT, true));
        String sub;
        if (!Compete.inRoom(s)) {
            sub = HadithCard.label("Create a group or join a friend's", "ગ્રુપ બનાવો અથવા મિત્રના ગ્રુપમાં જોડાઓ", "گروپ بنائیں یا دوست کے گروپ میں شامل ہوں", "ग्रुप बनाएँ या दोस्त के ग्रुप में जुड़ें");
        } else {
            java.util.List<Compete.Row> rows = Compete.board(this, false);
            int rank = 1;
            for (int i = 0; i < rows.size(); i++) if (rows.get(i).mine) rank = i + 1;
            sub = rows.size() <= 1 ? HadithCard.label("Waiting for friends to join…", "મિત્રો જોડાય તેની રાહ…", "دوستوں کے شامل ہونے کا انتظار…", "दोस्तों के जुड़ने का इंतज़ार…")
                    : HadithCard.label("Today you're #" + rank + " of " + rows.size(), "આજે તમે " + rows.size() + " માંથી #" + rank,
                    "آج آپ " + rows.size() + " میں سے #" + rank, "आज आप " + rows.size() + " में से #" + rank);
            Compete.sync(this, false, null);
        }
        TextView st = Ui.text(this, sub, 12, Ui.BLUE, false);
        st.setPadding(0, Ui.dp(2), 0, 0);
        col.addView(st);
        c.addView(col, Ui.weight(1));
        c.addView(Ui.text(this, "›", 22, Ui.SUB, true));
        Ui.press(c);
        c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Haptics.play(Haptics.NAV);
                startActivity(new Intent(MainActivity.this, CompeteActivity.class));
            }
        });
        return c;
    }

    /** Quiet entry to the private Tawbah & Islah screen (7-day reminders after a slip). */
    private View tawbahEntry() {
        LinearLayout c = Ui.row(this);
        c.setBackground(Ui.roundStroke(Ui.CARD, 18, Ui.STROKE, 1));
        c.setPadding(Ui.dp(14), Ui.dp(12), Ui.dp(14), Ui.dp(12));
        LinearLayout col = Ui.col(this);
        col.addView(Ui.text(this, HadithCard.label("🌱  Tawbah & Islah", "🌱  તૌબા અને ઇસ્લાહ", "🌱  توبہ و اصلاح", "🌱  तौबा और इस्लाह"), 14.5f, Ui.TEXT, true));
        int running = 0;
        org.json.JSONArray keys = Gunah.series(this).names();
        for (int i = 0; keys != null && i < keys.length(); i++) if (Gunah.dayOf(this, keys.optString(i)) > 0) running++;
        String sub = running > 0
                ? HadithCard.label(running + " private 7-day reminder" + (running == 1 ? "" : "s") + " running", running + " ખાનગી 7-દિવસીય રિમાઇન્ડર ચાલુ",
                running + " نجی 7 روزہ یاد دہانی جاری", running + " निजी 7-दिन के रिमाइंडर चालू")
                : HadithCard.label("Slipped today? Get 7 days of private reminders", "આજે ભૂલ થઈ? 7 દિવસના ખાનગી રિમાઇન્ડર મેળવો",
                "آج لغزش ہوئی؟ 7 دن کی نجی یاد دہانیاں پائیں", "आज ग़लती हुई? 7 दिन के निजी रिमाइंडर पाएँ");
        TextView st = Ui.text(this, sub, 12, running > 0 ? Ui.EMERALD : Ui.SUB, false);
        st.setPadding(0, Ui.dp(2), 0, 0);
        col.addView(st);
        c.addView(col, Ui.weight(1));
        c.addView(Ui.text(this, "›", 22, Ui.SUB, true));
        Ui.press(c);
        c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Haptics.play(Haptics.NAV);
                startActivity(new Intent(MainActivity.this, GunahActivity.class));
            }
        });
        return c;
    }

    private static final String[] TIP_T = {"t", "gt", "ut", "ht"}, TIP_B = {"b", "gb", "ub", "hb"};

    /** 💡 Tip of the day — business, health, wellness, money, mind, family. */
    private View tipCard(JSONObject it) {
        LinearLayout c = Ui.col(this);
        c.setBackground(Ui.roundStroke(0xFF14122A, 22, Ui.alpha(Ui.PURPLE, 0.45f), 1));
        c.setPadding(Ui.dp(16), Ui.dp(16), Ui.dp(16), Ui.dp(14));
        LinearLayout top = Ui.row(this);
        String cat = it.optString("cat");
        top.addView(Ui.text(this, Lang.pick("💡  TIP OF THE DAY", "💡  આજની ટિપ") + "  ·  " + tipCat(cat), 11, 0xFFC4B5FD, true), Ui.weight(1));
        top.addView(nextBtn(Daily.TIPS, 0xFFC4B5FD), Ui.lp(Ui.dp(36), Ui.dp(36)));
        c.addView(top);
        java.util.List<String[]> ts = Lang.texts(it, TIP_T), bs = Lang.texts(it, TIP_B);
        boolean first = true;
        for (String[] t : ts) {
            String body = "";
            for (String[] b : bs) if (b[0].equals(t[0])) body = b[1];
            TextView tt = Ui.title(this, (first ? it.optString("e") + "  " : "") + t[1], first ? 19 : 17);
            tt.setPadding(0, Ui.dp(first ? 10 : 12), 0, 0);
            if (t[0].equals("gu")) Fonts.applyGujarati(tt, true);
            else if (t[0].equals("ur")) Fonts.applyUrdu(tt);
            c.addView(tt);
            TextView bb = Ui.text(this, body, 14.5f, first ? Ui.TEXT : 0xFFE9DFC6, false);
            bb.setPadding(0, Ui.dp(4), 0, 0);
            if (t[0].equals("gu")) Fonts.applyGujarati(bb, false);
            else if (t[0].equals("ur")) Fonts.applyUrdu(bb);
            c.addView(bb);
            first = false;
        }
        if (it.optString("src").length() > 0) {
            TextView src = Ui.text(this, Lang.pick("Source: ", "સ્રોત: ") + it.optString("src"), 11.5f, Ui.MUTED, false);
            src.setPadding(0, Ui.dp(10), 0, 0);
            c.addView(src);
        }
        return c;
    }

    private static String tipCat(String c) {
        if ("business".equals(c)) return Lang.pick("Business", "ધંધો");
        if ("health".equals(c)) return Lang.pick("Health", "તંદુરસ્તી");
        if ("wellness".equals(c)) return Lang.pick("Wellness", "સુખાકારી");
        if ("money".equals(c)) return Lang.pick("Money", "પૈસા");
        if ("family".equals(c)) return Lang.pick("Family", "પરિવાર");
        return Lang.pick("Mind", "મન");
    }

    private View wisdomCard(final JSONObject w, boolean ofDay) {
        LinearLayout c = Ui.col(this);
        c.setBackground(ofDay ? Ui.roundStroke(0xFF1A1710, 22, Ui.alpha(Ui.GOLD, 0.35f), 1) : Ui.roundStroke(Ui.CARD, 22, Ui.STROKE, 1));
        c.setPadding(Ui.dp(16), Ui.dp(16), Ui.dp(16), Ui.dp(14));
        LinearLayout top = Ui.row(this);
        top.addView(Ui.text(this, ofDay ? Lang.t("wisdom_of_day") : topicsLine(w), 11, Ui.GOLD, true), Ui.weight(1));
        final String id = w.optString("id");
        if (ofDay) {
            final TextView ref = Ui.text(this, "↻", 22, Ui.GOLD, true);
            ref.setGravity(Gravity.CENTER);
            ref.setBackground(Ui.circle(Ui.alpha(Ui.GOLD, 0.14f)));
            top.addView(ref, Ui.lp(Ui.dp(38), Ui.dp(38)));
            Ui.press(ref);
            ref.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Haptics.play(Haptics.REFRESH);
                    v.animate().rotationBy(360).setDuration(450).start();
                    s.refreshWisdom();
                    h.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            refresh();
                        }
                    }, 250);
                }
            });
        }
        if (!ofDay) {
            final TextView fav = Ui.text(this, s.isFav(id) ? "♥" : "♡", 20, s.isFav(id) ? Ui.PINK : Ui.MUTED, false);
            fav.setPadding(Ui.dp(10), 0, 0, 0);
            top.addView(fav);
            fav.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    s.toggleFav(id);
                    boolean on = s.isFav(id);
                    fav.setText(on ? "♥" : "♡");
                    fav.setTextColor(on ? Ui.PINK : Ui.MUTED);
                    fav.animate().scaleX(1.4f).scaleY(1.4f).setDuration(120).withEndAction(new Runnable() {
                        @Override
                        public void run() {
                            fav.animate().scaleX(1f).scaleY(1f).setDuration(120).start();
                        }
                    }).start();
                }
            });
        }
        c.addView(top);
        String ar = w.optString("ar");
        if (ar.length() > 0) {
            TextView a = Ui.text(this, ar, ofDay ? 22 : 21, Ui.GOLD_L, false);
            a.setTextDirection(View.TEXT_DIRECTION_RTL);
            a.setGravity(Gravity.START);
            Ui.arabic(a);
            a.setLineSpacing(Ui.dp(5), 1f);
            a.setPadding(0, Ui.dp(12), 0, Ui.dp(4));
            c.addView(a);
        }
        Ui.translations(this, c, w, 15.5f, true);
        c.addView(Ui.space(this, 8));
        if (w.optString("src").length() > 0) c.addView(Ui.text(this, "— " + w.optString("src"), 12, Ui.SUB, false));
        if (ofDay) {
            Ui.press(c);
            c.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    goTab(2);
                }
            });
        } else {
            c.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    Dialogs.confirm(MainActivity.this, Lang.pick("Remove this reminder?", "આ નસીહત હટાવવી?"),
                            Lang.pick("It will no longer appear.", "હવે તે દેખાશે નહીં."), new Runnable() {
                                @Override
                                public void run() {
                                    s.deleteWisdom(id);
                                    refresh();
                                }
                            });
                    return true;
                }
            });
        }
        return c;
    }

    private String topicsLine(JSONObject w) {
        JSONArray t = w.optJSONArray("topics");
        StringBuilder b = new StringBuilder();
        if (t != null) for (int k = 0; k < t.length(); k++) {
            if (b.length() > 0) b.append("  ·  ");
            b.append(t.optString(k).toUpperCase(Locale.US));
        }
        if (w.optBoolean("mine")) b.append(b.length() > 0 ? "  ·  " : "").append("MINE");
        return b.toString();
    }

    // ===================================================== wisdom page
    private void wisdomPage(LinearLayout page) {
        titleRow(page, Lang.t("nav_wisdom"));
        page.addView(Ui.text(this, Lang.t("wisdom_sub"), 13, Ui.SUB, false));
        page.addView(Ui.space(this, 12));
        LinearLayout btns = Ui.row(this);
        TextView add = Ui.button(this, Lang.t("add_one"), Ui.GOLD, Ui.GOLD_D, 0xFF1A1205);
        add.setTextSize(14);
        add.setPadding(Ui.dp(12), Ui.dp(10), Ui.dp(12), Ui.dp(10));
        TextView imp = Ui.ghost(this, Lang.t("paste_many"), Ui.GOLD);
        btns.addView(add, Ui.weight(1));
        btns.addView(Ui.space(this, 1), Ui.lp(Ui.dp(10), 1));
        btns.addView(imp, Ui.weight(1));
        page.addView(btns);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Dialogs.addWisdom(MainActivity.this, reb);
            }
        });
        imp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Dialogs.importWisdom(MainActivity.this, reb);
            }
        });

        final String[] keys = new String[Dialogs.TOPICS.length + 2];
        final String[] labels = new String[keys.length];
        keys[0] = "all";
        labels[0] = Lang.t("all");
        keys[1] = "fav";
        labels[1] = Lang.t("saved_tab");
        for (int k = 0; k < Dialogs.TOPICS.length; k++) {
            keys[k + 2] = Dialogs.TOPICS[k];
            labels[k + 2] = Dialogs.topicLabel(Dialogs.TOPICS[k]);
        }
        int sel = 0;
        for (int k = 0; k < keys.length; k++) if (keys[k].equals(wisdomFilter)) sel = k;
        final int[] holder = {sel};
        final LinearLayout list = Ui.col(this);
        final HorizontalScrollView[] chipsRef = new HorizontalScrollView[1];
        final Runnable fill = new Runnable() {
            @Override
            public void run() {
                list.removeAllViews();
                List<JSONObject> shown = new ArrayList<JSONObject>();
                if (wisdomQuery.trim().length() >= 2) {
                    for (Library.Hit hit : Library.get(MainActivity.this).search(s, wisdomQuery, 40)) shown.add(hit.item);
                    list.addView(Ui.text(MainActivity.this, Lang.pick(shown.size() + " found for “" + wisdomQuery.trim() + "”", "“" + wisdomQuery.trim() + "” માટે " + shown.size() + " મળ્યા"),
                            12, Ui.MUTED, false), Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 10));
                    for (JSONObject o : shown) list.addView(wisdomCard(o, false), Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 10));
                    return;
                }
                for (JSONObject o : s.wisdom()) {
                    if (wisdomFilter.equals("all")) shown.add(o);
                    else if (wisdomFilter.equals("fav")) {
                        if (s.isFav(o.optString("id"))) shown.add(o);
                    } else if (Store.hasTopic(o, wisdomFilter)) shown.add(o);
                }
                int sh = s.i("wisdom_shuffle", 0);
                if (sh > 0) java.util.Collections.shuffle(shown, new java.util.Random(sh * 31L + Store.dayNumber()));
                list.addView(Ui.text(MainActivity.this, Lang.t("n_reminders", shown.size()), 12, Ui.MUTED, false), Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 10));
                for (JSONObject o : shown) list.addView(wisdomCard(o, false), Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 10));
                list.setAlpha(0f);
                list.animate().alpha(1f).setDuration(180).start();
            }
        };
        final View chips = Dialogs.selector(this, labels, holder, new Runnable() {
            @Override
            public void run() {
                wisdomFilter = keys[holder[0]];
                fill.run(); // only the list changes — the chip row stays where it is
                centerChip(chipsRef[0], holder[0]);
            }
        });
        chipsRef[0] = (HorizontalScrollView) chips;
        final android.widget.EditText search = Ui.input(this, Lang.pick("🔎  Search ayat & hadith (English / ગુજરાતી / عربي)", "🔎  આયત અને હદીસ શોધો (English / ગુજરાતી / عربي)"), wisdomQuery, false);
        search.setSingleLine(true);
        page.addView(search, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 14, 0, 0));
        search.addTextChangedListener(new android.text.TextWatcher() {
            final Runnable run = new Runnable() {
                @Override
                public void run() {
                    fill.run();
                }
            };

            @Override
            public void beforeTextChanged(CharSequence c, int a, int b, int d) {
            }

            @Override
            public void onTextChanged(CharSequence c, int a, int b, int d) {
            }

            @Override
            public void afterTextChanged(android.text.Editable e) {
                wisdomQuery = e.toString();
                h.removeCallbacks(run);
                h.postDelayed(run, 300);
            }
        });
        chips.setPadding(0, Ui.dp(16), 0, Ui.dp(12));
        page.addView(chips);
        page.addView(list);
        fill.run();
        final int start = sel;
        chips.post(new Runnable() {
            @Override
            public void run() {
                centerChip(chipsRef[0], start);
            }
        });
    }

    private void centerChip(HorizontalScrollView hs, int idx) {
        if (hs == null || hs.getChildCount() == 0) return;
        LinearLayout row = (LinearLayout) hs.getChildAt(0);
        if (idx < 0 || idx >= row.getChildCount()) return;
        View c = row.getChildAt(idx);
        hs.smoothScrollTo(Math.max(0, c.getLeft() - (hs.getWidth() - c.getWidth()) / 2), 0);
    }

    // ===================================================== DISCOVER (rebuilt)
    private static int[] catColors(String cat) {
        if ("Health".equals(cat)) return new int[]{0xFF065F56, 0xFF0B3B33};
        if ("Habits".equals(cat)) return new int[]{0xFF4338CA, 0xFF2E1065};
        if ("Business".equals(cat)) return new int[]{0xFF9A3412, 0xFF431407};
        if ("Islam".equals(cat)) return new int[]{0xFF155E63, 0xFF0C2A33};
        if ("Quran".equals(cat)) return new int[]{0xFF15803D, 0xFF052E16};
        if ("Success".equals(cat)) return new int[]{0xFFBE185D, 0xFF4A0E2E};
        if ("Hadith".equals(cat)) return new int[]{0xFF0F5132, 0xFF1C1917};
        if ("Money".equals(cat)) return new int[]{0xFFA16207, 0xFF3B2005};
        if ("Family".equals(cat)) return new int[]{0xFF9D174D, 0xFF2A0A1E};
        return new int[]{0xFF1D4ED8, 0xFF0C1E4A};
    }

    private static String catName(String cat) {
        if (Lang.ur() || Lang.hi()) return Lang.tr(cat);
        if (!Lang.gu()) return cat.toUpperCase(Locale.US);
        if ("Health".equals(cat)) return "તંદુરસ્તી";
        if ("Habits".equals(cat)) return "આદતો";
        if ("Business".equals(cat)) return "ધંધો";
        if ("Islam".equals(cat)) return "ઇસ્લામ";
        if ("Quran".equals(cat)) return "કુરઆન";
        if ("Success".equals(cat)) return "સફળતા";
        if ("Mind".equals(cat)) return "મન";
        if ("Hadith".equals(cat)) return "હદીસ";
        if ("Money".equals(cat)) return "પૈસા";
        if ("Family".equals(cat)) return "પરિવાર";
        return cat;
    }

    private void feedPage(LinearLayout page) {
        final java.util.List<JSONObject> order = s.deck();
        final String key = "feedpos_" + Store.today();
        final int pos = Math.min(s.i(key, 0), order.size());

        titleRow(page, Lang.t("nav_discover"));
        page.addView(Ui.text(this, Lang.t("discover_sub", order.size()), 13, Ui.SUB, false));

        final LinearLayout seg = Ui.row(this);
        seg.setPadding(0, Ui.dp(14), 0, Ui.dp(16));
        for (int k = 0; k < order.size(); k++) {
            View sgv = new View(this);
            sgv.setBackground(Ui.round(k < pos ? Ui.GOLD : k == pos ? Ui.alpha(Ui.GOLD, 0.55f) : Ui.alpha(0xFFFFFFFF, 0.12f), 4));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, Ui.dp(4), 1f);
            p.setMargins(Ui.dp(2), 0, Ui.dp(2), 0);
            seg.addView(sgv, p);
        }
        page.addView(seg);

        int cardH = Math.round(getResources().getDisplayMetrics().heightPixels * 0.60f);

        if (pos >= order.size()) {
            LinearLayout done = Ui.col(this);
            done.setGravity(Gravity.CENTER);
            done.setBackground(Ui.grad3(0xFF1E1B4B, 0xFF0F766E, 0xFF064E3B, 30));
            done.setPadding(Ui.dp(24), Ui.dp(40), Ui.dp(24), Ui.dp(40));
            TextView e = Ui.text(this, "🎯", 64, Ui.TEXT, false);
            e.setGravity(Gravity.CENTER);
            done.addView(e);
            TextView t = Ui.title(this, Lang.t("done_today"), 26);
            t.setGravity(Gravity.CENTER);
            done.addView(t);
            TextView m = Ui.text(this, Lang.t("done_msg", order.size()), 15, Ui.alpha(0xFFFFFFFF, 0.85f), false);
            m.setGravity(Gravity.CENTER);
            m.setPadding(0, Ui.dp(10), 0, Ui.dp(22));
            done.addView(m);
            TextView go = Ui.button(this, Lang.t("go_tasks"), Ui.GOLD, Ui.GOLD_D, 0xFF1A1205);
            done.addView(go, Ui.lp(Ui.MATCH, Ui.WRAP));
            done.addView(Ui.space(this, 10));
            TextView again = Ui.ghost(this, Lang.t("read_again"), 0xFFFFFFFF);
            done.addView(again, Ui.lp(Ui.MATCH, Ui.WRAP));
            go.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    goTab(0);
                }
            });
            again.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    s.put(key, 0);
                    refresh();
                }
            });
            page.addView(done, new LinearLayout.LayoutParams(Ui.MATCH, cardH));
            return;
        }

        // Story-style deck: tap right = next, tap left = back, or swipe. Cards change in place (no page rebuild).
        final int[] cur = {pos};
        final boolean[] busy = {false};
        final FeedCard card = new FeedCard(this);
        card.setElevation(Ui.dp(10));
        page.addView(card, new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP));

        LinearLayout actions = Ui.row(this);
        actions.setPadding(0, Ui.dp(12), 0, 0);
        final TextView fav = Ui.ghost(this, "", Ui.SUB);
        TextView share = Ui.ghost(this, Lang.t("share"), Ui.SUB);
        final TextView next = Ui.button(this, "", Ui.GOLD, Ui.GOLD_D, 0xFF1A1205);
        next.setPadding(Ui.dp(14), Ui.dp(10), Ui.dp(14), Ui.dp(10));
        actions.addView(fav, Ui.weight(1));
        actions.addView(Ui.space(this, 1), Ui.lp(Ui.dp(8), 1));
        actions.addView(share, Ui.weight(1));
        actions.addView(Ui.space(this, 1), Ui.lp(Ui.dp(8), 1));
        actions.addView(next, Ui.weight(1.2f));
        page.addView(actions);

        final Runnable fill = new Runnable() {
            @Override
            public void run() {
                int p = cur[0];
                JSONObject item = order.get(p);
                int[] cc = catColors(item.optString("cat"));
                card.set(cc[0], cc[1], catName(item.optString("cat")), (p + 1) + " / " + order.size(), item.optString("e"),
                        item, HadithCard.label("Tap right → next  ·  tap left ← back", "જમણે ટૅપ → આગળ  ·  ડાબે ટૅપ ← પાછળ",
                                "دائیں ٹیپ → اگلا  ·  بائیں ٹیپ ← پچھلا", "दाएँ टैप → अगला  ·  बाएँ टैप ← पिछला"));
                card.setArabic(item.optString("ar"), item.optString("ars"));
                card.setSource(item.optString("src"));
                for (int k = 0; k < seg.getChildCount(); k++)
                    seg.getChildAt(k).setBackground(Ui.round(k < p ? Ui.GOLD : k == p ? Ui.alpha(Ui.GOLD, 0.55f) : Ui.alpha(0xFFFFFFFF, 0.12f), 4));
                String fid = item.optString("fid");
                fav.setText(s.isFav(fid) ? Lang.t("saved") : Lang.t("save"));
                fav.setTextColor(s.isFav(fid) ? Ui.PINK : Ui.SUB);
                next.setText(p == order.size() - 1 ? Lang.t("finish") : Lang.t("next"));
            }
        };
        fill.run();

        // dir: +1 next, -1 back. fromX: where the card is now (after a drag), so the motion continues smoothly.
        final android.view.animation.DecelerateInterpolator dec = new android.view.animation.DecelerateInterpolator(2f);
        final android.view.animation.AccelerateInterpolator acc = new android.view.animation.AccelerateInterpolator(1.5f);
        final Dialogs.IntCallback go = new Dialogs.IntCallback() {
            @Override
            public void done(final int dir) {
                if (busy[0]) return;
                final int np = cur[0] + dir;
                if (np < 0) { // first card: small bounce
                    Haptics.play(Haptics.WARN);
                    card.animate().translationX(Ui.dp(18)).rotation(0).setDuration(90).withEndAction(new Runnable() {
                        @Override
                        public void run() {
                            card.animate().translationX(0).setDuration(160).setInterpolator(dec).start();
                        }
                    }).start();
                    return;
                }
                busy[0] = true;
                Haptics.play(Haptics.NAV);
                final float w = Math.max(1, card.getWidth());
                card.animate().translationX(-dir * w * 0.45f).rotation(-dir * 3f).alpha(0f).setDuration(130).setInterpolator(acc)
                        .withEndAction(new Runnable() {
                            @Override
                            public void run() {
                                if (np >= order.size()) {
                                    s.put(key, order.size());
                                    busy[0] = false;
                                    refresh();
                                    return;
                                }
                                cur[0] = np;
                                s.put(key, np);
                                fill.run();
                                card.setTranslationX(dir * w * 0.35f);
                                card.setRotation(dir * 2f);
                                card.animate().translationX(0).rotation(0).alpha(1f).setDuration(240).setInterpolator(dec)
                                        .withEndAction(new Runnable() {
                                            @Override
                                            public void run() {
                                                busy[0] = false;
                                            }
                                        }).start();
                            }
                        }).start();
            }
        };
        final Runnable goNext = new Runnable() {
            @Override
            public void run() {
                go.done(1);
            }
        };
        final Runnable goPrev = new Runnable() {
            @Override
            public void run() {
                go.done(-1);
            }
        };

        card.setOnTouchListener(new View.OnTouchListener() {
            float x0, y0;
            long t0;
            int mode; // 0 undecided, 1 horizontal drag, 2 vertical (let the page scroll)
            final int slop = android.view.ViewConfiguration.get(MainActivity.this).getScaledTouchSlop();
            android.view.VelocityTracker vt;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                if (vt == null) vt = android.view.VelocityTracker.obtain();
                vt.addMovement(e);
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        x0 = e.getRawX();
                        y0 = e.getRawY();
                        t0 = e.getEventTime();
                        mode = 0;
                        v.animate().cancel();
                        if (!busy[0]) v.animate().scaleX(0.985f).scaleY(0.985f).setDuration(90).start();
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        float dx = e.getRawX() - x0, dy = e.getRawY() - y0;
                        if (mode == 0 && (Math.abs(dx) > slop || Math.abs(dy) > slop)) {
                            mode = Math.abs(dx) > Math.abs(dy) ? 1 : 2;
                            if (mode == 1) v.getParent().requestDisallowInterceptTouchEvent(true);
                            v.animate().scaleX(1f).scaleY(1f).setDuration(90).start();
                        }
                        if (mode == 1 && !busy[0]) {
                            if (cur[0] == 0 && dx > 0) dx *= 0.3f; // rubber band on the first card
                            v.setTranslationX(dx);
                            v.setRotation(dx / Ui.dp(60));
                        }
                        return true;
                    }
                    case MotionEvent.ACTION_UP: {
                        float dx = e.getRawX() - x0, dy = e.getRawY() - y0;
                        vt.computeCurrentVelocity(1000);
                        float vx = vt.getXVelocity();
                        vt.recycle();
                        vt = null;
                        v.animate().scaleX(1f).scaleY(1f).setDuration(90).start();
                        if (busy[0]) return true;
                        if (mode == 1) {
                            boolean fling = Math.abs(vx) > Ui.dp(500) && Math.signum(vx) == Math.signum(dx);
                            if (Math.abs(dx) > v.getWidth() * 0.22f || fling) {
                                if (dx < 0) goNext.run();
                                else if (cur[0] > 0) goPrev.run();
                                else v.animate().translationX(0).rotation(0).setDuration(200).setInterpolator(dec).start();
                            } else v.animate().translationX(0).rotation(0).setDuration(200).setInterpolator(dec).start();
                        } else if (mode == 0 && e.getEventTime() - t0 < 400 && Math.abs(dx) < slop && Math.abs(dy) < slop) {
                            // tap: left third = back, rest = forward (like Instagram stories)
                            if (e.getX() < v.getWidth() * 0.33f) goPrev.run();
                            else goNext.run();
                        }
                        return true;
                    }
                    case MotionEvent.ACTION_CANCEL:
                        if (vt != null) {
                            vt.recycle();
                            vt = null;
                        }
                        v.animate().translationX(0).rotation(0).scaleX(1f).scaleY(1f).setDuration(200).start();
                        return true;
                }
                return false;
            }
        });

        fav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String fid = order.get(cur[0]).optString("fid");
                s.toggleFav(fid);
                boolean on = s.isFav(fid);
                fav.setText(on ? Lang.t("saved") : Lang.t("save"));
                fav.setTextColor(on ? Ui.PINK : Ui.SUB);
            }
        });
        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                JSONObject item = order.get(cur[0]);
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                String ar = item.optString("ar"), src = item.optString("ars").length() > 0 ? item.optString("ars") : item.optString("src");
                i.putExtra(Intent.EXTRA_TEXT, item.optString("e") + " " + Lang.one(item, new String[]{"t", "gt", "ut", "ht"})
                        + (ar.length() > 0 ? "\n\n" + ar : "")
                        + "\n\n" + Lang.one(item, new String[]{"b", "gb", "ub", "hb"})
                        + (item.optString("x").length() > 0 ? "\n\n✅ " + Lang.one(item, new String[]{"x", "gx", "ux", "hx"}) : "")
                        + (src.length() > 0 ? "\n— " + src : "") + "\n\nvia Muhasabah");
                startActivity(Intent.createChooser(i, Lang.t("share")));
            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goNext.run();
            }
        });
    }

    // ===================================================== PROGRESS
    private void statsPage(LinearLayout page) {
        int xp = Score.xp(s), lvl = Score.level(xp);
        int streak = Score.streak(s), best = Math.max(streak, s.i("best_streak", 0));
        titleRow(page, Lang.t("nav_progress"));
        page.addView(Ui.text(this, Lang.t("progress_sub"), 13, Ui.SUB, false), Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 14));
        LinearLayout sumRow = Ui.row(this);
        String[][] sb = {{Lang.pick("📅  Day", "📅  દિવસ"), "0"}, {Lang.pick("🗓  Week", "🗓  અઠવાડિયું"), "1"}, {Lang.pick("📆  Month", "📆  મહિનો"), "2"}};
        for (int k = 0; k < sb.length; k++) {
            final int mode = Integer.parseInt(sb[k][1]);
            TextView b = k == 1 ? Ui.button(this, sb[k][0], Ui.GOLD, Ui.GOLD_D, 0xFF1A1205) : Ui.ghost(this, sb[k][0], Ui.GOLD);
            b.setTextSize(13.5f);
            b.setPadding(Ui.dp(6), Ui.dp(11), Ui.dp(6), Ui.dp(11));
            LinearLayout.LayoutParams lp = Ui.weight(1);
            lp.setMargins(k == 0 ? 0 : Ui.dp(4), 0, k == 2 ? 0 : Ui.dp(4), 0);
            sumRow.addView(b, lp);
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startActivity(new Intent(MainActivity.this, SummaryActivity.class).putExtra("mode", mode));
                }
            });
        }
        page.addView(Ui.text(this, Lang.pick("SUMMARIES", "સારાંશ"), 12, Ui.SUB, true), Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 8));
        page.addView(sumRow, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 16));

        LinearLayout lc = Ui.col(this);
        lc.setBackground(Ui.grad3(0xFF4C1D95, 0xFF6D28D9, 0xFFBE185D, 26));
        lc.setPadding(Ui.dp(20), Ui.dp(18), Ui.dp(20), Ui.dp(18));
        LinearLayout lr = Ui.row(this);
        LinearLayout lcol = Ui.col(this);
        lcol.addView(Ui.text(this, Lang.pick("LEVEL ", "લેવલ ") + (lvl + 1), 12, Ui.GOLD_L, true));
        TextView ln = Ui.title(this, Lang.tr(Score.LEVEL_NAMES[lvl]), 28);
        ln.setTextColor(0xFFFFFFFF);
        lcol.addView(ln);
        lr.addView(lcol, Ui.weight(1));
        lr.addView(Ui.text(this, "🎖️", 44, Ui.TEXT, false));
        lc.addView(lr);
        lc.addView(Ui.space(this, 12));
        lc.addView(Ui.bar(this, Score.levelProgress(xp), Ui.GOLD, 10));
        String nx = lvl + 1 < Score.LEVEL_XP.length
                ? String.format(Locale.US, "%,d XP  ·  %,d → %s", xp, Score.LEVEL_XP[lvl + 1] - xp, Lang.tr(Score.LEVEL_NAMES[lvl + 1]))
                : String.format(Locale.US, "%,d XP  ·  Max", xp);
        TextView nt = Ui.text(this, nx, 13, Ui.alpha(0xFFFFFFFF, 0.85f), false);
        nt.setPadding(0, Ui.dp(8), 0, 0);
        lc.addView(nt);
        page.addView(lc, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));

        int sum7 = 0, n7 = 0, tp7 = 0;
        for (int k = 0; k > -7; k--) {
            String dd = Store.date(k);
            if (Score.hasData(s, dd) || k == 0) {
                sum7 += k == 0 ? Score.compute(s, dd).score : Score.dayScore(s, dd);
                n7++;
            }
            tp7 += s.timepassMinutes(dd);
        }
        LinearLayout tiles = Ui.equalRow(this);
        tiles.addView(tile("🔥", String.valueOf(streak), Lang.t("streak", best), Ui.ORANGE), Ui.cell());
        tiles.addView(Ui.space(this, 1), Ui.lp(Ui.dp(8), 1));
        tiles.addView(tile("✨", String.valueOf(Score.betterDays(s)), Lang.t("better_days"), Ui.GOLD), Ui.cell());
        tiles.addView(Ui.space(this, 1), Ui.lp(Ui.dp(8), 1));
        tiles.addView(tile("📈", String.valueOf(n7 == 0 ? 0 : sum7 / n7), Lang.t("avg7"), Ui.EMERALD), Ui.cell());
        page.addView(tiles, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));

        LinearLayout cc = Ui.card(this);
        LinearLayout ch = Ui.row(this);
        ch.addView(Ui.text(this, Lang.t("last14"), 15, Ui.TEXT, true), Ui.weight(1));
        ch.addView(Ui.text(this, "📱 " + (tp7 / 7) + Lang.pick(" min/day", " મિ/દિ"), 12, Ui.SUB, false));
        cc.addView(ch);
        Views.Bars bars = new Views.Bars(this);
        int[] vals = new int[14];
        String[] labs = new String[14];
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, -13);
        for (int k = 0; k < 14; k++) {
            int off = k - 13;
            String dd = Store.date(off);
            vals[k] = off == 0 ? Score.compute(s, dd).score : Score.dayScore(s, dd);
            labs[k] = String.valueOf(cal.get(Calendar.DAY_OF_MONTH));
            cal.add(Calendar.DAY_OF_YEAR, 1);
        }
        bars.set(vals, labs);
        cc.addView(bars, Ui.lpm(Ui.MATCH, Ui.dp(190), 0, 12, 0, 0));
        page.addView(cc, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));

        page.addView(Ui.title(this, Lang.t("badges"), 20), Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 8, 0, 10));
        List<Score.Badge> badges = Score.badges(s);
        LinearLayout brow = null;
        for (int k = 0; k < badges.size(); k++) {
            if (k % 3 == 0) {
                brow = Ui.row(this);
                brow.setGravity(Gravity.TOP);
                page.addView(brow, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 0, 0, 8));
            }
            Score.Badge bd = badges.get(k);
            LinearLayout bx = Ui.col(this);
            bx.setGravity(Gravity.CENTER_HORIZONTAL);
            bx.setPadding(Ui.dp(6), Ui.dp(14), Ui.dp(6), Ui.dp(12));
            bx.setBackground(bd.earned ? Ui.roundStroke(Ui.alpha(Ui.GOLD, 0.10f), 18, Ui.alpha(Ui.GOLD, 0.5f), 1)
                    : Ui.roundStroke(Ui.CARD, 18, Ui.STROKE, 1));
            TextView e = Ui.text(this, bd.earned ? bd.emoji : "🔒", 28, Ui.TEXT, false);
            e.setGravity(Gravity.CENTER);
            bx.addView(e);
            TextView n = Ui.text(this, bd.name, 12.5f, bd.earned ? Ui.GOLD_L : Ui.SUB, true);
            n.setGravity(Gravity.CENTER);
            n.setPadding(0, Ui.dp(6), 0, Ui.dp(2));
            bx.addView(n);
            TextView ds = Ui.text(this, bd.desc, 10.5f, Ui.MUTED, false);
            ds.setGravity(Gravity.CENTER);
            bx.addView(ds);
            LinearLayout.LayoutParams p = Ui.weight(1);
            p.setMargins(k % 3 == 0 ? 0 : Ui.dp(4), 0, k % 3 == 2 ? 0 : Ui.dp(4), 0);
            brow.addView(bx, p);
        }
        if (badges.size() % 3 != 0 && brow != null)
            for (int k = badges.size() % 3; k < 3; k++) brow.addView(new View(this), Ui.weight(1));
    }

    private View tile(String emoji, String value, String label, int color) {
        LinearLayout t = Ui.col(this);
        t.setBackground(Ui.roundStroke(Ui.CARD, 20, Ui.STROKE, 1));
        t.setPadding(Ui.dp(12), Ui.dp(14), Ui.dp(12), Ui.dp(14));
        t.addView(Ui.text(this, emoji, 20, Ui.TEXT, false));
        TextView v = Ui.title(this, value, 26);
        v.setTextColor(color);
        Ui.fit(v, 1, 13.0f);
        t.addView(v);
        TextView lb = Ui.text(this, label, 11.5f, Ui.SUB, false);
        Ui.fit(lb, 2, 8f);
        t.addView(lb);
        return t;
    }

    // ===================================================== in-app update
    void checkForUpdate(final boolean manual) {
        if (Updater.BASE.contains("GITHUB_USER")) return;
        if (!manual && System.currentTimeMillis() - s.l("upd_checked", 0) < 10 * 60000L && pendingUpdate == null) return;
        Updater.check(this, new Updater.Listener() {
            @Override
            public void onResult(Updater.Info newer, String error) {
                boolean had = pendingUpdate != null;
                pendingUpdate = newer;
                if (newer != null && !had && tab == 0) refresh();
                if (manual) android.widget.Toast.makeText(MainActivity.this, error != null
                        ? Lang.pick("Couldn't check: ", "ચેક ન થયું: ") + error
                        : newer == null ? Lang.pick("You have the latest version ✓", "તમારી પાસે નવું વર્ઝન છે ✓")
                        : Lang.pick("Update available!", "અપડેટ ઉપલબ્ધ છે!"), android.widget.Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onProgress(int percent) {
            }
        });
    }

    private View updateBanner() {
        final Updater.Info u = pendingUpdate;
        LinearLayout c = Ui.col(this);
        c.setBackground(Ui.grad(0xFF3A2A06, 0xFF1A1405, 20, GradientDrawable.Orientation.TL_BR));
        c.setPadding(Ui.dp(16), Ui.dp(14), Ui.dp(16), Ui.dp(14));
        LinearLayout r = Ui.row(this);
        LinearLayout t = Ui.col(this);
        t.addView(Ui.text(this, Lang.pick("⬆️  Update available · v", "⬆️  અપડેટ ઉપલબ્ધ · v") + u.versionName, 15, Ui.GOLD_L, true));
        if (u.notes != null && u.notes.length() > 0) {
            TextView n = Ui.text(this, u.notes, 12.5f, Ui.alpha(0xFFFFFFFF, 0.8f), false);
            n.setPadding(0, Ui.dp(4), 0, 0);
            t.addView(n);
        }
        r.addView(t, Ui.weight(1));
        final TextView go = Ui.text(this, Lang.pick("Update", "અપડેટ"), 14, 0xFF1A1205, true);
        go.setGravity(Gravity.CENTER);
        go.setBackground(Ui.grad(Ui.GOLD, Ui.GOLD_D, 50, GradientDrawable.Orientation.LEFT_RIGHT));
        go.setPadding(Ui.dp(16), Ui.dp(10), Ui.dp(16), Ui.dp(10));
        Ui.press(go);
        r.addView(go, Ui.lpm(Ui.WRAP, Ui.WRAP, 10, 0, 0, 0));
        c.addView(r);
        go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startUpdate(u, go);
            }
        });
        return c;
    }

    private void startUpdate(Updater.Info u, final TextView btn) {
        if (!Updater.ensureInstallPermission(this)) {
            android.widget.Toast.makeText(this, Lang.pick("Allow \"Install unknown apps\" for Muhasabah, then come back and tap Update again.",
                    "Muhasabah માટે \"Install unknown apps\" ચાલુ કરો, પછી પાછા આવીને ફરી અપડેટ દબાવો."), android.widget.Toast.LENGTH_LONG).show();
            return;
        }
        btn.setEnabled(false);
        btn.setText("0%");
        Updater.downloadAndInstall(this, u, new Updater.Listener() {
            @Override
            public void onResult(Updater.Info newer, String error) {
                btn.setEnabled(true);
                btn.setText(Lang.pick("Retry", "ફરી"));
                android.widget.Toast.makeText(MainActivity.this, Lang.pick("Update failed: ", "અપડેટ નિષ્ફળ: ") + error,
                        android.widget.Toast.LENGTH_LONG).show();
            }

            @Override
            public void onProgress(int percent) {
                btn.setText(percent >= 100 ? Lang.pick("Installing…", "ઇન્સ્ટૉલ…") : percent + "%");
            }
        });
    }

    // ===================================================== pull-to-refresh
    private void pullRefresh(final PullRefresh p) {
        String today = Store.today();
        if (tab == 0) {
            Greet.bump(s);
            s.refreshWisdom();
            s.put("upd_checked", 0L);
            checkForUpdate(false);
        } else if (tab == 1) {
            s.put("feed_seed_" + today, s.i("feed_seed_" + today, 0) + 1);
            s.put("feedpos_" + today, 0);
        } else if (tab == 2) {
            s.put("wisdom_shuffle", s.i("wisdom_shuffle", 0) + 1);
        }
        Content.sync(this, true, new Content.Done() {
            @Override
            public void done(int added, String error) {
                if (added > 0) android.widget.Toast.makeText(MainActivity.this, Lang.pick(added + " new ayat/hadith added ✨", added + " નવી આયત/હદીસ ઉમેરાઈ ✨"),
                        android.widget.Toast.LENGTH_SHORT).show();
            }
        });
        h.postDelayed(new Runnable() {
            @Override
            public void run() {
                p.done();
                scrollY[tab] = 0;
                animateNext = true;
                show(tab);
            }
        }, 450);
    }
}
