package com.mahendi.muhasabah;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadFactory;

/**
 * Body-part detector: finds faces (male / female) and covered or exposed body parts in a 320×320 picture.
 * Model: NudeNet 3 "320n" (YOLOv8n) by notAI-tech — AGPL-3.0; Muhasabah's source is published accordingly.
 * Weights are float16, run in pure Java on the phone; nothing leaves the device.
 */
public final class BodyNet {
    public static final int SIZE = 320;
    public static final String[] LABELS = {
            "FEMALE_GENITALIA_COVERED", "FACE_FEMALE", "BUTTOCKS_EXPOSED", "FEMALE_BREAST_EXPOSED",
            "FEMALE_GENITALIA_EXPOSED", "MALE_BREAST_EXPOSED", "ANUS_EXPOSED", "FEET_EXPOSED", "BELLY_COVERED",
            "FEET_COVERED", "ARMPITS_COVERED", "ARMPITS_EXPOSED", "FACE_MALE", "BELLY_EXPOSED",
            "MALE_GENITALIA_EXPOSED", "ANUS_COVERED", "FEMALE_BREAST_COVERED", "BUTTOCKS_COVERED"};
    public static final int F_GEN_COV = 0, FACE_F = 1, BUTT_EXP = 2, F_BREAST_EXP = 3, F_GEN_EXP = 4, M_BREAST_EXP = 5,
            ANUS_EXP = 6, FEET_EXP = 7, BELLY_COV = 8, FEET_COV = 9, ARMPIT_COV = 10, ARMPIT_EXP = 11, FACE_M = 12,
            BELLY_EXP = 13, M_GEN_EXP = 14, ANUS_COV = 15, F_BREAST_COV = 16, BUTT_COV = 17;
    private static final int NC = 18;

    /** One detection: class, score, box (x0, y0, x1, y1) in 0..1 of the 320 square. */
    public static final class Det {
        public int cls;
        public float score, x0, y0, x1, y1;

        public float area() {
            return Math.max(0, x1 - x0) * Math.max(0, y1 - y0);
        }
    }

    private static final int CONV = 1, SPLIT = 2, CONCAT = 3, ADD = 4, MAXPOOL = 5, UP2 = 6;

    private static final class Op {
        int type, in, in2, out, k, s, pt, pl, pb, pr, ci, co, act;
        int[] ins, outs, sizes;
        float[] w, b;
    }

    private final Op[] ops;
    private final int nbuf;
    private final int[] outIds = new int[3];
    private final ExecutorService pool;
    private final int threads;

    public BodyNet(InputStream raw) throws IOException {
        DataInputStream in = new DataInputStream(new BufferedInputStream(raw, 1 << 16));
        byte[] m = new byte[4];
        in.readFully(m);
        if (m[0] != 'Y' || m[1] != 'L' || m[2] != 'O' || m[3] != '1') throw new IOException("bad body model");
        int n = in.readInt();
        nbuf = in.readInt();
        for (int i = 0; i < 3; i++) outIds[i] = in.readInt();
        ops = new Op[n];
        for (int k = 0; k < n; k++) {
            Op o = new Op();
            o.type = in.readByte();
            switch (o.type) {
                case CONV: {
                    o.in = in.readInt();
                    o.out = in.readInt();
                    o.k = in.readInt();
                    o.s = in.readInt();
                    o.pt = in.readInt();
                    o.pl = in.readInt();
                    o.pb = in.readInt();
                    o.pr = in.readInt();
                    o.ci = in.readInt();
                    o.co = in.readInt();
                    o.act = in.readInt();
                    int len = o.k * o.k * o.ci * o.co;
                    byte[] h = new byte[len * 2];
                    in.readFully(h);
                    o.w = new float[len];
                    for (int i = 0; i < len; i++) o.w[i] = half(((h[2 * i] & 0xff) << 8) | (h[2 * i + 1] & 0xff));
                    o.b = new float[o.co];
                    for (int i = 0; i < o.co; i++) o.b[i] = in.readFloat();
                    break;
                }
                case SPLIT: {
                    o.in = in.readInt();
                    int c = in.readInt();
                    o.outs = new int[c];
                    o.sizes = new int[c];
                    for (int i = 0; i < c; i++) {
                        o.outs[i] = in.readInt();
                        o.sizes[i] = in.readInt();
                    }
                    break;
                }
                case CONCAT: {
                    int c = in.readInt();
                    o.ins = new int[c];
                    for (int i = 0; i < c; i++) o.ins[i] = in.readInt();
                    o.out = in.readInt();
                    break;
                }
                case ADD:
                    o.in = in.readInt();
                    o.in2 = in.readInt();
                    o.out = in.readInt();
                    break;
                case MAXPOOL:
                case UP2:
                    o.in = in.readInt();
                    o.out = in.readInt();
                    break;
                default:
                    throw new IOException("bad op " + o.type);
            }
            ops[k] = o;
        }
        in.close();
        threads = Math.max(1, Math.min(4, Runtime.getRuntime().availableProcessors() - 1));
        pool = Executors.newFixedThreadPool(threads, new ThreadFactory() {
            @Override
            public Thread newThread(Runnable r) {
                Thread t = new Thread(r, "body-net");
                t.setDaemon(true);
                t.setPriority(Thread.MIN_PRIORITY + 1);
                return t;
            }
        });
    }

    /** IEEE 754 half → float. */
    static float half(int h) {
        int s = (h >>> 15) & 1, e = (h >>> 10) & 0x1f, f = h & 0x3ff;
        float v;
        if (e == 0) v = (float) (f * Math.pow(2, -24));
        else if (e == 31) v = f == 0 ? Float.POSITIVE_INFINITY : Float.NaN;
        else v = Float.intBitsToFloat(((e - 15 + 127) << 23) | (f << 13));
        return s == 1 ? -v : v;
    }

    public void close() {
        pool.shutdownNow();
    }

    /** Raw head outputs (3 grids, HWC with 82 channels each) for an RGB 0..1 image of SIZE×SIZE. */
    public synchronized float[][] raw(float[] rgb) throws Exception {
        float[][] buf = new float[nbuf][];
        int[] H = new int[nbuf], W = new int[nbuf], C = new int[nbuf];
        buf[0] = rgb;
        H[0] = SIZE;
        W[0] = SIZE;
        C[0] = 3;
        for (final Op o : ops) {
            switch (o.type) {
                case CONV: {
                    final int h = H[o.in], w = W[o.in];
                    final int ho = (h + o.pt + o.pb - o.k) / o.s + 1, wo = (w + o.pl + o.pr - o.k) / o.s + 1;
                    final float[] src = buf[o.in], dst = new float[ho * wo * o.co];
                    parallel(ho, new Rows() {
                        @Override
                        public void run(int y0, int y1) {
                            conv(o, src, h, w, dst, wo, y0, y1);
                        }
                    });
                    buf[o.out] = dst;
                    H[o.out] = ho;
                    W[o.out] = wo;
                    C[o.out] = o.co;
                    break;
                }
                case SPLIT: {
                    float[] x = buf[o.in];
                    int c = C[o.in], px = H[o.in] * W[o.in], off = 0;
                    for (int i = 0; i < o.outs.length; i++) {
                        int sz = o.sizes[i];
                        float[] d = new float[px * sz];
                        for (int p = 0; p < px; p++) System.arraycopy(x, p * c + off, d, p * sz, sz);
                        buf[o.outs[i]] = d;
                        H[o.outs[i]] = H[o.in];
                        W[o.outs[i]] = W[o.in];
                        C[o.outs[i]] = sz;
                        off += sz;
                    }
                    break;
                }
                case CONCAT: {
                    int px = H[o.ins[0]] * W[o.ins[0]], c = 0;
                    for (int id : o.ins) c += C[id];
                    float[] d = new float[px * c];
                    int off = 0;
                    for (int id : o.ins) {
                        int ci = C[id];
                        float[] x = buf[id];
                        for (int p = 0; p < px; p++) System.arraycopy(x, p * ci, d, p * c + off, ci);
                        off += ci;
                    }
                    buf[o.out] = d;
                    H[o.out] = H[o.ins[0]];
                    W[o.out] = W[o.ins[0]];
                    C[o.out] = c;
                    break;
                }
                case ADD: {
                    float[] a = buf[o.in], b = buf[o.in2], d = new float[a.length];
                    for (int i = 0; i < d.length; i++) d[i] = a[i] + b[i];
                    buf[o.out] = d;
                    H[o.out] = H[o.in];
                    W[o.out] = W[o.in];
                    C[o.out] = C[o.in];
                    break;
                }
                case MAXPOOL: {
                    float[] x = buf[o.in];
                    int h = H[o.in], w = W[o.in], c = C[o.in];
                    float[] d = new float[x.length];
                    for (int y = 0; y < h; y++)
                        for (int xx = 0; xx < w; xx++) {
                            int op = (y * w + xx) * c;
                            for (int j = 0; j < c; j++) d[op + j] = Float.NEGATIVE_INFINITY;
                            for (int i = Math.max(0, y - 2); i <= Math.min(h - 1, y + 2); i++)
                                for (int jx = Math.max(0, xx - 2); jx <= Math.min(w - 1, xx + 2); jx++) {
                                    int sp = (i * w + jx) * c;
                                    for (int j = 0; j < c; j++) if (x[sp + j] > d[op + j]) d[op + j] = x[sp + j];
                                }
                        }
                    buf[o.out] = d;
                    H[o.out] = h;
                    W[o.out] = w;
                    C[o.out] = c;
                    break;
                }
                default: { // UP2 (nearest)
                    float[] x = buf[o.in];
                    int h = H[o.in], w = W[o.in], c = C[o.in];
                    float[] d = new float[x.length * 4];
                    for (int y = 0; y < h * 2; y++)
                        for (int xx = 0; xx < w * 2; xx++)
                            System.arraycopy(x, ((y / 2) * w + xx / 2) * c, d, (y * w * 2 + xx) * c, c);
                    buf[o.out] = d;
                    H[o.out] = h * 2;
                    W[o.out] = w * 2;
                    C[o.out] = c;
                }
            }
        }
        return new float[][]{buf[outIds[0]], buf[outIds[1]], buf[outIds[2]]};
    }

    /** Detections above minScore, after non-maximum suppression (per class). */
    public List<Det> detect(float[] rgb, float minScore) throws Exception {
        float[][] outs = raw(rgb);
        int[] strides = {8, 16, 32};
        List<Det> all = new ArrayList<Det>();
        float[] e = new float[16];
        for (int s = 0; s < 3; s++) {
            int g = SIZE / strides[s];
            float[] o = outs[s];
            for (int y = 0; y < g; y++)
                for (int x = 0; x < g; x++) {
                    int p = (y * g + x) * (64 + NC);
                    int best = -1;
                    float bl = -1e9f;
                    for (int c = 0; c < NC; c++) if (o[p + 64 + c] > bl) {
                        bl = o[p + 64 + c];
                        best = c;
                    }
                    float sc = (float) (1 / (1 + Math.exp(-bl)));
                    if (sc < minScore) continue;
                    float[] d = new float[4];
                    for (int side = 0; side < 4; side++) {
                        int q = p + side * 16;
                        float mx = -1e9f, sum = 0, acc = 0;
                        for (int i = 0; i < 16; i++) mx = Math.max(mx, o[q + i]);
                        for (int i = 0; i < 16; i++) {
                            e[i] = (float) Math.exp(o[q + i] - mx);
                            sum += e[i];
                        }
                        for (int i = 0; i < 16; i++) acc += e[i] * i;
                        d[side] = acc / sum;
                    }
                    Det dt = new Det();
                    dt.cls = best;
                    dt.score = sc;
                    dt.x0 = (x + 0.5f - d[0]) * strides[s] / SIZE;
                    dt.y0 = (y + 0.5f - d[1]) * strides[s] / SIZE;
                    dt.x1 = (x + 0.5f + d[2]) * strides[s] / SIZE;
                    dt.y1 = (y + 0.5f + d[3]) * strides[s] / SIZE;
                    all.add(dt);
                }
        }
        Collections.sort(all, new Comparator<Det>() {
            @Override
            public int compare(Det a, Det b) {
                return Float.compare(b.score, a.score);
            }
        });
        List<Det> keep = new ArrayList<Det>();
        for (Det d : all) {
            boolean ok = true;
            for (Det k : keep) if (iou(d, k) > 0.45f) { // NudeNet suppresses across classes
                ok = false;
                break;
            }
            if (ok) keep.add(d);
            if (keep.size() >= 40) break;
        }
        return keep;
    }

    static float iou(Det a, Det b) {
        float ix = Math.max(0, Math.min(a.x1, b.x1) - Math.max(a.x0, b.x0)), iy = Math.max(0, Math.min(a.y1, b.y1) - Math.max(a.y0, b.y0));
        float in = ix * iy, u = a.area() + b.area() - in;
        return u <= 0 ? 0 : in / u;
    }

    private interface Rows {
        void run(int y0, int y1);
    }

    private void parallel(final int rows, final Rows r) throws Exception {
        int parts = Math.min(threads, rows);
        if (parts <= 1) {
            r.run(0, rows);
            return;
        }
        List<Callable<Void>> jobs = new ArrayList<Callable<Void>>();
        for (int p = 0; p < parts; p++) {
            final int y0 = rows * p / parts, y1 = rows * (p + 1) / parts;
            jobs.add(new Callable<Void>() {
                @Override
                public Void call() {
                    r.run(y0, y1);
                    return null;
                }
            });
        }
        for (Future<Void> f : pool.invokeAll(jobs)) f.get();
    }

    /** Convolution (NHWC, weights [k][k][ci][co]) + bias, optional SiLU. */
    private static void conv(Op o, float[] src, int h, int w, float[] dst, int wo, int y0, int y1) {
        final int ci = o.ci, co = o.co, k = o.k, st = o.s;
        final float[] wt = o.w, b = o.b;
        float[] acc = new float[co];
        for (int y = y0; y < y1; y++) {
            for (int x = 0; x < wo; x++) {
                System.arraycopy(b, 0, acc, 0, co);
                for (int i = 0; i < k; i++) {
                    int iy = y * st + i - o.pt;
                    if (iy < 0 || iy >= h) continue;
                    for (int j = 0; j < k; j++) {
                        int ix = x * st + j - o.pl;
                        if (ix < 0 || ix >= w) continue;
                        int sp = (iy * w + ix) * ci, wp = (i * k + j) * ci * co;
                        for (int c = 0; c < ci; c++) {
                            float v = src[sp + c];
                            if (v == 0f) continue;
                            int row = wp + c * co;
                            for (int d = 0; d < co; d++) acc[d] += v * wt[row + d];
                        }
                    }
                }
                int op = (y * wo + x) * co;
                if (o.act == 1) for (int d = 0; d < co; d++) {
                    float v = acc[d];
                    dst[op + d] = v / (1f + (float) Math.exp(-v));
                }
                else System.arraycopy(acc, 0, dst, op, co);
            }
        }
    }
}
