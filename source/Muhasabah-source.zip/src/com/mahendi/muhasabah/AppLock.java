package com.mahendi.muhasabah;

import android.content.Context;

/**
 * Whole-app locks. When the guard catches something haram in an app, that app stays locked for
 * {@link #CATCH_MS}; when a daily hard limit (e.g. Instagram 40 min) is used up, the app stays locked
 * until midnight. A locked app can't be used at all: every time it comes to the front, Muhasabah's
 * block screen opens instead. There is no "extend" button.
 */
public final class AppLock {
    public static final long CATCH_MS = 30 * 60_000L;
    private static final String K = "applock_", K_WHY = "applockwhy_";
    /** Daily hard limit in minutes per app (0 = none). Raising one only takes effect tomorrow. */
    public static final String K_CAP = "cap_", K_CAP_NEXT = "capnext_", K_CAP_DAY = "capday_";
    public static final String IG = "com.instagram.android";

    /** Apps offered for a daily hard limit, with their default (Instagram 40 min). */
    public static final String[][] CAPPABLE = {
            {IG, "Instagram", "40"},
            {"com.instagram.lite", "Instagram Lite", "40"},
            {"com.google.android.youtube", "YouTube", "0"},
            {"com.facebook.katana", "Facebook", "0"},
            {"com.snapchat.android", "Snapchat", "0"},
            {"com.zhiliaoapp.musically", "TikTok", "0"},
            {"in.mohalla.sharechat", "ShareChat", "0"},
            {"com.twitter.android", "X (Twitter)", "0"}};

    private AppLock() {
    }

    public static long until(Store s, String pkg) {
        return pkg == null ? 0 : s.l(K + pkg, 0);
    }

    public static boolean locked(Store s, String pkg) {
        return until(s, pkg) > System.currentTimeMillis();
    }

    /** reason: "vulgar", "word", "incognito", "reels" or "cap". Never shortens an existing lock. */
    public static void lock(Store s, String pkg, long untilMs, String reason) {
        if (pkg == null || pkg.length() == 0) return;
        if (untilMs <= until(s, pkg)) return;
        s.put(K + pkg, untilMs);
        s.put(K_WHY + pkg, reason);
    }

    public static void unlock(Store s, String pkg) {
        s.put(K + pkg, 0L);
    }

    public static String why(Store s, String pkg) {
        return s.s(K_WHY + pkg, "vulgar");
    }

    public static long endOfToday() {
        return Store.startOfToday() + 86_400_000L;
    }

    // ---------------- daily hard limits ----------------
    public static int capDefault(String pkg) {
        for (String[] a : CAPPABLE) if (a[0].equals(pkg)) return Integer.parseInt(a[2]);
        return 0;
    }

    /** Today's limit in minutes (0 = no limit). A raise chosen today waits until tomorrow. */
    public static int cap(Store s, String pkg) {
        String today = Store.today();
        if (s.p.contains(K_CAP_NEXT + pkg) && !today.equals(s.s(K_CAP_DAY + pkg, ""))) {
            s.put(K_CAP + pkg, s.i(K_CAP_NEXT + pkg, 0));
            s.p.edit().remove(K_CAP_NEXT + pkg).apply();
        }
        return s.i(K_CAP + pkg, capDefault(pkg));
    }

    /** Lowering (or setting a limit) applies now; raising or removing applies from tomorrow. Returns true if it applied now. */
    public static boolean setCap(Store s, String pkg, int min) {
        int cur = cap(s, pkg);
        boolean stricter = cur == 0 ? min > 0 : (min > 0 && min < cur);
        if (stricter) {
            s.put(K_CAP + pkg, min);
            s.p.edit().remove(K_CAP_NEXT + pkg).apply();
            return true;
        }
        s.put(K_CAP_NEXT + pkg, min);
        s.put(K_CAP_DAY + pkg, Store.today());
        return false;
    }

    public static int pendingCap(Store s, String pkg) {
        return s.p.contains(K_CAP_NEXT + pkg) ? s.i(K_CAP_NEXT + pkg, 0) : -1;
    }

    public static String label(String pkg) {
        for (String[] a : CAPPABLE) if (a[0].equals(pkg)) return a[1];
        return pkg;
    }

    /** Minutes used today (from Android's own usage records). */
    public static int usedToday(Context c, String pkg) {
        try {
            return WatchService.measure(c, Store.startOfToday(), System.currentTimeMillis()).minutes(pkg);
        } catch (Throwable e) {
            return 0;
        }
    }

    public static String appName(Context c, String pkg) {
        try {
            android.content.pm.PackageManager pm = c.getPackageManager();
            return pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString();
        } catch (Exception e) {
            return label(pkg);
        }
    }
}
