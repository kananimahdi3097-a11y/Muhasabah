package com.mahendi.muhasabah;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/** Screens for the commitment lock: settings section, Today card, loosen feedback, emergency unlock, partner PIN. */
public final class LockUi {
    private LockUi() {
    }

    /**
     * Use for every change that makes the rules looser. Applies now only in the 30-min emergency window;
     * otherwise it waits the cooling-off period, and during a lock it's refused.
     */
    public static void loosen(final Activity a, JSONObject change, final Runnable after) {
        int r = Lock.request(a, change);
        Store s = Store.get(a);
        if (r == Lock.NOW) {
            Toast.makeText(a, Lang.pick("Applied ✓", "લાગુ થયું ✓"), Toast.LENGTH_SHORT).show();
            if (after != null) after.run();
            return;
        }
        if (r == Lock.QUEUED) {
            Haptics.play(Haptics.TOGGLE);
            long due = Lock.now(s) + Lock.coolHours(s) * 3600_000L;
            String when = new SimpleDateFormat("EEE h:mm a", Lang.locale()).format(new Date(due));
            LinearLayout body = Ui.col(a);
            body.addView(Ui.text(a, "⏳", 44, Ui.TEXT, false));
            body.addView(Ui.text(a, Lang.pick("Saved. “" + change.optString("desc") + "” will apply in " + Lock.coolHours(s) + " hours (" + when + ") — only if you still want it.",
                    "સેવ થયું. “" + change.optString("desc") + "” " + Lock.coolHours(s) + " કલાક પછી (" + when + ") લાગુ થશે — જો ત્યારે પણ જોઈતું હોય તો."), 15, Ui.TEXT, false));
            body.addView(Ui.space(a, 8));
            body.addView(Ui.text(a, Lang.pick("Most urges pass long before that. You can cancel it anytime in Settings → Commitment lock.",
                    "મોટા ભાગની ઇચ્છા એ પહેલાં જ જતી રહે છે. સેટિંગ્સ → કમિટમેન્ટ લૉકમાં ગમે ત્યારે રદ કરી શકો."), 13, Ui.SUB, false));
            body.addView(Ui.space(a, 16));
            TextView ok = Ui.button(a, Lang.pick("OK", "ઠીક"), Ui.GOLD, Ui.GOLD_D, 0xFF1A1205);
            body.addView(ok, Ui.lp(Ui.MATCH, Ui.WRAP));
            final AlertDialog d = Dialogs.sheet(a, Lang.pick("Cooling-off", "થોડી રાહ"), body);
            ok.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    d.dismiss();
                    if (after != null) after.run();
                }
            });
            d.show();
            return;
        }
        lockedSheet(a, after);
    }

    /** "Locked" explanation with a reminder and the emergency route. */
    public static void lockedSheet(final Activity a, final Runnable after) {
        Store s = Store.get(a);
        Haptics.play(Haptics.WARN);
        LinearLayout body = Ui.col(a);
        TextView big = Ui.text(a, "🔒", 48, Ui.TEXT, false);
        big.setGravity(Gravity.CENTER);
        body.addView(big, Ui.lp(Ui.MATCH, Ui.WRAP));
        TextView t = Ui.text(a, Lang.pick("Your rules are locked for " + Lock.left(Lock.remainingMs(s)) + " more. Right now you can only make them stricter.",
                "તમારા નિયમ હજી " + Lock.left(Lock.remainingMs(s)) + " લૉક છે. અત્યારે ફક્ત વધુ કડક કરી શકો."), 16, Ui.TEXT, true);
        t.setGravity(Gravity.CENTER);
        body.addView(t, Ui.lp(Ui.MATCH, Ui.WRAP));
        JSONObject w = s.pick("discipline", "akl", "purity");
        if (w != null) {
            LinearLayout wc = Ui.col(a);
            wc.setBackground(Ui.roundStroke(Ui.CARD2, 16, Ui.STROKE, 1));
            wc.setPadding(Ui.dp(14), Ui.dp(6), Ui.dp(14), Ui.dp(12));
            Ui.translations(a, wc, w, 14, true);
            TextView src = Ui.text(a, "— " + w.optString("src"), 11.5f, Ui.MUTED, false);
            src.setPadding(0, Ui.dp(6), 0, 0);
            wc.addView(src);
            body.addView(wc, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 14, 0, 0));
        }
        body.addView(Ui.space(a, 16));
        TextView ok = Ui.button(a, Lang.pick("I'll stay strong 💪", "હું મજબૂત રહીશ 💪"), Ui.EMERALD, Ui.TEAL, 0xFFFFFFFF);
        body.addView(ok, Ui.lp(Ui.MATCH, Ui.WRAP));
        TextView em = Ui.ghost(a, Lang.pick("Real emergency? Ask your partner", "સાચી ઇમરજન્સી? પાર્ટનરને પૂછો"), Ui.SUB);
        body.addView(em, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        final AlertDialog d = Dialogs.sheet(a, Lang.pick("Locked", "લૉક"), body);
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                d.dismiss();
                if (after != null) after.run();
            }
        });
        em.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                d.dismiss();
                emergency(a, after);
            }
        });
        d.show();
    }

    // ---------------- start a lock ----------------
    public static void startDialog(final Activity a, final Runnable after) {
        final Store s = Store.get(a);
        LinearLayout body = Ui.col(a);
        body.addView(Ui.text(a, Lang.pick("For this long, nothing can be loosened: no removing blocked words or sites, no raising app or reels limits, no switching the guardian off. Making rules stricter still works.",
                "આટલા સમય સુધી કંઈ ઢીલું નહીં થાય: બ્લૉક શબ્દ/સાઇટ હટાવી નહીં શકાય, ઍપ કે રીલ્સની મર્યાદા વધારી નહીં શકાય, ગાર્ડિયન બંધ નહીં થાય. કડક કરવું ચાલુ રહેશે."), 14, Ui.SUB, false));
        body.addView(Ui.space(a, 12));
        final int[] pick = {0};
        String[] labels = {Lang.pick("24 hours", "24 કલાક"), Lang.pick("48 hours", "48 કલાક"), Lang.pick("7 days", "7 દિવસ"), Lang.pick("30 days", "30 દિવસ")};
        body.addView(Dialogs.selector(a, labels, pick, null));
        body.addView(Ui.space(a, 12));
        boolean guard = GuardService.isOn(), admin = AdminReceiver.active(a);
        String warn = "";
        if (!guard) warn += Lang.pick("⚠️ The Accessibility guardian is off — phone-settings protection won't work.\n", "⚠️ ઍક્સેસિબિલિટી ગાર્ડિયન બંધ છે — ફોન-સેટિંગ્સ સુરક્ષા નહીં ચાલે.\n");
        if (!admin) warn += Lang.pick("⚠️ Uninstall protection is off — turn it on first for a real lock.", "⚠️ અનઇન્સ્ટૉલ સુરક્ષા બંધ છે — સાચા લૉક માટે પહેલાં ચાલુ કરો.");
        if (warn.length() > 0) {
            TextView wt = Ui.text(a, warn.trim(), 12.5f, Ui.ORANGE, false);
            body.addView(wt);
            body.addView(Ui.space(a, 10));
        }
        body.addView(Ui.text(a, Lang.pick("You can't undo this. Only your partner's emergency PIN can end it early — and that costs " + Lock.EMERGENCY_XP + " XP and your streak.",
                "આ પાછું નહીં ફરે. ફક્ત પાર્ટનરનો ઇમરજન્સી PIN વહેલું ખોલી શકે — અને તેની કિંમત " + Lock.EMERGENCY_XP + " XP અને તમારો સિલસિલો."), 12.5f, Ui.MUTED, false));
        body.addView(Ui.space(a, 14));
        TextView go = Ui.button(a, Lang.pick("🔒  Lock my rules", "🔒  મારા નિયમ લૉક કરો"), Ui.GOLD, Ui.GOLD_D, 0xFF1A1205);
        body.addView(go, Ui.lp(Ui.MATCH, Ui.WRAP));
        final AlertDialog d = Dialogs.sheet(a, Lang.pick("Commitment lock", "કમિટમેન્ટ લૉક"), body);
        go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Lock.start(s, Lock.HOURS[pick[0]]);
                WatchService.start(a);
                Lock.syncNetwork(a);
                Haptics.play(Haptics.SUCCESS);
                d.dismiss();
                Toast.makeText(a, Lang.pick("Locked 🔒 Bismillah — you've got this.", "લૉક થયું 🔒 બિસ્મિલ્લાહ — તમે કરી શકશો."), Toast.LENGTH_LONG).show();
                if (after != null) after.run();
            }
        });
        d.show();
    }

    // ---------------- emergency ----------------
    public static void emergency(final Activity a, final Runnable after) {
        final Store s = Store.get(a);
        LinearLayout body = Ui.col(a);
        if (!Lock.hasPin(s)) {
            body.addView(Ui.text(a, Lang.pick("No partner PIN is set, so there's no early way out. The lock ends on its own in " + Lock.left(Lock.remainingMs(s)) + ".",
                    "પાર્ટનર PIN સેટ નથી, એટલે વહેલો રસ્તો નથી. લૉક " + Lock.left(Lock.remainingMs(s)) + "માં જાતે ખૂલશે."), 15, Ui.TEXT, false));
            Dialogs.sheet(a, Lang.pick("Emergency unlock", "ઇમરજન્સી અનલૉક"), body).show();
            return;
        }
        String pn = s.s(Lock.K_PNAME, "");
        body.addView(Ui.text(a, Lang.pick("Ask " + (pn.isEmpty() ? "your partner" : pn) + " to type their PIN. Unlocking now costs " + Lock.EMERGENCY_XP
                        + " XP, resets your streak, and it shows in your weekly summary.",
                "PIN લખવા " + (pn.isEmpty() ? "તમારા પાર્ટનર" : pn) + "ને કહો. હમણાં અનલૉક કરવાથી " + Lock.EMERGENCY_XP + " XP કપાશે, સિલસિલો તૂટશે, અને સાપ્તાહિક સારાંશમાં દેખાશે."),
                14, Ui.SUB, false));
        body.addView(Ui.space(a, 12));
        final EditText pin = Ui.input(a, "PIN", "", true);
        pin.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        body.addView(pin);
        body.addView(Ui.space(a, 12));
        TextView go = Ui.button(a, Lang.pick("Unlock (emergency)", "અનલૉક (ઇમરજન્સી)"), Ui.RED, 0xFFBE123C, 0xFFFFFFFF);
        body.addView(go, Ui.lp(Ui.MATCH, Ui.WRAP));
        final String phone = s.s(Lock.K_PPHONE, "").replaceAll("[^0-9]", "");
        if (phone.length() >= 8) {
            TextView wa = Ui.ghost(a, Lang.pick("💬  Ask on WhatsApp", "💬  WhatsApp પર પૂછો"), Ui.EMERALD);
            body.addView(wa, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
            wa.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String msg = "Assalamu alaikum. I'm asking for my Muhasabah emergency unlock PIN. Reason: ";
                    try {
                        a.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + phone + "?text=" + Uri.encode(msg))));
                    } catch (Exception e) {
                        Toast.makeText(a, "WhatsApp not found", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
        final AlertDialog d = Dialogs.sheet(a, Lang.pick("Emergency unlock", "ઇમરજન્સી અનલૉક"), body);
        go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!Lock.checkPin(s, pin.getText().toString().trim())) {
                    Haptics.play(Haptics.WARN);
                    Lock.log(s, "pin_wrong", "");
                    pin.setText("");
                    Toast.makeText(a, Lang.pick("Wrong PIN", "ખોટો PIN"), Toast.LENGTH_SHORT).show();
                    return;
                }
                Lock.emergencyUnlock(s);
                Lock.applyDue(a);
                d.dismiss();
                Toast.makeText(a, Lang.pick("Unlocked. For 30 minutes changes apply instantly. The PIN is used up — your partner can set a new one.",
                        "અનલૉક. 30 મિનિટ સુધી ફેરફાર તરત લાગુ થશે. PIN વપરાઈ ગયો — પાર્ટનર નવો સેટ કરી શકે."), Toast.LENGTH_LONG).show();
                if (after != null) after.run();
            }
        });
        d.show();
    }

    // ---------------- partner ----------------
    public static void partnerDialog(final Activity a, final Runnable after) {
        final Store s = Store.get(a);
        if (Lock.isLocked(s)) {
            lockedSheet(a, after);
            return;
        }
        LinearLayout body = Ui.col(a);
        body.addView(Ui.text(a, Lang.pick("Hand the phone to someone you trust (wife, parent, close friend). They type a PIN you don't know. Only that PIN can end a lock early.",
                "ફોન તમારા ભરોસાના માણસને આપો (પત્ની, માતા-પિતા, નજીકનો મિત્ર). તે એવો PIN લખે જે તમને ખબર ન હોય. ફક્ત એ PIN લૉક વહેલું ખોલી શકે."), 14, Ui.SUB, false));
        body.addView(Ui.space(a, 12));
        final EditText name = Ui.input(a, Lang.pick("Partner's name", "પાર્ટનરનું નામ"), s.s(Lock.K_PNAME, ""), false);
        body.addView(name);
        body.addView(Ui.space(a, 8));
        final EditText phone = Ui.input(a, Lang.pick("WhatsApp number with country code (optional), e.g. 9198…", "WhatsApp નંબર દેશ કોડ સાથે (વૈકલ્પિક), દા.ત. 9198…"),
                s.s(Lock.K_PPHONE, ""), false);
        phone.setInputType(InputType.TYPE_CLASS_PHONE);
        body.addView(phone);
        body.addView(Ui.space(a, 8));
        final EditText old = Ui.input(a, Lang.pick("Current PIN", "હાલનો PIN"), "", true);
        old.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        if (Lock.hasPin(s)) {
            body.addView(old);
            body.addView(Ui.space(a, 8));
        }
        final EditText p1 = Ui.input(a, Lang.pick("New PIN (4–8 digits) — partner types", "નવો PIN (4–8 આંકડા) — પાર્ટનર લખે"), "", true);
        p1.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        body.addView(p1);
        body.addView(Ui.space(a, 8));
        final EditText p2 = Ui.input(a, Lang.pick("Repeat PIN", "PIN ફરી"), "", true);
        p2.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        body.addView(p2);
        body.addView(Ui.space(a, 14));
        TextView save = Ui.button(a, Lang.pick("Save", "સેવ"), Ui.EMERALD, Ui.TEAL, 0xFFFFFFFF);
        body.addView(save, Ui.lp(Ui.MATCH, Ui.WRAP));
        final AlertDialog d = Dialogs.sheet(a, Lang.pick("Emergency partner", "ઇમરજન્સી પાર્ટનર"), body);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String n1 = p1.getText().toString().trim(), n2 = p2.getText().toString().trim();
                if (Lock.hasPin(s) && n1.length() > 0 && !Lock.checkPin(s, old.getText().toString().trim())) {
                    Toast.makeText(a, Lang.pick("Current PIN is wrong", "હાલનો PIN ખોટો છે"), Toast.LENGTH_SHORT).show();
                    return;
                }
                if (n1.length() > 0) {
                    if (n1.length() < 4 || n1.length() > 8 || !n1.equals(n2)) {
                        Toast.makeText(a, Lang.pick("PINs must match and be 4–8 digits", "PIN સરખા અને 4–8 આંકડાના હોવા જોઈએ"), Toast.LENGTH_SHORT).show();
                        return;
                    }
                    Lock.setPin(s, n1);
                }
                s.put(Lock.K_PNAME, name.getText().toString().trim());
                s.put(Lock.K_PPHONE, phone.getText().toString().trim());
                Haptics.play(Haptics.SUCCESS);
                d.dismiss();
                if (after != null) after.run();
            }
        });
        d.show();
    }

    // ---------------- Settings section ----------------
    public static void settingsCard(final Activity a, LinearLayout c, final Runnable rebuild) {
        final Store s = Store.get(a);
        boolean locked = Lock.isLocked(s);
        LinearLayout st = Ui.row(a);
        TextView ic = Ui.text(a, locked ? "🔒" : "🔓", 26, Ui.TEXT, false);
        st.addView(ic, Ui.lpm(Ui.WRAP, Ui.WRAP, 0, 0, 12, 0));
        LinearLayout tc = Ui.col(a);
        tc.addView(Ui.text(a, locked ? Lang.pick("Locked", "લૉક છે") : Lang.pick("Not locked", "લૉક નથી"), 17, locked ? Ui.GOLD : Ui.TEXT, true));
        if (locked) {
            String until = new SimpleDateFormat("EEE d MMM, h:mm a", Lang.locale()).format(new Date(Lock.until(s)));
            tc.addView(Ui.text(a, Lang.pick(Lock.left(Lock.remainingMs(s)) + " left · until " + until, Lock.left(Lock.remainingMs(s)) + " બાકી · " + until + " સુધી"), 12.5f, Ui.SUB, false));
        } else
            tc.addView(Ui.text(a, Lang.pick("Loosening changes wait " + Lock.coolHours(s) + " h before they apply.", "ઢીલા ફેરફાર " + Lock.coolHours(s) + " કલાક પછી લાગુ થાય છે."), 12.5f, Ui.SUB, false));
        st.addView(tc, Ui.weight(1));
        c.addView(st);
        c.addView(Ui.space(a, 12));
        TextView go = Ui.button(a, locked ? Lang.pick("➕  Extend the lock", "➕  લૉક લંબાવો") : Lang.pick("🔒  Lock my rules", "🔒  મારા નિયમ લૉક કરો"), Ui.GOLD, Ui.GOLD_D, 0xFF1A1205);
        c.addView(go, Ui.lp(Ui.MATCH, Ui.WRAP));
        go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startDialog(a, rebuild);
            }
        });
        if (locked) {
            TextView em = Ui.ghost(a, Lang.pick("Emergency unlock (partner PIN)", "ઇમરજન્સી અનલૉક (પાર્ટનર PIN)"), Ui.SUB);
            c.addView(em, Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
            em.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    emergency(a, rebuild);
                }
            });
        }

        // pending changes
        List<JSONObject> pend = Lock.pending(s);
        if (!pend.isEmpty()) {
            c.addView(Ui.text(a, Lang.pick("WAITING CHANGES", "રાહ જોતા ફેરફાર"), 12, Ui.SUB, true), Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 16, 0, 6));
            for (final JSONObject o : pend) {
                LinearLayout r = Ui.row(a);
                r.setPadding(0, Ui.dp(6), 0, Ui.dp(6));
                LinearLayout rc = Ui.col(a);
                rc.addView(Ui.text(a, o.optString("desc"), 14, Ui.TEXT, true));
                long left = Math.max(o.optLong("due"), locked ? Lock.until(s) : 0) - Lock.now(s);
                rc.addView(Ui.text(a, left > 0 ? Lang.pick("applies in " + Lock.left(left) + (locked ? " (after the lock)" : ""), Lock.left(left) + "માં લાગુ" + (locked ? " (લૉક પછી)" : ""))
                        : Lang.pick("applies when the lock ends", "લૉક પૂરું થાય ત્યારે લાગુ"), 12, Ui.MUTED, false));
                r.addView(rc, Ui.weight(1));
                TextView x = Ui.pill(a, Lang.pick("Cancel", "રદ"), Ui.alpha(Ui.EMERALD, 0.16f), Ui.EMERALD);
                x.setPadding(Ui.dp(12), Ui.dp(7), Ui.dp(12), Ui.dp(7));
                Ui.press(x);
                r.addView(x);
                x.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Lock.cancel(s, o.optString("id"));
                        Haptics.play(Haptics.SUCCESS);
                        Toast.makeText(a, Lang.pick("Cancelled — MashaAllah, you held on 🌟", "રદ — માશાઅલ્લાહ, તમે મક્કમ રહ્યા 🌟"), Toast.LENGTH_SHORT).show();
                        rebuild.run();
                    }
                });
                c.addView(r);
            }
        }

        // cooling-off hours
        c.addView(Ui.text(a, Lang.pick("Cooling-off for loosening", "ઢીલા ફેરફાર માટે રાહ"), 13, Ui.SUB, true), Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 16, 0, 8));
        final int[] opts = {12, 24, 48, 72};
        int cur = Lock.coolHours(s), idx = 1;
        for (int k = 0; k < opts.length; k++) if (opts[k] == cur) idx = k;
        final int[] h = {idx};
        final int curIdx = idx;
        c.addView(Dialogs.selector(a, new String[]{"12h", "24h", "48h", "72h"}, h, new Runnable() {
            @Override
            public void run() {
                int v = opts[h[0]];
                if (v >= Lock.coolHours(s)) { // longer wait = stricter → instant
                    s.put(Lock.K_COOL, v);
                    rebuild.run();
                } else {
                    h[0] = curIdx;
                    loosen(a, Lock.change("int", Lock.K_COOL, v, Lang.pick("Cooling-off → " + v + " h", "રાહ → " + v + " કલાક")), rebuild);
                }
            }
        }));

        // protections
        c.addView(Ui.text(a, Lang.pick("PROTECTION", "સુરક્ષા"), 12, Ui.SUB, true), Ui.lpm(Ui.MATCH, Ui.WRAP, 0, 18, 0, 4));
        boolean admin = AdminReceiver.active(a);
        row(a, c, "🛡️  " + Lang.pick("Uninstall protection", "અનઇન્સ્ટૉલ સુરક્ષા"),
                admin ? Lang.pick("On — Muhasabah can't be uninstalled on impulse", "ચાલુ — Muhasabah ઉતાવળે અનઇન્સ્ટૉલ નહીં થાય")
                        : Lang.pick("Off — tap to turn on (needs no special powers)", "બંધ — ચાલુ કરવા ટૅપ કરો"),
                admin, new Runnable() {
                    @Override
                    public void run() {
                        if (!AdminReceiver.active(a)) a.startActivity(AdminReceiver.enableIntent(a));
                    }
                });
        boolean guard = GuardService.isOn();
        row(a, c, "⚙️  " + Lang.pick("Phone-settings guard", "ફોન-સેટિંગ્સ ગાર્ડ"),
                guard ? Lang.pick("During a lock, the screens to force-stop, clear, uninstall or switch off Muhasabah are closed",
                        "લૉક દરમિયાન Muhasabah બંધ/ક્લિયર/અનઇન્સ્ટૉલ કરવાની સ્ક્રીન બંધ રહેશે")
                        : Lang.pick("Needs the Accessibility guardian (full version)", "ઍક્સેસિબિલિટી ગાર્ડિયન જોઈએ (ફુલ વર્ઝન)"),
                guard, null);
        final boolean hasPin = Lock.hasPin(s);
        String pn = s.s(Lock.K_PNAME, "");
        row(a, c, "🤝  " + Lang.pick("Emergency partner", "ઇમરજન્સી પાર્ટનર"),
                hasPin ? Lang.pick("Set" + (pn.isEmpty() ? "" : " · " + pn) + " — only their PIN can end a lock early", "સેટ" + (pn.isEmpty() ? "" : " · " + pn) + " — ફક્ત તેમનો PIN લૉક વહેલું ખોલી શકે")
                        : Lang.pick("Not set — tap to let someone you trust choose a PIN", "સેટ નથી — ભરોસાના માણસ પાસે PIN રખાવવા ટૅપ કરો"),
                hasPin, new Runnable() {
                    @Override
                    public void run() {
                        partnerDialog(a, rebuild);
                    }
                });
        int xpPen = s.i(Lock.K_XP_PEN, 0);
        String wk = Store.date(-6), td = Store.today();
        int tries = Lock.count(s, "tamper", wk, td) + Lock.count(s, "refused", wk, td), breaks = Lock.count(s, "emergency", "0000", td);
        TextView info = Ui.text(a, Lang.pick("This week: " + tries + " blocked attempts · Emergency unlocks ever: " + breaks + (xpPen > 0 ? " (−" + xpPen + " XP)" : ""),
                "આ અઠવાડિયે: " + tries + " રોકેલા પ્રયાસ · કુલ ઇમરજન્સી અનલૉક: " + breaks + (xpPen > 0 ? " (−" + xpPen + " XP)" : "")), 12, Ui.MUTED, false);
        info.setPadding(0, Ui.dp(10), 0, 0);
        c.addView(info);
    }

    private static void row(Activity a, LinearLayout c, String title, String sub, boolean on, final Runnable tap) {
        LinearLayout r = Ui.row(a);
        r.setPadding(0, Ui.dp(8), 0, Ui.dp(8));
        LinearLayout rc = Ui.col(a);
        rc.addView(Ui.text(a, title, 14.5f, Ui.TEXT, true));
        rc.addView(Ui.text(a, sub, 12, Ui.SUB, false));
        r.addView(rc, Ui.weight(1));
        r.addView(Ui.pill(a, on ? "✓" : "›", on ? Ui.alpha(Ui.EMERALD, 0.18f) : Ui.alpha(Ui.GOLD, 0.15f), on ? Ui.EMERALD : Ui.GOLD), Ui.lpm(Ui.WRAP, Ui.WRAP, 10, 0, 0, 0));
        if (tap != null) {
            Ui.press(r);
            r.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    tap.run();
                }
            });
        }
        c.addView(r);
    }

    // ---------------- Today card ----------------
    /** Small status line on the Today screen; null when there is nothing to show. */
    public static View todayCard(final Activity a) {
        Store s = Store.get(a);
        boolean locked = Lock.isLocked(s);
        int pend = Lock.pending(s).size();
        if (!locked && pend == 0) return null;
        LinearLayout r = Ui.row(a);
        r.setBackground(Ui.roundStroke(Ui.alpha(locked ? Ui.GOLD : Ui.BLUE, 0.10f), 18, Ui.alpha(locked ? Ui.GOLD : Ui.BLUE, 0.45f), 1));
        r.setPadding(Ui.dp(14), Ui.dp(12), Ui.dp(14), Ui.dp(12));
        r.addView(Ui.text(a, locked ? "🔒" : "⏳", 22, Ui.TEXT, false), Ui.lpm(Ui.WRAP, Ui.WRAP, 0, 0, 12, 0));
        LinearLayout c = Ui.col(a);
        if (locked) {
            c.addView(Ui.text(a, Lang.pick("Rules locked · " + Lock.left(Lock.remainingMs(s)) + " left", "નિયમ લૉક · " + Lock.left(Lock.remainingMs(s)) + " બાકી"), 15, Ui.GOLD, true));
            c.addView(Ui.text(a, Lang.pick("Stay firm — the urge passes, the reward stays.", "મક્કમ રહો — ઇચ્છા જાય છે, ઇનામ રહે છે."), 12, Ui.SUB, false));
        } else {
            c.addView(Ui.text(a, Lang.pick(pend + " loosening change" + (pend == 1 ? "" : "s") + " waiting", pend + " ઢીલા ફેરફાર રાહમાં"), 15, Ui.TEXT, true));
            c.addView(Ui.text(a, Lang.pick("Still want them? Cancel anytime in Settings.", "હજી જોઈએ છે? સેટિંગ્સમાં ગમે ત્યારે રદ કરો."), 12, Ui.SUB, false));
        }
        r.addView(c, Ui.weight(1));
        Ui.press(r);
        r.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a.startActivity(new Intent(a, SettingsActivity.class).putExtra("section", "lock"));
            }
        });
        return r;
    }
}
