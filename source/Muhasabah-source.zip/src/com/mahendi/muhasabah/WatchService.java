package com.mahendi.muhasabah;

import android.app.AppOpsManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.Service;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.Process;
import android.provider.Settings;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * Always-on guardian. Every 30 seconds it measures today's time in your timepass apps,
 * fires escalating reminders, and runs the morning / evening / late-night check-ins.
 */
public class WatchService extends Service {
    private static final int FG_ID = 7;
    private Handler h;
    private Runnable tick;
    private String lastGuardText = "";

    public static void start(Context c) {
        try {
            c.startForegroundService(new Intent(c, WatchService.class));
        } catch (Exception ignored) {
        }
    }

    // ---------- permission helpers ----------
    public static boolean hasUsage(Context c) {
        AppOpsManager ops = (AppOpsManager) c.getSystemService(Context.APP_OPS_SERVICE);
        int mode = ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.getPackageName());
        return mode == AppOpsManager.MODE_ALLOWED;
    }

    public static boolean hasOverlay(Context c) {
        return Settings.canDrawOverlays(c);
    }

    public static boolean hasNotif(Context c) {
        return c.getSystemService(NotificationManager.class).areNotificationsEnabled();
    }

    public static boolean hasBattery(Context c) {
        PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
        return pm.isIgnoringBatteryOptimizations(c.getPackageName());
    }

    // ---------- usage measurement ----------
    public static class UsageResult {
        public final Map<String, Long> ms = new HashMap<String, Long>();
        public String current;

        void add(String pkg, long d) {
            if (d <= 0) return;
            Long v = ms.get(pkg);
            ms.put(pkg, (v == null ? 0 : v) + d);
        }

        public int minutes(String pkg) {
            Long v = ms.get(pkg);
            return v == null ? 0 : (int) (v / 60000L);
        }
    }

    public static UsageResult measure(Context c, long from, long to) {
        UsageResult r = new UsageResult();
        UsageStatsManager um = (UsageStatsManager) c.getSystemService(Context.USAGE_STATS_SERVICE);
        UsageEvents ev = um.queryEvents(from, to);
        if (ev == null) return r;
        UsageEvents.Event e = new UsageEvents.Event();
        String cur = null;
        long curStart = 0;
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e);
            int t = e.getEventType();
            String pk = e.getPackageName();
            long ts = e.getTimeStamp();
            if (t == UsageEvents.Event.ACTIVITY_RESUMED) {
                if (cur != null && !cur.equals(pk)) {
                    r.add(cur, ts - curStart);
                    cur = null;
                }
                if (cur == null) {
                    cur = pk;
                    curStart = ts;
                }
            } else if (t == UsageEvents.Event.ACTIVITY_PAUSED || t == UsageEvents.Event.ACTIVITY_STOPPED) {
                if (cur != null && cur.equals(pk)) {
                    r.add(cur, ts - curStart);
                    cur = null;
                }
            } else if (t == UsageEvents.Event.SCREEN_NON_INTERACTIVE || t == UsageEvents.Event.DEVICE_SHUTDOWN) {
                if (cur != null) {
                    r.add(cur, ts - curStart);
                    cur = null;
                }
            }
        }
        if (cur != null) {
            r.add(cur, to - curStart);
            r.current = cur;
        }
        return r;
    }

    // ---------- lifecycle ----------
    @Override
    public void onCreate() {
        super.onCreate();
        Notify.channels(this);
        goForeground("Tracking timepass apps & your daily progress");
        h = new Handler(Looper.getMainLooper());
        tick = new Runnable() {
            @Override
            public void run() {
                try {
                    check();
                } catch (Throwable ignored) {
                }
                h.postDelayed(this, 30000);
            }
        };
        h.post(tick);
    }

    private void goForeground(String text) {
        Notification n = Notify.guardian(this, text);
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(FG_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            } else {
                startForeground(FG_ID, n);
            }
        } catch (Exception ignored) {
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        goForeground(lastGuardText.length() > 0 ? lastGuardText : "Tracking timepass apps & your daily progress");
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (h != null) h.removeCallbacks(tick);
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private static boolean inWindow(int mod, int start, int end) {
        start = ((start % 1440) + 1440) % 1440;
        end = ((end % 1440) + 1440) % 1440;
        if (start <= end) return mod >= start && mod < end;
        return mod >= start || mod < end;
    }

    // ---------- the main check ----------
    private void check() {
        try {
            Reminders.check(this);
            Gunah.check(this);
            Compete.sync(this, false, null);
            Lock.tick(this);
            Lock.syncNetwork(this);
        } catch (Throwable ignored) {
        }
        Store s = Store.get(this);
        if (!s.b(Store.K_MONITOR, true) && !Lock.isLocked(s)) return;
        long now = System.currentTimeMillis();
        int mod = Store.minuteOfDay();
        String today = Store.today();
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        boolean on = pm.isInteractive();
        int wake = s.i(Store.K_WAKE, 315), sleep = s.i(Store.K_SLEEP, 1380), checkAt = s.i(Store.K_CHECK, 1260);
        boolean strict = s.b(Store.K_STRICT, true);

        Score.dayScore(s, Store.date(-1)); // freeze yesterday's score

        // Oversleeping: first use of the phone came long after wake-up time
        if (on && mod >= wake && s.i("first_on_" + today, -1) < 0) {
            s.put("first_on_" + today, mod);
            if (mod > wake + Cfg.get(s, "n_oversleep") && mod < 14 * 60 && s.once("oversleep")) {
                Notify.post(this, 301, Notify.CH_NUDGE, "😴 You woke up " + Ui.hm(mod - wake) + " late",
                        Lines.make(s, Lines.WAKE, strict),
                        s.pick("sleep", "laziness"));
            }
        }

        // Morning kick-off
        if (mod >= wake && mod < wake + 180 && s.once("morning")) {
            int y = Score.dayScore(s, Store.date(-1));
            Notify.post(this, 302, Notify.CH_DAILY, "🌅 Bismillah — a new day",
                    "Yesterday's score: " + y + ". Today's mission: beat it.", s.pick("time", "work"));
        }

        // Timepass apps
        if (on && hasUsage(this)) usageChecks(s, now, today, strict);

        // Afternoon nudge if the day is slipping
        if (mod >= Cfg.get(s, "n_afternoon") && mod < checkAt && s.once("afternoon")) {
            int t = Score.compute(s, today).score;
            if (t < Cfg.get(s, "n_afternoon_thr")) {
                Notify.post(this, 303, Notify.CH_NUDGE, "⚡ Half the day is gone — score " + t,
                        Lines.make(s, Lines.BAD_DAY, strict),
                        s.pick("laziness", "time"));
            }
        }

        // Weekly summary (Sunday, after the evening check) and monthly summary (1st, morning)
        java.util.Calendar cal = java.util.Calendar.getInstance();
        if (cal.get(java.util.Calendar.DAY_OF_WEEK) == java.util.Calendar.SUNDAY && mod >= checkAt + 30 && s.once("weekly_sum")) {
            String[] wk = Summary.weekOf(today);
            Summary.Period p = Summary.compute(s, wk[0], wk[1]), pv = Summary.previous(s, p, false);
            int dlt = p.avg - pv.avg;
            Notify.postIntent(this, 480, Notify.CH_DAILY, Lang.pick("🗓 Your week: average " + p.avg, "🗓 તમારું અઠવાડિયું: સરેરાશ " + p.avg),
                    Lang.pick((dlt >= 0 ? "▲ " + dlt : "▼ " + (-dlt)) + " vs last week · " + p.betterDays + " better days · " + p.completion + "% tasks done. Tap to see it all.",
                            "ગયા અઠવાડિયા કરતાં " + (dlt >= 0 ? "▲ " + dlt : "▼ " + (-dlt)) + " · " + p.betterDays + " બહેતર દિવસ · " + p.completion + "% કામ પૂરા. જોવા ટૅપ કરો."),
                    new Intent(this, SummaryActivity.class).putExtra("mode", SummaryActivity.WEEK).putExtra("date", today));
        }
        if (cal.get(java.util.Calendar.DAY_OF_MONTH) == 1 && mod >= wake + 30 && s.once("monthly_sum")) {
            String last = Summary.shift(today, -1);
            String[] mo = Summary.monthOf(last);
            Summary.Period p = Summary.compute(s, mo[0], mo[1]), pv = Summary.previous(s, p, true);
            int dlt = p.avg - pv.avg;
            Notify.postIntent(this, 481, Notify.CH_DAILY, Lang.pick("📆 Last month: average " + p.avg, "📆 ગયો મહિનો: સરેરાશ " + p.avg),
                    Lang.pick((dlt >= 0 ? "▲ " + dlt : "▼ " + (-dlt)) + " vs the month before · " + p.betterDays + " better days. Tap for your monthly summary.",
                            "તેના આગલા મહિના કરતાં " + (dlt >= 0 ? "▲ " + dlt : "▼ " + (-dlt)) + " · " + p.betterDays + " બહેતર દિવસ. માસિક સારાંશ માટે ટૅપ કરો."),
                    new Intent(this, SummaryActivity.class).putExtra("mode", SummaryActivity.MONTH).putExtra("date", last));
        }

        // Evening: better than yesterday?
        if (mod >= checkAt && s.once("evening")) evening(s, false, strict);
        if (mod >= checkAt + Cfg.get(s, "n_final") && s.once("final")) evening(s, true, strict);

        // Late-night phone use
        if (on && inWindow(mod, sleep + Cfg.get(s, "n_night_start"), wake - 30)) {
            long last = s.l("night_nudge", 0);
            if (now - last > Cfg.get(s, "n_night_gap") * 60000L) {
                s.put("night_nudge", now);
                Notify.post(this, 304, Notify.CH_NUDGE, Lines.sleepTitle(s, strict),
                        Lines.make(s, Lines.SLEEP, strict),
                        s.pick("sleep"));
            }
        }

        // Keep the always-on notification informative
        String gt = "Score " + Score.compute(s, today).score + " · Timepass " + s.timepassMinutes(today) + "/" + s.timepassLimit() + " min";
        if (!gt.equals(lastGuardText)) {
            lastGuardText = gt;
            try {
                getSystemService(NotificationManager.class).notify(FG_ID, Notify.guardian(this, gt));
            } catch (Exception ignored) {
            }
        }
    }

    private void evening(Store s, boolean last, boolean strict) {
        String today = Store.today();
        int t = Score.compute(s, today).score;
        int y = Score.dayScore(s, Store.date(-1));
        if (t > y || t >= Score.goodDay(s)) {
            if (!last) {
                Notify.post(this, 305, Notify.CH_DAILY, "🏆 Better than yesterday!",
                        "Today " + t + " vs yesterday " + y + ". MashaAllah — protect this streak.", s.pick("gratitude"));
            }
            return;
        }
        int need = y - t + 1;
        String line = "You're at " + t + ", yesterday was " + y + ". You need " + need + " more points before the day ends.";
        if (strict && (t < 40 || last)) line = Lines.make(s, Lines.BAD_DAY, true) + "\n" + line;
        JSONObject w = s.byId("h1");
        if (w == null) w = s.pick("betterday", "accountability");
        Notify.post(this, 306, Notify.CH_NUDGE,
                last ? "⏰ Last chance to beat yesterday" : "⚖️ Today isn't better than yesterday — yet", line, w);
    }

    private void usageChecks(Store s, long now, String today, boolean strict) {
        UsageResult r = measure(this, Store.startOfToday(), now);
        JSONArray apps = s.apps();
        JSONObject u = new JSONObject();
        for (int k = 0; k < apps.length(); k++) {
            JSONObject o = apps.optJSONObject(k);
            if (o == null) continue;
            String pkg = o.optString("pkg"), name = o.optString("name", pkg);
            int lim = o.optInt("limit", 30);
            int used = r.minutes(pkg);
            try {
                u.put(pkg, used);
            } catch (Exception ignored) {
            }
            int level = used < lim - Cfg.get(s, "a_warn") ? -1 : used < lim ? 0 : used < lim + Cfg.get(s, "a_step") ? 1 : used < lim + Cfg.get(s, "a_pause") ? 2 : 3;
            String key = "lv_" + today + "_" + pkg;
            int fired = s.i(key, -1);
            boolean fg = pkg.equals(r.current);
            int nid = 400 + Math.abs(pkg.hashCode() % 500);
            if (level > fired && level <= 2) {
                s.put(key, level);
                if (level == 0) {
                    Notify.post(this, nid, Notify.CH_NUDGE, "⏳ 5 minutes left on " + name,
                            "You've used " + used + " of your " + lim + " min today. Finish up.", null);
                } else if (level == 1) {
                    Notify.post(this, nid, Notify.CH_NUDGE, "🛑 " + name + " limit reached (" + lim + " min)",
                            Lines.make(s, Lines.SCROLL, false), s.pick("time"));
                } else {
                    Notify.post(this, nid, Notify.CH_NUDGE, "⚠️ " + (used - lim) + " min over on " + name,
                            Lines.make(s, Lines.SCROLL, strict),
                            s.pick("time", "discipline", "laziness"));
                }
            }
            if (level >= 3 && fg) {
                long snooze = s.l("snooze_" + pkg, 0), lastPause = s.l("pause_" + pkg, 0);
                if (now > snooze && now - lastPause > Cfg.get(s, "a_pause_gap") * 60000L) {
                    s.put("pause_" + pkg, now);
                    s.put(key, 3);
                    if (hasOverlay(this)) {
                        Intent i = new Intent(this, PauseActivity.class);
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        i.putExtra("pkg", pkg);
                        i.putExtra("name", name);
                        i.putExtra("used", used);
                        i.putExtra("limit", lim);
                        try {
                            startActivity(i);
                        } catch (Exception ignored) {
                        }
                        Notify.post(this, nid, Notify.CH_NUDGE, "🚨 " + used + " min on " + name + " today",
                                Lines.make(s, Lines.SCROLL, strict),
                                s.pick("time", "accountability"));
                    } else {
                        Notify.post(this, nid, Notify.CH_NUDGE, "🚨 " + used + " min on " + name + " today",
                                Lines.make(s, Lines.SCROLL, strict),
                                s.pick("time", "accountability"));
                    }
                }
            }
        }
        s.saveUsage(today, u);
    }
}
