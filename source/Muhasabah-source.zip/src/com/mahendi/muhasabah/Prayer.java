package com.mahendi.muhasabah;

import java.util.Calendar;
import java.util.TimeZone;

/**
 * Approximate prayer times (Shia Ithna-ʿAshari / Jafari method: Fajr 16°, Maghrib 4°, Isha 14° below the horizon,
 * Zuhr at solar noon), computed on the phone for a fixed place — Bhavnagar by default. Times can differ from your
 * local masjid by a few minutes; follow your masjid / marjaʿ timetable.
 */
public final class Prayer {
    public static final String K_LAT = "pt_lat", K_LNG = "pt_lng", K_CITY = "pt_city";
    public static final int FAJR = 0, SUNRISE = 1, ZUHR = 2, MAGHRIB = 3, ISHA = 4;

    private Prayer() {
    }

    public static double lat(Store s) {
        return Double.longBitsToDouble(s.l(K_LAT, Double.doubleToLongBits(21.7645)));
    }

    public static double lng(Store s) {
        return Double.longBitsToDouble(s.l(K_LNG, Double.doubleToLongBits(72.1519)));
    }

    public static String city(Store s) {
        return s.s(K_CITY, "Bhavnagar");
    }

    /** Minutes after local midnight for Fajr, Sunrise, Zuhr, Maghrib, Isha on that day. */
    public static int[] times(Store s, Calendar day) {
        Calendar c = (Calendar) day.clone();
        c.set(Calendar.HOUR_OF_DAY, 12);
        double tz = TimeZone.getDefault().getOffset(c.getTimeInMillis()) / 3600000.0;
        return times(lat(s), lng(s), tz, c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH));
    }

    static int[] times(double la, double lo, double tz, int y, int m, int d) {
        if (m <= 2) {
            y -= 1;
            m += 12;
        }
        int a = y / 100, b = 2 - a + a / 4;
        double jd = Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + d + b - 1524.5 - lo / (15 * 24);
        double[] guess = {5, 6, 12, 18, 18};
        double[] t = new double[5];
        for (int pass = 0; pass < 2; pass++) {
            for (int k = 0; k < 5; k++) {
                double g = pass == 0 ? guess[k] : t[k];
                double[] sp = sun(jd + g / 24);
                double noon = fix24(12 - sp[1]);
                if (k == ZUHR) t[k] = noon;
                else {
                    double angle = k == FAJR ? 16 : k == SUNRISE ? 0.833 : k == MAGHRIB ? 4 : 14;
                    double v = (-Math.sin(Math.toRadians(angle)) - Math.sin(sp[0]) * Math.sin(Math.toRadians(la)))
                            / (Math.cos(sp[0]) * Math.cos(Math.toRadians(la)));
                    double h = Math.toDegrees(Math.acos(Math.max(-1, Math.min(1, v)))) / 15;
                    t[k] = noon + (k == FAJR || k == SUNRISE ? -h : h);
                }
            }
        }
        int[] out = new int[5];
        for (int k = 0; k < 5; k++) {
            double local = t[k] + tz - lo / 15;
            out[k] = (int) Math.round(fix24(local) * 60) % 1440;
        }
        out[ZUHR] = Math.min(1439, out[ZUHR] + 1); // just after the sun passes the meridian
        return out;
    }

    /** {declination (rad), equation of time (hours)}. */
    private static double[] sun(double jd) {
        double dd = jd - 2451545.0;
        double g = Math.toRadians(fix(357.529 + 0.98560028 * dd, 360)), q = fix(280.459 + 0.98564736 * dd, 360);
        double l = Math.toRadians(fix(q + 1.915 * Math.sin(g) + 0.020 * Math.sin(2 * g), 360));
        double e = Math.toRadians(23.439 - 0.00000036 * dd);
        double ra = Math.toDegrees(Math.atan2(Math.cos(e) * Math.sin(l), Math.cos(l))) / 15;
        double decl = Math.asin(Math.sin(e) * Math.sin(l));
        double eqt = q / 15 - fix24(ra);
        eqt = ((eqt + 12) % 24 + 24) % 24 - 12;
        return new double[]{decl, eqt};
    }

    private static double fix(double a, double b) {
        a = a - b * Math.floor(a / b);
        return a < 0 ? a + b : a;
    }

    private static double fix24(double h) {
        return fix(h, 24);
    }

    public static String name(int k) {
        switch (k) {
            case FAJR: return HadithCard.label("Fajr", "ફજ્ર", "فجر", "फ़ज्र");
            case SUNRISE: return HadithCard.label("Sunrise", "સૂર્યોદય", "طلوعِ آفتاب", "सूर्योदय");
            case ZUHR: return HadithCard.label("Zuhr", "ઝોહર", "ظہر", "ज़ोहर");
            case MAGHRIB: return HadithCard.label("Maghrib", "મગરિબ", "مغرب", "मग़रिब");
            default: return HadithCard.label("Isha", "ઈશા", "عشاء", "इशा");
        }
    }

    /** The next of Fajr / Zuhr / Maghrib from now: {which, minuteOfDay, tomorrow?1:0}. */
    public static int[] next(Store s) {
        Calendar now = Calendar.getInstance();
        int m = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE);
        int[] t = times(s, now);
        for (int k : new int[]{FAJR, ZUHR, MAGHRIB}) if (t[k] > m) return new int[]{k, t[k], 0};
        Calendar tm = (Calendar) now.clone();
        tm.add(Calendar.DAY_OF_YEAR, 1);
        return new int[]{FAJR, times(s, tm)[FAJR], 1};
    }
}
