package com.mahendi.muhasabah;

import android.animation.ValueAnimator;
import android.content.Context;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Pull down at the top of a page to refresh it (no extra libraries). */
public class PullRefresh extends FrameLayout {
    public interface Listener {
        void onRefresh(PullRefresh p);
    }

    private final ScrollView sv;
    private final TextView spinner;
    private final int slop, size, trigger, max;
    private float y0, x0, pull;
    private boolean dragging, busy;
    private Listener listener;

    public PullRefresh(Context c, ScrollView child) {
        super(c);
        sv = child;
        addView(sv, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        size = Ui.dp(42);
        trigger = Ui.dp(84);
        max = Ui.dp(130);
        slop = ViewConfiguration.get(c).getScaledTouchSlop();
        spinner = Ui.text(c, "↻", 22, 0xFF1A1205, true);
        spinner.setGravity(Gravity.CENTER);
        spinner.setBackground(Ui.grad(Ui.GOLD_L, Ui.GOLD, 50, android.graphics.drawable.GradientDrawable.Orientation.TL_BR));
        spinner.setElevation(Ui.dp(6));
        LayoutParams lp = new LayoutParams(size, size, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        addView(spinner, lp);
        spinner.setTranslationY(-size * 1.5f);
        spinner.setAlpha(0f);
    }

    public void setListener(Listener l) {
        listener = l;
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent e) {
        if (busy) return false;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                y0 = e.getY();
                x0 = e.getX();
                dragging = false;
                return false;
            case MotionEvent.ACTION_MOVE: {
                float dy = e.getY() - y0, dx = e.getX() - x0;
                if (!dragging && dy > slop * 1.5f && dy > Math.abs(dx) * 1.3f && !sv.canScrollVertically(-1)) {
                    dragging = true;
                    y0 = e.getY();
                    return true;
                }
                return false;
            }
        }
        return false;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (!dragging) return super.onTouchEvent(e);
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_MOVE:
                pull = Math.max(0, Math.min(max, (e.getY() - y0) * 0.5f));
                place(pull);
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                dragging = false;
                if (pull >= trigger && listener != null) {
                    busy = true;
                    animateTo(trigger * 0.75f, 160);
                    spinner.animate().rotationBy(720).setDuration(700).setInterpolator(new DecelerateInterpolator()).start();
                    Haptics.play(Haptics.REFRESH);
                    postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            listener.onRefresh(PullRefresh.this);
                        }
                    }, 380);
                } else animateTo(0, 200);
                return true;
        }
        return true;
    }

    private void place(float p) {
        pull = p;
        float f = Math.min(1f, p / trigger);
        spinner.setTranslationY(p - size * 1.1f);
        spinner.setAlpha(f);
        spinner.setRotation(p * 2.4f);
        spinner.setScaleX(0.6f + 0.4f * f);
        spinner.setScaleY(0.6f + 0.4f * f);
        sv.setTranslationY(p * 0.45f);
    }

    private void animateTo(float target, long ms) {
        ValueAnimator a = ValueAnimator.ofFloat(pull, target);
        a.setDuration(ms);
        a.setInterpolator(new DecelerateInterpolator());
        a.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator an) {
                place((Float) an.getAnimatedValue());
            }
        });
        a.start();
    }

    /** Call when the refresh work is finished. */
    public void done() {
        busy = false;
        animateTo(0, 260);
    }

    public ScrollView scrollView() {
        return sv;
    }

    static View unused() {
        return null;
    }
}
