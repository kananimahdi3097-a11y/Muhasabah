"""Muhasabah logo — an 8-point Islamic star (khatam) cradling a gold crescent and a
rising path of three steps, on a deep emerald→indigo field. Premium, hand-detailed."""
import sys, math
from PIL import Image, ImageDraw, ImageFilter

S = 1024
SS = 2  # supersample


def lerp(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(len(a)))


import numpy as np


def _img(rgb):
    a = np.dstack([rgb, np.full(rgb.shape[:2], 255.0)]).clip(0, 255).astype(np.uint8)
    return Image.fromarray(a, "RGBA")


def radial(size, inner, outer, cx, cy, r):
    y, x = np.mgrid[0:size, 0:size].astype(np.float32)
    t = np.clip(np.hypot(x - cx, y - cy) / r, 0, 1)[..., None]
    return _img(np.array(inner) * (1 - t) + np.array(outer) * t)


def diag(size, c1, c2, c3):
    y, x = np.mgrid[0:size, 0:size].astype(np.float32)
    t = ((x + y) / (2 * size))[..., None]
    a = np.array(c1, np.float32); b = np.array(c2, np.float32); c = np.array(c3, np.float32)
    lo = a + (b - a) * np.clip(t * 2, 0, 1)
    hi = b + (c - b) * np.clip((t - 0.5) * 2, 0, 1)
    return _img(np.where(t < 0.5, lo, hi))


def star8(cx, cy, r_out, r_in, rot=0):
    pts = []
    for k in range(16):
        r = r_out if k % 2 == 0 else r_in
        a = math.pi / 8 * k + rot
        pts.append((cx + r * math.sin(a), cy - r * math.cos(a)))
    return pts


def main(out):
    W = S * SS
    f = W / 108.0
    base = diag(W, (16, 90, 84), (11, 24, 60), (6, 10, 26))
    d = ImageDraw.Draw(base, "RGBA")

    # soft inner glow
    glow = Image.new("L", (W, W), 0)
    ImageDraw.Draw(glow).ellipse([30 * f, 26 * f, 86 * f, 82 * f], fill=70)
    glow = glow.filter(ImageFilter.GaussianBlur(10 * f))
    base.paste(lerp((16, 90, 84), (245, 196, 81), 0.5) + (255,), (0, 0), glow)

    cx, cy = 54 * f, 55 * f

    # outer star — thin gold ring (two squares)
    ring = Image.new("RGBA", (W, W), (0, 0, 0, 0))
    rd = ImageDraw.Draw(ring)
    for rot in (0, math.pi / 4):
        rd.regular_polygon((cx, cy, 40 * f), 4, rotation=math.degrees(rot), outline=(245, 205, 110, 255), width=int(1.6 * f))
    base.alpha_composite(ring)

    # filled Rub el Hizb (two overlapping squares), gold gradient
    sm = Image.new("L", (W, W), 0)
    smd = ImageDraw.Draw(sm)
    for rot in (0, 45):
        smd.regular_polygon((cx, cy, 33 * f), 4, rotation=rot, fill=255)
    shadow = sm.filter(ImageFilter.GaussianBlur(3 * f))
    base.paste((0, 0, 0, 255), (int(f * 1.0), int(f * 1.8)), shadow.point(lambda v: int(v * 0.45)))
    gold = diag(W, (255, 236, 160), (240, 180, 50), (196, 132, 20))
    base.paste(gold, (0, 0), sm)
    # engraved inner line
    eng = ImageDraw.Draw(base, "RGBA")
    for rot in (0, 45):
        eng.regular_polygon((cx, cy, 29.5 * f), 4, rotation=rot, outline=(120, 78, 10, 150), width=int(0.6 * f))

    # inner deep disc with gold rim
    disc = Image.new("L", (W, W), 0)
    ImageDraw.Draw(disc).ellipse([cx - 21 * f, cy - 21 * f, cx + 21 * f, cy + 21 * f], fill=255)
    rim = Image.new("L", (W, W), 0)
    ImageDraw.Draw(rim).ellipse([cx - 22.2 * f, cy - 22.2 * f, cx + 22.2 * f, cy + 22.2 * f], fill=255)
    base.paste((255, 228, 140, 255), (0, 0), rim)
    inner = radial(W, (22, 40, 84), (7, 11, 28), cx - 4 * f, cy - 6 * f, 26 * f)
    base.paste(inner, (0, 0), disc)

    # crescent
    cm = Image.new("L", (W, W), 0)
    cmd = ImageDraw.Draw(cm)
    cmd.ellipse([cx - 14 * f, cy - 14 * f, cx + 14 * f, cy + 14 * f], fill=255)
    cmd.ellipse([cx - 7 * f, cy - 17.5 * f, cx + 18 * f, cy + 7.5 * f], fill=0)
    cs = cm.filter(ImageFilter.GaussianBlur(2.2 * f))
    base.paste((245, 196, 81, 255), (0, 0), cs.point(lambda v: int(v * 0.35)))
    base.paste(diag(W, (255, 240, 180), (246, 198, 84), (214, 150, 28)), (0, 0), cm)

    # five-point star inside the crescent opening, rising (growth)
    def star5(x, y, ro, ri):
        pts = []
        for k in range(10):
            r = ro if k % 2 == 0 else ri
            a = math.pi / 5 * k
            pts.append((x + r * math.sin(a), y - r * math.cos(a)))
        return pts
    eng.polygon(star5(cx + 7 * f, cy - 6.5 * f, 5.2 * f, 2.2 * f), fill=(255, 246, 214, 255))

    # sparkle
    scx, scy, rr = 80 * f, 28 * f, 3.0 * f
    eng.polygon([(scx, scy - rr), (scx + rr * 0.25, scy - rr * 0.25), (scx + rr, scy), (scx + rr * 0.25, scy + rr * 0.25),
                 (scx, scy + rr), (scx - rr * 0.25, scy + rr * 0.25), (scx - rr, scy), (scx - rr * 0.25, scy - rr * 0.25)],
                fill=(255, 245, 210, 230))

    img = base.resize((S, S), Image.LANCZOS)
    mask = Image.new("L", (W, W), 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, W - 1, W - 1], radius=W * 0.235, fill=255)
    mask = mask.resize((S, S), Image.LANCZOS)
    final = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    final.paste(img, (0, 0), mask)
    final.save(out)


if __name__ == "__main__":
    main(sys.argv[1])
