# Builds res/drawable/splash_anim.xml: the launcher emblem assembling itself (Android 12+ splash screen).
import re
src = open("res/drawable/ic_fg.xml").read()
P = re.findall(r"<path [^>]*?/>|<path [^>]*[^/]>.*?</path>", src, re.S)
assert len(P) == 10, len(P)
def named(p, n):
    return p.replace("<path ", f'<path android:name="{n}" ', 1)
NS = 'xmlns:android="http://schemas.android.com/apk/res/android" xmlns:aapt="http://schemas.android.com/aapt"'
halo = ('<path android:name="halo" android:fillAlpha="0" android:pathData="M18,54 a36,36 0 1,0 72,0 a36,36 0 1,0 -72,0 Z">'
        '<aapt:attr name="android:fillColor"><gradient android:type="radial" android:centerX="54" android:centerY="54" '
        'android:gradientRadius="36" android:startColor="#80F5C451" android:centerColor="#26F5C451" android:endColor="#00F5C451"/></aapt:attr></path>')
vec = f'''<vector android:width="108dp" android:height="108dp" android:viewportWidth="108" android:viewportHeight="108">
{halo}
<group android:pivotX="54" android:pivotY="54" android:scaleX="0.80" android:scaleY="0.80">
<group android:name="g_out" android:pivotX="54" android:pivotY="54" android:rotation="-135" android:scaleX="0.3" android:scaleY="0.3">
{named(P[0].replace('android:strokeColor', 'android:strokeAlpha="0" android:strokeColor'), "o1")}
{named(P[1].replace('android:strokeColor', 'android:strokeAlpha="0" android:strokeColor'), "o2")}
</group>
<group android:name="g_star" android:pivotX="54" android:pivotY="54" android:rotation="90" android:scaleX="0" android:scaleY="0">
{P[2]}
{P[3]}
{P[4]}
</group>
<group android:name="g_disc" android:pivotX="54" android:pivotY="54" android:scaleX="0" android:scaleY="0">
{P[5]}
{P[6]}
</group>
<group android:name="g_moon" android:pivotX="54" android:pivotY="54" android:rotation="-70" android:scaleX="0.5" android:scaleY="0.5">
{named(P[7].replace('<path ', '<path android:fillAlpha="0" ', 1), "moon")}
</group>
<group android:name="g_s5" android:pivotX="61" android:pivotY="47" android:rotation="-180" android:scaleX="0" android:scaleY="0">
{P[8]}
</group>
<group android:name="g_spk" android:pivotX="80" android:pivotY="27" android:scaleX="0" android:scaleY="0">
{P[9]}
</group>
</group>
</vector>'''
FOS = "@android:interpolator/fast_out_slow_in"
OVR = "@android:anim/overshoot_interpolator"
def anim(*items):
    body = "\n".join(items)
    return f'<set>\n{body}\n</set>'
def oa(prop, a, b, start, dur, interp=FOS, vt="floatType"):
    return (f'<objectAnimator android:propertyName="{prop}" android:valueFrom="{a}" android:valueTo="{b}" '
            f'android:startOffset="{start}" android:duration="{dur}" android:valueType="{vt}" android:interpolator="{interp}"/>')
def scale(a, b, start, dur, interp=FOS):
    return oa("scaleX", a, b, start, dur, interp) + "\n" + oa("scaleY", a, b, start, dur, interp)
targets = {
    "halo": anim(oa("fillAlpha", 0, 1, 0, 450), oa("fillAlpha", 1, 0.35, 450, 550)),
    "g_out": anim(oa("rotation", -135, 0, 0, 750), scale(0.3, 1, 0, 750)),
    "o1": anim(oa("strokeAlpha", 0, 1, 0, 400)),
    "o2": anim(oa("strokeAlpha", 0, 1, 0, 400)),
    "g_star": anim(oa("rotation", 90, 0, 80, 720), scale(0, 1, 80, 620, OVR)),
    "g_disc": anim(scale(0, 1, 220, 480, OVR)),
    "g_moon": anim(oa("rotation", -70, 0, 380, 560), scale(0.5, 1, 380, 560, OVR)),
    "moon": anim(oa("fillAlpha", 0, 1, 380, 300)),
    "g_s5": anim(oa("rotation", -180, 0, 600, 400), scale(0, 1, 600, 380, OVR)),
    "g_spk": anim(oa("rotation", 0, 90, 720, 300), scale(0, 1.4, 720, 180), scale(1.4, 1, 900, 120)),
}
tg = "\n".join(f'<target android:name="{n}"><aapt:attr name="android:animation">{a}</aapt:attr></target>' for n, a in targets.items())
out = f'''<animated-vector {NS}>
<aapt:attr name="android:drawable">
{vec}
</aapt:attr>
{tg}
</animated-vector>
'''
open("res/drawable/splash_anim.xml", "w").write(out)
print("splash_anim.xml written", len(out))
