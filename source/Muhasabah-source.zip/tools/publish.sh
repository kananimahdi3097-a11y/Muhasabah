#!/usr/bin/env bash
# Builds both variants and publishes them to the GitHub repo the app updates from.
# Usage: tools/publish.sh <path-to-repo-clone> "notes in English" "notes in Gujarati"
set -euo pipefail
cd "$(dirname "$0")/.."
REPO=${1:?repo clone path}
NOTES_EN=${2:-"Improvements and fixes."}
NOTES_GU=${3:-"સુધારા અને ફિક્સ."}

tools/build.sh
LITE=1 tools/build.sh

CODE=$(grep -o 'android:versionCode="[0-9]*"' AndroidManifest.xml | grep -o '[0-9]*')
NAME=$(grep -o 'android:versionName="[^"]*"' AndroidManifest.xml | sed 's/.*="//; s/"//')
mkdir -p "$REPO/apk"
cp out/Muhasabah.apk "$REPO/apk/Muhasabah.apk"
cp out/Muhasabah_lite.apk "$REPO/apk/Muhasabah_lite.apk"
SHA_FULL=$(sha256sum out/Muhasabah.apk | cut -d' ' -f1)
SHA_LITE=$(sha256sum out/Muhasabah_lite.apk | cut -d' ' -f1)

python3 - "$REPO/update.json" "$CODE" "$NAME" "$SHA_FULL" "$SHA_LITE" "$NOTES_EN" "$NOTES_GU" <<'PY'
import json, sys
path, code, name, sf, sl, en, gu = sys.argv[1:]
json.dump({"versionCode": int(code), "versionName": name,
           "apk_full": "apk/Muhasabah.apk", "sha256_full": sf,
           "apk_lite": "apk/Muhasabah_lite.apk", "sha256_lite": sl,
           "notes_en": en, "notes_gu": gu}, open(path, "w"), ensure_ascii=False, indent=2)
PY

# Corresponding source (AGPL-3.0, required by the NudeNet model) — never the signing key
mkdir -p "$REPO/source"
python3 - "$REPO/source/Muhasabah-source.zip" <<'PY'
import os, sys, zipfile
out = sys.argv[1]
skip_dirs = {"build", "out", ".git"}
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    for top in ["AndroidManifest.xml", "src", "res", "assets", "tools"]:
        if os.path.isfile(top):
            z.write(top); continue
        for d, dirs, files in os.walk(top):
            dirs[:] = [x for x in dirs if x not in skip_dirs]
            for f in files:
                p = os.path.join(d, f)
                if f.endswith((".jks", ".keystore", ".pem", ".p12", ".idsig")): continue
                if d.startswith("assets/fonts"): continue  # third-party fonts: not ours to publish
                if p == "tools/build.sh":
                    import re
                    t = open(p).read()
                    t = re.sub(r"(pass:|-storepass |-keypass )[^\s\"]+", lambda m: m.group(1) + "$KS_PASS", t)
                    z.writestr(p, t)
                    continue
                z.write(p)
print("source zip:", os.path.getsize(out))
PY
cp assets/licenses/NudeNet-AGPL-3.0.txt "$REPO/source/LICENSE-AGPL-3.0.txt"
cat > "$REPO/source/README.md" <<'MD'
# Muhasabah — source code

The complete source of the Muhasabah Android app (`Muhasabah-source.zip`), published under the
GNU Affero General Public License v3.0 (see `LICENSE-AGPL-3.0.txt`), because the app includes the
NudeNet body-part detection model, which is AGPL-3.0.

Third-party parts:
- NudeNet 3 "320n" model — notAI-tech, AGPL-3.0 (`assets/nudenet320.bin`, converted to float16)
- nsfwjs MobileNetV2 model — Infinite Red / GantMan, MIT (`assets/nsfw_mv2.bin`)

Fonts are not included (third-party): put the Arabic and Gujarati fonts named in `src/.../Fonts.java` into `assets/fonts/`.

Build: `tools/build.sh` (no Gradle; needs the Android SDK tools named in the script and your own signing key).
The release signing key is not part of this source.
MD

cd "$REPO"
git add -A
git commit -q -m "Muhasabah $NAME (versionCode $CODE)

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_01WdSpAfJqzr3aPZ1nmy48aR"
git push -q
echo "PUBLISHED v$NAME ($CODE)"
