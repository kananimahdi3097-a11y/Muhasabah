#!/usr/bin/env bash
# Builds Muhasabah.apk without Gradle: aapt2 -> javac -> dx -> zipalign -> apksigner.
# Needs: android.jar (API 35), aapt2, dalvik-exchange (dx), zipalign, apksigner, JDK.
set -euo pipefail
cd "$(dirname "$0")/.."
SDK=${SDK:-/home/claude/sdk}
OUT=build
rm -rf "$OUT" && mkdir -p "$OUT/gen" "$OUT/classes"

"$SDK/aapt2" compile --dir res -o "$OUT/res.zip"
MAN=AndroidManifest.xml
NAME=Muhasabah
if [ "${LITE:-0}" = "1" ]; then
  python3 - "$OUT/AndroidManifest.xml" <<'PY'
import re, sys
s = open("AndroidManifest.xml").read()
s = re.sub(r'\s*<service\s+android:name="\.GuardService".*?</service>', '', s, flags=re.S)
s = re.sub(r'android:versionName="([^"]+)"', lambda m: 'android:versionName="%s lite"' % m.group(1), s)
open(sys.argv[1], "w").write(s)
PY
  MAN="$OUT/AndroidManifest.xml"; NAME=Muhasabah_lite
fi
"$SDK/aapt2" link -o "$OUT/base.apk" -I "$SDK/android.jar" --manifest "$MAN" \
  --min-sdk-version 30 --target-sdk-version 35 \
  -A assets --java "$OUT/gen" "$OUT/res.zip" --auto-add-overlay

if ! javac -nowarn -encoding UTF-8 --release 8 -cp "$SDK/android.jar" -d "$OUT/classes" \
  $(find src "$OUT/gen" -name '*.java') > "$OUT/javac.log" 2>&1; then
  grep -v "JAVA_TOOL_OPTIONS" "$OUT/javac.log"; echo "JAVAC FAILED"; exit 1
fi

dalvik-exchange --dex --min-sdk-version=26 --output="$OUT/classes.dex" "$OUT/classes"
(cd "$OUT" && zip -qj base.apk classes.dex)
zipalign -f -p 4 "$OUT/base.apk" "$OUT/aligned.apk"

KS=${KS:-tools/muhasabah-release.jks}
if [ ! -f "$KS" ]; then
  keytool -genkeypair -keystore "$KS" -storepass $KS_PASS -keypass $KS_PASS -alias muhasabah \
    -keyalg RSA -keysize 2048 -validity 20000 -dname "CN=Mahendi Kanani, O=Muhasabah, L=Bhavnagar, C=IN" >/dev/null 2>&1
fi
apksigner sign --ks "$KS" --ks-pass pass:$KS_PASS --ks-key-alias muhasabah --out "out/$NAME.apk" "$OUT/aligned.apk"
apksigner verify "out/$NAME.apk" && echo "BUILD OK: out/$NAME.apk ($(du -h "out/$NAME.apk" | cut -f1))"
