import math
cx, cy = 54.0, 54.0
def sq(r, diamond):
    if diamond:
        p = [(cx, cy - r), (cx + r, cy), (cx, cy + r), (cx - r, cy)]
    else:
        h = r / math.sqrt(2); p = [(cx - h, cy - h), (cx + h, cy - h), (cx + h, cy + h), (cx - h, cy + h)]
    return "M" + " L".join(f"{x:.2f},{y:.2f}" for x, y in p) + " Z"
def circ(x, y, r):
    return f"M{x - r:.2f},{y:.2f} a{r:.2f},{r:.2f} 0 1,0 {2 * r:.2f},0 a{r:.2f},{r:.2f} 0 1,0 {-2 * r:.2f},0 Z"
# crescent: circle A (cx,cy) r=14 minus circle B (cx+5.5, cy-5) r=12.5
ax, ay, ar = cx, cy, 14.0; bx, by, br = cx + 5.5, cy - 5.0, 12.5
d = math.hypot(bx - ax, by - ay); a = (ar * ar - br * br + d * d) / (2 * d); h = math.sqrt(ar * ar - a * a)
mx, my = ax + a * (bx - ax) / d, ay + a * (by - ay) / d
p1 = (mx + h * (by - ay) / d, my - h * (bx - ax) / d); p2 = (mx - h * (by - ay) / d, my + h * (bx - ax) / d)
# go from p1 around big circle (large arc, away from B) to p2, then back along B (small arc)
cres = f"M{p1[0]:.2f},{p1[1]:.2f} A{ar},{ar} 0 1,0 {p2[0]:.2f},{p2[1]:.2f} A{br},{br} 0 0,1 {p1[0]:.2f},{p1[1]:.2f} Z"
def star5(x, y, ro, ri):
    pts = []
    for k in range(10):
        r = ro if k % 2 == 0 else ri; t = math.pi / 5 * k
        pts.append((x + r * math.sin(t), y - r * math.cos(t)))
    return "M" + " L".join(f"{px:.2f},{py:.2f}" for px, py in pts) + " Z"
st = star5(cx + 7, cy - 6.5, 5.2, 2.2)
def sparkle(x, y, r):
    q = r * 0.25
    p = [(x, y - r), (x + q, y - q), (x + r, y), (x + q, y + q), (x, y + r), (x - q, y + q), (x - r, y), (x - q, y - q)]
    return "M" + " L".join(f"{a:.2f},{b:.2f}" for a, b in p) + " Z"
filled = sq(33, False) + " " + sq(33, True)
outline_a, outline_b = sq(40, False), sq(40, True)
GOLD = '<aapt:attr name="android:fillColor"><gradient android:type="linear" android:startX="20" android:startY="20" android:endX="88" android:endY="88" android:startColor="#FFFFECA0" android:centerColor="#FFF0B432" android:endColor="#FFC48414"/></aapt:attr>'
NS = 'xmlns:android="http://schemas.android.com/apk/res/android" xmlns:aapt="http://schemas.android.com/aapt"'
HDR = f'<vector {NS} android:width="108dp" android:height="108dp" android:viewportWidth="108" android:viewportHeight="108">'
G = '<group android:pivotX="54" android:pivotY="54" android:scaleX="0.80" android:scaleY="0.80">'
fg = f'''{HDR}
{G}
<path android:strokeColor="#FFF5CD6E" android:strokeWidth="1.6" android:pathData="{outline_a}"/>
<path android:strokeColor="#FFF5CD6E" android:strokeWidth="1.6" android:pathData="{outline_b}"/>
<path android:fillType="nonZero" android:pathData="{filled}">{GOLD}</path>
<path android:strokeColor="#96784E0A" android:strokeWidth="0.6" android:pathData="{sq(29.5, False)}"/>
<path android:strokeColor="#96784E0A" android:strokeWidth="0.6" android:pathData="{sq(29.5, True)}"/>
<path android:fillColor="#FFFFE48C" android:pathData="{circ(cx, cy, 22.2)}"/>
<path android:pathData="{circ(cx, cy, 21)}"><aapt:attr name="android:fillColor"><gradient android:type="radial" android:centerX="50" android:centerY="48" android:gradientRadius="26" android:startColor="#FF162854" android:endColor="#FF070B1C"/></aapt:attr></path>
<path android:pathData="{cres}"><aapt:attr name="android:fillColor"><gradient android:type="linear" android:startX="40" android:startY="44" android:endX="66" android:endY="70" android:startColor="#FFFFF0B4" android:centerColor="#FFF6C654" android:endColor="#FFD6961C"/></aapt:attr></path>
<path android:fillColor="#FFFFF6D6" android:pathData="{st}"/>
<path android:fillColor="#E6FFF5D2" android:pathData="{sparkle(80, 27, 3.0)}"/>
</group>
</vector>
'''
bg = f'''{HDR}
<path android:pathData="M0,0h108v108h-108z"><aapt:attr name="android:fillColor"><gradient android:type="linear" android:startX="0" android:startY="0" android:endX="108" android:endY="108" android:startColor="#FF105A54" android:centerColor="#FF0B183C" android:endColor="#FF060A1A"/></aapt:attr></path>
<path android:pathData="{circ(56, 52, 30)}"><aapt:attr name="android:fillColor"><gradient android:type="radial" android:centerX="56" android:centerY="52" android:gradientRadius="30" android:startColor="#40F5C451" android:endColor="#00F5C451"/></aapt:attr></path>
</vector>
'''
mono = f'''<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="108dp" android:height="108dp" android:viewportWidth="108" android:viewportHeight="108">
{G}
<path android:fillColor="#FFFFFFFF" android:fillType="evenOdd" android:pathData="{filled} {circ(cx, cy, 21)}"/>
<path android:fillColor="#FFFFFFFF" android:pathData="{cres} {st}"/>
</group>
</vector>
'''
stat = f'''<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="24dp" android:height="24dp" android:viewportWidth="84" android:viewportHeight="84">
<group android:translateX="-12" android:translateY="-12">
<path android:fillColor="#FFFFFFFF" android:fillType="evenOdd" android:pathData="{filled} {circ(cx, cy, 21)}"/>
<path android:fillColor="#FFFFFFFF" android:pathData="{cres} {st}"/>
</group>
</vector>
'''
for name, x in [("ic_fg", fg), ("ic_bg", bg), ("ic_mono", mono), ("ic_stat", stat)]:
    open(f"res/drawable/{name}.xml", "w").write(x)
print("icons written", p1, p2)
